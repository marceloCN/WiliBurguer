<?php

use App\Http\Controllers\CajaController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ConfiguracionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InsumoController;
use App\Http\Controllers\InventarioController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\PedidoController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProductoSucursalController;
use App\Http\Controllers\PromocionController;
use App\Http\Controllers\SucursalController;
use App\Http\Controllers\UnidadMedidaController;
use App\Http\Controllers\UsuarioController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('inicio');

Route::get('/login', [LoginController::class, 'show'])->name('login');
Route::post('/login', [LoginController::class, 'store'])->middleware('guest')->name('login.store');
Route::post('/logout', [LoginController::class, 'destroy'])->name('logout');

Route::middleware('guest')->group(function () {
    Route::get('/forgot-password', [PasswordResetController::class, 'showForgotForm'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
    Route::get('/reset-password/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [PasswordResetController::class, 'reset'])->name('password.store');
});

Route::middleware('auth')->group(function () {
    // el dashboard para cualquier usuario
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // ==========================================================================
    // MÓDULOS DEL DASHBOARD (todos bajo /dashboard y con nombre dashboard.*)
    // ==========================================================================
    Route::prefix('dashboard')->name('dashboard.')->group(function () {

        // ======================================================================
        // MI PERFIL (datos del empleado y de la cuenta)
        // ======================================================================
        Route::prefix('mi-perfil')->name('perfil.')->group(function () {
            Route::get('/', [PerfilController::class, 'index'])->name('index');
            Route::post('/', [PerfilController::class, 'update'])->name('update');
        });

        // ======================================================================
        // CONFIGURACIÓN DEL SITIO (permiso 50 en el rol ADMINISTRADOR;
        // datos en configuracion_sistema)
        // ======================================================================
        Route::prefix('configuracion')->name('configuracion.')->middleware('permiso:50')->group(function () {
            Route::get('/', [ConfiguracionController::class, 'index'])->name('index');
            Route::post('/', [ConfiguracionController::class, 'update'])->name('update');
        });

        // ======================================================================
        // EMPLEADOS (cuentas, roles, estado, contraseña)
        // ADMINISTRADOR → todos. GERENTE → solo empleados de su sucursal (cajero/mesero).
        // ======================================================================
        Route::prefix('usuarios')->name('usuarios.')->group(function () {
            Route::get('/', [UsuarioController::class, 'index'])->middleware('permiso:102')->name('index');
            Route::post('/', [UsuarioController::class, 'store'])->middleware('permiso:100')->name('store');
            Route::post('/{cuenta}/estado', [UsuarioController::class, 'alternarEstado'])->middleware('permiso:105')->name('estado');
            Route::post('/{cuenta}/actualizar', [UsuarioController::class, 'actualizar'])->middleware('permiso:101')->name('actualizar');
            Route::post('/{cuenta}/rol', [UsuarioController::class, 'cambiarRol'])->middleware('permiso:101')->name('rol');
            Route::post('/{cuenta}/password', [UsuarioController::class, 'reiniciarPassword'])->middleware('permiso:106')->name('password');
        });

        // ======================================================================
        // SUCURSALES, HORARIOS, MESAS Y CAJAS
        // ADMINISTRADOR → todas. GERENTE → solo su sucursal (y sus horarios).
        // ======================================================================
        Route::prefix('sucursales')->name('sucursales.')->group(function () {
            Route::get('/', [SucursalController::class, 'index'])->middleware('permiso:202,201')->name('index');
            Route::get('/crear', [SucursalController::class, 'create'])->middleware('permiso:200')->name('crear');
            Route::post('/', [SucursalController::class, 'store'])->middleware('permiso:200')->name('store');
            Route::get('/{sucursal}/editar', [SucursalController::class, 'edit'])->middleware('permiso:201')->name('editar');
            Route::post('/{sucursal}', [SucursalController::class, 'update'])->middleware('permiso:201')->name('update');
            Route::post('/{sucursal}/gerente', [SucursalController::class, 'asignarGerente'])->middleware('permiso:204')->name('gerente');

            Route::post('/{sucursal}/horarios', [SucursalController::class, 'horarioStore'])->middleware('permiso:220')->name('horario.store');
            Route::post('/{sucursal}/horarios/{horario}', [SucursalController::class, 'horarioUpdate'])->middleware('permiso:221')->name('horario.update');
            Route::post('/{sucursal}/horarios/{horario}/baja', [SucursalController::class, 'horarioBaja'])->middleware('permiso:225')->name('horario.baja');

            Route::post('/{sucursal}/cajas', [SucursalController::class, 'cajaStore'])->middleware('permiso:400')->name('caja.store');
            Route::post('/{sucursal}/cajas/{caja}', [SucursalController::class, 'cajaUpdate'])->middleware('permiso:401')->name('caja.update');
            Route::post('/{sucursal}/cajas/{caja}/baja', [SucursalController::class, 'cajaBaja'])->middleware('permiso:405')->name('caja.baja');

            Route::post('/{sucursal}/mesas', [SucursalController::class, 'mesaStore'])->middleware('permiso:210')->name('mesa.store');
            Route::post('/{sucursal}/mesas/{mesa}', [SucursalController::class, 'mesaUpdate'])->middleware('permiso:211')->name('mesa.update');
            Route::post('/{sucursal}/mesas/{mesa}/baja', [SucursalController::class, 'mesaBaja'])->middleware('permiso:215')->name('mesa.baja');
        });

        // ======================================================================
        // MENÚ DE PRODUCTOS (categorías + productos en una sola pantalla; solo ADMINISTRADOR).
        // El middleware 'admin' ya restringe el grupo completo: un no-administrador
        // jamás llega aquí (302/312 que comparten MESERO/CAJERO son solo para su
        // sucursal en el módulo productos-sucursal), y el ADMINISTRADOR tiene todos
        // los permisos, por eso no hace falta repetir permiso:XXX por ruta.
        // ======================================================================
        Route::prefix('menu')->name('menu.')->middleware('admin')->group(function () {
            Route::get('/', [MenuController::class, 'index'])->name('index');
            Route::get('/buscar', [MenuController::class, 'buscar'])->name('buscar');
            Route::post('/categorias', [CategoriaController::class, 'store'])->name('categoria.store');
            Route::post('/categorias/{categoria}', [CategoriaController::class, 'update'])->name('categoria.update');
            Route::post('/categorias/{categoria}/baja', [CategoriaController::class, 'baja'])->name('categoria.baja');
            Route::post('/categorias/{categoria}/reactivar', [CategoriaController::class, 'reactivar'])->name('categoria.reactivar');
            Route::post('/productos', [ProductoController::class, 'store'])->name('producto.store');
            Route::post('/productos/{producto}', [ProductoController::class, 'update'])->name('producto.update');
            Route::post('/productos/{producto}/baja', [ProductoController::class, 'baja'])->name('producto.baja');
            Route::post('/productos/{producto}/reactivar', [ProductoController::class, 'reactivar'])->name('producto.reactivar');
        });

        // ======================================================================
        // INSUMOS Y RECETAS (unidades de medida + insumos + detalle de receta)
        // ADMINISTRADOR y GERENTE (permisos 330-345)
        // ======================================================================
        Route::prefix('insumos')->name('insumos.')->group(function () {
            Route::get('/', [InsumoController::class, 'index'])
                ->middleware('permiso:330,331,335,336,337,338,340,341,345')->name('index');

            Route::post('/unidades', [UnidadMedidaController::class, 'store'])->middleware('permiso:330')->name('unidad.store');
            Route::post('/unidades/{unidad}', [UnidadMedidaController::class, 'update'])->middleware('permiso:331')->name('unidad.update');
            Route::post('/unidades/{unidad}/baja', [UnidadMedidaController::class, 'baja'])->middleware('permiso:335')->name('unidad.baja');
            Route::post('/unidades/{unidad}/reactivar', [UnidadMedidaController::class, 'reactivar'])->middleware('permiso:330')->name('unidad.reactivar');

            Route::post('/recetas', [InsumoController::class, 'recetaStore'])->middleware('permiso:340')->name('receta.store');
            Route::post('/recetas/{detalle}', [InsumoController::class, 'recetaUpdate'])->middleware('permiso:341')->name('receta.update');
            Route::post('/recetas/{detalle}/baja', [InsumoController::class, 'recetaBaja'])->middleware('permiso:345')->name('receta.baja');

            Route::post('/', [InsumoController::class, 'store'])->middleware('permiso:336')->name('store');
            Route::post('/{insumo}', [InsumoController::class, 'update'])->middleware('permiso:337')->name('update');
            Route::post('/{insumo}/baja', [InsumoController::class, 'baja'])->middleware('permiso:338')->name('baja');
            Route::post('/{insumo}/reactivar', [InsumoController::class, 'reactivar'])->middleware('permiso:336')->name('reactivar');
        });

        // ======================================================================
        // INVENTARIO Y MOVIMIENTOS DE INVENTARIO (permisos 346 y 347)
        // ADMINISTRADOR → cualquier sucursal. GERENTE → sucursales que gerencia.
        // CAJERO → su sucursal (idsucursal).
        // ======================================================================
        Route::prefix('inventario')->name('inventario.')->group(function () {
            Route::get('/', [InventarioController::class, 'index'])->middleware('permiso:347')->name('index');
            Route::get('/reporte', [InventarioController::class, 'reporte'])->middleware('permiso:347')->name('reporte');
            Route::post('/movimientos', [InventarioController::class, 'store'])->middleware('permiso:346')->name('movimiento.store');
            Route::post('/{inventario}/minimo', [InventarioController::class, 'actualizarMinimo'])->middleware('permiso:348')->name('minimo');
        });

        // ======================================================================
        // PRODUCTOS POR SUCURSAL (permisos 316-320)
        // ADMINISTRADOR y GERENTE → definen los productos que existen en la sucursal
        // (precio y disponibilidad), editan precios y ven el historial.
        // CAJERO → lista y modifica la disponibilidad. MESERO no accede: los
        // productos de su sucursal los ve en la ventana de Generar pedidos.
        // ======================================================================
        Route::prefix('productos-sucursal')->name('productos-sucursal.')->group(function () {
            Route::get('/', [ProductoSucursalController::class, 'index'])->middleware('permiso:317')->name('index');
            Route::get('/buscar', [ProductoSucursalController::class, 'buscar'])->middleware('permiso:317')->name('buscar');

            Route::post('/registrar-precio', [ProductoSucursalController::class, 'registrar'])->middleware('permiso:316')->name('registrar');
            Route::post('/{sucursalProducto}/precio', [ProductoSucursalController::class, 'actualizarPrecio'])->middleware('permiso:318')->name('precio');
            Route::post('/{sucursalProducto}/disponibilidad', [ProductoSucursalController::class, 'disponibilidad'])->middleware('permiso:319')->name('disponibilidad');
            Route::get('/{sucursalProducto}/historial', [ProductoSucursalController::class, 'historial'])->middleware('permiso:320')->name('historial');
        });

        // ======================================================================
        // PROMOCIONES (permisos 350-355)
        // ADMINISTRADOR y GERENTE → crean, editan y dan de baja promociones de
        // una sucursal (descuento % o monto fijo sobre uno o más productos).
        // CAJERO → solo lista las promociones de su sucursal (352). MESERO no
        // accede: las ve como categoría de Generar pedidos con la caja abierta.
        // ======================================================================
        Route::prefix('promociones')->name('promociones.')->group(function () {
            Route::get('/', [PromocionController::class, 'index'])->middleware('permiso:352')->name('index');
            Route::post('/', [PromocionController::class, 'store'])->middleware('permiso:350')->name('store');
            Route::post('/{promocion}', [PromocionController::class, 'update'])->middleware('permiso:351')->name('update');
            Route::post('/{promocion}/baja', [PromocionController::class, 'baja'])->middleware('permiso:355')->name('baja');
        });

        // ======================================================================
        // GENERAR PEDIDOS / VENTANA DE ATENCIÓN (permisos 500-506 y 440)
        // CAJERO, MESERO y GERENTE atienden pedidos directos (mesa o para llevar)
        // con precio ajustable por cantidad y hora de recogida. El cobro pasa por
        // una pasarela de pago simulada según el método elegido (EFECTIVO, TARJETA,
        // BANCO) y solo quien tenga el permiso 440 (cajero/gerente) puede cobrar;
        // el mesero ejecuta/entrega los pedidos.
        // ======================================================================
        Route::prefix('generar-pedidos')->name('generar-pedidos.')->group(function () {
            Route::get('/', [PedidoController::class, 'index'])->middleware('permiso:500,501,502,505,506')->name('index');
            Route::post('/', [PedidoController::class, 'store'])->middleware('permiso:500')->name('store');
            Route::post('/{pedido}/editar', [PedidoController::class, 'editar'])->middleware('permiso:501,506')->name('editar');
            Route::post('/{pedido}/ejecutar', [PedidoController::class, 'ejecutar'])->middleware('permiso:501')->name('ejecutar');
            Route::post('/{pedido}/anular', [PedidoController::class, 'anular'])->middleware('permiso:505')->name('anular');
            Route::get('/{pedido}/detalle', [PedidoController::class, 'detalle'])->middleware('permiso:502')->name('detalle');
            Route::post('/pagar', [PedidoController::class, 'pagar'])->middleware('permiso:440')->name('pagar');
        });

        // ======================================================================
        // CAJA Y JORNADAS (aperturas 410-415, movimientos 420-425, cierres 430-437)
        // ADMINISTRADOR y GERENTE → todo. CAJERO → abre, edita, registra
        // movimientos y cierra su sucursal (sin 415). MESERO no accede (403).
        // La apertura crea automáticamente el cierre provisional vía trigger;
        // ese trigger también recalcula el cierre al editarse o cerrarse.
        // ======================================================================
        Route::prefix('caja')->name('caja.')->group(function () {
            Route::get('/', [CajaController::class, 'index'])
                ->middleware('permiso:410,411,412,415,420,421,422,425,430,436,437')->name('index');
            Route::post('/aperturas', [CajaController::class, 'abrir'])->middleware('permiso:410')->name('apertura.store');
            Route::post('/aperturas/{apertura}', [CajaController::class, 'editarApertura'])->middleware('permiso:411')->name('apertura.update');
            Route::post('/aperturas/{apertura}/baja', [CajaController::class, 'bajaApertura'])->middleware('permiso:415')->name('apertura.baja');

            Route::post('/aperturas/{apertura}/movimientos', [CajaController::class, 'movimientoStore'])->middleware('permiso:420')->name('movimiento.store');
            Route::post('/movimientos/{movimiento}', [CajaController::class, 'movimientoUpdate'])->middleware('permiso:421')->name('movimiento.update');
            Route::post('/movimientos/{movimiento}/baja', [CajaController::class, 'movimientoBaja'])->middleware('permiso:425')->name('movimiento.baja');

            Route::post('/aperturas/{apertura}/cerrar', [CajaController::class, 'cerrar'])->middleware('permiso:430')->name('cerrar');
            Route::get('/cierres/exportar', [CajaController::class, 'historialPdf'])->middleware('permiso:437')->name('historial.pdf');
            Route::get('/cierres', [CajaController::class, 'historial'])->middleware('permiso:437')->name('historial');
            Route::get('/cierres/{cierre}/pdf', [CajaController::class, 'cierrePdf'])->middleware('permiso:436')->name('cierre.pdf');
            Route::get('/cierres/{cierre}', [CajaController::class, 'detalleCierre'])->middleware('permiso:436')->name('cierre.detalle');
        });
    });
});
