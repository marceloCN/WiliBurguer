-- Procedimiento almacenado: registrar_accion
-- Registra una acción en bitacoraaccion y es reutilizable por cualquier
-- proceso/controlador. El código de permiso se resuelve internamente: busca la
-- fila activa en "permiso" por su código y, si no existe, cae a un permiso
-- activo cualquiera (mismo criterio que el fallback del controlador).
-- p_resultado indica si la acción se realizó (p. ej. 'EXITOSO') o no ('FALLIDO').
--
-- Nota: SOLO PostgreSQL (CREATE PROCEDURE, PostgreSQL >= 11). No debe usarse
-- como migración porque las pruebas corren sobre SQLite (:memory:).
-- Se eliminan las firmas previas porque CREATE OR REPLACE no cambia la lista
-- de parámetros (crearía una sobrecarga).

DROP PROCEDURE IF EXISTS registrar_accion(INTEGER, VARCHAR, VARCHAR, BIGINT, VARCHAR, VARCHAR, VARCHAR);
DROP PROCEDURE IF EXISTS registrar_accion(INTEGER, VARCHAR, VARCHAR, BIGINT, VARCHAR, VARCHAR, VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE registrar_accion(
    p_id_empleado INTEGER,
    p_accion VARCHAR(10),
    p_tabla_afectada VARCHAR(100),
    p_id_registro_afectado BIGINT,
    p_codigo_permiso VARCHAR(100),
    p_resultado VARCHAR(255),
    p_equipo VARCHAR(150),
    p_ip VARCHAR(45)
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_id_permiso INTEGER;
BEGIN
    v_id_permiso := COALESCE(
        (SELECT id FROM permiso WHERE codigo = p_codigo_permiso AND estado = TRUE),
        (SELECT id FROM permiso WHERE estado = TRUE ORDER BY id LIMIT 1),
        1
    );

    INSERT INTO bitacoraaccion (idempleado, idpermiso, accion, tablaafectada, idregistroafectado, equipo, ip, resultado)
    VALUES (
        p_id_empleado,
        v_id_permiso,
        p_accion,
        p_tabla_afectada,
        p_id_registro_afectado,
        p_equipo,
        p_ip,
        COALESCE(p_resultado, 'EXITOSO')
    );
END;
$$;