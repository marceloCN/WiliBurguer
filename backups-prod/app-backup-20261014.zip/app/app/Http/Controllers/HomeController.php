<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\ConfiguracionSistema;
use App\Models\Promocion;
use App\Models\Sucursal;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function index(): View
    {
        // obtener la configuracion del sistema
        $configuracion = ConfiguracionSistema::where('estado', true)
            ->pluck('valor', 'clave');

        // obtener el conjunto de imagenes_carrusel
        $sliders = collect(json_decode($configuracion->get('IMAGENES_CARRUSEL', '[]'), true))
            ->sortBy('orden')
            ->values();

        // relacion que me obtiene sus horarios de atencion como los productos con sus categorias por sucursal
        $sucursales = Sucursal::with([
            'horarios.diaAtencion',
            'productosSucursal.producto.categoria',
        ])->where('estado', true)->orderBy('nombre')->get();

        // obtener las categorias activas ordenadas por nombre y para cada cat obtener cantidad de productos
        $categorias = Categoria::withCount(['productos' => function ($q) {
            $q->where('estado', true);
        }])->where('estado', true)->orderBy('nombre')->get();

        // Baja automática: las promociones vencidas se desactivan solas.
        Promocion::marcarVencidas();

        // obtiene la selacion de todas las promociones activas en funcion al producto y sucursal
        $promocionesActivas = Promocion::with([
            'sucursalesProducto.producto',
            'sucursalesProducto.sucursal',
        ])->where('activo', true)
            ->where('fechainicio', '<=', now())
            ->where('fechafin', '>=', now())
            ->orderBy('fechafin')
            ->get();

        $promocionesPorSucursal = collect();
        foreach ($promocionesActivas as $promo) {
            $sucursalesPromo = $promo->sucursalesProducto
                ->map(fn ($sp) => $sp->sucursal)
                ->filter()
                ->unique('id');

            foreach ($sucursalesPromo as $sucursal) {
                $promocionesPorSucursal[$sucursal->id] = $promocionesPorSucursal->get($sucursal->id, collect());
                $promocionesPorSucursal[$sucursal->id]->push($promo);
            }
        }
        $promocionesPorSucursal->transform(fn ($items, $id) => $items->unique('id')->values());

        // Si no hay promociones activas en ninguna sucursal, se oculta el slide
        // promocional del carrusel (identificado por su botón que apunta a #promociones).
        if ($promocionesActivas->isEmpty()) {
            $sliders = $sliders->reject(fn ($slider) => data_get($slider, 'boton_url') === '#promociones')->values();
        }

        return view('inicio', compact(
            'configuracion',
            'sliders',
            'sucursales',
            'categorias',
            'promocionesActivas',
            'promocionesPorSucursal'
        ));
    }
}
