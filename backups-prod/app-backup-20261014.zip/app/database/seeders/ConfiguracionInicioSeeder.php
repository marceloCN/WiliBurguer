<?php

namespace Database\Seeders;

use App\Models\ConfiguracionSistema;
use Illuminate\Database\Seeder;

class ConfiguracionInicioSeeder extends Seeder
{
    public function run(): void
    {
        $configuraciones = [
            ['SITIO_NOMBRE', 'Burger Willy and Grill', 'Nombre comercial del sistema/negocio'],
            ['SITIO_ESLOGAN', 'Sabores que se quedan', 'Eslogan que aparece en el inicio'],
            ['SITIO_TELEFONO', '987 654 321', 'Teléfono de contacto principal'],
            ['SITIO_EMAIL', 'contacto@burguerwilly.com', 'Correo de contacto'],
            ['SITIO_DIRECCION', 'Av. Principal 123, Lima', 'Dirección principal'],
            ['SITIO_HORARIO', 'Lun - Dom: 12:00 p.m. - 11:00 p.m.', 'Horario de atención general'],
            ['SITIO_HABILITAR_CARRUSEL', '1', 'Muestra el carrusel de imágenes en el inicio'],
            ['SITIO_HABILITAR_MENU', '1', 'Muestra la sección de menú/ productos'],
            ['SITIO_HABILITAR_PROMOCIONES', '1', 'Muestra la sección de promociones'],
            ['SITIO_HABILITAR_SUCURSALES', '1', 'Muestra la sección de sucursales'],
            ['IMAGENES_CARRUSEL', json_encode([
                [
                    'titulo' => 'Las mejores hamburguesas a la parrilla',
                    'subtitulo' => 'Ingredientes frescos, fuego real y el mejor sabor de la ciudad.',
                    'imagen' => 'https://source.unsplash.com/1600x900/?hamburger,grill',
                    'boton_texto' => 'Ver menú',
                    'boton_url' => '#menu',
                    'orden' => 1,
                ],
                [
                    'titulo' => 'Promociones que se quedan',
                    'subtitulo' => 'Aprovecha nuestros descuentos exclusivos por sucursal.',
                    'imagen' => 'https://source.unsplash.com/1600x900/?restaurant,burger',
                    'boton_texto' => 'Promociones',
                    'boton_url' => '#promociones',
                    'orden' => 2,
                ],
                [
                    'titulo' => 'Encuéntranos siempre cerca',
                    'subtitulo' => 'Visita nuestras sucursales y conoce horarios, mapas y más.',
                    'imagen' => 'https://source.unsplash.com/1600x900/?grill,barbecue',
                    'boton_texto' => 'Sucursales',
                    'boton_url' => '#sucursales',
                    'orden' => 3,
                ],
            ], JSON_UNESCAPED_UNICODE), 'Imágenes del carrusel del inicio (JSON)'],
        ];

        foreach ($configuraciones as [$clave, $valor, $descripcion]) {
            ConfiguracionSistema::updateOrCreate(
                ['clave' => $clave],
                ['valor' => $valor, 'descripcion' => $descripcion, 'estado' => true]
            );
        }

        $this->command->info('Configuración inicial del sistema creada.');
    }
}
