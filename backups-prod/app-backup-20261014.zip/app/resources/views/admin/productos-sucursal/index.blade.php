@extends('layouts.app')

@section('title', 'Productos por sucursal · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Productos por sucursal 🧾</h1>
                <p class="text-muted mb-0">Define qué productos existen en cada sucursal, su precio y su disponibilidad.</p>
            </div>
        </div>

        @include('partials.mensajes')

        <p class="small text-muted mb-3">
            Esta página define qué productos del catálogo existen en cada <strong>sucursal</strong>, a qué <strong>precio</strong> se venden
            y si están <strong>disponibles</strong>. Elige la sucursal (arriba o a la izquierda) y una categoría: cada tarjeta muestra su estado
            en esa sucursal. «+ Registrar en sucursal» agrega el producto con su precio y disponibilidad, «Precio» lo actualiza
            (el cambio queda en el historial), «Historial» revisa los cambios de precio y «Marcar agotado/disponible» alterna la
            disponibilidad. Los <strong>meseros y cajeros</strong> solo listan; requieren una caja abierta en la sucursal para operar.
        </p>

        <div class="row g-4">
            {{-- ================= Columna izquierda: SUCURSAL y CATEGORÍAS ================= --}}
            <div class="col-12 col-lg-4">
                @if ($sucursales->count() > 1)
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursal</span>
                        <span class="badge text-bg-dark">{{ $sucursales->count() }}</span>
                    </div>
                    <div class="list-group">
                        @foreach ($sucursales as $sucursal)
                            <a href="{{ route('dashboard.productos-sucursal.index', ['idsucursal' => $sucursal->id]) }}"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                      {{ $sucursalActual->id === $sucursal->id ? 'active' : '' }}">
                                <span class="fw-semibold">{{ $sucursal->nombre }}</span>
                                @if (!$sucursal->estado)
                                    <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                @endif
                            </a>
                        @endforeach
                    </div>
                </div>
                @endif

                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Categorías</span>
                        <span class="badge text-bg-dark">{{ $categorias->count() }}</span>
                    </div>
                    <div class="list-group">
                        @forelse ($categorias as $categoria)
                            <a href="{{ route('dashboard.productos-sucursal.index', ['idsucursal' => $sucursalActual->id, 'idcategoria' => $categoria->id]) }}"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center gap-2
                                      {{ $categoriaActual?->id === $categoria->id ? 'active' : '' }}">
                                <span class="d-flex align-items-center gap-2 text-truncate">
                                    <span class="fw-semibold text-truncate">{{ $categoria->nombre }}</span>
                                    @if (!$categoria->estado)
                                        <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                    @endif
                                </span>
                                <span class="badge rounded-pill {{ $categoriaActual?->id === $categoria->id ? 'text-bg-light' : 'text-bg-brand' }}">
                                    {{ $categoria->productos_count }} prod.
                                </span>
                            </a>
                        @empty
                            <div class="list-group-item text-center text-muted py-4">
                                No hay categorías registradas.
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>

            {{-- ================= Columna derecha: PRODUCTOS ================= --}}
            <div class="col-12 col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                    <span class="badge text-bg-brand">{{ $sucursalActual->nombre }}</span>
                    @if ($sucursales->count() === 1)
                        <span class="text-muted small">Productos de tu sucursal</span>
                    @endif
                </div>

                @if ($operacionBloqueada)
                    <div class="alert alert-warning d-flex align-items-start gap-2">
                        <span>🔒</span>
                        <div>
                            <strong>No hay una apertura de caja abierta en {{ $sucursalActual->nombre }}.</strong>
                            Puedes ver el listado, pero para atender a un cliente de una mesa o llevar, y para modificar
                            la disponibilidad, es necesario que un cajero haya abierto la caja en esta sucursal.
                        </div>
                    </div>
                @endif

                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span class="fw-bold">
                            @if ($categoriaActual)
                                Productos · {{ $categoriaActual->nombre }}
                            @else
                                Productos
                            @endif
                        </span>
                    </div>
                    <div class="card-body">
                        @if (! $categoriaActual)
                            <div class="text-center text-muted py-4">
                                No hay categorías registradas.
                            </div>
                        @else
                            <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                                <div class="input-group" style="max-width: 360px;">
                                    <span class="input-group-text bg-white">🔍</span>
                                    <input type="search" id="buscadorProductos" class="form-control"
                                           placeholder="Buscar producto por nombre…"
                                           aria-label="Buscar producto por nombre" autocomplete="off">
                                </div>
                                <span class="small text-muted" id="contadorProductos"></span>
                            </div>

                            <div id="contenedorProductos">
                                @include('admin.productos-sucursal._productos', ['productos' => $productos])
                            </div>
                        @endif
                    </div>

                    @if ($productos instanceof \Illuminate\Pagination\LengthAwarePaginator && $productos->hasPages())
                        <div class="card-footer bg-light-subtle border-top py-3" id="piePaginacion">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-muted">
                                <span>
                                    Mostrando {{ $productos->firstItem() }}–{{ $productos->lastItem() }}
                                    de {{ $productos->total() }} productos
                                </span>
                                <nav aria-label="Paginación de productos">
                                    {{ $productos->onEachSide(1)->links() }}
                                </nav>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- ================= Modal registrar producto en sucursal (permiso 316) ================= --}}
    @if ($puedeRegistrar)
    <div class="modal fade" id="registrarSucursalProductoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form method="POST" action="{{ route('dashboard.productos-sucursal.registrar') }}" class="modal-content border-0 shadow">
                @csrf
                <input type="hidden" name="idsucursal" value="{{ $sucursalActual->id }}">
                <input type="hidden" name="idproducto" id="regSPIdproducto">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Registrar en {{ $sucursalActual->nombre }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label class="form-label small text-muted">Imagen del producto</label>
                            <div class="foto-preview-wrap">
                                <span class="foto-preview-placeholder" id="regSPPreviewPlaceholder">🖼️ Vista previa</span>
                                <img id="regSPVistaPrevia" class="foto-preview-img" alt="Vista previa del producto">
                            </div>
                        </div>
                        <div class="col-12 col-md-8">
                            <label class="form-label">Producto *</label>
                            <input type="text" id="regSPNombre" class="form-control fw-semibold" readonly disabled>
                            <div class="form-text mb-3">Este producto se agregará al menú de {{ $sucursalActual->nombre }}.</div>

                            <label class="form-label">Precio de venta (S/) *</label>
                            <input type="number" name="precioproducto" id="regSPPrecio" class="form-control form-control-lg"
                                   min="0" step="0.01" max="99999999.99" required placeholder="0.00">
                            <div class="form-text mb-3">El precio que se mostrará a los clientes de esta sucursal.</div>

                            <label class="form-label">Disponibilidad</label>
                            <div class="btn-group w-100" role="group" aria-label="Disponibilidad del producto">
                                <input type="radio" class="btn-check" name="disponibilidad" value="1"
                                       id="regSPDisponible" checked>
                                <label class="btn btn-outline-success" for="regSPDisponible">
                                    ✅ Disponible
                                </label>
                                <input type="radio" class="btn-check" name="disponibilidad" value="0"
                                       id="regSPAgotado">
                                <label class="btn btn-outline-danger" for="regSPAgotado">
                                    ❌ Agotado
                                </label>
                            </div>
                            <div class="form-text">«Disponible» se ofrece a los clientes; «Agotado» se oculta del menú público.</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Registrar en la sucursal</button>
                </div>
            </form>
        </div>
    </div>
    @endif

    {{-- ================= Modal editar precio (permiso 318) ================= --}}
    @if ($puedeEditarPrecio)
    <div class="modal fade" id="editarPrecioSPModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-editar-precio-sp" class="modal-content border-0 shadow">
                @csrf
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar precio</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label">Producto</label>
                    <input type="text" id="editarPrecioSPNombre" class="form-control" readonly disabled>
                    <div class="row g-3 mt-1">
                        <div class="col-md-6">
                            <label class="form-label">Precio actual (S/)</label>
                            <input type="text" id="editarPrecioSPAnterior" class="form-control" readonly disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nuevo precio (S/) *</label>
                            <input type="number" name="precioproducto" id="editarPrecioSPNuevo" class="form-control"
                                   min="0" step="0.01" max="99999999.99" required placeholder="0.00">
                        </div>
                    </div>
                    <div class="form-text mt-2">El cambio quedará registrado en el historial de precios.</div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar precio</button>
                </div>
            </form>
        </div>
    </div>
    @endif

    {{-- ================= Modal historial de precios (permiso 320) ================= --}}
    @if ($puedeHistorial)
    <div class="modal fade" id="historialSPModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Historial de precios</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body" id="historialSPCuerpo">
                    <div class="text-center text-muted py-4">Cargando…</div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    @endif
@endsection

@push('scripts')
    <script>
        @if ($puedeRegistrar)
        const modalRegistrarSP = document.getElementById('registrarSucursalProductoModal');
        if (modalRegistrarSP) {
            modalRegistrarSP.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('regSPIdproducto').value = boton.dataset.id;
                document.getElementById('regSPNombre').value = boton.dataset.nombre;
                document.getElementById('regSPDisponible').checked = true;

                const preview = document.getElementById('regSPVistaPrevia');
                const placeholder = document.getElementById('regSPPreviewPlaceholder');
                if (boton.dataset.urlFoto) {
                    preview.src = boton.dataset.urlFoto;
                    preview.style.display = 'block';
                    placeholder.style.display = 'none';
                } else {
                    preview.removeAttribute('src');
                    preview.style.display = 'none';
                    placeholder.style.display = '';
                }
            });
        }
        @endif

        @if ($puedeEditarPrecio)
        const modalPrecioSP = document.getElementById('editarPrecioSPModal');
        if (modalPrecioSP) {
            modalPrecioSP.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('editarPrecioSPNombre').value = boton.dataset.nombre;
                document.getElementById('editarPrecioSPAnterior').value = boton.dataset.precio;
                document.getElementById('editarPrecioSPNuevo').value = boton.dataset.precio;
                document.getElementById('form-editar-precio-sp').setAttribute(
                    'action',
                    '{{ route('dashboard.productos-sucursal.precio', ['sucursalProducto' => '__ID__']) }}'.replace('__ID__', boton.dataset.id)
                );
            });
        }
        @endif

        @if ($puedeHistorial)
        document.addEventListener('click', function (evento) {
            const boton = evento.target.closest('[data-historial-url]');
            if (!boton) return;
            if (boton.dataset.historialUrl) {
                document.getElementById('historialSPCuerpo').innerHTML =
                    '<div class="text-center text-muted py-4">Cargando…</div>';
                fetch(boton.dataset.historialUrl)
                    .then(function (respuesta) {
                        if (!respuesta.ok) throw new Error('Error de red');
                        return respuesta.text();
                    })
                    .then(function (html) {
                        document.getElementById('historialSPCuerpo').innerHTML = html;
                    })
                    .catch(function () {
                        document.getElementById('historialSPCuerpo').innerHTML =
                            '<div class="text-center text-danger py-4">No se pudo cargar el historial.</div>';
                    });
            }
        });
        @endif

        (function () {
            const buscador = document.getElementById('buscadorProductos');
            if (!buscador) return;

            const contenedor = document.getElementById('contenedorProductos');
            const contador = document.getElementById('contadorProductos');
            const piePaginacion = document.getElementById('piePaginacion');
            const htmlInicial = contenedor.innerHTML;
            const urlBuscar = '{{ route('dashboard.productos-sucursal.buscar') }}';
            const idCategoria = {{ $categoriaActual?->id ?? 0 }};
            const idSucursal = {{ $sucursalActual->id }};
            let temporizador = null;
            let abortador = null;

            function restaurarVista(limpiarCampo = true) {
                contenedor.innerHTML = htmlInicial;
                contador.textContent = '';
                if (piePaginacion) piePaginacion.style.display = '';
                if (limpiarCampo) buscador.value = '';
            }

            buscador.addEventListener('input', function () {
                clearTimeout(temporizador);
                const q = buscador.value.trim();

                if (q === '') {
                    restaurarVista(false);
                    return;
                }

                temporizador = setTimeout(function () {
                    if (abortador) abortador.abort();
                    abortador = new AbortController();

                    const url = urlBuscar + '?idsucursal=' + encodeURIComponent(idSucursal)
                        + '&idcategoria=' + encodeURIComponent(idCategoria)
                        + '&q=' + encodeURIComponent(q);

                    fetch(url, { signal: abortador.signal })
                        .then(function (respuesta) {
                            if (!respuesta.ok) throw new Error('Error de red');
                            return respuesta.json();
                        })
                        .then(function (datos) {
                            contenedor.innerHTML = datos.html;
                            contador.textContent = datos.total + ' resultado' + (datos.total === 1 ? '' : 's');
                            if (piePaginacion) piePaginacion.style.display = 'none';
                        })
                        .catch(function (error) {
                            if (error.name === 'AbortError') return;
                            contador.textContent = 'No se pudo realizar la búsqueda.';
                        });
                }, 250);
            });
        })();
    </script>
@endpush

@push('styles')
    <style>
        .foto-preview-wrap {
            border: 2px dashed #cfd4da;
            border-radius: .9rem;
            background: #f8f9fa;
            min-height: 220px;
            max-height: 320px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            padding: .75rem;
        }

        .foto-preview-placeholder {
            color: #9aa4af;
            font-size: .95rem;
            text-align: center;
        }

        .foto-preview-img {
            max-width: 100%;
            max-height: 290px;
            object-fit: contain;
            border-radius: .5rem;
            box-shadow: 0 8px 24px rgba(0, 0, 0, .14);
            display: none;
        }

        .tarjeta-producto-menu {
            transition: transform .15s ease, box-shadow .15s ease;
        }

        .tarjeta-producto-menu:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(0, 0, 0, .1);
        }
    </style>
@endpush