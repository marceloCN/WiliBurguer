@extends('layouts.app')

@section('title', 'Panel de administración · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">
                    Panel de administración <span class="badge text-bg-brand ms-1">{{ $rol->claverol }}</span>
                </h1>
                <p class="text-muted mb-0">👤 {{ $empleado->nombre }} · Administra el restaurante desde estos módulos.</p>
            </div>
            @if (isset($permisos['pedidos']))
                <a href="{{ route('dashboard.generar-pedidos.index') }}" class="btn btn-brand">
                    🧾 Ir a Generar pedidos
                </a>
            @endif
        </div>

        @include('partials.mensajes')

        @if ($sinSucursal)
            <div class="alert alert-warning shadow-sm">
                ⏳ Aún no tienes una sucursal asignada. Contacta al administrador para que te asigne una y
                puedas comenzar a operar los módulos que requieren sucursal.
            </div>
        @endif

        <div class="row g-3">
            @forelse ($permisos as $codigo => $modulo)
                @if ($modulo['activo'] && $modulo['ruta'])
                    <div class="col-12 col-sm-6 col-lg-4 col-xxl-3">
                        <a href="{{ route($modulo['ruta'], $modulo['parametros'] ?? []) }}"
                           class="card tarjeta-producto h-100 text-decoration-none">
                            <div class="card-body">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="badge {{ $modulo['color'] }} p-3 rounded-3 fs-4">{{ $modulo['icono'] }}</span>
                                    <div class="min-w-0">
                                        <h2 class="h6 fw-bold mb-0 text-dark">{{ $modulo['titulo'] }}</h2>
                                    </div>
                                </div>
                                <p class="text-muted small mt-2 mb-0">{{ $modulo['descripcion'] }}</p>
                            </div>
                        </a>
                    </div>
                @endif
            @empty
                <div class="col-12">
                    <div class="alert alert-info shadow-sm mb-0">
                        Tu rol no tiene módulos asignados en este panel.
                    </div>
                </div>
            @endforelse
        </div>
    </div>
@endsection