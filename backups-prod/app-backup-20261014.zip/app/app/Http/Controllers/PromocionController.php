<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use App\Models\Promocion;
use App\Models\Sucursal;
use App\Models\SucursalProducto;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class PromocionController extends Controller
{
    /**
     * Listado de promociones por sucursal (permiso 352).
     * ADMINISTRADOR → todas las sucursales; GERENTE → las que gerencia;
     * CAJERO/MESERO → su sucursal (solo pueden ver el listado).
     */
    public function index(Request $request): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursales = $this->sucursalesPermitidas($empleado);

        if ($sucursales->isEmpty()) {
            abort(403, 'No tienes una sucursal asignada para ver promociones.');
        }

        $sucursalActual = $sucursales->firstWhere('id', $request->integer('idsucursal'))
            ?? $sucursales->first();

        // Baja automática: las promociones cuya fecha de fin ya pasó se desactivan solas.
        Promocion::marcarVencidas();

        $promociones = Promocion::with('sucursalesProducto.producto')
            ->whereHas('sucursalesProducto', fn ($query) => $query->where('idsucursal', $sucursalActual->id))
            ->orderByDesc('id')
            ->get();

        $sucursalProductos = SucursalProducto::with('producto')
            ->where('idsucursal', $sucursalActual->id)
            ->get()
            ->sortBy(fn ($sp) => mb_strtolower($sp->producto?->nombre ?? ''))
            ->values();

        return view('admin.promociones.index', compact(
            'empleado',
            'sucursales',
            'sucursalActual',
            'promociones',
            'sucursalProductos',
        ) + $this->flagsDeOperacion($empleado));
    }

    /**
     * Crea una promoción (permiso 350): descuento por porcentaje o monto fijo
     * aplicado a uno o más productos de la sucursal con vigencia definida.
     */
    public function store(Request $request): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalActualPermitida($empleado, $request->integer('idsucursal'));

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'tipodescuento' => ['required', 'in:PORCENTAJE,MONTO_FIJO'],
            'valordescuento' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'fechainicio' => ['required', 'date'],
            'fechafin' => ['required', 'date', 'after:fechainicio'],
            'idproductos' => ['required', 'array', 'min:1'],
            'idproductos.*' => ['integer'],
            'cantidades' => ['array'],
            'cantidades.*' => ['nullable', 'integer', 'min:1', 'max:100'],
            'photo' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'],
        ]);

        if ($validated['tipodescuento'] === 'PORCENTAJE' && (float) $validated['valordescuento'] > 100) {
            return back()->withErrors(['valordescuento' => 'El descuento por porcentaje no puede superar el 100%.'])
                ->withInput();
        }

        $productos = $this->sucursalProductosValidos($sucursalActual, $validated['idproductos']);
        $pivots = $this->pivotConCantidades($productos, $validated);
        $rutaPhoto = $request->file('photo')?->store('promociones', 'public');

        $promocion = DB::transaction(function () use ($validated, $pivots, $rutaPhoto) {
            $promocion = Promocion::create([
                'nombre' => $validated['nombre'],
                'tipodescuento' => $validated['tipodescuento'],
                'valordescuento' => $validated['valordescuento'],
                'fechainicio' => $validated['fechainicio'],
                'fechafin' => $validated['fechafin'],
                'activo' => true,
                'photo' => $rutaPhoto,
            ]);

            $promocion->sucursalesProducto()->attach($pivots);

            return $promocion;
        });

        $this->registrarAccion($empleado->id, 'CREATE', 'promocion', $promocion->id, '350');

        return redirect()->route('dashboard.promociones.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Promoción {$promocion->nombre} creada para {$sucursalActual->nombre}.");
    }

    /**
     * Edita una promoción (permiso 351).
     */
    public function update(Request $request, Promocion $promocion): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->promocionPermitida($empleado, $promocion);

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'tipodescuento' => ['required', 'in:PORCENTAJE,MONTO_FIJO'],
            'valordescuento' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'fechainicio' => ['required', 'date'],
            'fechafin' => ['required', 'date', 'after:fechainicio'],
            'idproductos' => ['required', 'array', 'min:1'],
            'idproductos.*' => ['integer'],
            'cantidades' => ['array'],
            'cantidades.*' => ['nullable', 'integer', 'min:1', 'max:100'],
            'photo' => ['nullable', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'],
        ]);

        if ($validated['tipodescuento'] === 'PORCENTAJE' && (float) $validated['valordescuento'] > 100) {
            return back()->withErrors(['valordescuento' => 'El descuento por porcentaje no puede superar el 100%.'])
                ->withInput();
        }

        $productos = $this->sucursalProductosValidos($sucursalActual, $validated['idproductos']);
        $pivots = $this->pivotConCantidades($productos, $validated);

        DB::transaction(function () use ($promocion, $validated, $pivots, $request) {
            $rutaPhoto = $promocion->photo;

            if ($request->file('photo')) {
                if ($promocion->photo) {
                    Storage::disk('public')->delete($promocion->photo);
                }
                $rutaPhoto = $request->file('photo')->store('promociones', 'public');
            }

            $promocion->update([
                'nombre' => $validated['nombre'],
                'tipodescuento' => $validated['tipodescuento'],
                'valordescuento' => $validated['valordescuento'],
                'fechainicio' => $validated['fechainicio'],
                'fechafin' => $validated['fechafin'],
                'activo' => true,
                'photo' => $rutaPhoto,
            ]);

            $promocion->sucursalesProducto()->sync($pivots);
        });

        $this->registrarAccion($empleado->id, 'UPDATE', 'promocion', $promocion->id, '351');

        return redirect()->route('dashboard.promociones.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Promoción {$promocion->nombre} actualizada en {$sucursalActual->nombre}.");
    }

    /**
     * Da de baja una promoción (permiso 355).
     */
    public function baja(Request $request, Promocion $promocion): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->promocionPermitida($empleado, $promocion);

        $promocion->update(['activo' => false]);

        $this->registrarAccion($empleado->id, 'DELETE', 'promocion', $promocion->id, '355');

        return redirect()->route('dashboard.promociones.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Promoción {$promocion->nombre} dada de baja en {$sucursalActual->nombre}.");
    }

    /** Sucursales que el empleado puede operar (mismo criterio que productos-sucursal). */
    private function sucursalesPermitidas(Empleado $empleado): Collection
    {
        $claverol = $empleado->rol?->claverol;

        if ($claverol === 'ADMINISTRADOR') {
            return Sucursal::orderBy('nombre')->get();
        }

        if ($claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->orderBy('nombre')
                ->get();
        }

        return $empleado->idsucursal
            ? Sucursal::where('id', $empleado->idsucursal)->get()
            : collect();
    }

    private function sucursalActualPermitida(Empleado $empleado, int $idsucursal): Sucursal
    {
        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $idsucursal)
            ?? $this->sucursalesPermitidas($empleado)->first();

        abort_unless($sucursal, 403, 'No tienes acceso a esa sucursal.');

        return $sucursal;
    }

    private function promocionPermitida(Empleado $empleado, Promocion $promocion): Sucursal
    {
        $sucursales = $this->sucursalesPermitidas($empleado);

        $idsucursal = $promocion->sucursalesProducto
            ->pluck('idsucursal')
            ->first(fn ($id) => $sucursales->pluck('id')->contains($id));

        abort_unless($idsucursal, 403, 'Esa promoción no pertenece a una sucursal que puedas operar.');

        return $sucursales->firstWhere('id', $idsucursal);
    }

    /** Devuelve solo los sucursal_producto que pertenecen a la sucursal y existen. */
    private function sucursalProductosValidos(Sucursal $sucursal, array $ids): Collection
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));

        $productos = SucursalProducto::where('idsucursal', $sucursal->id)
            ->whereIn('id', $ids)
            ->get();

        abort_if($productos->isEmpty(), 422, 'Selecciona al menos un producto de la sucursal.');

        return $productos;
    }

    /**
     * Construye el pivote para attach/sync en la forma id => ['cantidad_producto' => n].
     * Las cantidades llegan en el mismo orden que los idproductos del formulario.
     */
    private function pivotConCantidades(Collection $productos, array $validated): array
    {
        $permitidos = $productos->pluck('id')->mapWithKeys(fn ($id) => [$id => true]);
        $cantidades = $validated['cantidades'] ?? [];
        $pivots = [];

        foreach ($validated['idproductos'] as $i => $id) {
            $id = (int) $id;

            if (! $permitidos->has($id)) {
                continue;
            }

            $pivots[$id] = ['cantidad_producto' => max(1, (int) ($cantidades[$i] ?? 1))];
        }

        return $pivots;
    }

    private function flagsDeOperacion(Empleado $empleado): array
    {
        $claverol = $empleado->rol?->claverol;

        $codigos = $empleado->rol?->permisos
            ? $empleado->rol->permisos->where('estado', true)->pluck('codigo')
            : collect();

        return [
            'puedeCrear' => $codigos->contains('350'),
            'puedeEditar' => $codigos->contains('351'),
            'puedeBaja' => $codigos->contains('355'),
            'esAdmin' => $claverol === 'ADMINISTRADOR',
        ];
    }
}
