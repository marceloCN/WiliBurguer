<?php

namespace App\Http\Controllers;

use App\Models\DetalleReceta;
use App\Models\Insumo;
use App\Models\Producto;
use App\Models\UnidadMedida;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class InsumoController extends Controller
{
    public function index(Request $request): View
    {
        $unidades = UnidadMedida::withCount('insumos')
            ->orderBy('nombre')
            ->get();

        $idunidadmedida = $request->integer('idunidadmedida');

        $unidadActual = $unidades->firstWhere('id', $idunidadmedida)
            ?? $unidades->firstWhere('estado', true)
            ?? $unidades->first();

        $insumos = $unidadActual
            ? Insumo::with('unidadMedida')
                ->where('idunidadmedida', $unidadActual->id)
                ->orderBy('nombre')
                ->get()
            : collect();

        $productos = Producto::with('categoria')
            ->withCount('detallesReceta')
            ->orderBy('nombre')
            ->get();

        $productosAgrupados = $productos
            ->groupBy(fn (Producto $producto) => $producto->categoria?->nombre ?? 'Sin categoría')
            ->sortKeys();

        $idproducto = $request->integer('idproducto');

        $productoActual = $productos->firstWhere('id', $idproducto)
            ?? $productos->first();

        $receta = $productoActual
            ? DetalleReceta::with('insumo.unidadMedida')
                ->where('idproducto', $productoActual->id)
                ->get()
                ->filter(fn (DetalleReceta $detalle) => $detalle->insumo && $detalle->insumo->estado)
                ->sortBy(fn (DetalleReceta $detalle) => mb_strtolower($detalle->insumo?->nombre ?? ''))
            : collect();

        $insumosReceta = $productoActual
            ? DetalleReceta::where('idproducto', $productoActual->id)->pluck('idinsumo')->all()
            : [];

        $insumosDisponibles = Insumo::with('unidadMedida')
            ->where('estado', true)
            ->whereNotIn('id', $insumosReceta)
            ->orderBy('nombre')
            ->get();

        $tab = $request->input('tab', 'insumos');

        return view('admin.insumos.index', compact(
            'unidades',
            'idunidadmedida',
            'unidadActual',
            'insumos',
            'productos',
            'productosAgrupados',
            'idproducto',
            'productoActual',
            'receta',
            'insumosDisponibles',
            'tab',
        ));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validar($request);

        $nombre = mb_trim($validated['nombre']);

        $existente = $this->insumoPorNombre($nombre);

        if ($existente && $existente->estado) {
            return back()->withInput()->with('error', 'Ya existe un insumo activo con ese nombre.');
        }

        if ($existente) {
            $existente->update([
                'nombre' => $nombre,
                'descripcion' => $validated['descripcion'] ?? '',
                'idunidadmedida' => $validated['idunidadmedida'],
                'estado' => true,
            ]);

            $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'insumo', $existente->id, '336');

            return redirect()->route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $existente->idunidadmedida])
                ->with('exito', "Insumo {$existente->nombre} reactivado.");
        }

        $insumo = Insumo::create([
            'nombre' => $nombre,
            'descripcion' => $validated['descripcion'] ?? '',
            'idunidadmedida' => $validated['idunidadmedida'],
            'estado' => true,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'insumo', $insumo->id, '336');

        return redirect()->route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $insumo->idunidadmedida])
            ->with('exito', "Insumo {$insumo->nombre} creado.");
    }

    public function update(Request $request, Insumo $insumo): RedirectResponse
    {
        $validated = $this->validar($request);

        $nombre = mb_trim($validated['nombre']);

        $existente = $this->insumoPorNombre($nombre, $insumo->id);

        if ($existente && $existente->estado) {
            return back()->withInput()->with('error', 'Ya existe un insumo activo con ese nombre.');
        }

        $insumo->update([
            'nombre' => $nombre,
            'descripcion' => $validated['descripcion'] ?? '',
            'idunidadmedida' => $validated['idunidadmedida'],
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'insumo', $insumo->id, '337');

        return back()->with('exito', "Insumo {$insumo->nombre} actualizado.");
    }

    public function baja(Insumo $insumo): RedirectResponse
    {
        $insumo->update(['estado' => false]);

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'insumo', $insumo->id, '338');

        return back()->with('exito', "Insumo {$insumo->nombre} dado de baja.");
    }

    public function reactivar(Insumo $insumo): RedirectResponse
    {
        if ($insumo->estado) {
            return back()->with('info', "El insumo {$insumo->nombre} ya está activo.");
        }

        $insumo->update(['estado' => true]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'insumo', $insumo->id, '336');

        return redirect()->route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $insumo->idunidadmedida])
            ->with('exito', "Insumo {$insumo->nombre} reactivado.");
    }

    public function recetaStore(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'idproducto' => ['required', 'exists:producto,id'],
            'idinsumo' => ['required', 'exists:insumo,id'],
            'cantidad' => ['required', 'numeric', 'gt:0'],
        ]);

        $producto = Producto::findOrFail($validated['idproducto']);
        $insumo = Insumo::findOrFail($validated['idinsumo']);

        if ($this->insumoEnReceta($producto->id, $insumo->id)) {
            return back()->withInput()->with('error', "El insumo {$insumo->nombre} ya está en la receta de {$producto->nombre}.");
        }

        $detalle = DetalleReceta::create([
            'idproducto' => $producto->id,
            'idinsumo' => $insumo->id,
            'cantidad' => $validated['cantidad'],
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'detallereceta', $detalle->id, '340');

        return redirect()->route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $producto->id])
            ->with('exito', "Insumo {$insumo->nombre} agregado a la receta de {$producto->nombre}.");
    }

    public function recetaUpdate(Request $request, DetalleReceta $detalle): RedirectResponse
    {
        $validated = $request->validate([
            'cantidad' => ['required', 'numeric', 'gt:0'],
        ]);

        $detalle->update(['cantidad' => $validated['cantidad']]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'detallereceta', $detalle->id, '341');

        $insumo = $detalle->insumo;

        return redirect()->route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $detalle->idproducto])
            ->with('exito', "Cantidad del insumo {$insumo?->nombre} actualizada.");
    }

    public function recetaBaja(DetalleReceta $detalle): RedirectResponse
    {
        $idproducto = $detalle->idproducto;
        $insumo = $detalle->insumo;

        $detalle->delete();

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'detallereceta', $detalle->id, '345');

        return redirect()->route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $idproducto])
            ->with('exito', "Insumo {$insumo?->nombre} quitado de la receta.");
    }

    private function insumoEnReceta(int $idproducto, int $idinsumo): bool
    {
        return DetalleReceta::where('idproducto', $idproducto)
            ->where('idinsumo', $idinsumo)
            ->exists();
    }

    private function insumoPorNombre(string $nombre, ?int $ignorarId = null): ?Insumo
    {
        return Insumo::whereRaw('LOWER(nombre) = ?', [mb_strtolower($nombre)])
            ->when($ignorarId, fn ($query) => $query->where('id', '!=', $ignorarId))
            ->first();
    }

    private function validar(Request $request): array
    {
        return $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'descripcion' => ['nullable', 'string'],
            'idunidadmedida' => ['required', Rule::exists('unidadmedida', 'id')->where('estado', true)],
        ]);
    }
}