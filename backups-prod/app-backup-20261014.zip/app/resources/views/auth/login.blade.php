@extends('layouts.app')

@section('title', 'Iniciar sesión · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-7 col-lg-5 col-xl-4">
                <div class="card tarjeta-producto border-0 mb-0">
                    <div class="card-body p-4 p-md-5">
                        <div class="text-center mb-4">
                            <div class="display-4 text-brand">Welcome</div>
                            <h1 class="h3 fw-bold mb-1">{{$configuracionSitio->get('SITIO_NOMBRE')}}</h1>
                            <p class="text-muted mb-0">Sistema de gestión y administracion para BurguerWilli and Grill</p>
                        </div>

                        @if ($errors->any())
                            <div class="alert alert-danger py-2 small">
                                <ul class="mb-0">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form method="POST" action="{{ route('login.store') }}">
                            @csrf

                            <div class="mb-3">
                                <label for="usuario" class="form-label">Usuario o correo</label>
                                <input type="text" class="form-control @error('usuario') is-invalid @enderror"
                                       id="usuario" name="usuario" value="{{ old('usuario') }}"
                                       placeholder="usuario@correo.com" autofocus required>
                                @error('usuario')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Contraseña</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror"
                                       id="password" name="password" placeholder="••••••••" required>
                                @error('password')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-brand btn-lg">Ingresar</button>
                            </div>

                            <div class="text-center mt-3">
                                <a href="{{ route('password.request') }}" class="small text-decoration-none">¿Olvidaste tu contraseña?</a>
                            </div>

                            <p class="text-center text-muted small mt-3 mb-0">
                                ¿No tienes cuenta? Contacta con tu administrador.
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection