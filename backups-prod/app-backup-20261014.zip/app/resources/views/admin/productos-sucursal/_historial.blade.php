{{-- Historial de precios del producto en la sucursal. Requiere $historial y $sucursalProducto. --}}
@if ($historial->isEmpty())
    <div class="text-center text-muted py-4">Este producto aún no tiene cambios de precio registrados.</div>
@else
    <div class="table-responsive">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th>Fecha del cambio</th>
                    <th>Precio anterior</th>
                    <th>Precio nuevo</th>
                    <th>Variación</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($historial as $registro)
                    @php
                        $anterior = (float) $registro->precioanterior;
                        $nuevo = (float) $registro->precionuevo;
                        $diferencia = round($nuevo - $anterior, 2);
                    @endphp
                    <tr>
                        <td>{{ \Carbon\Carbon::parse($registro->fecha_registro)->format('d/m/Y H:i') }}</td>
                        <td>S/ {{ number_format($anterior, 2) }}</td>
                        <td class="fw-semibold">S/ {{ number_format($nuevo, 2) }}</td>
                        <td>
                            @if ($diferencia > 0)
                                <span class="badge text-bg-success">+S/ {{ number_format($diferencia, 2) }}</span>
                            @elseif ($diferencia < 0)
                                <span class="badge text-bg-danger">-S/ {{ number_format(abs($diferencia), 2) }}</span>
                            @else
                                <span class="badge text-bg-secondary">Sin cambio</span>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif