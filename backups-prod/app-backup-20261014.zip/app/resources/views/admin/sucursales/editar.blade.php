@extends('layouts.app')

@section('title', 'Editar sucursal · ' . $sucursal->nombre . ' · ' . $configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Editar sucursal</h1>
                <p class="text-muted mb-0">
                    Estás editando: <strong>{{ $sucursal->nombre }}</strong>
                    <span class="badge {{ $sucursal->estado ? 'text-bg-success' : 'text-bg-secondary' }} ms-1">
                        {{ $sucursal->estado ? 'Activa' : 'Inactiva' }}
                    </span>
                </p>
            </div>
            <a href="{{ route('dashboard.sucursales.index') }}" class="btn btn-outline-secondary btn-sm">← Volver</a>
        </div>

        @include('partials.mensajes')

        <ul class="nav nav-pills seccion-tabs mb-4 flex-wrap gap-2" id="sucursalTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="tab-datos-tab" data-bs-toggle="pill" data-bs-target="#tab-datos"
                    type="button" role="tab" aria-controls="tab-datos" aria-selected="true">🏪 Datos y ubicación</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-horarios-tab" data-bs-toggle="pill" data-bs-target="#tab-horarios"
                    type="button" role="tab" aria-controls="tab-horarios" aria-selected="false">🕒 Horarios</button>
            </li>
            @if ($puedeGestionarMesas)
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-mesas-tab" data-bs-toggle="pill" data-bs-target="#tab-mesas"
                        type="button" role="tab" aria-controls="tab-mesas" aria-selected="false">🪑 Mesas</button>
                </li>
            @endif
            @if ($puedeGestionarCajas)
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-cajas-tab" data-bs-toggle="pill" data-bs-target="#tab-cajas"
                        type="button" role="tab" aria-controls="tab-cajas" aria-selected="false">🛢️ Cajas</button>
                </li>
            @endif
        </ul>

        <div class="tab-content" id="sucursalTabsContent">
            {{-- ============================================================
                 PESTAÑA 1: DATOS GENERALES + MAPA
                 ============================================================ --}}
            <div class="tab-pane fade show active" id="tab-datos" role="tabpanel" aria-labelledby="tab-datos-tab">
                <div class="row g-4">
                    @if ($esAdmin)
                        <div class="col-12">
                            <div class="card tarjeta-producto mb-4 border-warning-subtle">
                                <div class="card-body">
                                    <div class="d-flex align-items-center gap-2 mb-3">
                                        <span class="badge text-bg-brand px-3 py-2">👤 Gerente asignado</span>
                                    </div>
                                    <form method="POST" action="{{ route('dashboard.sucursales.gerente', $sucursal) }}">
                                        @csrf
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label">Gerente del sistema *</label>
                                                <div class="row g-2">
                                                    <div class="col-md-9">
                                                        <select name="idempleadogerente" class="form-select" required>
                                                            @if ($sucursal->gerente)
                                                                <option value="{{ $sucursal->gerente->id }}" @selected(true)>
                                                                    {{ $sucursal->gerente->nombre }}
                                                                    {{ $sucursal->gerente->apellido }} (actual)
                                                                </option>
                                                            @endif
                                                            <option value="">— Sin gerente —</option>
                                                            @foreach ($gerentesDisponibles as $gerente)
                                                                <option value="{{ $gerente->id }}"
                                                                    @selected(old('idempleadogerente') == $gerente->id)>
                                                                    {{ $gerente->nombre }} {{ $gerente->apellido }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 d-grid">
                                                        <button type="submit" class="btn btn-brand">
                                                            <i class="bi bi-person-check"></i> Asignar gerente
                                                        </button>
                                                    </div>
                                                </div>
                                                <p class="small text-muted mt-2 mb-0">
                                                    Solo se muestran gerentes del sistema que no están asignados a otra
                                                    sucursal.
                                                </p>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endif

                    <div class="{{ $esAdmin ? 'col-xl-7' : 'col-12' }}">
                        <form method="POST" action="{{ route('dashboard.sucursales.update', $sucursal) }}" id="form-datos-sucursal">
                            @csrf
                            <input type="hidden" name="latitud" id="latitud-envio"
                                value="{{ old('latitud', $sucursal->latitud) }}">
                            <input type="hidden" name="longitud" id="longitud-envio"
                                value="{{ old('longitud', $sucursal->longitud) }}">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Datos generales</h2>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                                            <input type="text" name="nombre" class="form-control" required
                                                value="{{ old('nombre', $sucursal->nombre) }}" maxlength="255">
                                            @error('nombre')
                                                <div class="form-text text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Teléfono <span class="text-danger">*</span></label>
                                            <input type="text" name="telefono" class="form-control" required
                                                value="{{ old('telefono', $sucursal->telefono) }}" maxlength="15">
                                            @error('telefono')
                                                <div class="form-text text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Dirección <span class="text-danger">*</span></label>
                                            <input type="text" name="direccion" class="form-control" required
                                                value="{{ old('direccion', $sucursal->direccion) }}" maxlength="255">
                                            @error('direccion')
                                                <div class="form-text text-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer bg-light-subtle border-top">
                                    <button type="submit" class="btn btn-brand">💾 Guardar sucursal</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="{{ $esAdmin ? 'col-xl-5' : 'col-12' }}">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-1">Ubicación en el mapa</h2>
                                <p class="small text-muted mb-3">
                                    Busca una dirección, haz clic en el mapa o arrastra el marcador para fijar la
                                    ubicación exacta.
                                </p>

                                <div class="input-group mb-3">
                                    <input type="text" id="buscarLugar" class="form-control"
                                        placeholder="Buscar dirección o lugar…">
                                    <button type="button" id="btnBuscarLugar" class="btn btn-brand">
                                        <i class="bi bi-search"></i> Buscar
                                    </button>
                                </div>

                                <div id="mapa-editar" class="mapa-editar mb-3"></div>

                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Latitud <span
                                                class="text-danger">*</span></label>
                                        <input type="number" step="any" name="latitud" id="latitud"
                                            class="form-control" value="{{ old('latitud', $sucursal->latitud) }}"
                                            required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Longitud <span
                                                class="text-danger">*</span></label>
                                        <input type="number" step="any" name="longitud" id="longitud"
                                            class="form-control" value="{{ old('longitud', $sucursal->longitud) }}"
                                            required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- ============================================================
                 PESTAÑA 2: HORARIOS DE ATENCIÓN
                 ============================================================ --}}
            <div class="tab-pane fade" id="tab-horarios" role="tabpanel" aria-labelledby="tab-horarios-tab">
                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-1">Agregar horario</h2>
                                    <p class="small text-muted mb-3">
                                        Define el horario de atención de cada día: la <strong>hora de cierre debe ser
                                        posterior a la apertura</strong> y solo puede existir <strong>un horario por día</strong>.
                                        Si un día no atienden, déjalo sin registrar.
                                    </p>
                                <form method="POST"
                                    action="{{ route('dashboard.sucursales.horario.store', $sucursal) }}">
                                    @csrf
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label small fw-bold">Día <span
                                                    class="text-danger">*</span></label>
                                            <select name="iddiaatencion" class="form-select" required>
                                                @foreach ($dias as $dia)
                                                    <option value="{{ $dia->id }}">{{ $dia->nombredia }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label small fw-bold">Apertura <span
                                                    class="text-danger">*</span></label>
                                            <input type="time" name="horaapertura" class="form-control" required
                                                value="{{ old('horaapertura') }}">
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label small fw-bold">Cierre <span
                                                    class="text-danger">*</span></label>
                                            <input type="time" name="horacierre" class="form-control" required
                                                value="{{ old('horacierre') }}">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label small fw-bold">Estado inicial</label>
                                            <select name="activo" class="form-select">
                                                <option value="1" @selected(old('activo', 1))>Activo</option>
                                                <option value="0" @selected(old('activo') === '0')>Inactivo</option>
                                            </select>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-brand w-100">+ Agregar horario</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-3">Horarios registrados</h2>
                                @if ($sucursal->horarios->isEmpty())
                                    <div class="alert alert-light text-center mb-0">
                                        Esta sucursal aún no tiene horarios registrados.
                                    </div>
                                @else
                                    <div class="table-responsive">
                                        <table class="table align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Día</th>
                                                    <th>Horario</th>
                                                    <th>Estado</th>
                                                    <th class="text-end">Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($sucursal->horarios->sortBy(fn($h) => $h->diaAtencion?->numerodia) as $horario)
                                                    <tr>
                                                        <td>
                                                            <span class="fw-semibold">
                                                                {{ $horario->diaAtencion?->nombredia ?? 'Sin asignar' }}
                                                            </span>
                                                        </td>
                                                        <td class="font-monospace">
                                                            {{ substr($horario->horaapertura, 0, 5) }} –
                                                            {{ substr($horario->horacierre, 0, 5) }}
                                                        </td>
                                                        <td>
                                                            <span
                                                                class="badge rounded-pill {{ $horario->activo ? 'text-bg-success' : 'text-bg-secondary' }}">
                                                                {{ $horario->activo ? 'Activo' : 'Inactivo' }}
                                                            </span>
                                                        </td>
                                                        <td class="text-end">
                                                            <button type="button" class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="collapse"
                                                                data-bs-target="#editar-horario-{{ $horario->idhorariosucursal }}"
                                                                aria-expanded="false"
                                                                aria-controls="editar-horario-{{ $horario->idhorariosucursal }}">
                                                                ✏️ Editar
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    <tr class="table-light">
                                                        <td colspan="4" class="p-0 border-0">
                                                            <div class="collapse"
                                                                id="editar-horario-{{ $horario->idhorariosucursal }}">
                                                                <div class="p-3">
                                                                    <form method="POST"
                                                                        action="{{ route('dashboard.sucursales.horario.update', [$sucursal, $horario]) }}"
                                                                        class="row g-2 align-items-end">
                                                                        @csrf
                                                                        <div class="col-6 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Día</label>
                                                                            <select name="iddiaatencion"
                                                                                class="form-select form-select-sm">
                                                                                @foreach ($dias as $dia)
                                                                                    <option value="{{ $dia->id }}"
                                                                                        @selected($horario->iddiaatencion === $dia->id)>
                                                                                        {{ $dia->nombredia }}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-5 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Apertura</label>
                                                                            <input type="time" name="horaapertura"
                                                                                value="{{ substr($horario->horaapertura, 0, 5) }}"
                                                                                class="form-control form-control-sm"
                                                                                required>
                                                                        </div>
                                                                        <div
                                                                            class="col-2 col-md-1 text-center text-muted pb-1">
                                                                            –
                                                                        </div>
                                                                        <div class="col-5 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Cierre</label>
                                                                            <input type="time" name="horacierre"
                                                                                value="{{ substr($horario->horacierre, 0, 5) }}"
                                                                                class="form-control form-control-sm"
                                                                                required>
                                                                        </div>
                                                                        <div class="col-6 col-md-2">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Estado</label>
                                                                            <select name="activo"
                                                                                class="form-select form-select-sm">
                                                                                <option value="1"
                                                                                    @selected($horario->activo)>Activo</option>
                                                                                <option value="0"
                                                                                    @selected(!$horario->activo)>Inactivo
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-6 col-md-3 d-flex gap-1">
                                                                            <button type="submit"
                                                                                class="btn btn-sm btn-brand flex-fill">
                                                                                ✓ Guardar
                                                                            </button>
                                                                            <button type="button"
                                                                                class="btn btn-sm btn-outline-secondary"
                                                                                data-bs-toggle="collapse"
                                                                                data-bs-target="#editar-horario-{{ $horario->idhorariosucursal }}">
                                                                                Cancelar
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                    <button type="button"
                                                                        class="btn btn-sm btn-outline-danger mt-2"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#modal-confirmar-baja"
                                                                        data-accion="{{ route('dashboard.sucursales.horario.baja', [$sucursal, $horario]) }}"
                                                                        data-mensaje="¿Eliminar el horario del {{ $horario->diaAtencion?->nombredia ?? 'día seleccionado' }}?">
                                                                        🗑️ Eliminar
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- ============================================================
                 PESTAÑA 3: MESAS (solo si tiene permiso)
                 ============================================================ --}}
            @if ($puedeGestionarMesas)
                <div class="tab-pane fade" id="tab-mesas" role="tabpanel" aria-labelledby="tab-mesas-tab">
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-1">Registrar mesa</h2>
                                    <p class="small text-muted mb-3">
                                        Asigna a cada mesa un <strong>número</strong> y cuántas <strong>personas</strong>
                                        puede sentar. El número de mesa <strong>no puede repetirse</strong> dentro de
                                        esta sucursal.
                                    </p>
                                    <form method="POST" action="{{ route('dashboard.sucursales.mesa.store', $sucursal) }}">
                                            @csrf
                                            <div class="row g-3">
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Número <span
                                                            class="text-danger">*</span></label>
                                                    <input type="number" name="numeromesa" class="form-control" min="1"
                                                        required value="{{ old('numeromesa') }}">
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Capacidad <span
                                                            class="text-danger">*</span></label>
                                                    <input type="number" name="capacidad" class="form-control" min="1"
                                                        required value="{{ old('capacidad', 4) }}">
                                                </div>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-brand w-100">+ Registrar mesa</button>
                                                </div>
                                            </div>
                                        </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Mesas de esta sucursal</h2>
                                    @if ($sucursal->mesas->isEmpty())
                                        <div class="alert alert-light text-center mb-0">
                                            Esta sucursal aún no tiene mesas registradas.
                                        </div>
                                    @else
                                        <div class="table-responsive">
                                            <table class="table align-middle mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Mesa</th>
                                                        <th>Capacidad</th>
                                                        <th>Estado</th>
                                                        <th class="text-end">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($sucursal->mesas->sortBy('numeromesa') as $mesa)
                                                        <tr>
                                                            <td>
                                                                <span class="fw-semibold">Mesa {{ $mesa->numeromesa }}</span>
                                                            </td>
                                                            <td>
                                                                {{ $mesa->capacidad }}
                                                                <span class="text-muted small">personas</span>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge rounded-pill {{ $mesa->estado ? 'text-bg-success' : 'text-bg-secondary' }}">
                                                                    {{ $mesa->estado ? 'Activa' : 'Inactiva' }}
                                                                </span>
                                                            </td>
                                                            <td class="text-end">
                                                                <button type="button" class="btn btn-sm btn-outline-brand"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#editar-mesa-{{ $mesa->id }}"
                                                                    aria-expanded="false"
                                                                    aria-controls="editar-mesa-{{ $mesa->id }}">
                                                                    ✏️ Editar
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <tr class="table-light">
                                                            <td colspan="4" class="p-0 border-0">
                                                                <div class="collapse" id="editar-mesa-{{ $mesa->id }}">
                                                                    <div class="p-3">
                                                                        <form method="POST"
                                                                            action="{{ route('dashboard.sucursales.mesa.update', [$sucursal, $mesa]) }}"
                                                                            class="row g-2 align-items-end">
                                                                            @csrf
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Número</label>
                                                                                <input type="number" name="numeromesa"
                                                                                    class="form-control form-control-sm"
                                                                                    min="1" value="{{ $mesa->numeromesa }}"
                                                                                    required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Capacidad</label>
                                                                                <input type="number" name="capacidad"
                                                                                    class="form-control form-control-sm"
                                                                                    min="1" value="{{ $mesa->capacidad }}"
                                                                                    required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Estado</label>
                                                                                <select name="estado"
                                                                                    class="form-select form-select-sm">
                                                                                    <option value="1" @selected($mesa->estado)>Activa
                                                                                    </option>
                                                                                    <option value="0" @selected(!$mesa->estado)>Inactiva
                                                                                    </option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-6 col-md-3 gap-1 d-flex">
                                                                                <button type="submit"
                                                                                    class="btn btn-sm btn-brand flex-fill">
                                                                                    ✓ Guardar
                                                                                </button>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-secondary"
                                                                                    data-bs-toggle="collapse"
                                                                                    data-bs-target="#editar-mesa-{{ $mesa->id }}">
                                                                                    Cancelar
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                        @if ($mesa->estado)
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-danger mt-2"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#modal-confirmar-baja"
                                                                                    data-accion="{{ route('dashboard.sucursales.mesa.baja', [$sucursal, $mesa]) }}"
                                                                                    data-mensaje="¿Dar de baja la Mesa {{ $mesa->numeromesa }}?">
                                                                                    🗑️ Dar de baja
                                                                                </button>
                                                                            @endif
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            {{-- ============================================================
                 PESTAÑA 4: CAJAS (solo si tiene permiso)
                 ============================================================ --}}
            @if ($puedeGestionarCajas)
                <div class="tab-pane fade" id="tab-cajas" role="tabpanel" aria-labelledby="tab-cajas-tab">
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-1">Registrar caja</h2>
                                    <p class="small text-muted mb-3">
                                        Cada caja recibe un <strong>nombre</strong> que no puede repetirse dentro de esta
                                        sucursal, y solo puede haber <strong>dos cajas activas</strong> a la vez.
                                        La caja no se asocia a un cajero: sirve para identificar la apertura y cualquier
                                        cajero puede abrirla con solo conocer su nombre.
                                    </p>
                                    <form method="POST"
                                        action="{{ route('dashboard.sucursales.caja.store', $sucursal) }}">
                                        @csrf
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label small fw-bold">Nombre <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="nombre" class="form-control" required
                                                    maxlength="100" value="{{ old('nombre') }}"
                                                    placeholder="Ej. Caja 1">
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label small fw-bold">Estado inicial</label>
                                                <select name="activo" class="form-select">
                                                    <option value="1" @selected(old('activo', 1))>Activa</option>
                                                    <option value="0" @selected(old('activo') === '0')>Inactiva</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-brand w-100">Registrar
                                                    caja</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Cajas de esta sucursal</h2>
                                    @if ($sucursal->cajas->isEmpty())
                                        <div class="alert alert-light text-center mb-0">
                                            Esta sucursal aún no tiene cajas registradas.
                                        </div>
                                    @else
                                        <div class="table-responsive">
                                            <table class="table align-middle mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Caja</th>
                                                        <th>Estado</th>
                                                        <th class="text-end">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($sucursal->cajas as $caja)
                                                        <tr>
                                                            <td>
                                                                <span class="fw-semibold">{{ $caja->nombre }}</span>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge rounded-pill {{ $caja->activo ? 'text-bg-success' : 'text-bg-secondary' }}">
                                                                    {{ $caja->activo ? 'Activa' : 'Inactiva' }}
                                                                </span>
                                                            </td>
                                                            <td class="text-end">
                                                                <button type="button"
                                                                    class="btn btn-sm btn-outline-brand"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#editar-caja-{{ $caja->id }}"
                                                                    aria-expanded="false"
                                                                    aria-controls="editar-caja-{{ $caja->id }}">
                                                                    ✏️ Editar
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <tr class="table-light">
                                                            <td colspan="3" class="p-0 border-0">
                                                                <div class="collapse" id="editar-caja-{{ $caja->id }}">
                                                                    <div class="p-3">
                                                                        <form method="POST"
                                                                            action="{{ route('dashboard.sucursales.caja.update', [$sucursal, $caja]) }}"
                                                                            class="row g-2 align-items-end">
                                                                            @csrf
                                                                            <div class="col-6 col-md-4">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Nombre</label>
                                                                                <input type="text" name="nombre"
                                                                                    class="form-control form-control-sm"
                                                                                    maxlength="100"
                                                                                    value="{{ $caja->nombre }}" required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Estado</label>
                                                                                <select name="activo"
                                                                                    class="form-select form-select-sm">
                                                                                    <option value="1"
                                                                                        @selected($caja->activo)>Activa
                                                                                    </option>
                                                                                    <option value="0"
                                                                                        @selected(!$caja->activo)>Inactiva
                                                                                    </option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-12 col-md-5 gap-1 d-flex">
                                                                                <button type="submit"
                                                                                    class="btn btn-sm btn-brand flex-fill">
                                                                                    ✓ Guardar
                                                                                </button>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-secondary"
                                                                                    data-bs-toggle="collapse"
                                                                                    data-bs-target="#editar-caja-{{ $caja->id }}">
                                                                                    Cancelar
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                        @if ($caja->activo)
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-danger mt-2"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#modal-confirmar-baja"
                                                                                    data-accion="{{ route('dashboard.sucursales.caja.baja', [$sucursal, $caja]) }}"
                                                                                    data-mensaje="¿Dar de baja la caja {{ $caja->nombre }}?">
                                                                                    🗑️ Dar de baja
                                                                                </button>
                                                                            @endif
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>

        {{-- Modal compartido de confirmación de bajas (mesas, horarios, cajas) --}}
        <div class="modal fade" id="modal-confirmar-baja" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <form method="POST" id="form-confirmar-baja" class="modal-content">
                    @csrf
                    <div class="modal-header">
                        <h2 class="modal-title fs-5">⚠️ Confirmar baja</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-0" id="texto-confirmar-baja"></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">🗑️ Confirmar baja</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        .mapa-editar {
            height: 340px;
            border-radius: 0.75rem;
            background: #eee;
            z-index: 0;
        }

        .seccion-tabs .nav-link {
            border-radius: 2rem;
            padding: .5rem 1.1rem;
            font-weight: 600;
        }

        .seccion-tabs .nav-link.active {
            background-color: var(--brand);
            color: #fff;
        }

        @media (max-width: 575.98px) {
            .mapa-editar {
                height: 280px;
            }
        }
    </style>
@endpush

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        const latInicial = {{ (float) $sucursal->latitud }};
        const lngInicial = {{ (float) $sucursal->longitud }};

        const campoLat = document.getElementById('latitud');
        const campoLng = document.getElementById('longitud');
        const latitudEnvio = document.getElementById('latitud-envio');
        const longitudEnvio = document.getElementById('longitud-envio');

        function sincronizarEnvio() {
            latitudEnvio.value = campoLat.value;
            longitudEnvio.value = campoLng.value;
        }

        const mapa = L.map('mapa-editar').setView([latInicial, lngInicial], 16);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(mapa);

        const marcador = L.marker([latInicial, lngInicial], { draggable: true }).addTo(mapa);

        function fijarCoordenadas(lat, lng) {
            campoLat.value = lat.toFixed(6);
            campoLng.value = lng.toFixed(6);
            sincronizarEnvio();
        }

        fijarCoordenadas(latInicial, lngInicial);

        marcador.on('dragend', function() {
            const posicion = marcador.getLatLng();
            fijarCoordenadas(posicion.lat, posicion.lng);
        });

        mapa.on('click', function(evento) {
            marcador.setLatLng(evento.latlng);
            fijarCoordenadas(evento.latlng.lat, evento.latlng.lng);
        });

        [campoLat, campoLng].forEach(function(input) {
            input.addEventListener('change', function() {
                const lat = parseFloat(campoLat.value);
                const lng = parseFloat(campoLng.value);
                if (Number.isFinite(lat) && Number.isFinite(lng)) {
                    marcador.setLatLng([lat, lng]);
                    mapa.panTo([lat, lng]);
                    sincronizarEnvio();
                }
            });
        });

        document.getElementById('form-datos-sucursal').addEventListener('submit', sincronizarEnvio);

        // Buscador de direcciones (Nominatim / OpenStreetMap)
        const inputBusqueda = document.getElementById('buscarLugar');
        const botonBusqueda = document.getElementById('btnBuscarLugar');

        function buscarLugar() {
            const texto = inputBusqueda.value.trim();
            if (!texto) return;
            fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(texto))
                .then(function(respuesta) {
                    if (!respuesta.ok) throw new Error('Error de red');
                    return respuesta.json();
                })
                .then(function(resultados) {
                    if (!resultados.length) {
                        alert('No se encontró el lugar buscado.');
                        return;
                    }
                    const lat = parseFloat(resultados[0].lat);
                    const lng = parseFloat(resultados[0].lon);
                    nombre = resultados[0].display_name;
                    // Si el campo dirección está vacío o es el valor por defecto, lo completamos.
                    const campoDireccion = document.querySelector('input[name="direccion"]');
                    if (campoDireccion && !campoDireccion.value.trim()) {
                        campoDireccion.value = nombre;
                    }
                    marcador.setLatLng([lat, lng]);
                    mapa.panTo([lat, lng], 16);
                    fijarCoordenadas(lat, lng);
                })
                .catch(function() {
                    alert('No se pudo realizar la búsqueda. Revisa tu conexión.');
                });
        }

        botonBusqueda.addEventListener('click', buscarLugar);
        inputBusqueda.addEventListener('keydown', function(evento) {
            if (evento.key === 'Enter') {
                evento.preventDefault();
                buscarLugar();
            }
        });

        // Modal de confirmación de bajas: copia la acción y el mensaje del botón disparador.
        const modalBaja = document.getElementById('modal-confirmar-baja');
        if (modalBaja) {
            modalBaja.addEventListener('show.bs.modal', function(evento) {
                const disparador = evento.relatedTarget;
                if (!disparador) return;
                document.getElementById('form-confirmar-baja')
                    .setAttribute('action', disparador.getAttribute('data-accion'));
                document.getElementById('texto-confirmar-baja').textContent =
                    disparador.getAttribute('data-mensaje') || '¿Confirmas realizar esta acción?';
            });
        }
    </script>
@endpush