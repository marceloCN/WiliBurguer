
<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $sp = $sucursalProductos->get($producto->id);
        ?>
        <div class="col-12 col-sm-6 col-xl-4">
            <div class="card h-100 tarjeta-producto-menu border">
                <div class="ratio ratio-4x3 bg-light-subtle overflow-hidden rounded-top">
                    <?php if($producto->photo): ?>
                        <img src="<?php echo e(asset('storage/'.$producto->photo)); ?>" alt="<?php echo e($producto->nombre); ?>"
                             class="object-fit-cover w-100" loading="lazy">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center text-muted small">
                            Sin foto
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-body pb-2">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <h2 class="h6 fw-bold mb-1"><?php echo e($producto->nombre); ?></h2>
                        <?php if($producto->estado): ?>
                            <span class="badge text-bg-success">Activo</span>
                        <?php else: ?>
                            <span class="badge text-bg-secondary">Inactivo</span>
                        <?php endif; ?>
                    </div>

                    <?php if($sp): ?>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <span class="fs-5 fw-bold">S/ <?php echo e(number_format($sp->precioproducto, 2)); ?></span>
                            <?php if($sp->disponibilidad): ?>
                                <span class="badge text-bg-success">Disponible</span>
                            <?php else: ?>
                                <span class="badge text-bg-danger">Agotado</span>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <span class="text-muted">—</span>
                            <span class="badge text-bg-light border">Sin precio en esta sucursal</span>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
                    $puedeEditar = $puedeEditarPrecio && $puedeHistorial;
                    $puedeToggle = $puedeDisponibilidad && !$operacionBloqueada;
                ?>
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2 flex-wrap">
                    <?php if($puedeRegistrar && ! $sp): ?>
                        <button class="btn btn-sm btn-brand flex-fill"
                                data-bs-toggle="modal"
                                data-bs-target="#registrarSucursalProductoModal"
                                data-id="<?php echo e($producto->id); ?>"
                                data-nombre="<?php echo e($producto->nombre); ?>"
                                data-url-foto="<?php echo e($producto->photo ? asset('storage/'.$producto->photo) : ''); ?>">
                            + Registrar en sucursal
                        </button>
                    <?php endif; ?>

                    <?php if($sp && ($puedeEditarPrecio || $puedeHistorial)): ?>
                        <?php if($puedeEditarPrecio): ?>
                            <button class="btn btn-sm btn-outline-brand"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editarPrecioSPModal"
                                    data-id="<?php echo e($sp->id); ?>"
                                    data-nombre="<?php echo e($producto->nombre); ?>"
                                    data-precio="<?php echo e(number_format($sp->precioproducto, 2, '.', '')); ?>">
                                Precio
                            </button>
                        <?php endif; ?>
                        <?php if($puedeHistorial): ?>
                            <button class="btn btn-sm btn-outline-secondary"
                                    data-historial-url="<?php echo e(route('dashboard.productos-sucursal.historial', $sp)); ?>"
                                    data-bs-toggle="modal"
                                    data-bs-target="#historialSPModal">
                                Historial
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if($sp && $puedeDisponibilidad): ?>
                        <form method="POST" action="<?php echo e(route('dashboard.productos-sucursal.disponibilidad', $sp)); ?>"
                              class="d-inline m-0 flex-fill">
                            <?php echo csrf_field(); ?>
                            <?php if($sp->disponibilidad): ?>
                                <button class="btn btn-sm w-100 <?php echo e($puedeToggle ? 'btn-outline-danger' : 'btn-outline-secondary'); ?>"
                                        <?php if(!$puedeToggle): ?> disabled title="Necesitas una apertura de caja abierta para esta acción" <?php endif; ?>>
                                    Marcar agotado
                                </button>
                            <?php else: ?>
                                <button class="btn btn-sm w-100 <?php echo e($puedeToggle ? 'btn-outline-success' : 'btn-outline-secondary'); ?>"
                                        <?php if(!$puedeToggle): ?> disabled title="Necesitas una apertura de caja abierta para esta acción" <?php endif; ?>>
                                    Marcar disponible
                                </button>
                            <?php endif; ?>
                        </form>
                    <?php endif; ?>

                    <?php if($sp && !$puedeEditar && !$puedeDisponibilidad && !$puedeHistorial && !$puedeRegistrar): ?>
                        <span class="small text-muted w-100 text-center py-1">Solo lectura</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="text-center text-muted py-4">
                <?php echo e($vacioMensaje ?? 'No hay productos en esta categoría.'); ?>

            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH /var/www/html/resources/views/admin/productos-sucursal/_productos.blade.php ENDPATH**/ ?>