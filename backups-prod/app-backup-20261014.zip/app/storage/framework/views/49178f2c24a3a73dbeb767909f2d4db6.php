
<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-12 col-sm-6 col-xl-4">
            <div class="card h-100 tarjeta-producto-menu border">
                <div class="ratio ratio-4x3 bg-light-subtle overflow-hidden rounded-top">
                    <?php if($producto->photo): ?>
                        <img src="<?php echo e(asset('storage/'.$producto->photo)); ?>" alt="<?php echo e($producto->nombre); ?>"
                             class="object-fit-cover w-100" loading="lazy">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center text-muted small">
                            Sin foto
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-body pb-2">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <h2 class="h6 fw-bold mb-1"><?php echo e($producto->nombre); ?></h2>
                        <?php if($producto->estado): ?>
                            <span class="badge text-bg-success">Activo</span>
                        <?php else: ?>
                            <span class="badge text-bg-secondary">Inactivo</span>
                        <?php endif; ?>
                    </div>
                    <p class="small text-muted mb-0">
                        <?php echo e(\Illuminate\Support\Str::limit($producto->descripcion, 80)); ?>

                    </p>
                </div>
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2">
                    <button class="btn btn-sm btn-outline-brand flex-fill"
                            data-bs-toggle="modal"
                            data-bs-target="#editarProductoModal"
                            data-id="<?php echo e($producto->id); ?>"
                            data-nombre="<?php echo e($producto->nombre); ?>"
                            data-descripcion="<?php echo e($producto->descripcion); ?>"
                            data-idcategoria="<?php echo e($producto->idcategoria); ?>"
                            data-tiene-foto="<?php echo e($producto->photo ? '1' : '0'); ?>"
                            data-url-foto="<?php echo e($producto->photo ? asset('storage/'.$producto->photo) : ''); ?>">
                        Editar
                    </button>
                    <?php if($producto->estado): ?>
                        <button class="btn btn-sm btn-outline-danger"
                                data-bs-toggle="modal"
                                data-bs-target="#modal-confirmar-baja"
                                data-accion="<?php echo e(route('dashboard.menu.producto.baja', $producto)); ?>"
                                data-mensaje="¿Dar de baja el producto <?php echo e($producto->nombre); ?>?">
                            Dar de baja
                        </button>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('dashboard.menu.producto.reactivar', $producto)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="text-center text-muted py-4">
                <?php echo e($vacioMensaje ?? 'No hay productos en esta categoría. Pulsa "+ Nuevo producto".'); ?>

            </div>
        </div>
    <?php endif; ?>
</div><?php /**PATH /var/www/html/resources/views/admin/menu/_productos.blade.php ENDPATH**/ ?>