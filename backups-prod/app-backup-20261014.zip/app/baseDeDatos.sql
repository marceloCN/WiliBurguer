CREATE TABLE Rol (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    claveRol VARCHAR(50) NOT NULL UNIQUE,
    nombreRol VARCHAR(50) NOT NULL
);

-- Registra las sucursales
create table Sucursal (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre varchar(100) not null,
    direccion varchar(200) not null,
    telefono varchar(15) not null,
    latitud decimal(10, 8) not null,
    longitud decimal(11, 8) not null,
    estado boolean not null default true,
    idEmpleadoGerente int null
);

CREATE TABLE Permiso (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    codigo VARCHAR(100) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    estado BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE RolPermiso (
    idRol INT NOT NULL,
    idPermiso INT NOT NULL,
    PRIMARY KEY (idRol, idPermiso),
    FOREIGN KEY (idRol) REFERENCES Rol(id),
    FOREIGN KEY (idPermiso) REFERENCES Permiso(id)
);

CREATE TABLE DiaAtencion (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombreDia VARCHAR(20) NOT NULL,
    numeroDia INT NOT NULL
);

CREATE TABLE HorarioSucursal (
    idHorarioSucursal INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idSucursal INT NOT NULL,
    horaApertura TIME NOT NULL,
    horaCierre TIME NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    idDiaAtencion INT NOT NULL,
    FOREIGN KEY (idSucursal) REFERENCES Sucursal(id),
    FOREIGN KEY (idDiaAtencion) REFERENCES DiaAtencion(id),
    UNIQUE (idSucursal, idDiaAtencion)
);

-- Registra los empleados que se tiene con los diferentes roles
create table Empleado (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre varchar(100) not null,
    apellido varchar(100) not null,
    telefono varchar(15),
    estado boolean not null default true,
    fechaRegistro   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    idjefe int null,
    idRol int not null,
    idSucursal int null,
    foreign key (idjefe) references Empleado(id),
    foreign key (idRol) references Rol(id),
    foreign key (idSucursal) references Sucursal(id)
);

-- cuenta de usuario del empleado
CREATE TABLE CuentaUsuario (
    id             INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idEmpleado           INTEGER NOT NULL UNIQUE,
    usuario              VARCHAR(50) NOT NULL UNIQUE,
    correo               VARCHAR(150) NOT NULL UNIQUE,
    passwordHash         VARCHAR(255),
    googleSub            VARCHAR(255) UNIQUE,
    intentosFallidos     INTEGER NOT NULL DEFAULT 0,
    bloqueado            BOOLEAN NOT NULL DEFAULT FALSE,
    bloqueadoHasta       TIMESTAMP NULL,
    fechaCreacion        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ultimoAcceso         TIMESTAMP NULL,
    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id)
);

-- adicionando la clave foranea de idEmpleado en la tabla Sucursal
alter table Sucursal
add constraint fk_sucursal_empleado
foreign key (idEmpleadoGerente) references Empleado(id);

create table Categoria (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre varchar(100) not null,
    estado boolean not null default true
);

create table Producto (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre varchar(100) not null,
    descripcion varchar(200) not null,
    photo varchar(255),
    estado boolean not null default true,
    idCategoria int not null,
    foreign key (idCategoria) references Categoria(id)
);

-- creacion de unidad de medida
CREATE TABLE UnidadMedida (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    abreviatura VARCHAR(10) NOT NULL UNIQUE,
    tipo VARCHAR(20) NOT NULL,
    estado BOOLEAN NOT NULL DEFAULT TRUE
);

-- creacion de insumos
CREATE TABLE Insumo (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255),
    idUnidadMedida INT NOT NULL,
    estado BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (idUnidadMedida) REFERENCES UnidadMedida(id)
);

-- crear la relacion de DetalleReceta
CREATE TABLE DetalleReceta (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idProducto INT NOT NULL,
    idInsumo INT NOT NULL,
    cantidad NUMERIC(12,3) NOT NULL,
    FOREIGN KEY (idProducto) REFERENCES Producto(id),
    FOREIGN KEY (idInsumo) REFERENCES Insumo(id),
        UNIQUE (idProducto, idInsumo),
        CHECK (cantidad > 0)
);

-- Relación muchos a muchos entre Sucursal y Producto
create table sucursal_producto (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idSucursal int not null,
    idProducto int not null,
    PrecioProducto decimal(10, 2) not null,
    disponibilidad boolean not null default true,
    foreign key (idSucursal) references Sucursal(id),
    foreign key (idProducto) references Producto(id),
    UNIQUE (idSucursal, idProducto),
    CHECK (PrecioProducto >= 0)
);

-- el inventario por sucursal
CREATE TABLE InventarioSucursal (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idSucursal INT NOT NULL,
    idInsumo INT NOT NULL,
    cantidad NUMERIC(12,3) NOT NULL DEFAULT 0,
    cantidadMinima NUMERIC(12,3),
    fechaActualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, 
        FOREIGN KEY (idSucursal)
        REFERENCES Sucursal(id),

        FOREIGN KEY (idInsumo)
        REFERENCES Insumo(id),
        UNIQUE (idSucursal, idInsumo),
        CHECK (cantidad >= 0),
        CHECK (cantidadMinima IS NULL  OR cantidadMinima >= 0)
);

CREATE TYPE tipoMovimientoInventario AS ENUM ('ENTRADA', 'SALIDA', 'AJUSTE');

-- el MovimientoInventario
CREATE TABLE MovimientoInventario (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idInventarioSucursal INT NOT NULL,
    tipoMovimiento tipoMovimientoInventario NOT NULL,
    cantidad NUMERIC(12,3) NOT NULL,
    cantidadAnterior NUMERIC(12,3) NOT NULL,
    cantidadNueva NUMERIC(12,3) NOT NULL,
    fechaMovimiento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    idEmpleado INT,
    observacion VARCHAR(255),
        FOREIGN KEY (idInventarioSucursal)
        REFERENCES InventarioSucursal(id),
        FOREIGN KEY (idEmpleado)
        REFERENCES Empleado(id),
        CHECK (cantidad > 0)
);

-- Registra los cambios de precio de los productos
create table historialProducto (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fecha_registro TIMESTAMP not null,
    precioAnterior decimal(10, 2) not null,
    precioNuevo decimal(10, 2) not null,
    idProductoSucursal int not null,
    foreign key (idProductoSucursal) references sucursal_producto(id)
);


create table Mesa (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    numeroMesa int not null,  
    capacidad int not null default 4,
    estado boolean not null default true,
    idSucursal INT NOT NULL,
    FOREIGN KEY (idSucursal) REFERENCES Sucursal(id),
    UNIQUE (idSucursal, numeroMesa)
);

-- registra los pedidos realizados por los clientes
CREATE TYPE tipoEstado_pedido AS ENUM ('PENDIENTE', 'ANULADO', 'EJECUTADO');

CREATE TYPE tipoEstado_venta AS ENUM ('PENDIENTE', 'PAGADA', 'RECHAZADO', 'ANULADO');
CREATE TYPE tipoEstado_pago AS ENUM ('PENDIENTE', 'APROBADO', 'RECHAZADO', 'ANULADO');

CREATE TABLE MetodoPago (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    gateway VARCHAR(50) NULL -- pasarela asociada: EFECTIVO, TARJETA, BANCO
);

CREATE TABLE Mesa (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    numeroMesa INT NOT NULL,
    capacidad INT NOT NULL,
    estado BOOLEAN NOT NULL DEFAULT TRUE,
    idSucursal INT NOT NULL,
    FOREIGN KEY (idSucursal) REFERENCES Sucursal(id)
);

INSERT INTO MetodoPago (nombre, activo, gateway) VALUES
('Efectivo', TRUE, 'EFECTIVO'),
('Tarjeta de crédito', TRUE, 'TARJETA'),
('Transferencia bancaria', TRUE, 'BANCO');

CREATE TYPE tipo_pedido AS ENUM ('MESA','PARA_LLEVAR');

CREATE TABLE pedido (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nroPedido INT NOT NULL,
    fecha TIMESTAMP NOT NULL,
    horarecogida TIMESTAMP NULL, -- hora definida para ordenar y recoger el pedido
    total DECIMAL(10,2) NOT NULL,
    estadoPedido tipoEstado_pedido NOT NULL DEFAULT 'PENDIENTE',
    tipoPedido tipo_pedido NOT NULL DEFAULT 'MESA',
    idSucursal INT NOT NULL,
    idEmpleado INT NOT NULL,
    idMesa INT NULL,
    idAperturaCaja INT NULL, -- jornada de caja en la que se registró el pedido (reinicia nroPedido)
    subtotalPedido DECIMAL(10,2) NOT NULL,
    descuentoPedido DECIMAL(10,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (idSucursal) REFERENCES Sucursal(id),
    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id),
    FOREIGN KEY (idMesa) REFERENCES Mesa(id),
    FOREIGN KEY (idAperturaCaja) REFERENCES AperturaCaja(id),
    CHECK (subtotalPedido >= 0),
    CHECK (descuentoPedido >= 0),
    CHECK (total >= 0)
);

CREATE TABLE detallePedido (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cantidad INT NOT NULL,
    precioUnitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    descuento DECIMAL(10,2) NOT NULL DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    idPedido INT NOT NULL,
    idProductoSucursal INT NULL,
    idPromocion INT NULL,
    FOREIGN KEY (idPedido) REFERENCES pedido(id),

    FOREIGN KEY (idProductoSucursal) REFERENCES sucursal_producto(id),
    FOREIGN KEY (idPromocion) REFERENCES Promocion(id),

    CHECK (cantidad > 0),
    CHECK (precioUnitario >= 0),
    CHECK (subtotal >= 0),
    CHECK (descuento >= 0),
    CHECK (total >= 0),
    CHECK (idProductoSucursal IS NOT NULL OR idPromocion IS NOT NULL)
);


-- registra los descuentos(Promocion) aplicados a los productos en un periodo de tiempo determinado
create type tipoDescuento as enum('PORCENTAJE', 'MONTO_FIJO');
CREATE TABLE Promocion (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    tipoDescuento tipoDescuento NOT NULL default 'MONTO_FIJO',
    valorDescuento DECIMAL(10,2) NOT NULL,
    fechaInicio TIMESTAMP NOT NULL,
    fechaFin TIMESTAMP NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    photo VARCHAR(255), -- imagen publicitaria de la promoción (storage/public)
    CHECK (valorDescuento >= 0),
    CHECK (fechaFin > fechaInicio),
    CHECK (tipoDescuento = 'MONTO_FIJO' OR valorDescuento <= 100)
);

-- Una promoción puede aplicarse a varios productos y un producto puede participar en varias promociones.
-- cantidad_producto indica cuántas unidades del producto incluye la promoción
-- (ej.: 2 simples a S/ 25 en lugar del precio unitario).
CREATE TABLE promocion_sucursal_producto (
    idPromocion INT NOT NULL,
    idSucursalProducto INT NOT NULL,
    cantidad_producto INT NOT NULL DEFAULT 1,
    PRIMARY KEY (idPromocion, idSucursalProducto),
    FOREIGN KEY (idPromocion) REFERENCES Promocion(id),
    FOREIGN KEY (idSucursalProducto) REFERENCES sucursal_producto(id),
    CHECK (cantidad_producto >= 1)
);

-- Registra los métodos de pago disponibles para las ventas
create table MetodoPago (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre varchar(50) not null unique,
    activo BOOLEAN NOT NULL DEFAULT true,
    gateway varchar(50) not null
);

-- Registra cada venta realizada por un empleado usando un método de pago
create type tipoEstadoVenta as enum('PENDIENTE','PAGADA','RECHAZADO','ANULADO');
create table Venta (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fechaVenta Timestamp not null,
    totalVenta decimal(10, 2) not null,
    estadoVenta tipoEstadoVenta not null default 'PENDIENTE',
    idEmpleado int not null,
    idPedido int unique,
    foreign key (idEmpleado) references Empleado(id),
    foreign key (idPedido) references pedido(id)
);

CREATE TABLE Caja (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    idSucursal INT NOT NULL,
    FOREIGN KEY (idSucursal) REFERENCES Sucursal(id)
);



create type tipoEstadoCaja as enum('ABIERTA','CERRADA');
CREATE TABLE AperturaCaja (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fechaApertura timestamp NOT NULL,
    montoInicial DECIMAL(10,2) NOT NULL,
    estado tipoEstadoCaja NOT NULL DEFAULT 'ABIERTA',
    idCaja INT NOT NULL,
    idEmpleado INT NOT NULL,

    FOREIGN KEY (idCaja) REFERENCES Caja(id),

    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id),

    CHECK (montoInicial >= 0)
);


-- genera o registra el tipo de pago para efectuar recibo
create type tipoEstadoPago as enum('PENDIENTE','APROBADO','RECHAZADO','ANULADO');
create table Pago (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idVenta int not null,
    idMetodoPago int not null,
    idAperturaCaja int not null,
    montoPago decimal(10,2) not null,
    estadoPago tipoEstadoPago NOT NULL DEFAULT 'PENDIENTE',
    montoRecibido DECIMAL(10,2) NULL,   -- el pago que realizo el cliente
    cambioEntregado DECIMAL(10,2) NOT NULL DEFAULT 0, -- el pago que devuelve el cajero
    referenciaExterna varchar(200),
    gateway varchar(50),
    codigoAutorizacion varchar(100),
    idTransaccion VARCHAR(200),
    ultimos4 varchar(4),
    marcaTarjeta varchar(30),
    fechaPago timestamp not null default current_timestamp,
    observacionPago varchar(200),
    foreign key (idVenta) references Venta(id),
    foreign key (idMetodoPago) references MetodoPago(id),
    foreign key (idAperturaCaja) references AperturaCaja(id)
);

-- qué caja/jornada lo generó, qué empleado lo realizó y, opcionalmente, qué venta originó el movimiento.
create type tipoMovimientoCaja as enum('INGRESO','EGRESO');
CREATE TABLE MovimientoCaja (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    fechaMovimiento timestamp not null,
    tipoMovimiento tipoMovimientoCaja NOT NULL,

    concepto VARCHAR(150) NOT NULL,
    monto DECIMAL(10,2) NOT NULL,
    observacion VARCHAR(250),

    idAperturaCaja INT NOT NULL,
    idEmpleado INT NOT NULL,

    FOREIGN KEY (idAperturaCaja) REFERENCES AperturaCaja(id),

    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id),

    CHECK (monto > 0)
);

CREATE TABLE CierreCaja (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fechaCierre timestamp NOT NULL,

    fondoInicial DECIMAL(10,2) NOT NULL,

    -- Ventas según medio de pago
    totalVentasEfectivo DECIMAL(10,2) NOT NULL DEFAULT 0,
    totalVentasQR DECIMAL(10,2) NOT NULL DEFAULT 0,
    totalVentasTarjeta DECIMAL(10,2) NOT NULL DEFAULT 0,
    totalVentas DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- Movimientos que afectan efectivo físico
    totalIngresos DECIMAL(10,2) NOT NULL DEFAULT 0,
    totalEgresos DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- Control físico de efectivo
    efectivoEsperado DECIMAL(10,2) NOT NULL,
    efectivoContado DECIMAL(10,2) NOT NULL,
    diferencia DECIMAL(10,2) NOT NULL,

    observacion VARCHAR(250),

    idAperturaCaja INT NOT NULL UNIQUE,
    idEmpleado INT NOT NULL,

    FOREIGN KEY (idAperturaCaja) REFERENCES AperturaCaja(id),

    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id)
);

CREATE TABLE Venta (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fechaVenta TIMESTAMP NOT NULL,
    totalVenta DECIMAL(10,2) NOT NULL,
    estadoVenta tipoEstado_venta NOT NULL DEFAULT 'PENDIENTE',
    idEmpleado INT NOT NULL,
    idPedido INT NOT NULL,
    FOREIGN KEY (idEmpleado) REFERENCES Empleado(id),
    FOREIGN KEY (idPedido) REFERENCES pedido(id),
    CHECK (totalVenta >= 0)
);

CREATE TABLE Pago (
    id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idVenta INT NOT NULL,
    idMetodoPago INT NOT NULL,
    idAperturaCaja INT NOT NULL,
    montoPago DECIMAL(10,2) NOT NULL,
    estadoPago tipoEstado_pago NOT NULL DEFAULT 'PENDIENTE',
    montoRecibido DECIMAL(10,2),
    cambioEntregado DECIMAL(10,2),
    referenciaExterna VARCHAR(100),
    gateway VARCHAR(50),
    codigoAutorizacion VARCHAR(50),
    idTransaccion VARCHAR(50),
    ultimos4 VARCHAR(4),
    marcaTarjeta VARCHAR(30),
    fechaPago TIMESTAMP,
    observacionPago VARCHAR(250),
    FOREIGN KEY (idVenta) REFERENCES Venta(id),
    FOREIGN KEY (idMetodoPago) REFERENCES MetodoPago(id),
    FOREIGN KEY (idAperturaCaja) REFERENCES AperturaCaja(id),
    CHECK (montoPago >= 0)
);

CREATE TABLE BitacoraAcceso (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idEmpleado INT,
    fechaHora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tipoAcceso VARCHAR(20) NOT NULL,
    equipo VARCHAR(100),
    ip VARCHAR(45),
    resultado VARCHAR(20) NOT NULL,
    detalle VARCHAR(255),
    CONSTRAINT fk_bitacora_acceso_empleado
        FOREIGN KEY (idEmpleado)
        REFERENCES Empleado(id),
    CONSTRAINT ck_bitacora_acceso_tipo
        CHECK (tipoAcceso IN ('LOGIN', 'LOGOUT')),
    CONSTRAINT ck_bitacora_acceso_resultado
        CHECK (resultado IN ('EXITOSO', 'FALLIDO'))
);

CREATE TABLE BitacoraAccion (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idEmpleado INT NOT NULL,
    idPermiso INT NOT NULL,
    fechaHora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    accion VARCHAR(10) NOT NULL,
    tablaAfectada VARCHAR(100),
    idRegistroAfectado BIGINT,
    equipo VARCHAR(150),
    ip VARCHAR(45),
    resultado VARCHAR(255) NOT NULL DEFAULT 'EXITOSO',
    CONSTRAINT fk_bitacora_accion_empleado
        FOREIGN KEY (idEmpleado)
        REFERENCES Empleado(id),
    CONSTRAINT fk_bitacora_accion_permiso
        FOREIGN KEY (idPermiso)
        REFERENCES Permiso(id)
);


create table configuracion_sistema(
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    clave varchar(100) unique,
    valor text,
    descripcion varchar(255),
    estadoo boolean default TRUE,
);

DROP TABLE IF EXISTS
    BitacoraAccion,
    BitacoraAcceso,
    CierreCaja,
    MovimientoCaja,
    Pago,
    AperturaCaja,
    Caja,
    Venta,
    detallePedido,
    pedido,
    promocion_sucursal_producto,
    Promocion,
    Mesa,
    historialProducto,
    MovimientoInventario,
    InventarioSucursal,
    sucursal_producto,
    DetalleReceta,
    Insumo,
    UnidadMedida,
    Producto,
    Categoria,
    HorarioSucursal,
    CuentaUsuario,
    Empleado,
    Sucursal,
    DiaAtencion,
    RolPermiso,
    Permiso,
    MetodoPago,
    Rol
CASCADE;
DROP TYPE IF EXISTS
    tipoMovimientoInventario,
    tipoEstado_pedido,
    tipo_pedido,
    tipoDescuento,
    tipoEstadoVenta,
    tipoEstadoCaja,
    tipoEstadoPago,
    tipoMovimientoCaja
CASCADE;



insert into DiaAtencion (nombreDia, numeroDia) values
('Lunes', 1),
('Martes', 2),
('Miércoles', 3),
('Jueves', 4),
('Viernes', 5),
('Sábado', 6),
('Domingo', 7);

insert into MetodoPago (nombre) values
('Efectivo'),
('Tarjeta de crédito'),
('Transferencia bancaria');

insert into Rol (claveRol, nombreRol) values
('ADMINISTRADOR', 'Administrador'),
('GERENTE', 'Gerente'),
('CAJERO', 'Cajero'),
('MESERO', 'Mesero');

INSERT INTO Permiso (codigo, nombre) VALUES
('50','Registrar o modificar configuración del sistema'),
-- EMPLEADOS
('100', 'Crear nuevo empleado'),
('101', 'Editar empleados'),
('102', 'Listar empleados'),
('105', 'Dar de baja a empleado'),
('106', 'Modificar contraseña de empleado'),
('107', 'Listar empleados activos'),
('108', 'Listar empleados inactivos'),
('150', 'Listar bitácora de acceso de empleados'),
('151', 'Listar bitácora de acciones de empleados'),

-- SUCURSALES
('200', 'Crear nueva sucursal'),
('201', 'Editar datos de sucursal'),
('202', 'Listar sucursales'),
('204', 'Asignar gerente a sucursal'),
('205', 'Dar de baja a sucursal'),
('206', 'Asignar empleado a sucursal'),
('207', 'Quitar empleado de sucursal'),
('208', 'Listar empleados de sucursal'),

-- MESAS Y HORARIOS
('210', 'Registrar mesa'),
('211', 'Editar mesa'),
('212', 'Listar mesas'),
('215', 'Dar de baja a mesa'),
('220', 'Registrar horario de atención de sucursal'),
('221', 'Editar horario de atención de sucursal'),
('222', 'Listar horario de atención de sucursal'),
('225', 'Dar de baja a horario de atención de sucursal'),

-- CATEGORÍAS Y PRODUCTOS
('300', 'Crear nueva categoría'),
('301', 'Editar categoría'),
('302', 'Listar categorías'),
('305', 'Dar de baja a categoría'),

('310', 'Crear producto'),
('311', 'Editar producto'),
('312', 'Listar productos'),
('315', 'Dar de baja a producto'),
('316', 'Registrar precio y disponibilidad de producto por sucursal'),
('317', 'Listar productos disponibles de sucursal'),
('318', 'Editar precio de producto de sucursal'),
('319', 'Deshabilitar disponibilidad de producto'),
('320', 'Listar historial de producto por sucursal'),

-- UNIDAD DE MEDIDA, INSUMOS E INVENTARIOS
('330', 'crear unidad de medida'),
('331', 'editar unidad de medida'),
('335', 'Dar de baja unidad de medida'),
('336', 'crear insumo'),
('337', 'editar datos de insumo'),
('338', 'dar de baja insumo'),

('340', 'crear detalle de receta'),
('341', 'modificar detalle de receta'),
('345', 'dar de baja detalle de receta'),

('346', 'Registrar movimiento de inventario'),
('347', 'Listar inventario y movimientos de sucursal'),
('348', 'Establecer cantidad mínima de inventario'),

-- PROMOCIONES Y CUPONES
('350', 'Crear promoción en una sucursal'),
('351', 'Editar promoción de sucursal'),
('352', 'Listar promociones'),
('355', 'Dar de baja a promoción de sucursal'),

-- CAJA
('400', 'Crear nueva caja'),
('401', 'Editar datos de caja'),
('402', 'Listar cajas'),
('405', 'Dar de baja a caja'),

('410', 'Crear apertura de caja'),
('411', 'Editar apertura de caja'),
('412', 'Listar historial de aperturas por caja'),
('415', 'Dar de baja a apertura de caja'),

-- MOVIMIENTOS Y CIERRE
('420', 'Registrar movimiento de caja'),
('421', 'Editar movimiento de caja'),
('422', 'Listar movimientos de caja'),
('425', 'Dar de baja a movimiento de caja'),

('430', 'Crear cierre de caja'),
('436', 'Ver detalle de cierre de caja'),
('437', 'Listar historial de cierre de caja'),

-- VENTAS Y PAGOS
('440', 'Registrar venta'),
('441', 'Editar venta'),
('442', 'Listar ventas'),
('445', 'Anular venta'),
('446', 'Registrar método de pago'),
('447', 'Dar de baja a método de pago'),
('448', 'Listar métodos de pago'),

-- PEDIDOS
('500', 'Crear pedido'),
('501', 'Editar pedido'),
('502', 'Listar pedidos'),
('505', 'Dar de baja a pedido'),
('506', 'Editar detalle de pedido');

-- insertar permisos a los roles de tipo MESERO
INSERT INTO RolPermiso (idRol, idPermiso)
SELECT r.id, p.id
FROM Rol r, Permiso p
WHERE r.claveRol = 'MESERO'
  AND p.codigo IN ('106', '212', '302', '500','501','502','505','506');

-- insertar permisos a los roles de tipo CAJERO
INSERT INTO RolPermiso (idRol, idPermiso)
SELECT (SELECT id FROM Rol WHERE claveRol = 'CAJERO'), id
FROM Permiso WHERE codigo IN ('106', '210','211','212','215','222', '302', '317','319', '352', 
    '402','410','411','412','420','421','422','425','430','436','437','440','441','442','445', '448', '500','501','502','505','506', '346', '347', '348');  

-- insertar permisos a los roles de tipo GERENTE
INSERT INTO RolPermiso (idRol, idPermiso)
SELECT (SELECT id FROM Rol WHERE claveRol = 'GERENTE'), id
FROM Permiso WHERE codigo IN (
    '100', '101', '102', '105', '106',

    '201', '206', '207', '208',

    '210','211','212','215', '220', '221', '222', '225',

    '316', '317', '318', '319', '320', '330', '331', '335', '336', '337', '338', '340', '341', '345', '346', '347', '348', '350', '351', '352', '355', 

    '400', '401', '402', '405', '410', '411', '412', '415', '420', '421', '422', '425', '430', '436', '437','440','441','442','445', '448', '500','501','502','505','506');


-- insertando las categorias
INSERT INTO Categoria (nombre) values ('HAMBURGUESAS'), ('VARIADOS'), ('PORCIONES'), ('GASEOSAS'), ('BEBIDA'),('ASADO');

-- insertando los productos
INSERT INTO Producto (nombre, descripcion, idCategoria )
SELECT datos.nombreProducto, datos.descripcion, c.id FROM( VALUES
        -- HAMBURGUESAS
        ('ECO SIMPLE', 'Deliciosa carne Premium 135gr, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('ECO SUPER', 'Deliciosa carne premium 135 gr.,tocino,ahumado, pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa','HAMBURGUESAS'),
        ('ECO FULL', 'Deliciosa carne Premium 135gr, tocino ahumado, huevo frito, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('EL TOXICO', 'Deliciosa carne premium, papas rusticas willi, tocino ahumado, mermelada de locoto, cebolla crispy, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('ECO DOGOR', 'Deliciosa carne Premium 135gr, choclito, salchica, viena, queso extra, pan tostado , tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('CHIKIWILLI', 'Deliciosa carne de pollo broaster, papas rusticas willy, Pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('CHIKILOCO', 'Deliciosa carne de pollo broaster, papas rusticas willi, tocino ahumado. pico de gallo, nachos, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('SIMPLE', 'Deliciosa carne Premium 135gr, papas rusticas willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('DOBLE', 'Deliciosa carne Premium 270gr, papas rusticas willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('FULL', 'Deliciosa carne Premium 135gr, tocino ahumado, huevo frito, papas rusticas Willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('DOGOR', 'Deliciosa carne Premium 135gr, choclito salchicha Viena, queso extra, papas rusticas Willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa','HAMBURGUESAS'),
        ('SUPER', 'Deliciosa carne premium 135 gr.,tocino ahumado, papas rusticas Willi,  Pan brioche de pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa','HAMBURGUESAS'),
        ('TOXICA', 'Deliciosa carne premium 135 gr.,tocino ahumado, pico de gallo, nachos picantes, jalapeño, papas rusticas Wili, Pan brioche de pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa','HAMBURGUESAS'),
        -- VARIADOS
        ('Salchipapas','Papas rusticas willi, salchicja Viena Santa Fe bañadas de salsa de la casa y espolvoreada de queso rallado','VARIADOS'),
        ('Willi Nuggets','Tiritas de pollo willi rebosada acompañado con papas rusticas y su salsa de la casa','VARIADOS'),
        ('Lomitos','Pan de oregano, carne lomito, lechuga, tomate, cebolla, papas rusticas wili y su salsa de la casa','VARIADOS'),
        ('Pepito','Pan de oregano, carne picada de hamburguesa, salchicha viena, choclito, bañada de salsa y espolvoreada de queso rallado con papa rustica y su salsa','VARIADOS'),
        ('Willi Nachos','Nachos picantes acompañadado con carne de hamburguesa, pico de gallo, choclito, queso muzzarela, limones en gajos y su salsa de la casa','VARIADOS'),
        ('Willi Tacos','Tortillas de maiz tostadas acompañada con carne de hamburguesa, queso muzarela, pico de gallo, choclitos, tiras de lechuga, papas rusticas y su salsa de la casa','VARIADOS'),
        ('Crispy king Wili','Pollo a la Broaster acompañado con arroz primavera y porcion de papas rusticas y porcion de papas rusticas willi con su deliciosa salsa de la casa','VARIADOS'),
        ('Burrito','Tortillas de maiz tostadas acompañada con carne de hamburguesa, pollo o mixto, queso criollo, pico de gallo, chiclito, toras de lechuga, papas rusticas y su salsa de la casa','VARIADOS'),
        
        -- PORCIONES
        ('Papas','Porcion de papas fritas crocantes','PORCIONES'),
        ('Hamburguesas','Porcion de de carne de Hamburguesa','PORCIONES'),
        ('Tocino','Porcion de tocino frito crocantes','PORCIONES'),
        ('Nuggets','Porcion de nuggets frito crocantes','PORCIONES'),
        ('Huevo','Porcion de huevo frito crocantes','PORCIONES'),
        ('Lomito','Porcion de carne de lomito frito crocantes','PORCIONES'),
        ('Queso','Porcion de queso crocantes','PORCIONES'),
        ('Salchicha','Porcion de salchicha crocantes','PORCIONES'),
        -- GASEOSAS
        ('Soda 2.5L','Gaseosa de 2.5L Fria','GASEOSAS'),
        ('Agua Vital','gaseosa vital','GASEOSAS'),
        ('Soda 1.5L','Gaseosa de 1.5L Fria','GASEOSAS'),
        ('Personal','Gaseosa de 500ml Fria','GASEOSAS'),
        ('Simba','Gaseosa de 2L Fria','GASEOSAS'),
        ('Peque','Gaseosa de 250ml Fria','GASEOSAS'),
        ('Paceña','Bebida alcoholica Fria','GASEOSAS'),
        ('Soda 2L','Gaseosa de 2L Fria','GASEOSAS'),
        ('Popular','Gaseosa de 500ml Fria','GASEOSAS'),
        ('Aquarios','Gaseosa de 2L Fria','GASEOSAS'),
        ('Corona','Gaseosa Alcoholica Fria','GASEOSAS'),
        -- BEBIDA
        ('Refresco Jarra Grande', 'bebida de jarra grande','BEBIDA'),
        ('Refresco Jarra Mediana', 'bebida de jarra Mediana','BEBIDA'),
        ('Refresco vaso', 'bebida en vaso','BEBIDA'),
        -- ASADO
        ('Entraña','La entraña es un corte de diafragma de la res, famoso por su intenso sabor y textura jugosa, ideal para quienes disfrutam un carne una carne con mucho caracter','ASADO')
) AS datos(nombreProducto, descripcion, nombreCategoria)
INNER JOIN Categoria c ON c.nombre = datos.nombreCategoria;


INSERT INTO UnidadMedida (nombre, abreviatura, tipo) VALUES
('Kilogramo', 'kg', 'PESO'),
('Litro', 'L', 'VOLUMEN'),
('Unidad', 'und', 'CONTEO');

-- ==========================================
-- INSUMOS
-- ==========================================

INSERT INTO Insumo
(nombre, descripcion, idUnidadMedida)
VALUES
('Carne molida',
 'Carne molida para la preparación de hamburguesas',
 1),

('Papa',
 'Papa utilizada para preparar las porciones de papas fritas',
 1),

('Cebolla',
 'Cebolla fresca para hamburguesas y otros productos',
 1),

('Tomate',
 'Tomate fresco utilizado en hamburguesas',
 1),

('Lechuga',
 'Lechuga fresca para hamburguesas',
 1),

('Queso',
 'Queso utilizado para hamburguesas',
 1),

('Aceite',
 'Aceite vegetal utilizado para freír',
 2),

('Pan de hamburguesa',
 'Pan utilizado para la preparación de hamburguesas',
 3),

('Huevo',
 'Huevos utilizados en diferentes preparaciones',
 3),

('Sal',
 'Sal utilizada para condimentar alimentos',
 1);


-- este procedimiento almacenado registrara el tipo de acceso que esta realizando el usuario
CREATE OR REPLACE PROCEDURE registrar_acceso(
    p_id_empleado INTEGER,
    p_tipo_acceso VARCHAR(20),
    p_equipo VARCHAR(100),
    p_ip VARCHAR(45),
    p_resultado VARCHAR(20),
    p_detalle VARCHAR(255)
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO bitacoraacceso (idempleado, tipoacceso, equipo, ip, resultado, detalle)
    VALUES (
        p_id_empleado,
        p_tipo_acceso,
        p_equipo,
        p_ip,
        p_resultado,
        LEFT(p_detalle, 255)
    );
END;
$$;

-- crear un procedimiento almacenado para registrar una accion
CREATE OR REPLACE PROCEDURE registrar_accion(
    p_id_empleado INTEGER,
    p_accion VARCHAR(10),
    p_tabla_afectada VARCHAR(100),
    p_id_registro_afectado BIGINT,
    p_codigo_permiso VARCHAR(100),
    p_resultado VARCHAR(255),
    p_equipo VARCHAR(150),
    p_ip VARCHAR(45)
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_id_permiso INTEGER;
BEGIN
    v_id_permiso := COALESCE(
        (SELECT id FROM permiso WHERE codigo = p_codigo_permiso AND estado = TRUE),
        (SELECT id FROM permiso WHERE estado = TRUE ORDER BY id LIMIT 1),
        1
    );

    INSERT INTO bitacoraaccion (idempleado, idpermiso, accion, tablaafectada, idregistroafectado, equipo, ip, resultado)
    VALUES (
        p_id_empleado,
        v_id_permiso,
        p_accion,
        p_tabla_afectada,
        p_id_registro_afectado,
        p_equipo,
        p_ip,
        COALESCE(p_resultado, 'EXITOSO')
    );
END;
$$;

-- si es true paso los 15 min lo desbloquea
CREATE OR REPLACE FUNCTION verificar_bloqueo_y_desbloquear(p_id_cuenta int)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
DECLARE
    v_hasta TIMESTAMP;
BEGIN
	SELECT cu.bloqueadohasta INTO v_hasta FROM cuentausuario cu WHERE cu.idempleado = p_id_cuenta;
    if now() > v_hasta then
        UPDATE cuentausuario cu SET bloqueado = FALSE, bloqueadohasta = NULL, intentosfallidos = 0
		WHERE cu.idempleado = p_id_cuenta;
        RETURN TRUE;
	end if;
    return false;
END;
$$;

-- reasigna la cadena de mando cuando el gerente de una sucursal cambia:
-- los cajeros/meseros del antiguo gerente pasan a depender del nuevo,
-- y el antiguo gerente pasa a depender del nuevo gerente.
CREATE OR REPLACE PROCEDURE reasignar_subordinados(
    p_jefe_anterior INTEGER,
    p_jefe_nuevo INTEGER,
    p_idsucursal INTEGER
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_id_rol_cajero INTEGER;
    v_id_rol_mesero INTEGER;
BEGIN
    IF p_jefe_anterior IS NOT DISTINCT FROM p_jefe_nuevo THEN
        RETURN;
    END IF;

    SELECT id INTO v_id_rol_cajero FROM rol WHERE claverol = 'CAJERO' LIMIT 1;
    SELECT id INTO v_id_rol_mesero FROM rol WHERE claverol = 'MESERO' LIMIT 1;

    -- Si el nuevo gerente dependía del antiguo (idjefe = antiguo), romper
    -- la referencia circular: el nuevo jefe queda sin jefe.
    IF p_jefe_nuevo IS NOT NULL THEN
        UPDATE empleado
           SET idjefe = NULL
         WHERE id = p_jefe_nuevo
           AND idjefe IS NOT DISTINCT FROM p_jefe_anterior;
    END IF;

    -- Reasignar al nuevo gerente TODOS los cajeros/meseros que dependían
    -- del antiguo gerente (estén en esta u otra sucursal).
    UPDATE empleado
       SET idjefe = p_jefe_nuevo
     WHERE idjefe IS NOT DISTINCT FROM p_jefe_anterior
       AND idrol IN (v_id_rol_cajero, v_id_rol_mesero)
       AND (p_jefe_nuevo IS NULL OR id <> p_jefe_nuevo);

    -- Los cajeros/meseros de ESTA sucursal que estén sin gerente (idjefe NULL)
    -- pasan a depender del nuevo gerente.
    UPDATE empleado
       SET idjefe = p_jefe_nuevo
     WHERE idsucursal = p_idsucursal
       AND idjefe IS NULL
       AND idrol IN (v_id_rol_cajero, v_id_rol_mesero)
       AND (p_jefe_nuevo IS NULL OR id <> p_jefe_nuevo);

    -- El antiguo gerente queda sin jefe.
    IF p_jefe_anterior IS NOT NULL THEN
        UPDATE empleado SET idjefe = NULL WHERE id = p_jefe_anterior;
    END IF;
END;
$$;

-- Cajas de sucursal: registro, actualización y baja con sus reglas de negocio.
-- Una sucursal admite como máximo dos cajas activas y el nombre no puede
-- repetirse dentro de la misma sucursal.
CREATE OR REPLACE FUNCTION registrar_caja(p_idsucursal INTEGER, p_nombre VARCHAR(100),p_activo BOOLEAN) RETURNS INTEGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_activas INTEGER;
    v_duplicado INTEGER;
    v_id INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_activas
      FROM caja
     WHERE idsucursal = p_idsucursal AND activo = TRUE;

    IF v_activas >= 2 THEN
        RAISE EXCEPTION 'La sucursal ya tiene dos cajas activas.';
    END IF;

    SELECT COUNT(*) INTO v_duplicado
      FROM caja
     WHERE idsucursal = p_idsucursal AND nombre = p_nombre;

    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una caja con ese nombre en esta sucursal.';
    END IF;

    INSERT INTO caja (nombre, idsucursal, activo)
    VALUES (p_nombre, p_idsucursal, p_activo)
    RETURNING id INTO v_id;

    RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION actualizar_caja(p_id INTEGER, p_idsucursal INTEGER, p_nombre VARCHAR(100), p_activo BOOLEAN) RETURNS VOID
LANGUAGE plpgsql
AS $$
DECLARE
    v_duplicado INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_duplicado
      FROM caja
     WHERE idsucursal = p_idsucursal
       AND nombre = p_nombre
       AND id <> p_id;

    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una caja con ese nombre en esta sucursal.';
    END IF;

    UPDATE caja
       SET nombre = p_nombre,
           activo = p_activo
     WHERE id = p_id;
END;
$$;

DROP FUNCTION IF EXISTS dar_baja_caja(INTEGER);

CREATE OR REPLACE PROCEDURE dar_baja_caja(p_id INTEGER, p_id_empleado INTEGER, p_codigo_permiso VARCHAR(100), p_equipo VARCHAR(150), p_ip VARCHAR(45))
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE caja SET activo = FALSE WHERE id = p_id;
    CALL registrar_accion(p_id_empleado, 'DELETE', 'caja', p_id, p_codigo_permiso, 'EXITOSO', p_equipo, p_ip);
END;
$$;

-- Mesas de sucursal: registro, actualización y baja con sus reglas de negocio.
-- El número de mesa no puede repetirse dentro de la misma sucursal.
CREATE OR REPLACE PROCEDURE registrar_mesa(p_idsucursal INTEGER, p_numeromesa INTEGER, p_capacidad INTEGER,p_estado BOOLEAN, p_id_empleado INTEGER,
    p_codigo_permiso VARCHAR(100), p_equipo VARCHAR(150), p_ip VARCHAR(45))
LANGUAGE plpgsql
AS $$
DECLARE
    v_id INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_id
      FROM mesa
     WHERE idsucursal = p_idsucursal AND numeromesa = p_numeromesa;

    IF v_id > 0 THEN
        RAISE EXCEPTION 'Ya existe una mesa con ese número en esta sucursal.';
    END IF;

    INSERT INTO mesa (numeromesa, capacidad, estado, idsucursal)
    VALUES (p_numeromesa, p_capacidad, p_estado, p_idsucursal)
    RETURNING id INTO v_id;

    CALL registrar_accion(p_id_empleado, 'CREATE', 'mesa', v_id, p_codigo_permiso,'EXITOSO', p_equipo, p_ip);
END;
$$;

CREATE OR REPLACE PROCEDURE actualizar_mesa(p_id INTEGER, p_idsucursal INTEGER, p_numeromesa INTEGER, p_capacidad INTEGER, p_estado BOOLEAN, p_id_empleado INTEGER,
    p_codigo_permiso VARCHAR(100), p_equipo VARCHAR(150), p_ip VARCHAR(45))
LANGUAGE plpgsql
AS $$
DECLARE
    v_duplicado INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_duplicado FROM mesa WHERE idsucursal = p_idsucursal AND numeromesa = p_numeromesa AND id <> p_id;
    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una mesa con ese número en esta sucursal.';
    END IF;
    UPDATE mesa SET numeromesa = p_numeromesa, capacidad = p_capacidad, estado = p_estado WHERE id = p_id;
    CALL registrar_accion(p_id_empleado, 'UPDATE', 'mesa', p_id, p_codigo_permiso, 'EXITOSO', p_equipo, p_ip);
END;
$$;

CREATE OR REPLACE PROCEDURE dar_baja_mesa( p_id INTEGER, p_id_empleado INTEGER, p_codigo_permiso VARCHAR(100), p_equipo VARCHAR(150), p_ip VARCHAR(45))
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE mesa SET estado = FALSE WHERE id = p_id;
    CALL registrar_accion( p_id_empleado, 'DELETE', 'mesa', p_id, p_codigo_permiso, 'EXITOSO', p_equipo, p_ip);
END;
$$;

-- Perfil del empleado: actualiza datos personales y de la cuenta de usuario,
-- resetea los intentos fallidos al cambiar la contraseña y registra en bitácora
-- solo las tablas que realmente cambiaron. El hash de la contraseña lo calcula
-- PHP (bcrypt) porque PostgreSQL no puede generarlo compatible con Laravel.
CREATE OR REPLACE PROCEDURE actualizar_perfil(p_id_empleado INTEGER, p_nombre VARCHAR(100), p_apellido VARCHAR(100), p_telefono VARCHAR(15), p_usuario VARCHAR(50),
    p_correo VARCHAR(150), p_password_hash VARCHAR(255), p_equipo VARCHAR(150), p_ip VARCHAR(45))
LANGUAGE plpgsql
AS $$
DECLARE
    v_nombre VARCHAR(100);
    v_apellido VARCHAR(100);
    v_telefono VARCHAR(15);
    v_id_cuenta INTEGER;
    v_usuario VARCHAR(50);
    v_correo VARCHAR(150);
    v_cambia_empleado BOOLEAN;
    v_cambia_cuenta BOOLEAN;
BEGIN
    SELECT nombre, apellido, telefono
      INTO v_nombre, v_apellido, v_telefono
      FROM empleado
     WHERE id = p_id_empleado;

    SELECT id, usuario, correo
      INTO v_id_cuenta, v_usuario, v_correo
      FROM cuentausuario
     WHERE idempleado = p_id_empleado;

    v_cambia_empleado := p_nombre IS DISTINCT FROM v_nombre
        OR p_apellido IS DISTINCT FROM v_apellido
        OR COALESCE(p_telefono, '') IS DISTINCT FROM COALESCE(v_telefono, '');

    v_cambia_cuenta := p_usuario IS DISTINCT FROM v_usuario
        OR p_correo IS DISTINCT FROM v_correo
        OR p_password_hash IS NOT NULL;

    UPDATE empleado
       SET nombre = p_nombre,
           apellido = p_apellido,
           telefono = p_telefono
     WHERE id = p_id_empleado;

    UPDATE cuentausuario
       SET usuario = p_usuario,
           correo = p_correo
     WHERE idempleado = p_id_empleado;

    IF p_password_hash IS NOT NULL THEN
        UPDATE cuentausuario
           SET passwordhash = p_password_hash,
               intentosfallidos = 0,
               bloqueado = FALSE,
               bloqueadohasta = NULL
         WHERE idempleado = p_id_empleado;
    END IF;

    IF v_cambia_empleado THEN
        CALL registrar_accion(p_id_empleado, 'UPDATE', 'empleado', p_id_empleado, '101', 'EXITOSO', p_equipo, p_ip);
    END IF;

    IF v_cambia_cuenta THEN
        CALL registrar_accion(p_id_empleado, 'UPDATE', 'cuentausuario', v_id_cuenta, '106', 'EXITOSO', p_equipo, p_ip);
    END IF;
END;
$$;

-- =============================================================================
-- APERTURA Y CIERRE DE CAJA (triggers)
-- -----------------------------------------------------------------------------
-- 1. trg_validar_apertura_caja: impide abrir DOS jornadas a la vez en la misma
--    caja (una sola apertura en estado ABIERTA por caja).
-- 2. trg_crear_cierre_inicial: al abrir la caja se crea automáticamente el
--    CierreCaja provisional (totales en 0 y efectivo esperado = fondo inicial);
--    así la apertura "produce" sus parámetros iniciales de cierre al insertarse.
-- 3. trg_calcular_parametros_cierre: recalcula automáticamente el cierre a
--    partir de los pagos en estado APROBADO de la apertura (separados en
--    efectivo, QR y tarjeta por el nombre del método de pago), de los
--    movimientos de caja (ingresos/egresos) y del fondo inicial de la apertura.
--    efectivoEsperado = fondoInicial + ventasEfectivo + ingresos - egresos.
--    diferencia = efectivoContado - efectivoEsperado.
-- =============================================================================

CREATE OR REPLACE FUNCTION fn_validar_apertura_caja() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_abiertas INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA';
    ELSE
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA'
           AND id <> NEW.id;
    END IF;

    IF v_abiertas > 0 THEN
        RAISE EXCEPTION 'Ya existe una apertura de caja abierta para esta caja; debes cerrarla antes de abrir una nueva jornada.';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validar_apertura_caja
BEFORE INSERT OR UPDATE ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_validar_apertura_caja();

CREATE OR REPLACE FUNCTION fn_crear_cierre_inicial() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO cierrecaja (
        fechacierre, fondoinicial,
        totalventasefectivo, totalventasqr, totalventastarjeta, totalventas,
        totalingresos, totalegresos,
        efectivoesperado, efectivocontado, diferencia,
        observacion, idaperturacaja, idempleado
    ) VALUES (
        NEW.fechaapertura, NEW.montoinicial,
        0, 0, 0, 0,
        0, 0,
        NEW.montoinicial, NEW.montoinicial, 0,
        'Cierre provisional: la jornada aún está en curso.', NEW.id, NEW.idempleado
    );
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_crear_cierre_inicial
AFTER INSERT ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_crear_cierre_inicial();

CREATE OR REPLACE FUNCTION fn_calcular_parametros_cierre() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_efectivo NUMERIC(10,2) := 0;
    v_qr       NUMERIC(10,2) := 0;
    v_tarjeta  NUMERIC(10,2) := 0;
    v_ventas   NUMERIC(10,2) := 0;
    v_ingresos NUMERIC(10,2) := 0;
    v_egresos  NUMERIC(10,2) := 0;
    v_fondo    NUMERIC(10,2) := 0;
BEGIN
    SELECT COALESCE(SUM(CASE WHEN LOWER(mp.nombre) = 'efectivo' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) <> 'efectivo' AND LOWER(mp.nombre) NOT LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0)
      INTO v_efectivo, v_tarjeta, v_qr
      FROM pago p
      JOIN metodopago mp ON mp.id = p.idmetodopago
     WHERE p.idaperturacaja = NEW.idaperturacaja
       AND p.estadopago = 'APROBADO';

    v_ventas := v_efectivo + v_qr + v_tarjeta;

    SELECT COALESCE(SUM(monto), 0)
      INTO v_ingresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'INGRESO';

    SELECT COALESCE(SUM(monto), 0)
      INTO v_egresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'EGRESO';

    SELECT COALESCE(montoinicial, 0)
      INTO v_fondo
      FROM aperturacaja
     WHERE id = NEW.idaperturacaja;

    NEW.fondoinicial := v_fondo;
    NEW.totalventasefectivo := v_efectivo;
    NEW.totalventasqr := v_qr;
    NEW.totalventastarjeta := v_tarjeta;
    NEW.totalventas := v_ventas;
    NEW.totalingresos := v_ingresos;
    NEW.totalegresos := v_egresos;
    NEW.efectivoesperado := v_fondo + v_efectivo + v_ingresos - v_egresos;
    NEW.diferencia := NEW.efectivocontado - NEW.efectivoesperado;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_calcular_parametros_cierre
BEFORE INSERT OR UPDATE ON cierrecaja
FOR EACH ROW EXECUTE FUNCTION fn_calcular_parametros_cierre();

-- Cada pago aprobado (insert/update/delete) refresca los totales del cierre en curso,
-- invocando el BEFORE UPDATE de fn_calcular_parametros_cierre sobre la caja abierta.
CREATE OR REPLACE FUNCTION fn_refrescar_cierre_por_pago() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_refrescar_cierre_por_pago
AFTER INSERT OR UPDATE OR DELETE ON pago
FOR EACH ROW EXECUTE FUNCTION fn_refrescar_cierre_por_pago();

-- Cada ingreso/egreso (insert/update/delete) también refresca los totales del
-- cierre en curso usando el mismo patrón de "touch" sobre cierrecaja.
CREATE OR REPLACE FUNCTION fn_refrescar_cierre_por_movimiento() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_refrescar_cierre_por_movimiento
AFTER INSERT OR UPDATE OR DELETE ON movimientocaja
FOR EACH ROW EXECUTE FUNCTION fn_refrescar_cierre_por_movimiento();

