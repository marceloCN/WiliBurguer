SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- Tipos ENUM
CREATE TYPE tipo_pedido AS ENUM ('MESA', 'PARA_LLEVAR');
CREATE TYPE tipodescuento AS ENUM ('PORCENTAJE', 'MONTO_FIJO');
CREATE TYPE tipoestado_pedido AS ENUM ('PENDIENTE', 'ANULADO', 'EJECUTADO');
CREATE TYPE tipoestadocaja AS ENUM ('ABIERTA', 'CERRADA');
CREATE TYPE tipoestadopago AS ENUM ('PENDIENTE', 'APROBADO', 'RECHAZADO', 'ANULADO');
CREATE TYPE tipoestadoventa AS ENUM ('PENDIENTE', 'PAGADA', 'RECHAZADO', 'ANULADO');
CREATE TYPE tipomovimientocaja AS ENUM ('INGRESO', 'EGRESO');
CREATE TYPE tipomovimientoinventario AS ENUM ('ENTRADA', 'SALIDA', 'AJUSTE');

-- Creacion de tablas (PK y FK inline; ciclos diferidos al final)
CREATE TABLE rol (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    claverol varchar(50) NOT NULL,
    nombrerol varchar(50) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (claverol)
);

CREATE TABLE empleado (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    apellido varchar(100) NOT NULL,
    telefono varchar(15),
    estado boolean DEFAULT true NOT NULL,
    fecharegistro timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    idjefe int,
    idrol int NOT NULL,
    idsucursal int,
    PRIMARY KEY (id),
    FOREIGN KEY (idjefe) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idrol) REFERENCES rol (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE sucursal (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    direccion varchar(200) NOT NULL,
    telefono varchar(15) NOT NULL,
    latitud decimal(10,8) NOT NULL,
    longitud decimal(11,8) NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    idempleadogerente int,
    PRIMARY KEY (id),
    FOREIGN KEY (idempleadogerente) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE caja (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    idsucursal int NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE aperturacaja (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    fechaapertura timestamp NOT NULL,
    montoinicial decimal(10,2) NOT NULL,
    estado tipoestadocaja DEFAULT 'ABIERTA'::tipoestadocaja NOT NULL,
    idcaja int NOT NULL,
    idempleado int NOT NULL,
    PRIMARY KEY (id),
    CHECK ((montoinicial >= (0)::numeric)),
    FOREIGN KEY (idcaja) REFERENCES caja (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE bitacoraacceso (
    id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
    idempleado int,
    fechahora timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tipoacceso varchar(20) NOT NULL,
    equipo varchar(100),
    ip varchar(45),
    resultado varchar(20) NOT NULL,
    detalle varchar(255),
    PRIMARY KEY (id),
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE permiso (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    codigo varchar(100) NOT NULL,
    nombre varchar(100) NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (codigo)
);

CREATE TABLE bitacoraaccion (
    id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
    idempleado int NOT NULL,
    idpermiso int NOT NULL,
    fechahora timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    accion varchar(10) NOT NULL,
    tablaafectada varchar(100),
    idregistroafectado bigint,
    equipo varchar(150),
    ip varchar(45),
    resultado varchar(255) DEFAULT 'EXITOSO'::character varying NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idpermiso) REFERENCES permiso (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE categoria (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE cierrecaja (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    fechacierre timestamp NOT NULL,
    fondoinicial decimal(10,2) NOT NULL,
    totalventasefectivo decimal(10,2) DEFAULT 0 NOT NULL,
    totalventasqr decimal(10,2) DEFAULT 0 NOT NULL,
    totalventastarjeta decimal(10,2) DEFAULT 0 NOT NULL,
    totalventas decimal(10,2) DEFAULT 0 NOT NULL,
    totalingresos decimal(10,2) DEFAULT 0 NOT NULL,
    totalegresos decimal(10,2) DEFAULT 0 NOT NULL,
    efectivoesperado decimal(10,2) NOT NULL,
    efectivocontado decimal(10,2) NOT NULL,
    diferencia decimal(10,2) NOT NULL,
    observacion varchar(250),
    idaperturacaja int NOT NULL,
    idempleado int NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (idaperturacaja),
    FOREIGN KEY (idaperturacaja) REFERENCES aperturacaja (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE configuracion_sistema (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    clave varchar(100) NOT NULL,
    valor text,
    descripcion varchar(255),
    estado boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (clave)
);

CREATE TABLE cuentausuario (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idempleado int NOT NULL,
    usuario varchar(50) NOT NULL,
    correo varchar(150) NOT NULL,
    passwordhash varchar(255),
    googlesub varchar(255),
    intentosfallidos int DEFAULT 0 NOT NULL,
    bloqueado boolean DEFAULT false NOT NULL,
    bloqueadohasta timestamp,
    fechacreacion timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ultimoacceso timestamp,
    PRIMARY KEY (id),
    UNIQUE (correo),
    UNIQUE (googlesub),
    UNIQUE (idempleado),
    UNIQUE (usuario),
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE mesa (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    numeromesa int NOT NULL,
    capacidad int DEFAULT 4 NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    idsucursal int NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (idsucursal, numeromesa),
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE pedido (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nropedido int NOT NULL,
    fecha timestamp NOT NULL,
    total decimal(10,2) NOT NULL,
    estadopedido tipoestado_pedido DEFAULT 'PENDIENTE'::tipoestado_pedido NOT NULL,
    tipopedido tipo_pedido DEFAULT 'MESA'::tipo_pedido NOT NULL,
    idsucursal int NOT NULL,
    idempleado int NOT NULL,
    idmesa int,
    subtotalpedido decimal(10,2) NOT NULL,
    descuentopedido decimal(10,2) DEFAULT 0 NOT NULL,
    horarecogida timestamp,
    observaciones text,
    idaperturacaja int,
    PRIMARY KEY (id),
    CHECK ((subtotalpedido >= (0)::numeric)),
    CHECK ((descuentopedido >= (0)::numeric)),
    CHECK ((total >= (0)::numeric)),
    FOREIGN KEY (idaperturacaja) REFERENCES aperturacaja (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idmesa) REFERENCES mesa (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE producto (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    descripcion varchar(200) NOT NULL,
    photo varchar(255),
    estado boolean DEFAULT true NOT NULL,
    idcategoria int NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idcategoria) REFERENCES categoria (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE sucursal_producto (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idsucursal int NOT NULL,
    idproducto int NOT NULL,
    precioproducto decimal(10,2) NOT NULL,
    disponibilidad boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (idsucursal, idproducto),
    CHECK ((precioproducto >= (0)::numeric)),
    FOREIGN KEY (idproducto) REFERENCES producto (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE promocion (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    tipodescuento tipodescuento DEFAULT 'MONTO_FIJO'::tipodescuento NOT NULL,
    valordescuento decimal(10,2) NOT NULL,
    fechainicio timestamp NOT NULL,
    fechafin timestamp NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    photo varchar(255),
    PRIMARY KEY (id),
    CHECK ((valordescuento >= (0)::numeric)),
    CHECK ((fechafin > fechainicio)),
    CHECK (((tipodescuento = 'MONTO_FIJO'::tipodescuento) OR (valordescuento <= (100)::numeric)))
);

CREATE TABLE detallepedido (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    cantidad int NOT NULL,
    preciounitario decimal(10,2) NOT NULL,
    subtotal decimal(10,2) NOT NULL,
    descuento decimal(10,2) DEFAULT 0 NOT NULL,
    total decimal(10,2) NOT NULL,
    idpedido int NOT NULL,
    idproductosucursal int,
    idpromocion int,
    PRIMARY KEY (id),
    CHECK ((cantidad > 0)),
    CHECK ((preciounitario >= (0)::numeric)),
    CHECK ((subtotal >= (0)::numeric)),
    CHECK ((descuento >= (0)::numeric)),
    CHECK ((total >= (0)::numeric)),
    CHECK (((idproductosucursal IS NOT NULL) OR (idpromocion IS NOT NULL))),
    FOREIGN KEY (idpedido) REFERENCES pedido (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idproductosucursal) REFERENCES sucursal_producto (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idpromocion) REFERENCES promocion (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE unidadmedida (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(50) NOT NULL,
    abreviatura varchar(10) NOT NULL,
    tipo varchar(20) NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (abreviatura)
);

CREATE TABLE insumo (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(100) NOT NULL,
    descripcion varchar(255),
    idunidadmedida int NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idunidadmedida) REFERENCES unidadmedida (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE detallereceta (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idproducto int NOT NULL,
    idinsumo int NOT NULL,
    cantidad decimal(12,3) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (idproducto, idinsumo),
    CHECK ((cantidad > (0)::numeric)),
    FOREIGN KEY (idinsumo) REFERENCES insumo (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idproducto) REFERENCES producto (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE diaatencion (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombredia varchar(20) NOT NULL,
    numerodia int NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE historialproducto (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    fecha_registro timestamp NOT NULL,
    precioanterior decimal(10,2) NOT NULL,
    precionuevo decimal(10,2) NOT NULL,
    idproductosucursal int NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (idproductosucursal) REFERENCES sucursal_producto (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE horariosucursal (
    idhorariosucursal int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idsucursal int NOT NULL,
    horaapertura time NOT NULL,
    horacierre time NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    iddiaatencion int NOT NULL,
    PRIMARY KEY (idhorariosucursal),
    UNIQUE (idsucursal, iddiaatencion),
    FOREIGN KEY (iddiaatencion) REFERENCES diaatencion (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE inventariosucursal (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idsucursal int NOT NULL,
    idinsumo int NOT NULL,
    cantidad decimal(12,3) DEFAULT 0 NOT NULL,
    cantidadminima decimal(12,3),
    fechaactualizacion timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    PRIMARY KEY (id),
    UNIQUE (idsucursal, idinsumo),
    CHECK ((cantidad >= (0)::numeric)),
    CHECK (((cantidadminima IS NULL) OR (cantidadminima >= (0)::numeric))),
    FOREIGN KEY (idinsumo) REFERENCES insumo (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idsucursal) REFERENCES sucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE metodopago (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    nombre varchar(50) NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    gateway varchar(50),
    PRIMARY KEY (id),
    UNIQUE (nombre)
);

CREATE TABLE movimientocaja (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    fechamovimiento timestamp NOT NULL,
    tipomovimiento tipomovimientocaja NOT NULL,
    concepto varchar(150) NOT NULL,
    monto decimal(10,2) NOT NULL,
    observacion varchar(250),
    idaperturacaja int NOT NULL,
    idempleado int NOT NULL,
    PRIMARY KEY (id),
    CHECK ((monto > (0)::numeric)),
    FOREIGN KEY (idaperturacaja) REFERENCES aperturacaja (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE movimientoinventario (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idinventariosucursal int NOT NULL,
    tipomovimiento tipomovimientoinventario NOT NULL,
    cantidad decimal(12,3) NOT NULL,
    cantidadanterior decimal(12,3) NOT NULL,
    cantidadnueva decimal(12,3) NOT NULL,
    fechamovimiento timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    idempleado int,
    observacion varchar(255),
    PRIMARY KEY (id),
    CHECK ((cantidad > (0)::numeric)),
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idinventariosucursal) REFERENCES inventariosucursal (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE venta (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    fechaventa timestamp NOT NULL,
    totalventa decimal(10,2) NOT NULL,
    estadoventa tipoestadoventa DEFAULT 'PENDIENTE'::tipoestadoventa NOT NULL,
    idempleado int NOT NULL,
    idpedido int,
    PRIMARY KEY (id),
    UNIQUE (idpedido),
    FOREIGN KEY (idempleado) REFERENCES empleado (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idpedido) REFERENCES pedido (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE pago (
    id int GENERATED ALWAYS AS IDENTITY NOT NULL,
    idventa int NOT NULL,
    idmetodopago int NOT NULL,
    idaperturacaja int NOT NULL,
    montopago decimal(10,2) NOT NULL,
    estadopago tipoestadopago DEFAULT 'PENDIENTE'::tipoestadopago NOT NULL,
    montorecibido decimal(10,2),
    cambioentregado decimal(10,2) DEFAULT 0 NOT NULL,
    referenciaexterna varchar(200),
    gateway varchar(50),
    codigoautorizacion varchar(100),
    idtransaccion varchar(200),
    ultimos4 varchar(4),
    marcatarjeta varchar(30),
    fechapago timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observacionpago varchar(200),
    PRIMARY KEY (id),
    FOREIGN KEY (idaperturacaja) REFERENCES aperturacaja (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idmetodopago) REFERENCES metodopago (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idventa) REFERENCES venta (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE promocion_sucursal_producto (
    idpromocion int NOT NULL,
    idsucursalproducto int NOT NULL,
    cantidad_producto int DEFAULT 1 NOT NULL,
    PRIMARY KEY (idpromocion, idsucursalproducto),
    CHECK ((cantidad_producto >= 1)),
    FOREIGN KEY (idpromocion) REFERENCES promocion (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idsucursalproducto) REFERENCES sucursal_producto (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE rolpermiso (
    idrol int NOT NULL,
    idpermiso int NOT NULL,
    PRIMARY KEY (idrol, idpermiso),
    FOREIGN KEY (idpermiso) REFERENCES permiso (id) ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (idrol) REFERENCES rol (id) ON UPDATE NO ACTION ON DELETE NO ACTION
);


-- Poblacion de tablas
-- Datos para tabla: rol (4 registros)
INSERT INTO rol (id, claverol, nombrerol) OVERRIDING SYSTEM VALUE VALUES (2, 'ADMINISTRADOR', 'Administrador');
INSERT INTO rol (id, claverol, nombrerol) OVERRIDING SYSTEM VALUE VALUES (3, 'GERENTE', 'Gerente');
INSERT INTO rol (id, claverol, nombrerol) OVERRIDING SYSTEM VALUE VALUES (4, 'CAJERO', 'Cajero');
INSERT INTO rol (id, claverol, nombrerol) OVERRIDING SYSTEM VALUE VALUES (5, 'MESERO', 'Mesero');
SELECT setval(pg_get_serial_sequence('rol', 'id'), COALESCE((SELECT MAX(id) FROM rol), 1), true);

-- Datos para tabla: permiso (82 registros)
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (38, '225', 'Dar de baja a horario de atención de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (94, '347', 'Listar inventario y movimientos de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (95, '348', 'Establecer cantidad mínima de inventario', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (83, '445', 'Anular venta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (84, '446', 'Registrar método de pago', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (85, '447', 'Dar de baja a método de pago', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (86, '448', 'Listar métodos de pago', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (87, '500', 'Crear pedido', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (88, '501', 'Editar pedido', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (89, '502', 'Listar pedidos', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (90, '505', 'Dar de baja a pedido', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (91, '506', 'Editar detalle de pedido', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (14, '100', 'Crear nuevo empleado', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (15, '101', 'Editar empleados', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (16, '102', 'Listar empleados', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (17, '105', 'Dar de baja a empleado', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (18, '106', 'Modificar contraseña de empleado', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (19, '107', 'Listar empleados activos', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (20, '108', 'Listar empleados inactivos', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (21, '150', 'Listar bitácora de acceso de empleados', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (22, '151', 'Listar bitácora de acciones de empleados', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (23, '200', 'Crear nueva sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (24, '201', 'Editar datos de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (25, '202', 'Listar sucursales', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (26, '204', 'Asignar gerente a sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (27, '205', 'Dar de baja a sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (28, '206', 'Asignar empleado a sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (29, '207', 'Quitar empleado de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (30, '208', 'Listar empleados de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (31, '210', 'Registrar mesa', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (32, '211', 'Editar mesa', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (33, '212', 'Listar mesas', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (34, '215', 'Dar de baja a mesa', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (35, '220', 'Registrar horario de atención de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (36, '221', 'Editar horario de atención de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (37, '222', 'Listar horario de atención de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (39, '300', 'Crear nueva categoría', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (40, '301', 'Editar categoría', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (41, '302', 'Listar categorías', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (42, '305', 'Dar de baja a categoría', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (43, '310', 'Crear producto', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (44, '311', 'Editar producto', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (45, '312', 'Listar productos', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (46, '315', 'Dar de baja a producto', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (47, '316', 'Registrar precio y disponibilidad de producto por sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (48, '317', 'Listar productos disponibles de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (49, '318', 'Editar precio de producto de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (50, '319', 'Deshabilitar disponibilidad de producto', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (51, '320', 'Listar historial de producto por sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (52, '330', 'Crear unidad de medida', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (53, '331', 'Editar unidad de medida', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (54, '335', 'Dar de baja unidad de medida', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (55, '336', 'Crear insumo', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (56, '337', 'Editar datos de insumo', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (57, '338', 'Dar de baja insumo', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (58, '340', 'Crear detalle de receta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (59, '341', 'Modificar detalle de receta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (60, '345', 'Dar de baja detalle de receta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (93, '346', 'Registrar movimiento de inventario', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (61, '350', 'Crear promoción en una sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (62, '351', 'Editar promoción de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (63, '352', 'Listar promociones', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (64, '355', 'Dar de baja a promoción de sucursal', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (65, '400', 'Crear nueva caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (66, '401', 'Editar datos de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (67, '402', 'Listar cajas', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (68, '405', 'Dar de baja a caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (69, '410', 'Crear apertura de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (70, '411', 'Editar apertura de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (71, '412', 'Listar historial de aperturas por caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (72, '415', 'Dar de baja a apertura de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (73, '420', 'Registrar movimiento de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (74, '421', 'Editar movimiento de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (75, '422', 'Listar movimientos de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (76, '425', 'Dar de baja a movimiento de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (77, '430', 'Crear cierre de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (78, '436', 'Ver detalle de cierre de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (79, '437', 'Listar historial de cierre de caja', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (80, '440', 'Registrar venta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (81, '441', 'Editar venta', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (82, '442', 'Listar ventas', TRUE);
INSERT INTO permiso (id, codigo, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (92, '50', 'Registrar o modificar configuración del sistema', TRUE);
SELECT setval(pg_get_serial_sequence('permiso', 'id'), COALESCE((SELECT MAX(id) FROM permiso), 1), true);

-- Datos para tabla: rolpermiso (187 registros)
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 87);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 88);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 89);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 90);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 91);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 18);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 33);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 41);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 87);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 88);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 89);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 90);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (5, 91);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 18);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 31);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 32);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 33);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 34);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 37);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 41);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 48);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 50);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 63);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 67);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 69);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 70);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 71);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 73);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 74);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 75);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 76);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 77);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 78);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 79);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 93);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 94);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 95);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 80);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 81);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 82);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 83);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 86);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 87);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 88);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 89);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 90);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (4, 91);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 14);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 15);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 16);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 17);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 18);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 24);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 28);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 29);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 30);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 31);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 32);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 33);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 34);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 35);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 36);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 37);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 38);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 47);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 48);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 49);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 50);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 51);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 52);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 53);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 54);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 55);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 56);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 57);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 58);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 59);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 60);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 93);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 94);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 95);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 61);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 62);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 63);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 64);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 65);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 66);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 67);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 68);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 69);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 70);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 71);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 72);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 73);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 74);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 75);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 76);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 77);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 78);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 79);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 80);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 81);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 82);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 83);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (3, 86);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 92);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 14);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 15);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 16);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 17);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 18);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 19);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 20);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 21);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 22);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 23);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 24);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 25);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 26);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 27);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 28);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 29);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 30);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 31);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 32);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 33);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 34);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 35);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 36);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 37);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 38);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 39);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 40);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 41);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 42);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 43);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 44);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 45);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 46);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 47);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 48);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 49);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 50);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 51);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 52);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 53);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 54);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 55);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 56);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 57);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 58);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 59);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 60);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 93);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 94);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 95);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 61);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 62);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 63);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 64);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 65);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 66);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 67);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 68);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 69);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 70);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 71);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 72);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 73);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 74);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 75);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 76);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 77);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 78);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 79);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 80);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 81);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 82);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 83);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 84);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 85);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 86);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 87);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 88);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 89);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 90);
INSERT INTO rolpermiso (idrol, idpermiso) VALUES (2, 91);



-- Datos para tabla: empleado (9 registros)
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (15, 'Laura', 'Castro', '73130624', TRUE, '2026-09-13 00:38:54', NULL, 3, NULL);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (40, 'ramon', 'nogales', NULL, TRUE, '2026-09-14 12:02:48', NULL, 3, 7);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (2, 'Marcelo', 'Cruz Nogales', '70005937', TRUE, '2026-09-12 23:29:22.512172', NULL, 2, NULL);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (45, 'elena', 'nogales', NULL, TRUE, '2026-09-14 16:16:21', 15, 4, 6);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (41, 'Wendy', 'Salazar', '123456', TRUE, '2026-09-14 15:29:08', 15, 5, 6);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (39, 'Juan', 'Pinto', '123456', TRUE, '2026-09-14 02:26:06', 15, 4, 6);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (38, 'tatiana', 'guzman', NULL, TRUE, '2026-09-14 02:14:44', 40, 5, NULL);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (55, 'GerentePrueba', 'PDF', '00000000', TRUE, '2026-09-15 00:25:01', 2, 3, 7);
INSERT INTO empleado (id, nombre, apellido, telefono, estado, fecharegistro, idjefe, idrol, idsucursal) OVERRIDING SYSTEM VALUE VALUES (46, 'Andres', 'Guzman', NULL, FALSE, '2026-09-14 16:28:21', 15, 5, 6);
SELECT setval(pg_get_serial_sequence('empleado', 'id'), COALESCE((SELECT MAX(id) FROM empleado), 1), true);

-- Datos para tabla: sucursal (2 registros)
INSERT INTO sucursal (id, nombre, direccion, telefono, latitud, longitud, estado, idempleadogerente) OVERRIDING SYSTEM VALUE VALUES (6, 'Sucursal Centro', 'Calle Ruben Arrdondo, Nro 9', '75535749', '-17.88923300', '-63.32837100', TRUE, 15);
INSERT INTO sucursal (id, nombre, direccion, telefono, latitud, longitud, estado, idempleadogerente) OVERRIDING SYSTEM VALUE VALUES (7, 'Sucursal km 9', 'km 9', '57567', '-17.88171900', '-63.28588500', TRUE, 40);
SELECT setval(pg_get_serial_sequence('sucursal', 'id'), COALESCE((SELECT MAX(id) FROM sucursal), 1), true);

-- Datos para tabla: caja (3 registros)
INSERT INTO caja (id, nombre, activo, idsucursal) OVERRIDING SYSTEM VALUE VALUES (3, 'Caja principal', TRUE, 6);
INSERT INTO caja (id, nombre, activo, idsucursal) OVERRIDING SYSTEM VALUE VALUES (7, 'Caja2', TRUE, 7);
INSERT INTO caja (id, nombre, activo, idsucursal) OVERRIDING SYSTEM VALUE VALUES (6, 'Caja1', TRUE, 7);
SELECT setval(pg_get_serial_sequence('caja', 'id'), COALESCE((SELECT MAX(id) FROM caja), 1), true);

-- Datos para tabla: aperturacaja (4 registros)
INSERT INTO aperturacaja (id, fechaapertura, montoinicial, estado, idcaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (83, '2026-09-19 14:13:28', '50.00', 'CERRADA', 3, 15);
INSERT INTO aperturacaja (id, fechaapertura, montoinicial, estado, idcaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (84, '2026-09-19 21:24:20', '50.00', 'CERRADA', 3, 15);
INSERT INTO aperturacaja (id, fechaapertura, montoinicial, estado, idcaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (85, '2026-09-19 21:31:05', '0.00', 'CERRADA', 3, 39);
INSERT INTO aperturacaja (id, fechaapertura, montoinicial, estado, idcaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (34, '2026-09-18 06:26:48', '50.00', 'CERRADA', 3, 45);
SELECT setval(pg_get_serial_sequence('aperturacaja', 'id'), COALESCE((SELECT MAX(id) FROM aperturacaja), 1), true);

-- Datos para tabla: categoria (6 registros)
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (1, 'HAMBURGUESAS', TRUE);
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (2, 'VARIADOS', TRUE);
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (3, 'PORCIONES', TRUE);
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (4, 'GASEOSAS', TRUE);
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (5, 'BEBIDA', TRUE);
INSERT INTO categoria (id, nombre, estado) OVERRIDING SYSTEM VALUE VALUES (6, 'ASADO', TRUE);
SELECT setval(pg_get_serial_sequence('categoria', 'id'), COALESCE((SELECT MAX(id) FROM categoria), 1), true);

-- Datos para tabla: producto (46 registros)
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (1, 'TOXICA', 'Deliciosa carne premium 135 gr.,tocino ahumado, pico de gallo, nachos picantes, jalapeño, papas rusticas Wili, Pan brioche de pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa', NULL, TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (7, 'CHIKILOCO', 'Deliciosa carne de pollo broaster, papas rusticas willi, tocino ahumado. pico de gallo, nachos, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', NULL, TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (8, 'CHIKIWILLI', 'Deliciosa carne de pollo broaster, papas rusticas willy, Pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', NULL, TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (10, 'EL TOXICO', 'Deliciosa carne premium, papas rusticas willi, tocino ahumado, mermelada de locoto, cebolla crispy, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', NULL, TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (15, 'Crispy king Wili', 'Pollo a la Broaster acompañado con arroz primavera y porcion de papas rusticas y porcion de papas rusticas willi con su deliciosa salsa de la casa', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (16, 'Willi Tacos', 'Tortillas de maiz tostadas acompañada con carne de hamburguesa, queso muzarela, pico de gallo, choclitos, tiras de lechuga, papas rusticas y su salsa de la casa', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (17, 'Willi Nachos', 'Nachos picantes acompañadado con carne de hamburguesa, pico de gallo, choclito, queso muzzarela, limones en gajos y su salsa de la casa', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (18, 'Pepito', 'Pan de oregano, carne picada de hamburguesa, salchicha viena, choclito, bañada de salsa y espolvoreada de queso rallado con papa rustica y su salsa', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (19, 'Lomitos', 'Pan de oregano, carne lomito, lechuga, tomate, cebolla, papas rusticas wili y su salsa de la casa', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (21, 'Salchipapas', 'Papas rusticas willi, salchicja Viena Santa Fe bañadas de salsa de la casa y espolvoreada de queso rallado', NULL, TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (22, 'Salchicha', 'Porcion de salchicha crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (23, 'Queso', 'Porcion de queso crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (24, 'Lomito', 'Porcion de carne de lomito frito crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (25, 'Huevo', 'Porcion de huevo frito crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (26, 'Nuggets', 'Porcion de nuggets frito crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (27, 'Tocino', 'Porcion de tocino frito crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (28, 'Hamburguesas', 'Porcion de de carne de Hamburguesa', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (29, 'Papas', 'Porcion de papas fritas crocantes', NULL, TRUE, 3);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (30, 'Corona', 'Gaseosa Alcoholica Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (31, 'Aquarios', 'Gaseosa de 2L Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (32, 'Popular', 'Gaseosa de 500ml Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (33, 'Soda 2L', 'Gaseosa de 2L Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (34, 'Paceña', 'Bebida alcoholica Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (35, 'Peque', 'Gaseosa de 250ml Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (36, 'Simba', 'Gaseosa de 2L Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (37, 'Personal', 'Gaseosa de 500ml Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (38, 'Soda 1.5L', 'Gaseosa de 1.5L Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (40, 'Soda 2.5L', 'Gaseosa de 2.5L Fria', NULL, TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (41, 'Refresco vaso', 'bebida en vaso', NULL, TRUE, 5);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (42, 'Refresco Jarra Mediana', 'bebida de jarra Mediana', NULL, TRUE, 5);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (43, 'Refresco Jarra Grande', 'bebida de jarra grande', NULL, TRUE, 5);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (11, 'ECO FULL', 'Deliciosa carne Premium 135gr, tocino ahumado, huevo frito, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/Komcso1OY1ktR2CsuAOvXBAwzcRXuxJNIuFlKzBa.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (20, 'Willi Nuggets', 'Tiritas de pollo willi rebosada acompañado con papas rusticas y su salsa de la casa', 'productos/CFU6ybGgc5q16QZWjfDGDakCG8fuAxPxpIbjKxBO.jpg', TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (4, 'FULL', 'Deliciosa carne Premium 135gr, tocino ahumado, huevo frito, papas rusticas Willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/mx0zIgPjMkXCPCFLotDuXo8NpZoqqvPqIV5yLCfD.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (44, 'Entraña', 'La entraña es un corte de diafragma de la res, famoso por su intenso sabor y textura jugosa, ideal para quienes disfrutam un carne una carne con mucho caracter', NULL, TRUE, 6);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (49, 'Bandera', 'Corte obtenido de la falta de la res, de fibras largas y gran sabor. Perfecto para quienes buscan una porcion abundante y muy jugosa', NULL, TRUE, 6);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (50, 'Ribeye', 'Extraído de la parte alta del lomo (costillar). Destaca por su marmoleo de grasa, que le aporta un textura extremadamente tierna y un sabor intenso', NULL, TRUE, 6);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (14, 'Burrito', 'Tortillas de maiz tostadas acompañada con carne de hamburguesa, pollo o mixto, queso criollo, pico de gallo, chiclito, toras de lechuga, papas rusticas y su salsa de la casa', 'productos/kyNk0MH537PqnmFapU1tEQ7RXYxmcQFHlilnyAJZ.jpg', TRUE, 2);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (2, 'SUPER', 'Deliciosa carne premium 135 gr.,tocino ahumado, papas rusticas Willi,  Pan brioche de pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa', 'productos/WLf1YeFX4zFAaeWpNn87zjQgs0Xvd4tApysGaVWP.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (39, 'Agua Vital', 'gaseosa vital', 'productos/x0ewBLe31NolZv05C9RegUCkw9xlYbrpQZKIMNAg.jpg', TRUE, 4);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (6, 'SIMPLE', 'Deliciosa carne Premium 135gr, papas rusticas willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/Vl4UFRAUXgSHTfBoO8TMqENTG68eE9ioMkxxT8ix.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (3, 'DOGOR', 'Deliciosa carne Premium 135gr, choclito salchicha Viena, queso extra, papas rusticas Willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/2f7eNefpfYyfikqfG26xLpbgOQoqwOYrxabHG9F3.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (13, 'ECO SIMPLE', 'Deliciosa carne Premium 135gr, pan tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/TawQ8CJ1O5T1jfbr4vdgUyZZk5bxlzrAchIAsH6S.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (12, 'ECO SUPER', 'Deliciosa carne premium 135 gr.,tocino,ahumado, pan tostado, tomate, lechuga, cebolla, pepinillo y su salsa de la casa', 'productos/UFja2NVYZFd87tdi8gInTr5IjZRWqGa7VVmpah5U.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (9, 'ECO DOGOR', 'Deliciosa carne Premium 135gr, choclito, salchica, viena, queso extra, pan tostado , tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/rdYodDuToltjkJqAdVLIEGdSJz6z5r2lbrZHTJW9.jpg', TRUE, 1);
INSERT INTO producto (id, nombre, descripcion, photo, estado, idcategoria) OVERRIDING SYSTEM VALUE VALUES (5, 'DOBLE', 'Deliciosa carne Premium 270gr, papas rusticas willi, pan brioche de papa tostado, tomate, lechuga, cebolla, pepinillos y su salsa de la casa', 'productos/wersXHK1zFQBAoq6pNUn3Bs7fM8kjKBkqmjrK1tn.jpg', TRUE, 1);
SELECT setval(pg_get_serial_sequence('producto', 'id'), COALESCE((SELECT MAX(id) FROM producto), 1), true);



-- Datos para tabla: cierrecaja (4 registros)
INSERT INTO cierrecaja (id, fechacierre, fondoinicial, totalventasefectivo, totalventasqr, totalventastarjeta, totalventas, totalingresos, totalegresos, efectivoesperado, efectivocontado, diferencia, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (30, '2026-09-19 14:09:31', '50.00', '196.00', '0.00', '0.00', '196.00', '70.00', '0.00', '316.00', '190.00', '-126.00', 'total en caja cuento con eso, pero me pagaron 6 bs por QR', 34, 45);
INSERT INTO cierrecaja (id, fechacierre, fondoinicial, totalventasefectivo, totalventasqr, totalventastarjeta, totalventas, totalingresos, totalegresos, efectivoesperado, efectivocontado, diferencia, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (79, '2026-09-19 15:59:48', '50.00', '478.00', '0.00', '0.00', '478.00', '50.00', '20.00', '558.00', '558.00', '0.00', 'sin observacion', 83, 15);
INSERT INTO cierrecaja (id, fechacierre, fondoinicial, totalventasefectivo, totalventasqr, totalventastarjeta, totalventas, totalingresos, totalegresos, efectivoesperado, efectivocontado, diferencia, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (80, '2026-09-19 21:28:35', '50.00', '261.00', '0.00', '0.00', '261.00', '50.00', '20.00', '341.00', '420.00', '79.00', NULL, 84, 15);
INSERT INTO cierrecaja (id, fechacierre, fondoinicial, totalventasefectivo, totalventasqr, totalventastarjeta, totalventas, totalingresos, totalegresos, efectivoesperado, efectivocontado, diferencia, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (81, '2026-09-20 01:03:58', '0.00', '187.00', '0.00', '0.00', '187.00', '100.00', '30.00', '257.00', '250.00', '-7.00', NULL, 85, 39);
SELECT setval(pg_get_serial_sequence('cierrecaja', 'id'), COALESCE((SELECT MAX(id) FROM cierrecaja), 1), true);

-- Datos para tabla: configuracion_sistema (18 registros)
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (7, 'SITIO_HABILITAR_CARRUSEL', '1', 'Muestra el carrusel de imágenes en el inicio', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (13, 'TEMA_COLOR_PRIMARIO', '#4b5563', 'Color principal (botones, barra de navegación)', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (14, 'TEMA_COLOR_PRIMARIO_OSCURO', '#374151', 'Color principal oscuro (hover de botones)', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (15, 'TEMA_COLOR_FONDO', '#f4f5f7', 'Color de fondo de la página', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (16, 'TEMA_COLOR_TEXTO', '#1f2937', 'Color de texto', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (19, 'SITIO_MANTENIMIENTO_MENSAJE', 'Estamos realizando mejoras en la página. Volveremos muy pronto. Gracias por tu paciencia.', 'Mensaje que verán los visitantes mientras el sitio está en mantenimiento', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (17, 'TEMA_COLOR_DETALLE', '#10b981', 'Color de detalle (acentos, degradados)', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (2, 'SITIO_ESLOGAN', 'Sabores que se quedan', 'Eslogan que aparece en el inicio', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (4, 'SITIO_EMAIL', 'contacto@burguerwilly.com', 'Correo de contacto', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (5, 'SITIO_DIRECCION', 'Av. Principal 123, Lima', 'Dirección principal', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (6, 'SITIO_HORARIO', 'Lun - Dom: 12:00 p.m. - 11:00 p.m.', 'Horario de atención general', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (11, 'IMAGENES_CARRUSEL', '[{"titulo":"Salchipapas","subtitulo":"Papas rusticas willi, salchicha viena Santa Fe bañadas de salsa de la casa","imagen":"https:\/\/lh3.googleusercontent.com\/gps-cs-s\/AHRPTWlAe2Mgkh5jAsg_geFM6s1Dy9e1xzfCeLogvX4GhN4bHTpJGFgRrWHurshNy-4sj9iCOTaJwQ5jWn4kqplFBHKAJps1vh0tj8Bybhj0X7iFWFruaqlALVDT7iPuqssSPU8H50-7jA=s680-w680-h510-rw","boton_texto":"Salchipapas","boton_url":"https:\/\/lh3.googleusercontent.com\/gps-cs-s\/AHRPTWlAe2Mgkh5jAsg_geFM6s1Dy9e1xzfCeLogvX4GhN4bHTpJGFgRrWHurshNy-4sj9iCOTaJwQ5jWn4kqplFBHKAJps1vh0tj8Bybhj0X7iFWFruaqlALVDT7iPuqssSPU8H50-7jA=s680-w680-h510-rw","orden":1},{"titulo":"lomitos","subtitulo":"lomitos es el metodofd","imagen":"https:\/\/encrypted-tbn0.gstatic.com\/images?q=tbn:ANd9GcQ3WyIx8squ1a9hAjCFBx1X_fi75pX1PktFH0iJZL1ak6_XRtP7YSAH2RwTtLWjwu3tNLVK5pswmbNljKeuklDJRmszciOwavBG5ZYWncY&s=10","boton_texto":"lomitos","boton_url":"https:\/\/encrypted-tbn0.gstatic.com\/images?q=tbn:ANd9GcQ3WyIx8squ1a9hAjCFBx1X_fi75pX1PktFH0iJZL1ak6_XRtP7YSAH2RwTtLWjwu3tNLVK5pswmbNljKeuklDJRmszciOwavBG5ZYWncY&s=10","orden":2},{"titulo":"","subtitulo":"","imagen":"https:\/\/encrypted-tbn0.gstatic.com\/images?q=tbn:ANd9GcS7Gjf6iILZ5eUsVJZ4Q2FvjymhDUibOKWgQa7gZRZ9PA&s=10","boton_texto":"","boton_url":"","orden":3}]', 'Imágenes del carrusel del inicio (JSON)', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (1, 'SITIO_NOMBRE', '🍔 Burger Willy and Grill', 'Nombre comercial del sistema/negocio', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (3, 'SITIO_TELEFONO', '70005937', 'Teléfono de contacto principal', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (8, 'SITIO_HABILITAR_MENU', '1', 'Muestra la sección de menú/productos', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (10, 'SITIO_HABILITAR_SUCURSALES', '1', 'Muestra la sección de sucursales', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (9, 'SITIO_HABILITAR_PROMOCIONES', '1', 'Muestra la sección de promociones', TRUE);
INSERT INTO configuracion_sistema (id, clave, valor, descripcion, estado) OVERRIDING SYSTEM VALUE VALUES (18, 'SITIO_MANTENIMIENTO_ACTIVO', '0', 'Activa o desactiva el modo mantenimiento de la página', TRUE);
SELECT setval(pg_get_serial_sequence('configuracion_sistema', 'id'), COALESCE((SELECT MAX(id) FROM configuracion_sistema), 1), true);

-- Datos para tabla: cuentausuario (8 registros)
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (36, 38, 'tatiana', 'tatiana@burguer.com', '$2y$12$OlkThx7VUK8XiBKJXR3AcuNWjFCDtEjRCom2kqPWgMKetCVz5zVza', NULL, 0, FALSE, NULL, '2026-09-14 02:14:44', '2026-09-14 02:14:56');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (46, 46, 'andres.guzman', 'andres.guzman@gmail.com', '$2y$12$6kONaY9gHHzWrrcIuv4G2uGiC.5o5xh6pk55pb2gWXRWMdrTALQXa', NULL, 0, TRUE, NULL, '2026-09-14 16:28:21', '2026-09-15 13:26:44');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (40, 40, 'ramon.nogales', 'ramon.nogales@gmail.com', '$2y$12$xIPXftlpojs29G08/gPzbu98cGE0YKtpNxWMUKslTSgSGaaWI4oX2', NULL, 0, FALSE, NULL, '2026-09-14 12:02:48', '2026-09-14 12:02:56');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (2, 2, 'admin', 'cruznogalesmarcelo@gmail.com', '$2y$12$KDkpCgR1JaSnhAgqGtoK0.ZM7R3u3mS9AnKSqeQagFNm8pUsSjxvG', NULL, 1, FALSE, NULL, '2026-09-12 23:29:22.975277', '2026-09-16 21:27:07');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (15, 15, 'laura', 'laura@burger.com', '$2y$12$bjXArvvqbJL8rI/RCIdWYus.9AOusbyLcIZ/R/RjPk.du9QuBAyrG', NULL, 3, TRUE, '2026-09-21 10:38:25', '2026-09-13 00:38:54', '2026-09-14 16:17:01');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (41, 41, 'wendy.follow', 'wendy.follow@gmail.com', '$2y$12$3CPtzQJzbMvtHurgL/uT6uzKYfHw7FxK5ksch.Sa/iZER9yo/MNo.', NULL, 1, FALSE, NULL, '2026-09-14 15:29:08', '2026-09-14 15:46:04');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (37, 39, 'juan.pinto', 'juan.pinto@gmail.com', '$2y$12$.1QU.pEnPRbVevkJlW8ogOMtd6WKCdKdLGLzNE9.JpG54QhaZyw7G', NULL, 0, FALSE, NULL, '2026-09-14 02:26:07', '2026-09-14 17:24:34');
INSERT INTO cuentausuario (id, idempleado, usuario, correo, passwordhash, googlesub, intentosfallidos, bloqueado, bloqueadohasta, fechacreacion, ultimoacceso) OVERRIDING SYSTEM VALUE VALUES (45, 45, 'elena.nogales', 'elena.nogales@gmail.com', '$2y$12$uB/3EtbhYetNbbckNB3J0.HuJaBO44U1JVQqPYFv585prHXHpVTJ.', NULL, 0, FALSE, NULL, '2026-09-14 16:16:21', NULL);
SELECT setval(pg_get_serial_sequence('cuentausuario', 'id'), COALESCE((SELECT MAX(id) FROM cuentausuario), 1), true);

-- Datos para tabla: mesa (5 registros)
INSERT INTO mesa (id, numeromesa, capacidad, estado, idsucursal) OVERRIDING SYSTEM VALUE VALUES (12, 1, 4, TRUE, 6);
INSERT INTO mesa (id, numeromesa, capacidad, estado, idsucursal) OVERRIDING SYSTEM VALUE VALUES (18, 1, 4, TRUE, 7);
INSERT INTO mesa (id, numeromesa, capacidad, estado, idsucursal) OVERRIDING SYSTEM VALUE VALUES (19, 2, 4, TRUE, 7);
INSERT INTO mesa (id, numeromesa, capacidad, estado, idsucursal) OVERRIDING SYSTEM VALUE VALUES (20, 2, 4, TRUE, 6);
INSERT INTO mesa (id, numeromesa, capacidad, estado, idsucursal) OVERRIDING SYSTEM VALUE VALUES (21, 3, 4, TRUE, 6);
SELECT setval(pg_get_serial_sequence('mesa', 'id'), COALESCE((SELECT MAX(id) FROM mesa), 1), true);

-- Datos para tabla: pedido (27 registros)
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (173, 2, '2026-09-19 14:32:11', '67.00', 'EJECUTADO', 'MESA', 6, 15, 12, '67.00', '0.00', NULL, NULL, 83);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (174, 3, '2026-09-19 14:33:07', '233.00', 'EJECUTADO', 'MESA', 6, 15, 20, '242.00', '9.00', NULL, NULL, 83);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (175, 4, '2026-09-19 15:34:52', '85.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 15, NULL, '94.00', '9.00', NULL, NULL, 83);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (177, 2, '2026-09-19 21:26:25', '176.00', 'EJECUTADO', 'MESA', 6, 39, 12, '176.00', '0.00', NULL, NULL, 84);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (98, 3, '2026-09-18 16:09:45', '92.00', 'EJECUTADO', 'MESA', 6, 45, 20, '92.00', '0.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (159, 6, '2026-09-18 18:46:39', '18.00', 'PENDIENTE', 'PARA_LLEVAR', 6, 15, NULL, '23.00', '5.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (176, 1, '2026-09-19 21:25:39', '85.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 41, NULL, '94.00', '9.00', NULL, NULL, 84);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (165, 7, '2026-09-18 21:57:52', '85.00', 'PENDIENTE', 'PARA_LLEVAR', 6, 15, NULL, '94.00', '9.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (97, 2, '2026-09-18 16:08:52', '56.00', 'ANULADO', 'PARA_LLEVAR', 6, 45, NULL, '56.00', '0.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (148, 5, '2026-09-18 17:38:36', '65.00', 'ANULADO', 'PARA_LLEVAR', 6, 15, NULL, '65.00', '0.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (166, 8, '2026-09-18 22:14:59', '114.00', 'PENDIENTE', 'PARA_LLEVAR', 6, 15, NULL, '114.00', '0.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (96, 1, '2026-09-18 16:07:58', '42.00', 'EJECUTADO', 'MESA', 6, 45, 12, '47.00', '5.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (184, 7, '2026-09-19 22:44:22', '25.00', 'ANULADO', 'PARA_LLEVAR', 6, 39, NULL, '30.00', '5.00', NULL, '[Anulado el 20/09/2026 00:44]', 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (183, 6, '2026-09-19 22:43:51', '25.00', 'ANULADO', 'PARA_LLEVAR', 6, 39, NULL, '30.00', '5.00', NULL, '[Anulado el 20/09/2026 00:44]', 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (182, 5, '2026-09-19 22:43:23', '25.00', 'ANULADO', 'PARA_LLEVAR', 6, 39, NULL, '30.00', '5.00', NULL, '[Anulado el 20/09/2026 00:44]', 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (185, 8, '2026-09-20 00:43:42', '50.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 39, NULL, '50.00', '0.00', NULL, NULL, 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (112, 4, '2026-09-18 16:23:00', '33.00', 'EJECUTADO', 'MESA', 6, 15, 21, '33.00', '0.00', NULL, NULL, NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (178, 1, '2026-09-19 21:33:03', '85.00', 'ANULADO', 'PARA_LLEVAR', 6, 41, NULL, '94.00', '9.00', NULL, '[Anulado el 20/09/2026 00:46]', 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (179, 2, '2026-09-19 21:33:49', '85.00', 'ANULADO', 'PARA_LLEVAR', 6, 39, NULL, '94.00', '9.00', NULL, '[Anulado el 20/09/2026 00:46]', 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (181, 4, '2026-09-19 21:36:25', '70.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 39, NULL, '70.00', '0.00', NULL, NULL, 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (180, 3, '2026-09-19 21:35:58', '67.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 39, NULL, '67.00', '0.00', NULL, NULL, 85);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (171, 13, '2026-09-19 14:10:06', '8.00', 'ANULADO', 'PARA_LLEVAR', 6, 15, NULL, '8.00', '0.00', NULL, '[Anulado el 19/09/2026 14:10]', NULL);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (167, 9, '2026-09-19 00:31:35', '43.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 15, NULL, '43.00', '0.00', NULL, NULL, 34);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (168, 10, '2026-09-19 10:23:07', '85.00', 'EJECUTADO', 'MESA', 6, 15, 12, '94.00', '9.00', NULL, NULL, 34);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (169, 11, '2026-09-19 13:20:31', '60.00', 'EJECUTADO', 'MESA', 6, 15, 12, '65.00', '5.00', NULL, NULL, 34);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (170, 12, '2026-09-19 13:23:03', '8.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 15, NULL, '8.00', '0.00', NULL, NULL, 34);
INSERT INTO pedido (id, nropedido, fecha, total, estadopedido, tipopedido, idsucursal, idempleado, idmesa, subtotalpedido, descuentopedido, horarecogida, observaciones, idaperturacaja) OVERRIDING SYSTEM VALUE VALUES (172, 1, '2026-09-19 14:30:14', '93.00', 'EJECUTADO', 'PARA_LLEVAR', 6, 15, NULL, '102.00', '9.00', NULL, NULL, 83);
SELECT setval(pg_get_serial_sequence('pedido', 'id'), COALESCE((SELECT MAX(id) FROM pedido), 1), true);


-- Datos para tabla: sucursal_producto (8 registros)
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (3, 6, 5, '35.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (4, 6, 3, '32.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (5, 6, 9, '25.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (6, 6, 11, '23.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (7, 6, 13, '15.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (8, 6, 39, '8.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (9, 6, 12, '18.00', TRUE);
INSERT INTO sucursal_producto (id, idsucursal, idproducto, precioproducto, disponibilidad) OVERRIDING SYSTEM VALUE VALUES (10, 6, 10, '28.00', TRUE);
SELECT setval(pg_get_serial_sequence('sucursal_producto', 'id'), COALESCE((SELECT MAX(id) FROM sucursal_producto), 1), true);

-- Datos para tabla: promocion (4 registros)
INSERT INTO promocion (id, nombre, tipodescuento, valordescuento, fechainicio, fechafin, activo, photo) OVERRIDING SYSTEM VALUE VALUES (116, 'Promo Dogor 2x60', 'MONTO_FIJO', '4.00', '2026-09-16 21:10:00', '2026-09-22 21:10:00', TRUE, NULL);
INSERT INTO promocion (id, nombre, tipodescuento, valordescuento, fechainicio, fechafin, activo, photo) OVERRIDING SYSTEM VALUE VALUES (6, 'PromoEco 2EcoSimple a 25 Bs', 'MONTO_FIJO', '5.00', '2026-09-18 01:47:00', '2026-09-20 01:47:00', FALSE, 'promociones/p70Go1gIJCtSPX7KiSucz75pQ9GCZr3qtP9hgOO4.jpg');
INSERT INTO promocion (id, nombre, tipodescuento, valordescuento, fechainicio, fechafin, activo, photo) OVERRIDING SYSTEM VALUE VALUES (3, 'Promo line', 'MONTO_FIJO', '25.00', '2026-09-17 12:57:00', '2026-09-17 23:00:00', FALSE, NULL);
INSERT INTO promocion (id, nombre, tipodescuento, valordescuento, fechainicio, fechafin, activo, photo) OVERRIDING SYSTEM VALUE VALUES (4, 'Promo tragon', 'MONTO_FIJO', '3.00', '2026-09-17 12:59:00', '2026-09-17 23:59:00', FALSE, NULL);
SELECT setval(pg_get_serial_sequence('promocion', 'id'), COALESCE((SELECT MAX(id) FROM promocion), 1), true);

-- Datos para tabla: detallepedido (62 registros)
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (164, 1, '8.00', '8.00', '0.00', '8.00', 112, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (165, 1, '25.00', '25.00', '0.00', '25.00', 112, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (232, 1, '8.00', '8.00', '0.00', '8.00', 159, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (233, 1, '15.00', '15.00', '5.00', '10.00', 159, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (241, 2, '32.00', '64.00', '4.00', '60.00', 165, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (242, 2, '15.00', '30.00', '5.00', '25.00', 165, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (243, 2, '32.00', '64.00', '0.00', '64.00', 166, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (244, 2, '25.00', '50.00', '0.00', '50.00', 166, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (245, 1, '8.00', '8.00', '0.00', '8.00', 167, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (246, 1, '35.00', '35.00', '0.00', '35.00', 167, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (247, 2, '15.00', '30.00', '5.00', '25.00', 168, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (248, 2, '32.00', '64.00', '4.00', '60.00', 168, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (249, 2, '15.00', '30.00', '5.00', '25.00', 169, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (250, 1, '35.00', '35.00', '0.00', '35.00', 169, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (251, 1, '8.00', '8.00', '0.00', '8.00', 170, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (252, 1, '8.00', '8.00', '0.00', '8.00', 171, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (253, 1, '8.00', '8.00', '0.00', '8.00', 172, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (254, 2, '15.00', '30.00', '5.00', '25.00', 172, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (255, 2, '32.00', '64.00', '4.00', '60.00', 172, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (256, 1, '35.00', '35.00', '0.00', '35.00', 173, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (257, 1, '32.00', '32.00', '0.00', '32.00', 173, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (264, 1, '25.00', '25.00', '0.00', '25.00', 174, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (265, 1, '23.00', '23.00', '0.00', '23.00', 174, 6, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (266, 1, '32.00', '32.00', '0.00', '32.00', 174, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (267, 1, '35.00', '35.00', '0.00', '35.00', 174, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (268, 1, '15.00', '15.00', '0.00', '15.00', 174, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (269, 1, '18.00', '18.00', '0.00', '18.00', 174, 9, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (270, 2, '15.00', '30.00', '5.00', '25.00', 174, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (271, 2, '32.00', '64.00', '4.00', '60.00', 174, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (272, 2, '15.00', '30.00', '5.00', '25.00', 175, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (273, 2, '32.00', '64.00', '4.00', '60.00', 175, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (215, 1, '8.00', '8.00', '0.00', '8.00', 148, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (216, 1, '32.00', '32.00', '0.00', '32.00', 148, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (217, 1, '25.00', '25.00', '0.00', '25.00', 148, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (274, 2, '15.00', '30.00', '5.00', '25.00', 176, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (275, 2, '32.00', '64.00', '4.00', '60.00', 176, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (276, 1, '15.00', '15.00', '0.00', '15.00', 177, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (277, 1, '18.00', '18.00', '0.00', '18.00', 177, 9, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (278, 1, '28.00', '28.00', '0.00', '28.00', 177, 10, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (279, 1, '25.00', '25.00', '0.00', '25.00', 177, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (280, 1, '23.00', '23.00', '0.00', '23.00', 177, 6, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (281, 1, '32.00', '32.00', '0.00', '32.00', 177, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (282, 1, '35.00', '35.00', '0.00', '35.00', 177, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (283, 2, '15.00', '30.00', '5.00', '25.00', 178, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (284, 2, '32.00', '64.00', '4.00', '60.00', 178, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (285, 2, '15.00', '30.00', '5.00', '25.00', 179, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (286, 2, '32.00', '64.00', '4.00', '60.00', 179, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (287, 1, '35.00', '35.00', '0.00', '35.00', 180, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (288, 1, '32.00', '32.00', '0.00', '32.00', 180, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (289, 2, '35.00', '70.00', '0.00', '70.00', 181, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (290, 2, '15.00', '30.00', '5.00', '25.00', 182, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (291, 2, '15.00', '30.00', '5.00', '25.00', 183, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (292, 2, '15.00', '30.00', '5.00', '25.00', 184, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (293, 2, '25.00', '50.00', '0.00', '50.00', 185, NULL, 6);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (137, 1, '32.00', '32.00', '0.00', '32.00', 96, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (138, 1, '15.00', '15.00', '5.00', '10.00', 96, 7, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (139, 1, '8.00', '8.00', '0.00', '8.00', 97, 8, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (140, 1, '25.00', '25.00', '0.00', '25.00', 97, 5, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (141, 1, '23.00', '23.00', '0.00', '23.00', 97, 6, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (142, 1, '35.00', '35.00', '0.00', '35.00', 98, 3, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (143, 1, '32.00', '32.00', '0.00', '32.00', 98, 4, NULL);
INSERT INTO detallepedido (id, cantidad, preciounitario, subtotal, descuento, total, idpedido, idproductosucursal, idpromocion) OVERRIDING SYSTEM VALUE VALUES (144, 1, '25.00', '25.00', '0.00', '25.00', 98, 5, NULL);
SELECT setval(pg_get_serial_sequence('detallepedido', 'id'), COALESCE((SELECT MAX(id) FROM detallepedido), 1), true);

-- Datos para tabla: unidadmedida (5 registros)
INSERT INTO unidadmedida (id, nombre, abreviatura, tipo, estado) OVERRIDING SYSTEM VALUE VALUES (3, 'Gramos', 'GR', 'PESO', TRUE);
INSERT INTO unidadmedida (id, nombre, abreviatura, tipo, estado) OVERRIDING SYSTEM VALUE VALUES (4, 'Unidad', 'UND', 'UNIDAD', TRUE);
INSERT INTO unidadmedida (id, nombre, abreviatura, tipo, estado) OVERRIDING SYSTEM VALUE VALUES (5, 'Mililitro', 'ML', 'VOLUMEN', TRUE);
INSERT INTO unidadmedida (id, nombre, abreviatura, tipo, estado) OVERRIDING SYSTEM VALUE VALUES (6, 'Litro', 'L', 'VOLUMEN', TRUE);
INSERT INTO unidadmedida (id, nombre, abreviatura, tipo, estado) OVERRIDING SYSTEM VALUE VALUES (7, 'Rodajas', 'ROD', 'UNIDAD', TRUE);
SELECT setval(pg_get_serial_sequence('unidadmedida', 'id'), COALESCE((SELECT MAX(id) FROM unidadmedida), 1), true);

-- Datos para tabla: insumo (12 registros)
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (3, 'Pan de hamburguesa', 'Pan brioche', 4, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (5, 'Gaseosa 1L', 'Gaseosa de 1 litro', 6, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (6, 'Gaseosa 2L', 'Gaseosa de 2 Litros', 6, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (2, 'Carne de Burguer', 'Carne molida', 3, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (7, 'Gaseosa 1.5L', 'Gaseosa de 1.5 Litro', 6, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (8, 'Carne de Res', 'Carne de Res para Asado', 3, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (9, 'Chorizo Viena', 'Chorizo Viena para dogor', 3, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (10, 'Cebolla', 'Cebolla de rodaja', 7, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (11, 'Pepinillo', 'Rodaja de Pepinillo', 7, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (12, 'Lechuga', 'Rodaja de Lechuga', 7, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (13, 'Choclo', 'cuchara de choclo', 3, TRUE);
INSERT INTO insumo (id, nombre, descripcion, idunidadmedida, estado) OVERRIDING SYSTEM VALUE VALUES (14, 'Tomate', 'Rodaja de Tomate', 7, TRUE);
SELECT setval(pg_get_serial_sequence('insumo', 'id'), COALESCE((SELECT MAX(id) FROM insumo), 1), true);

-- Datos para tabla: detallereceta (29 registros)
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (3, 39, 5, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (4, 1, 2, '0.250');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (5, 33, 6, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (6, 9, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (12, 6, 2, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (13, 5, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (14, 5, 2, '270.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (16, 3, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (7, 11, 2, '135.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (17, 11, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (8, 13, 2, '135.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (18, 13, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (9, 12, 2, '135.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (19, 12, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (10, 10, 2, '135.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (20, 10, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (11, 4, 2, '135.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (21, 4, 3, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (22, 38, 7, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (23, 44, 8, '300.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (24, 49, 8, '400.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (25, 50, 8, '350.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (15, 3, 2, '120.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (26, 3, 9, '25.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (27, 3, 10, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (28, 3, 11, '1.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (29, 3, 12, '2.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (30, 3, 13, '10.000');
INSERT INTO detallereceta (id, idproducto, idinsumo, cantidad) OVERRIDING SYSTEM VALUE VALUES (31, 3, 14, '3.000');
SELECT setval(pg_get_serial_sequence('detallereceta', 'id'), COALESCE((SELECT MAX(id) FROM detallereceta), 1), true);

-- Datos para tabla: diaatencion (7 registros)
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (1, 'Lunes', 1);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (2, 'Martes', 2);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (3, 'Miércoles', 3);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (4, 'Jueves', 4);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (5, 'Viernes', 5);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (6, 'Sábado', 6);
INSERT INTO diaatencion (id, nombredia, numerodia) OVERRIDING SYSTEM VALUE VALUES (7, 'Domingo', 7);
SELECT setval(pg_get_serial_sequence('diaatencion', 'id'), COALESCE((SELECT MAX(id) FROM diaatencion), 1), true);

-- Datos para tabla: historialproducto (2 registros)
INSERT INTO historialproducto (id, fecha_registro, precioanterior, precionuevo, idproductosucursal) OVERRIDING SYSTEM VALUE VALUES (1, '2026-09-17 04:10:39', '32.00', '35.00', 3);
INSERT INTO historialproducto (id, fecha_registro, precioanterior, precionuevo, idproductosucursal) OVERRIDING SYSTEM VALUE VALUES (2, '2026-09-17 13:34:48', '26.00', '28.00', 10);
SELECT setval(pg_get_serial_sequence('historialproducto', 'id'), COALESCE((SELECT MAX(id) FROM historialproducto), 1), true);

-- Datos para tabla: horariosucursal (4 registros)
INSERT INTO horariosucursal (idhorariosucursal, idsucursal, horaapertura, horacierre, activo, iddiaatencion) OVERRIDING SYSTEM VALUE VALUES (7, 6, '16:00:00', '22:30:00', TRUE, 3);
INSERT INTO horariosucursal (idhorariosucursal, idsucursal, horaapertura, horacierre, activo, iddiaatencion) OVERRIDING SYSTEM VALUE VALUES (6, 6, '16:00:00', '22:30:00', TRUE, 2);
INSERT INTO horariosucursal (idhorariosucursal, idsucursal, horaapertura, horacierre, activo, iddiaatencion) OVERRIDING SYSTEM VALUE VALUES (5, 6, '16:00:00', '22:30:00', TRUE, 1);
INSERT INTO horariosucursal (idhorariosucursal, idsucursal, horaapertura, horacierre, activo, iddiaatencion) OVERRIDING SYSTEM VALUE VALUES (8, 7, '10:30:00', '15:00:00', TRUE, 7);
SELECT setval(pg_get_serial_sequence('horariosucursal', 'idhorariosucursal'), COALESCE((SELECT MAX(idhorariosucursal) FROM horariosucursal), 1), true);

-- Datos para tabla: inventariosucursal (6 registros)
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (6, 6, 2, '40000.000', '100.000', '2026-09-15 00:31:52');
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (5, 6, 6, '52.000', '5.000', '2026-09-15 00:31:57');
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (8, 6, 7, '39.000', '5.000', '2026-09-15 00:59:16');
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (10, 7, 5, '20.000', '50.000', '2026-09-17 02:31:01');
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (9, 7, 6, '50.000', '49.000', '2026-09-17 02:31:16');
INSERT INTO inventariosucursal (id, idsucursal, idinsumo, cantidad, cantidadminima, fechaactualizacion) OVERRIDING SYSTEM VALUE VALUES (11, 6, 12, '200.000', '30.000', '2026-09-17 14:30:44');
SELECT setval(pg_get_serial_sequence('inventariosucursal', 'id'), COALESCE((SELECT MAX(id) FROM inventariosucursal), 1), true);

-- Datos para tabla: metodopago (3 registros)
INSERT INTO metodopago (id, nombre, activo, gateway) OVERRIDING SYSTEM VALUE VALUES (2, 'Efectivo', TRUE, 'EFECTIVO');
INSERT INTO metodopago (id, nombre, activo, gateway) OVERRIDING SYSTEM VALUE VALUES (3, 'Tarjeta de crédito', TRUE, 'TARJETA');
INSERT INTO metodopago (id, nombre, activo, gateway) OVERRIDING SYSTEM VALUE VALUES (4, 'Transferencia bancaria', TRUE, 'BANCO');
SELECT setval(pg_get_serial_sequence('metodopago', 'id'), COALESCE((SELECT MAX(id) FROM metodopago), 1), true);

-- Datos para tabla: movimientocaja (9 registros)
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (120, '2026-09-19 14:07:24', 'INGRESO', 'Ingresar monedas', '50.00', NULL, 34, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (121, '2026-09-19 14:08:30', 'INGRESO', 'falto monedas', '20.00', NULL, 34, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (122, '2026-09-19 14:36:30', 'INGRESO', 'Ingresar monedas', '50.00', NULL, 83, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (123, '2026-09-19 14:36:49', 'EGRESO', 'se necesito comprar pan', '20.00', NULL, 83, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (124, '2026-09-19 21:24:49', 'INGRESO', 'Ingresar monedas', '50.00', NULL, 84, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (125, '2026-09-19 21:25:00', 'EGRESO', 'se necesito comprar pan', '20.00', NULL, 84, 15);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (126, '2026-09-19 21:31:22', 'INGRESO', 'monedas', '50.00', NULL, 85, 39);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (127, '2026-09-19 21:31:39', 'INGRESO', 'mas monedas', '50.00', NULL, 85, 39);
INSERT INTO movimientocaja (id, fechamovimiento, tipomovimiento, concepto, monto, observacion, idaperturacaja, idempleado) OVERRIDING SYSTEM VALUE VALUES (128, '2026-09-19 21:32:01', 'EGRESO', 'plata para llevar comida', '30.00', NULL, 85, 39);
SELECT setval(pg_get_serial_sequence('movimientocaja', 'id'), COALESCE((SELECT MAX(id) FROM movimientocaja), 1), true);

-- Datos para tabla: movimientoinventario (13 registros)
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (5, 5, 'ENTRADA', '20.000', '0.000', '20.000', '2026-09-14 23:39:10', 39, 'Coca de 2 litros');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (6, 6, 'ENTRADA', '40000.000', '0.000', '40000.000', '2026-09-14 23:39:53', 39, '40 Kg de carne');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (7, 5, 'SALIDA', '1.000', '20.000', '19.000', '2026-09-14 23:40:25', 39, 'El gerente saca una Coca');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (8, 5, 'AJUSTE', '1.000', '19.000', '1.000', '2026-09-14 23:42:10', 2, 'Debo una Coca de 2 litro');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (9, 5, 'ENTRADA', '1.000', '1.000', '2.000', '2026-09-14 23:42:50', 2, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (10, 5, 'ENTRADA', '50.000', '2.000', '52.000', '2026-09-14 23:46:35', 2, '50 litros de coca se ingresa');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (17, 8, 'ENTRADA', '60.000', '0.000', '60.000', '2026-09-15 00:57:51', 15, 'gaseosa coca de 1.5L');
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (18, 8, 'SALIDA', '5.000', '60.000', '55.000', '2026-09-15 00:58:25', 15, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (19, 8, 'SALIDA', '6.000', '55.000', '49.000', '2026-09-15 00:58:54', 39, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (20, 8, 'SALIDA', '10.000', '49.000', '39.000', '2026-09-15 00:59:16', 2, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (21, 9, 'ENTRADA', '50.000', '0.000', '50.000', '2026-09-17 02:26:12', 40, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (22, 10, 'ENTRADA', '20.000', '0.000', '20.000', '2026-09-17 02:30:31', 2, NULL);
INSERT INTO movimientoinventario (id, idinventariosucursal, tipomovimiento, cantidad, cantidadanterior, cantidadnueva, fechamovimiento, idempleado, observacion) OVERRIDING SYSTEM VALUE VALUES (23, 11, 'ENTRADA', '200.000', '0.000', '200.000', '2026-09-17 14:30:45', 15, 'Por bola de de lechuga serian 10 y se estan añadiendo 20 bolas de lechuga siendo total en rogadas 200');
SELECT setval(pg_get_serial_sequence('movimientoinventario', 'id'), COALESCE((SELECT MAX(id) FROM movimientoinventario), 1), true);

-- Datos para tabla: venta (13 registros)
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (109, '2026-09-19 10:22:22', '43.00', 'PAGADA', 15, 167);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (110, '2026-09-19 10:23:43', '85.00', 'PAGADA', 15, 168);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (111, '2026-09-19 13:21:59', '60.00', 'PAGADA', 15, 169);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (112, '2026-09-19 14:05:53', '8.00', 'PAGADA', 15, 170);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (113, '2026-09-19 14:31:17', '93.00', 'PAGADA', 15, 172);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (114, '2026-09-19 14:32:50', '67.00', 'PAGADA', 15, 173);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (115, '2026-09-19 14:34:22', '233.00', 'PAGADA', 15, 174);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (116, '2026-09-19 15:35:28', '85.00', 'PAGADA', 15, 175);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (117, '2026-09-19 21:26:39', '176.00', 'PAGADA', 39, 177);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (118, '2026-09-19 21:27:16', '85.00', 'PAGADA', 39, 176);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (119, '2026-09-20 00:45:40', '50.00', 'PAGADA', 39, 185);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (120, '2026-09-20 00:46:18', '70.00', 'PAGADA', 39, 181);
INSERT INTO venta (id, fechaventa, totalventa, estadoventa, idempleado, idpedido) OVERRIDING SYSTEM VALUE VALUES (121, '2026-09-20 00:46:31', '67.00', 'PAGADA', 39, 180);
SELECT setval(pg_get_serial_sequence('venta', 'id'), COALESCE((SELECT MAX(id) FROM venta), 1), true);

-- Datos para tabla: pago (13 registros)
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (84, 109, 2, 34, '43.00', 'APROBADO', '50.00', '7.00', NULL, 'EFECTIVO', 'EF-A2ZOFFEA', NULL, NULL, NULL, '2026-09-19 10:22:22', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (85, 110, 2, 34, '85.00', 'APROBADO', '100.00', '15.00', NULL, 'EFECTIVO', 'EF-IQYD7LXF', NULL, NULL, NULL, '2026-09-19 10:23:43', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (86, 111, 2, 34, '60.00', 'APROBADO', '100.00', '40.00', NULL, 'EFECTIVO', 'EF-WJHVPWFK', NULL, NULL, NULL, '2026-09-19 13:21:59', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (87, 112, 2, 34, '8.00', 'APROBADO', '8.00', '0.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 14:05:53', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (88, 113, 2, 83, '93.00', 'APROBADO', '100.00', '7.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 14:31:18', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (89, 114, 2, 83, '67.00', 'APROBADO', '100.00', '33.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 14:32:50', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (90, 115, 2, 83, '233.00', 'APROBADO', '250.00', '17.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 14:34:22', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (91, 116, 2, 83, '85.00', 'APROBADO', '100.00', '15.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 15:35:28', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (92, 117, 2, 84, '176.00', 'APROBADO', '200.00', '24.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 21:26:39', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (93, 118, 2, 84, '85.00', 'APROBADO', '100.00', '15.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-19 21:27:16', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (94, 119, 2, 85, '50.00', 'APROBADO', '50.00', '0.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-20 00:45:40', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (95, 120, 2, 85, '70.00', 'APROBADO', '100.00', '30.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-20 00:46:18', 'Pago en efectivo');
INSERT INTO pago (id, idventa, idmetodopago, idaperturacaja, montopago, estadopago, montorecibido, cambioentregado, referenciaexterna, gateway, codigoautorizacion, idtransaccion, ultimos4, marcatarjeta, fechapago, observacionpago) OVERRIDING SYSTEM VALUE VALUES (96, 121, 2, 85, '67.00', 'APROBADO', '100.00', '33.00', NULL, 'EFECTIVO', NULL, NULL, NULL, NULL, '2026-09-20 00:46:32', 'Pago en efectivo');
SELECT setval(pg_get_serial_sequence('pago', 'id'), COALESCE((SELECT MAX(id) FROM pago), 1), true);

-- Datos para tabla: promocion_sucursal_producto (5 registros)
INSERT INTO promocion_sucursal_producto (idpromocion, idsucursalproducto, cantidad_producto) VALUES (3, 8, 1);
INSERT INTO promocion_sucursal_producto (idpromocion, idsucursalproducto, cantidad_producto) VALUES (3, 9, 1);
INSERT INTO promocion_sucursal_producto (idpromocion, idsucursalproducto, cantidad_producto) VALUES (4, 6, 1);
INSERT INTO promocion_sucursal_producto (idpromocion, idsucursalproducto, cantidad_producto) VALUES (116, 4, 2);
INSERT INTO promocion_sucursal_producto (idpromocion, idsucursalproducto, cantidad_producto) VALUES (6, 7, 2);


-- Funciones y procedimientos almacenados
CREATE OR REPLACE FUNCTION public.actualizar_caja(p_id integer, p_idsucursal integer, p_nombre character varying, p_activo boolean)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_duplicado INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_duplicado
      FROM caja
     WHERE idsucursal = p_idsucursal
       AND nombre = p_nombre
       AND id <> p_id;

    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una caja con ese nombre en esta sucursal.';
    END IF;

    UPDATE caja
       SET nombre = p_nombre,
           activo = p_activo
     WHERE id = p_id;
END;
$function$
;

CREATE OR REPLACE PROCEDURE public.actualizar_mesa(IN p_id integer, IN p_idsucursal integer, IN p_numeromesa integer, IN p_capacidad integer, IN p_estado boolean, IN p_id_empleado integer, IN p_codigo_permiso character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_duplicado INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_duplicado
      FROM mesa
     WHERE idsucursal = p_idsucursal
       AND numeromesa = p_numeromesa
       AND id <> p_id;

    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una mesa con ese número en esta sucursal.';
    END IF;

    UPDATE mesa
       SET numeromesa = p_numeromesa,
           capacidad = p_capacidad,
           estado = p_estado
     WHERE id = p_id;

    CALL registrar_accion(
        p_id_empleado,
        'UPDATE',
        'mesa',
        p_id,
        p_codigo_permiso,
        'EXITOSO',
        p_equipo,
        p_ip
    );
END;
$procedure$
;

CREATE OR REPLACE PROCEDURE public.actualizar_perfil(IN p_id_empleado integer, IN p_nombre character varying, IN p_apellido character varying, IN p_telefono character varying, IN p_usuario character varying, IN p_correo character varying, IN p_password_hash character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_nombre VARCHAR(100);
    v_apellido VARCHAR(100);
    v_telefono VARCHAR(15);
    v_id_cuenta INTEGER;
    v_usuario VARCHAR(50);
    v_correo VARCHAR(150);
    v_cambia_empleado BOOLEAN;
    v_cambia_cuenta BOOLEAN;
BEGIN
    SELECT nombre, apellido, telefono
      INTO v_nombre, v_apellido, v_telefono
      FROM empleado
     WHERE id = p_id_empleado;

    SELECT id, usuario, correo
      INTO v_id_cuenta, v_usuario, v_correo
      FROM cuentausuario
     WHERE idempleado = p_id_empleado;

    v_cambia_empleado := p_nombre IS DISTINCT FROM v_nombre
        OR p_apellido IS DISTINCT FROM v_apellido
        OR COALESCE(p_telefono, '') IS DISTINCT FROM COALESCE(v_telefono, '');

    v_cambia_cuenta := p_usuario IS DISTINCT FROM v_usuario
        OR p_correo IS DISTINCT FROM v_correo
        OR p_password_hash IS NOT NULL;

    UPDATE empleado
       SET nombre = p_nombre,
           apellido = p_apellido,
           telefono = p_telefono
     WHERE id = p_id_empleado;

    UPDATE cuentausuario
       SET usuario = p_usuario,
           correo = p_correo
     WHERE idempleado = p_id_empleado;

    IF p_password_hash IS NOT NULL THEN
        UPDATE cuentausuario
           SET passwordhash = p_password_hash,
               intentosfallidos = 0,
               bloqueado = FALSE,
               bloqueadohasta = NULL
         WHERE idempleado = p_id_empleado;
    END IF;

    IF v_cambia_empleado THEN
        CALL registrar_accion(p_id_empleado, 'UPDATE', 'empleado', p_id_empleado, '101', 'EXITOSO', p_equipo, p_ip);
    END IF;

    IF v_cambia_cuenta THEN
        CALL registrar_accion(p_id_empleado, 'UPDATE', 'cuentausuario', v_id_cuenta, '106', 'EXITOSO', p_equipo, p_ip);
    END IF;
END;
$procedure$
;

CREATE OR REPLACE PROCEDURE public.dar_baja_caja(IN p_id integer, IN p_id_empleado integer, IN p_codigo_permiso character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
BEGIN
    UPDATE caja SET activo = FALSE WHERE id = p_id;

    CALL registrar_accion(
        p_id_empleado,
        'DELETE',
        'caja',
        p_id,
        p_codigo_permiso,
        'EXITOSO',
        p_equipo,
        p_ip
    );
END;
$procedure$
;

CREATE OR REPLACE PROCEDURE public.dar_baja_mesa(IN p_id integer, IN p_id_empleado integer, IN p_codigo_permiso character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
BEGIN
    UPDATE mesa SET estado = FALSE WHERE id = p_id;

    CALL registrar_accion(
        p_id_empleado,
        'DELETE',
        'mesa',
        p_id,
        p_codigo_permiso,
        'EXITOSO',
        p_equipo,
        p_ip
    );
END;
$procedure$
;

CREATE OR REPLACE FUNCTION public.fn_calcular_parametros_cierre()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_efectivo NUMERIC(10,2) := 0;
    v_qr       NUMERIC(10,2) := 0;
    v_tarjeta  NUMERIC(10,2) := 0;
    v_ventas   NUMERIC(10,2) := 0;
    v_ingresos NUMERIC(10,2) := 0;
    v_egresos  NUMERIC(10,2) := 0;
    v_fondo    NUMERIC(10,2) := 0;
BEGIN
    SELECT COALESCE(SUM(CASE WHEN LOWER(mp.nombre) = 'efectivo' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) <> 'efectivo' AND LOWER(mp.nombre) NOT LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0)
      INTO v_efectivo, v_tarjeta, v_qr
      FROM pago p
      JOIN metodopago mp ON mp.id = p.idmetodopago
     WHERE p.idaperturacaja = NEW.idaperturacaja
       AND p.estadopago = 'APROBADO';

    v_ventas := v_efectivo + v_qr + v_tarjeta;

    SELECT COALESCE(SUM(monto), 0)
      INTO v_ingresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'INGRESO';

    SELECT COALESCE(SUM(monto), 0)
      INTO v_egresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'EGRESO';

    SELECT COALESCE(montoinicial, 0)
      INTO v_fondo
      FROM aperturacaja
     WHERE id = NEW.idaperturacaja;

    NEW.fondoinicial := v_fondo;
    NEW.totalventasefectivo := v_efectivo;
    NEW.totalventasqr := v_qr;
    NEW.totalventastarjeta := v_tarjeta;
    NEW.totalventas := v_ventas;
    NEW.totalingresos := v_ingresos;
    NEW.totalegresos := v_egresos;
    NEW.efectivoesperado := v_fondo + v_efectivo + v_ingresos - v_egresos;
    NEW.diferencia := NEW.efectivocontado - NEW.efectivoesperado;

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_crear_cierre_inicial()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    INSERT INTO cierrecaja (
        fechacierre, fondoinicial,
        totalventasefectivo, totalventasqr, totalventastarjeta, totalventas,
        totalingresos, totalegresos,
        efectivoesperado, efectivocontado, diferencia,
        observacion, idaperturacaja, idempleado
    ) VALUES (
        NEW.fechaapertura, NEW.montoinicial,
        0, 0, 0, 0,
        0, 0,
        NEW.montoinicial, NEW.montoinicial, 0,
        'Cierre provisional: la jornada aún está en curso.', NEW.id, NEW.idempleado
    );
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_refrescar_cierre_por_movimiento()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_refrescar_cierre_por_pago()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_validar_apertura_caja()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_abiertas INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA';
    ELSE
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA'
           AND id <> NEW.id;
    END IF;

    IF v_abiertas > 0 THEN
        RAISE EXCEPTION 'Ya existe una apertura de caja abierta para esta caja; debes cerrarla antes de abrir una nueva jornada.';
    END IF;

    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE PROCEDURE public.reasignar_subordinados(IN p_jefe_anterior integer, IN p_jefe_nuevo integer, IN p_idsucursal integer)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_id_rol_cajero INTEGER;
    v_id_rol_mesero INTEGER;
BEGIN
    IF p_jefe_anterior IS NOT DISTINCT FROM p_jefe_nuevo THEN
        RETURN;
    END IF;

    SELECT id INTO v_id_rol_cajero FROM rol WHERE claverol = 'CAJERO' LIMIT 1;
    SELECT id INTO v_id_rol_mesero FROM rol WHERE claverol = 'MESERO' LIMIT 1;

    -- Si el nuevo gerente dependía del antiguo (idjefe = antiguo), romper
    -- la referencia circular: el nuevo jefe queda sin jefe.
    IF p_jefe_nuevo IS NOT NULL THEN
        UPDATE empleado
           SET idjefe = NULL
         WHERE id = p_jefe_nuevo
           AND idjefe IS NOT DISTINCT FROM p_jefe_anterior;
    END IF;

    -- Reasignar al nuevo gerente TODOS los cajeros/meseros que dependían
    -- del antiguo gerente (estén en esta u otra sucursal).
    UPDATE empleado
       SET idjefe = p_jefe_nuevo
     WHERE idjefe IS NOT DISTINCT FROM p_jefe_anterior
       AND idrol IN (v_id_rol_cajero, v_id_rol_mesero)
       AND (p_jefe_nuevo IS NULL OR id <> p_jefe_nuevo);

    -- Los cajeros/meseros de ESTA sucursal que estén sin gerente (idjefe NULL)
    -- pasan a depender del nuevo gerente.
    UPDATE empleado
       SET idjefe = p_jefe_nuevo
     WHERE idsucursal = p_idsucursal
       AND idjefe IS NULL
       AND idrol IN (v_id_rol_cajero, v_id_rol_mesero)
       AND (p_jefe_nuevo IS NULL OR id <> p_jefe_nuevo);

    -- El antiguo gerente queda sin jefe.
    IF p_jefe_anterior IS NOT NULL THEN
        UPDATE empleado SET idjefe = NULL WHERE id = p_jefe_anterior;
    END IF;
END;
$procedure$
;

CREATE OR REPLACE PROCEDURE public.registrar_acceso(IN p_id_empleado integer, IN p_tipo_acceso character varying, IN p_equipo character varying, IN p_ip character varying, IN p_resultado character varying, IN p_detalle character varying)
 LANGUAGE plpgsql
AS $procedure$
BEGIN
    INSERT INTO bitacoraacceso (idempleado, tipoacceso, equipo, ip, resultado, detalle)
    VALUES (
        p_id_empleado,
        p_tipo_acceso,
        p_equipo,
        p_ip,
        p_resultado,
        LEFT(p_detalle, 255)
    );
END;
$procedure$
;

CREATE OR REPLACE PROCEDURE public.registrar_accion(IN p_id_empleado integer, IN p_accion character varying, IN p_tabla_afectada character varying, IN p_id_registro_afectado bigint, IN p_codigo_permiso character varying, IN p_resultado character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_id_permiso INTEGER;
BEGIN
    v_id_permiso := COALESCE(
        (SELECT id FROM permiso WHERE codigo = p_codigo_permiso AND estado = TRUE),
        (SELECT id FROM permiso WHERE estado = TRUE ORDER BY id LIMIT 1),
        1
    );

    INSERT INTO bitacoraaccion (idempleado, idpermiso, accion, tablaafectada, idregistroafectado, equipo, ip, resultado)
    VALUES (
        p_id_empleado,
        v_id_permiso,
        p_accion,
        p_tabla_afectada,
        p_id_registro_afectado,
        p_equipo,
        p_ip,
        COALESCE(p_resultado, 'EXITOSO')
    );
END;
$procedure$
;

CREATE OR REPLACE FUNCTION public.registrar_caja(p_idsucursal integer, p_nombre character varying, p_activo boolean)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_activas INTEGER;
    v_duplicado INTEGER;
    v_id INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_activas
      FROM caja
     WHERE idsucursal = p_idsucursal AND activo = TRUE;

    IF v_activas >= 2 THEN
        RAISE EXCEPTION 'La sucursal ya tiene dos cajas activas.';
    END IF;

    SELECT COUNT(*) INTO v_duplicado
      FROM caja
     WHERE idsucursal = p_idsucursal AND nombre = p_nombre;

    IF v_duplicado > 0 THEN
        RAISE EXCEPTION 'Ya existe una caja con ese nombre en esta sucursal.';
    END IF;

    INSERT INTO caja (nombre, idsucursal, activo)
    VALUES (p_nombre, p_idsucursal, p_activo)
    RETURNING id INTO v_id;

    RETURN v_id;
END;
$function$
;

CREATE OR REPLACE PROCEDURE public.registrar_mesa(IN p_idsucursal integer, IN p_numeromesa integer, IN p_capacidad integer, IN p_estado boolean, IN p_id_empleado integer, IN p_codigo_permiso character varying, IN p_equipo character varying, IN p_ip character varying)
 LANGUAGE plpgsql
AS $procedure$
DECLARE
    v_id INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_id
      FROM mesa
     WHERE idsucursal = p_idsucursal AND numeromesa = p_numeromesa;

    IF v_id > 0 THEN
        RAISE EXCEPTION 'Ya existe una mesa con ese número en esta sucursal.';
    END IF;

    INSERT INTO mesa (numeromesa, capacidad, estado, idsucursal)
    VALUES (p_numeromesa, p_capacidad, p_estado, p_idsucursal)
    RETURNING id INTO v_id;

    CALL registrar_accion(
        p_id_empleado,
        'CREATE',
        'mesa',
        v_id,
        p_codigo_permiso,
        'EXITOSO',
        p_equipo,
        p_ip
    );
END;
$procedure$
;

CREATE OR REPLACE FUNCTION public.verificar_bloqueo_y_desbloquear(p_id_cuenta integer)
 RETURNS boolean
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_hasta TIMESTAMP;
BEGIN
	SELECT cu.bloqueadohasta INTO v_hasta FROM cuentausuario cu WHERE cu.idempleado = p_id_cuenta;
    if now()> v_hasta then
        UPDATE cuentausuario cu SET bloqueado = FALSE, bloqueadohasta = NULL, intentosfallidos = 0
		WHERE cu.idempleado = p_id_cuenta;
        RETURN TRUE;
	end if;
    return false;
END;
$function$
;

CREATE OR REPLACE FUNCTION fn_validar_apertura_caja() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_abiertas INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA';
    ELSE
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA'
           AND id <> NEW.id;
    END IF;

    IF v_abiertas > 0 THEN
        RAISE EXCEPTION 'Ya existe una apertura de caja abierta para esta caja; debes cerrarla antes de abrir una nueva jornada.';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validar_apertura_caja
BEFORE INSERT OR UPDATE ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_validar_apertura_caja();

CREATE OR REPLACE FUNCTION fn_crear_cierre_inicial() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO cierrecaja (
        fechacierre, fondoinicial,
        totalventasefectivo, totalventasqr, totalventastarjeta, totalventas,
        totalingresos, totalegresos,
        efectivoesperado, efectivocontado, diferencia,
        observacion, idaperturacaja, idempleado
    ) VALUES (
        NEW.fechaapertura, NEW.montoinicial,
        0, 0, 0, 0,
        0, 0,
        NEW.montoinicial, NEW.montoinicial, 0,
        'Cierre provisional: la jornada aún está en curso.', NEW.id, NEW.idempleado
    );
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_crear_cierre_inicial
AFTER INSERT ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_crear_cierre_inicial();

CREATE OR REPLACE FUNCTION fn_calcular_parametros_cierre() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_efectivo NUMERIC(10,2) := 0;
    v_qr       NUMERIC(10,2) := 0;
    v_tarjeta  NUMERIC(10,2) := 0;
    v_ventas   NUMERIC(10,2) := 0;
    v_ingresos NUMERIC(10,2) := 0;
    v_egresos  NUMERIC(10,2) := 0;
    v_fondo    NUMERIC(10,2) := 0;
BEGIN
    SELECT COALESCE(SUM(CASE WHEN LOWER(mp.nombre) = 'efectivo' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) <> 'efectivo' AND LOWER(mp.nombre) NOT LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0)
      INTO v_efectivo, v_tarjeta, v_qr
      FROM pago p
      JOIN metodopago mp ON mp.id = p.idmetodopago
     WHERE p.idaperturacaja = NEW.idaperturacaja
       AND p.estadopago = 'APROBADO';

    v_ventas := v_efectivo + v_qr + v_tarjeta;

    SELECT COALESCE(SUM(monto), 0)
      INTO v_ingresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'INGRESO';

    SELECT COALESCE(SUM(monto), 0)
      INTO v_egresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'EGRESO';

    SELECT COALESCE(montoinicial, 0)
      INTO v_fondo
      FROM aperturacaja
     WHERE id = NEW.idaperturacaja;

    NEW.fondoinicial := v_fondo;
    NEW.totalventasefectivo := v_efectivo;
    NEW.totalventasqr := v_qr;
    NEW.totalventastarjeta := v_tarjeta;
    NEW.totalventas := v_ventas;
    NEW.totalingresos := v_ingresos;
    NEW.totalegresos := v_egresos;
    NEW.efectivoesperado := v_fondo + v_efectivo + v_ingresos - v_egresos;
    NEW.diferencia := NEW.efectivocontado - NEW.efectivoesperado;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_calcular_parametros_cierre
BEFORE INSERT OR UPDATE ON cierrecaja
FOR EACH ROW EXECUTE FUNCTION fn_calcular_parametros_cierre();

-- Cada pago aprobado (insert/update/delete) refresca los totales del cierre en curso,
-- invocando el BEFORE UPDATE de fn_calcular_parametros_cierre sobre la caja abierta.
CREATE OR REPLACE FUNCTION fn_refrescar_cierre_por_pago() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_refrescar_cierre_por_pago
AFTER INSERT OR UPDATE OR DELETE ON pago
FOR EACH ROW EXECUTE FUNCTION fn_refrescar_cierre_por_pago();

-- Cada ingreso/egreso (insert/update/delete) también refresca los totales del
-- cierre en curso usando el mismo patrón de "touch" sobre cierrecaja.
CREATE OR REPLACE FUNCTION fn_refrescar_cierre_por_movimiento() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_refrescar_cierre_por_movimiento
AFTER INSERT OR UPDATE OR DELETE ON movimientocaja
FOR EACH ROW EXECUTE FUNCTION fn_refrescar_cierre_por_movimiento();

