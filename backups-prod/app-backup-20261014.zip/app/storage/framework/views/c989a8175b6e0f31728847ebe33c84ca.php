
<?php if($historial->isEmpty()): ?>
    <div class="text-center text-muted py-4">Este producto aún no tiene cambios de precio registrados.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th>Fecha del cambio</th>
                    <th>Precio anterior</th>
                    <th>Precio nuevo</th>
                    <th>Variación</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $anterior = (float) $registro->precioanterior;
                        $nuevo = (float) $registro->precionuevo;
                        $diferencia = round($nuevo - $anterior, 2);
                    ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($registro->fecha_registro)->format('d/m/Y H:i')); ?></td>
                        <td>S/ <?php echo e(number_format($anterior, 2)); ?></td>
                        <td class="fw-semibold">S/ <?php echo e(number_format($nuevo, 2)); ?></td>
                        <td>
                            <?php if($diferencia > 0): ?>
                                <span class="badge text-bg-success">+S/ <?php echo e(number_format($diferencia, 2)); ?></span>
                            <?php elseif($diferencia < 0): ?>
                                <span class="badge text-bg-danger">-S/ <?php echo e(number_format(abs($diferencia), 2)); ?></span>
                            <?php else: ?>
                                <span class="badge text-bg-secondary">Sin cambio</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/admin/productos-sucursal/_historial.blade.php ENDPATH**/ ?>