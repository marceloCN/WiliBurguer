<?php

require __DIR__ . '/../../../vendor/autoload.php';

$app = require_once __DIR__ . '/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$cols = DB::select("SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_name = 'rolpermiso' ORDER BY ordinal_position");
var_dump($cols);

$permisos = DB::table('permiso')->orderBy('codigo')->limit(10)->get();
echo "\nPrimeros permisos:\n";
var_dump($permisos->toArray());

$roles = DB::table('rol')->orderBy('id')->get();
echo "\nRoles:\n";
var_dump($roles->toArray());
