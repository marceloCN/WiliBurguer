<?php $__env->startSection('title', 'Mi perfil · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-12 col-md-10 col-lg-8 col-xl-6">
                <h1 class="h3 fw-bold mb-4">Mi perfil</h1>

                <?php if(session('exito')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('exito')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->all()): ?>
                    <div class="alert alert-danger">
                        <strong>Revisa los datos:</strong>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="card tarjeta-producto mb-4">
                    <div class="card-body p-4">
                        <h2 class="h5 fw-bold mb-3">Datos personales y de acceso</h2>
                        <form method="POST" action="<?php echo e(route('dashboard.perfil.update')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Nombre *</label>
                                    <input type="text" name="nombre" class="form-control"
                                           value="<?php echo e(old('nombre', $empleado->nombre)); ?>" required maxlength="100">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Apellido *</label>
                                    <input type="text" name="apellido" class="form-control"
                                           value="<?php echo e(old('apellido', $empleado->apellido)); ?>" required maxlength="100">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Teléfono</label>
                                    <input type="text" name="telefono" class="form-control"
                                           value="<?php echo e(old('telefono', $empleado->telefono)); ?>" maxlength="15">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Rol</label>
                                    <input type="text" class="form-control"
                                           value="<?php echo e($empleado->rol?->nombrerol); ?>" disabled>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Usuario *</label>
                                    <input type="text" name="usuario" class="form-control"
                                           value="<?php echo e(old('usuario', $cuenta->usuario)); ?>" required maxlength="255">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Correo *</label>
                                    <input type="email" name="correo" class="form-control"
                                           value="<?php echo e(old('correo', $cuenta->correo)); ?>" required maxlength="255">
                                </div>
                            </div>

                            <hr class="my-4">

                            <h3 class="h5 fw-bold mb-3">Cambiar contraseña</h3>
                            <p class="text-muted small mb-3">Opcional. Solo rellena estos campos si deseas cambiarla.</p>

                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label">Contraseña actual</label>
                                    <input type="password" name="password_actual" class="form-control" autocomplete="current-password">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Nueva contraseña</label>
                                    <input type="password" name="password" class="form-control" minlength="6" autocomplete="new-password">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Confirmar nueva contraseña</label>
                                    <input type="password" name="password_confirmation" class="form-control" autocomplete="new-password">
                                </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4">
                                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary">Cancelar</a>
                                <button type="submit" class="btn btn-brand">Guardar cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/perfil.blade.php ENDPATH**/ ?>