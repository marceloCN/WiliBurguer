@extends('layouts.app')

@section('title', 'Insumos y recetas · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Insumos y recetas 📦</h1>
                <p class="text-muted mb-0">Administra unidades de medida, insumos y la receta de cada producto.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <button class="btn btn-outline-brand" data-bs-toggle="modal" data-bs-target="#crearUnidadModal">
                    + Nueva unidad
                </button>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearInsumoModal"
                        @if (!$unidades->where('estado', true)->count()) disabled title="Primero crea una unidad de medida" @endif>
                    + Nuevo insumo
                </button>
            </div>
        </div>

        <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'insumos' ? 'active fw-bold' : 'text-reset' }}"
                   href="{{ route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $idunidadmedida]) }}">
                    📦 Insumos
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link {{ $tab === 'recetas' ? 'active fw-bold' : 'text-reset' }}"
                   href="{{ route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $idproducto]) }}">
                    🍔 Recetas por producto
                </a>
            </li>
        </ul>

        @include('partials.mensajes')

        @if ($tab === 'recetas')
            {{-- ================== SECCIÓN RECETAS (detalle de receta por producto) ================== --}}
            <p class="small text-muted mb-3">
                Aquí defines de qué está hecho cada producto: agrega los <strong>insumos</strong> que se necesitan para prepararlo
                (los mismos registrados en la pestaña «📦 Insumos») y la <strong>cantidad</strong> de cada uno según su unidad de medida.
            </p>
            <div class="row g-4">
                {{-- Columna izquierda: productos agrupados por categoría (como el menú) --}}
                <div class="col-12 col-lg-4">
                    <div class="card tarjeta-producto h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Productos</span>
                            <span class="badge text-bg-dark">{{ $productos->count() }}</span>
                        </div>
                        <div class="accordion accordion-flush" id="acordeonCategoriasReceta">
                            @forelse ($productosAgrupados as $categoriaNombre => $productosCategoria)
                                @php
                                    $itemId = 'acc-rec-' . $loop->index;
                                    $expandida = $productosCategoria->contains(
                                        fn (App\Models\Producto $p) => $p->id === $productoActual?->id,
                                    );
                                @endphp
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button py-3 {{ $expandida ? '' : 'collapsed' }}"
                                                type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#{{ $itemId }}"
                                                aria-expanded="{{ $expandida ? 'true' : 'false' }}"
                                                aria-controls="{{ $itemId }}">
                                            <span class="fw-semibold text-uppercase small">{{ $categoriaNombre }}</span>
                                            <span class="badge text-bg-secondary ms-2">{{ $productosCategoria->count() }}</span>
                                        </button>
                                    </h2>
                                    <div id="{{ $itemId }}"
                                         class="accordion-collapse collapse {{ $expandida ? 'show' : '' }}"
                                         data-bs-parent="#acordeonCategoriasReceta">
                                        <div class="accordion-body p-0">
                                            <div class="list-group list-group-flush">
                                                @foreach ($productosCategoria as $producto)
                                                    <div class="list-group-item d-flex justify-content-between align-items-center gap-2
                                                                {{ $productoActual?->id === $producto->id ? 'active' : '' }}">
                                                        <a href="{{ route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $producto->id]) }}"
                                                           class="d-flex justify-content-between align-items-center gap-2 flex-grow-1 text-decoration-none overflow-hidden {{ $productoActual?->id === $producto->id ? 'text-white' : 'text-reset' }}">
                                                            <span class="d-flex align-items-center gap-2 text-truncate">
                                                                <span class="fw-semibold text-truncate">{{ $producto->nombre }}</span>
                                                                @if (!$producto->estado)
                                                                    <span class="badge rounded-pill {{ $productoActual?->id === $producto->id ? 'text-bg-light' : 'text-bg-secondary' }}">Inactivo</span>
                                                                @endif
                                                            </span>
                                                            <span class="badge rounded-pill {{ $productoActual?->id === $producto->id ? 'text-bg-light' : 'text-bg-brand' }}">
                                                                {{ $producto->detalles_receta_count }} ing.
                                                            </span>
                                                        </a>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="text-center text-muted py-4">
                                    No hay productos registrados. Créalos desde "Menú de productos".
                                </div>
                            @endforelse
                        </div>
                    </div>
                </div>

                {{-- Columna derecha: receta del producto seleccionado --}}
                <div class="col-12 col-lg-8">
                    <div class="card tarjeta-producto">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                            @if ($productoActual)
                                <span class="fw-bold">Receta · {{ $productoActual->nombre }}</span>
                                <div class="d-flex gap-2 flex-wrap align-items-center">
                                    <span class="badge text-bg-brand">{{ $receta->count() }} insumo(s)</span>
                                    <button type="button" class="btn btn-sm btn-brand"
                                            data-bs-toggle="modal" data-bs-target="#crearRecetaModal"
                                            @if (! $insumosDisponibles->count()) disabled title="Sin insumos disponibles para agregar" @endif>
                                        + Agregar insumo a la receta
                                    </button>
                                </div>
                            @else
                                <span class="fw-bold">Receta</span>
                            @endif
                        </div>

                        @if ($productoActual)
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th>Insumo</th>
                                                <th>Unidad de medida</th>
                                                <th>Cantidad</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($receta as $detalle)
                                                <tr>
                                                    <td>
                                                        <span class="fw-semibold">{{ $detalle->insumo?->nombre }}</span>
                                                        <br>
                                                        <span class="small text-muted">{{ \Illuminate\Support\Str::limit($detalle->insumo?->descripcion, 45) }}</span>
                                                    </td>
                                                    <td>
                                                        <span class="badge text-bg-light border">
                                                            {{ $detalle->insumo?->unidadMedida?->abreviatura ?? '—' }}
                                                        </span>
                                                        <span class="small text-muted ms-1">{{ $detalle->insumo?->unidadMedida?->nombre }}</span>
                                                    </td>
                                                    <td class="fw-semibold">{{ rtrim(rtrim(number_format($detalle->cantidad, 3, '.', ''), '0'), '.') }}</td>
                                                    <td class="text-end">
                                                        <button class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editarCantidadModal"
                                                                data-id="{{ $detalle->id }}"
                                                                data-insumo="{{ $detalle->insumo?->nombre }}"
                                                                data-cantidad="{{ number_format($detalle->cantidad, 3, '.', '') }}">
                                                            Editar
                                                        </button>
                                                        <button class="btn btn-sm btn-outline-danger"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#modal-confirmar-baja"
                                                                data-accion="{{ route('dashboard.insumos.receta.baja', $detalle) }}"
                                                                data-mensaje="¿Quitar el insumo {{ $detalle->insumo?->nombre }} de la receta de {{ $productoActual->nombre }}?">
                                                            Quitar
                                                        </button>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="4" class="text-center py-4 text-muted">
                                                        Este producto aún no tiene receta. Pulsa "+ Agregar insumo a la receta".
                                                    </td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        @else
                            <div class="card-body">
                                <div class="text-center text-muted py-4">Registra productos para poder armar sus recetas.</div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @else
            {{-- ================== SECCIÓN INSUMOS (unidades + insumos) ================== --}}
            <p class="small text-muted mb-3">
                Primero crea la <strong>unidad de medida</strong> (ej. gramos, litros, unidades): es la forma en que se cuenta cada ingrediente.
                Luego crea el <strong>insumo</strong> asignándole una de esas unidades. Con los insumos registrados podrás armar la receta de cada producto en la pestaña «🍔 Recetas por producto».
            </p>
            <div class="row g-4">
                {{-- Columna izquierda: unidades de medida (como las categorías) --}}
                <div class="col-12 col-lg-4">
                    <div class="card tarjeta-producto h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Unidades de medida</span>
                            <span class="badge text-bg-dark">{{ $unidades->count() }}</span>
                        </div>
                        <div class="list-group">
                            @forelse ($unidades as $unidad)
                                <div class="list-group-item d-flex justify-content-between align-items-center gap-2
                                            {{ $unidadActual?->id === $unidad->id ? 'active' : '' }}">
                                    <a href="{{ route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $unidad->id]) }}"
                                       class="d-flex justify-content-between align-items-center gap-2 flex-grow-1 text-decoration-none overflow-hidden {{ $unidadActual?->id === $unidad->id ? 'text-white' : 'text-reset' }}">
                                        <span class="d-flex align-items-center gap-2 text-truncate">
                                            <span class="fw-semibold text-truncate">{{ $unidad->nombre }}</span>
                                            @if (!$unidad->estado)
                                                <span class="badge rounded-pill {{ $unidadActual?->id === $unidad->id ? 'text-bg-light' : 'text-bg-secondary' }}">Inactiva</span>
                                            @endif
                                        </span>
                                        <span class="badge rounded-pill {{ $unidadActual?->id === $unidad->id ? 'text-bg-light' : 'text-bg-brand' }}">
                                            {{ $unidad->insumos_count }} ins.
                                        </span>
                                    </a>
                                </div>
                            @empty
                                <div class="list-group-item text-center text-muted py-4">
                                    No hay unidades registradas. Crea una desde "Nueva unidad".
                                </div>
                            @endforelse
                        </div>
                    </div>
                </div>

                {{-- Columna derecha: insumos de la unidad seleccionada --}}
                <div class="col-12 col-lg-8">
                    <div class="card tarjeta-producto">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <span class="fw-bold">
                                @if ($unidadActual)
                                    Insumos · {{ $unidadActual->nombre }} ({{ $unidadActual->abreviatura }})
                                @else
                                    Insumos
                                @endif
                            </span>
                            @if ($unidadActual)
                                <div class="d-flex gap-2 flex-wrap">
                                    <button class="btn btn-sm btn-outline-brand" data-bs-toggle="modal"
                                            data-bs-target="#editarUnidadModal"
                                            data-id="{{ $unidadActual->id }}"
                                            data-nombre="{{ $unidadActual->nombre }}"
                                            data-abreviatura="{{ $unidadActual->abreviatura }}"
                                            data-tipo="{{ $unidadActual->tipo }}">
                                        Editar unidad
                                    </button>
                                    @if ($unidadActual->estado)
                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal"
                                                data-bs-target="#modal-confirmar-baja"
                                                data-accion="{{ route('dashboard.insumos.unidad.baja', $unidadActual) }}"
                                                data-mensaje="¿Dar de baja la unidad {{ $unidadActual->nombre }} ({{ $unidadActual->abreviatura }})?{{ $unidadActual->insumos_count ? ' Está usada por '.$unidadActual->insumos_count.' insumos y no se podrá completar la baja.' : '' }}">
                                            Dar de baja
                                        </button>
                                    @else
                                        <form method="POST" action="{{ route('dashboard.insumos.unidad.reactivar', $unidadActual) }}" class="d-inline m-0">
                                            @csrf
                                            <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                                        </form>
                                    @endif
                                </div>
                            @endif
                        </div>

                        <div class="card-body">
                            @if (! $unidadActual)
                                <div class="text-center text-muted py-4">
                                    Selecciona una unidad de medida para ver sus insumos.
                                </div>
                            @else
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th>Insumo</th>
                                                <th>Descripción</th>
                                                <th>Unidad</th>
                                                <th>Estado</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($insumos as $insumo)
                                                <tr>
                                                    <td class="fw-semibold">{{ $insumo->nombre }}</td>
                                                    <td class="small text-muted">
                                                        {{ \Illuminate\Support\Str::limit($insumo->descripcion, 55) }}
                                                    </td>
                                                    <td>
                                                        <span class="badge text-bg-light border">{{ $insumo->unidadMedida?->abreviatura }}</span>
                                                    </td>
                                                    <td>
                                                        @if ($insumo->estado)
                                                            <span class="badge text-bg-success">Activo</span>
                                                        @else
                                                            <span class="badge text-bg-secondary">Inactivo</span>
                                                        @endif
                                                    </td>
                                                    <td class="text-end">
                                                        <button class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editarInsumoModal"
                                                                data-id="{{ $insumo->id }}"
                                                                data-nombre="{{ $insumo->nombre }}"
                                                                data-descripcion="{{ $insumo->descripcion }}"
                                                                data-idunidadmedida="{{ $insumo->idunidadmedida }}">
                                                            Editar
                                                        </button>
                                                        @if ($insumo->estado)
                                                            <button class="btn btn-sm btn-outline-danger"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#modal-confirmar-baja"
                                                                    data-accion="{{ route('dashboard.insumos.baja', $insumo) }}"
                                                                    data-mensaje="¿Dar de baja el insumo {{ $insumo->nombre }}?">
                                                                Dar de baja
                                                            </button>
                                                        @else
                                                            <form method="POST" action="{{ route('dashboard.insumos.reactivar', $insumo) }}" class="d-inline m-0">
                                                                @csrf
                                                                <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                                                            </form>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="5" class="text-center py-4 text-muted">
                                                        No hay insumos en esta unidad. Pulsa "+ Nuevo insumo".
                                                    </td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>

    {{-- ================= Modal crear unidad ================= --}}
    <div class="modal fade" id="crearUnidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="{{ route('dashboard.insumos.unidad.store') }}">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nueva unidad de medida</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="50" placeholder="Gramos">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Abreviatura *</label>
                                <input type="text" name="abreviatura" class="form-control" required maxlength="10"
                                       placeholder="gr" oninput="this.value=this.value.toUpperCase()">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo *</label>
                                <select name="tipo" class="form-select" required>
                                    @foreach (\App\Http\Controllers\UnidadMedidaController::TIPOS as $tipo)
                                        <option value="{{ $tipo }}" @selected(old('tipo') === $tipo)>{{ $tipo }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear unidad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal editar unidad ================= --}}
    <div class="modal fade" id="editarUnidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-unidad">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar unidad de medida</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" id="editarUnidadNombre" class="form-control" required maxlength="50">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Abreviatura *</label>
                                <input type="text" name="abreviatura" id="editarUnidadAbreviatura" class="form-control"
                                       required maxlength="10" oninput="this.value=this.value.toUpperCase()">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo *</label>
                                <select name="tipo" id="editarUnidadTipo" class="form-select" required>
                                    @foreach (\App\Http\Controllers\UnidadMedidaController::TIPOS as $tipo)
                                        <option value="{{ $tipo }}">{{ $tipo }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal crear insumo ================= --}}
    <div class="modal fade" id="crearInsumoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="{{ route('dashboard.insumos.store') }}">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nuevo insumo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="100" autofocus>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Unidad de medida *</label>
                                <select name="idunidadmedida" class="form-select" required>
                                    @foreach ($unidades->where('estado', true) as $unidad)
                                        <option value="{{ $unidad->id }}" @selected($unidadActual?->id === $unidad->id)>
                                            {{ $unidad->nombre }} ({{ $unidad->abreviatura }})
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear insumo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal editar insumo ================= --}}
    <div class="modal fade" id="editarInsumoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-insumo">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar insumo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" id="editarInsumoNombre" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" id="editarInsumoDescripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Unidad de medida *</label>
                                <select name="idunidadmedida" id="editarInsumoUnidad" class="form-select" required>
                                    @foreach ($unidades->where('estado', true) as $unidad)
                                        <option value="{{ $unidad->id }}">{{ $unidad->nombre }} ({{ $unidad->abreviatura }})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal agregar insumo a la receta ================= --}}
    <div class="modal fade" id="crearRecetaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="{{ route('dashboard.insumos.receta.store') }}">
                    @csrf
                    @if ($productoActual)
                        <input type="hidden" name="idproducto" value="{{ $productoActual->id }}">
                    @endif
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">
                            Agregar insumo a la receta
                            @if ($productoActual) — {{ $productoActual->nombre }} @endif
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Insumo *</label>
                                <select name="idinsumo" class="form-select" required>
                                    @foreach ($insumosDisponibles as $insumo)
                                        <option value="{{ $insumo->id }}">
                                            {{ $insumo->nombre }} ({{ $insumo->unidadMedida?->abreviatura }})
                                        </option>
                                    @endforeach
                                </select>
                                <div class="form-text">Solo se muestran insumos activos que aún no están en esta receta.</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Cantidad *</label>
                                <input type="number" name="cantidad" class="form-control" required
                                       step="0.001" min="0.001" placeholder="Ej. 0.250">
                                <div class="form-text">La cantidad se expresa en la unidad de medida del insumo.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Agregar a la receta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal editar cantidad de receta ================= --}}
    <div class="modal fade" id="editarCantidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-cantidad">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar cantidad</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <label class="form-label" id="label-editar-cantidad">Cantidad *</label>
                        <input type="number" name="cantidad" id="editarCantidadValor" class="form-control" required
                               step="0.001" min="0.001">
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal compartido de confirmación de bajas ================= --}}
    <div class="modal fade" id="modal-confirmar-baja" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-confirmar-baja" class="modal-content">
                @csrf
                <div class="modal-header">
                    <h2 class="modal-title fs-5">⚠️ Confirmar baja</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0" id="texto-confirmar-baja"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">🗑️ Confirmar baja</button>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        const modalEditarUnidad = document.getElementById('editarUnidadModal');
        modalEditarUnidad.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarUnidadNombre').value = boton.dataset.nombre;
            document.getElementById('editarUnidadAbreviatura').value = boton.dataset.abreviatura;
            document.getElementById('editarUnidadTipo').value = boton.dataset.tipo;
            document.getElementById('form-editar-unidad').setAttribute(
                'action', '{{ route("dashboard.insumos.unidad.update", ["unidad" => "__ID__"]) }}'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalEditarInsumo = document.getElementById('editarInsumoModal');
        modalEditarInsumo.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarInsumoNombre').value = boton.dataset.nombre;
            document.getElementById('editarInsumoDescripcion').value = boton.dataset.descripcion || '';
            document.getElementById('editarInsumoUnidad').value = boton.dataset.idunidadmedida;
            document.getElementById('form-editar-insumo').setAttribute(
                'action', '{{ route("dashboard.insumos.update", ["insumo" => "__ID__"]) }}'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalEditarCantidad = document.getElementById('editarCantidadModal');
        modalEditarCantidad.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('label-editar-cantidad').textContent = 'Cantidad de ' + boton.dataset.insumo + ' *';
            document.getElementById('editarCantidadValor').value = boton.dataset.cantidad;
            document.getElementById('form-editar-cantidad').setAttribute(
                'action', '{{ route("dashboard.insumos.receta.update", ["detalle" => "__ID__"]) }}'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalBaja = document.getElementById('modal-confirmar-baja');
        if (modalBaja) {
            modalBaja.addEventListener('show.bs.modal', function (evento) {
                const disparador = evento.relatedTarget;
                if (!disparador) return;
                document.getElementById('form-confirmar-baja')
                    .setAttribute('action', disparador.getAttribute('data-accion'));
                document.getElementById('texto-confirmar-baja').textContent =
                    disparador.getAttribute('data-mensaje') || '¿Confirmas realizar esta acción?';
            });
        }
    </script>
@endpush