<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class PerfilController extends Controller
{
    public function index(): View
    {
        $cuenta = auth()->user();
        $empleado = $cuenta->empleado;

        return view('perfil', compact('cuenta', 'empleado'));
    }

    public function update(Request $request): RedirectResponse
    {
        $cuenta = auth()->user();
        $empleado = $cuenta->empleado;

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'apellido' => ['required', 'string', 'max:100'],
            'telefono' => ['nullable', 'string', 'max:15'],
            'usuario' => ['required', 'string', 'max:255', "unique:cuentausuario,usuario,{$cuenta->id}"],
            'correo' => ['required', 'email', 'max:255', "unique:cuentausuario,correo,{$cuenta->id}"],
            'password_actual' => ['nullable', 'string'],
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
        ]);

        if ($request->filled('password')) {
            if (! Hash::check($request->input('password_actual', ''), $cuenta->passwordhash)) {
                return back()
                    ->withInput()
                    ->withErrors(['password_actual' => 'La contraseña actual no es correcta.']);
            }
        }

        DB::statement('CALL actualizar_perfil(?, ?, ?, ?, ?, ?, ?, ?, ?)', [$empleado->id, $validated['nombre'], $validated['apellido'], $validated['telefono'],
            $validated['usuario'], $validated['correo'], $request->filled('password') ? Hash::make($validated['password']) : null, request()->userAgent(), request()->ip(),]);

        return back()->with('exito', 'Perfil actualizado correctamente.');
    }
}
