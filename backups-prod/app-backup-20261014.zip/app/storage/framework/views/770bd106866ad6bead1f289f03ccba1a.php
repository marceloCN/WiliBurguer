<?php $__env->startSection('title', 'Caja y jornadas · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Caja y jornadas 🔐</h1>
                <p class="text-muted mb-0">Abre la caja, registra movimientos y cierra la jornada.</p>
            </div>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <p class="small text-muted mb-3">
            Cada <strong>apertura</strong> abre una jornada: no puede haber dos jornadas abiertas en la misma caja.
            Al abrirla se genera automáticamente un <strong>cierre provisional</strong>. Durante la jornada se registran
            los <strong>movimientos</strong> (ingresos y egresos) y, al final, se registra el <strong>cierre</strong>
            indicando el efectivo contado; el sistema calcula el efectivo esperado y la diferencia con los pagos y
            movimientos de la jornada.
        </p>

        <div class="row g-4">
            
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursal</span>
                        <span class="badge text-bg-dark"><?php echo e($sucursales->count()); ?></span>
                    </div>
                    <div class="list-group">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('dashboard.caja.index', ['idsucursal' => $sucursal->id])); ?>"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                      <?php echo e($sucursalActual->id === $sucursal->id ? 'active' : ''); ?>">
                                <span class="fw-semibold"><?php echo e($sucursal->nombre); ?></span>
                                <?php if($apertura && $sucursalActual->id === $sucursal->id): ?>
                                    <span class="badge rounded-pill text-bg-success">Abierta</span>
                                <?php elseif(!$sucursal->estado): ?>
                                    <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light">
                        <span class="fw-bold">Cajas de <?php echo e($sucursalActual->nombre); ?></span>
                    </div>
                    <div class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span class="fw-semibold"><?php echo e($caja->nombre); ?></span>
                                <span class="badge rounded-pill <?php echo e($caja->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                    <?php echo e($caja->activo ? 'Activa' : 'Inactiva'); ?>

                                </span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="list-group-item text-center text-muted py-4">
                                No hay cajas registradas en esta sucursal.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-12 col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                    <span class="badge text-bg-brand"><?php echo e($sucursalActual->nombre); ?></span>
                    <?php if($apertura): ?>
                        <span class="badge text-bg-success">Jornada abierta</span>
                    <?php else: ?>
                        <span class="badge text-bg-secondary">Sin jornada abierta</span>
                    <?php endif; ?>
                </div>

                
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">🔓 Apertura de caja</span>
                        <?php if($apertura): ?>
                            <span class="badge text-bg-success">ABIERTA</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if(! $apertura): ?>
                            <?php if($cajas->where('activo', true)->isEmpty()): ?>
                                <div class="alert alert-warning mb-0">
                                    No hay cajas <strong>activas</strong> en <?php echo e($sucursalActual->nombre); ?>. Un
                                    administrador debe crearlas o reactivarlas desde «Sucursales».
                                </div>
                            <?php elseif($puedeAbrir): ?>
                                <form method="POST" action="<?php echo e(route('dashboard.caja.apertura.store')); ?>" class="row g-3 align-items-end">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="idsucursal" value="<?php echo e($sucursalActual->id); ?>">
                                    <div class="col-12 col-md-5">
                                        <label class="form-label">Caja *</label>
                                        <select name="idcaja" class="form-select" required>
                                            <?php $__currentLoopData = $cajas->where('activo', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($caja->id); ?>"><?php echo e($caja->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <label class="form-label">Fondo inicial (Bs.) *</label>
                                        <input type="number" name="montoinicial" class="form-control"
                                               min="0" step="0.01" max="99999999.99" required placeholder="0.00">
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <button type="submit" class="btn btn-brand w-100">Abrir caja</button>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-text">Al abrir la jornada se genera automáticamente su cierre provisional.</div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <div class="alert alert-info mb-0">
                                    No hay una jornada abierta. Un cajero o gerente debe abrir la caja para operar.
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="row g-3 mb-3">
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Caja</div>
                                    <div class="fw-semibold"><?php echo e($apertura->caja?->nombre); ?></div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Fondo inicial</div>
                                    <div class="fw-semibold">Bs. <?php echo e(number_format($apertura->montoinicial, 2)); ?></div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Abierta el</div>
                                    <div class="fw-semibold"><?php echo e($apertura->fechaapertura?->format('d/m/Y H:i')); ?></div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Aperturada por</div>
                                    <div class="fw-semibold"><?php echo e($apertura->empleado?->nombre); ?> <?php echo e($apertura->empleado?->apellido); ?></div>
                                </div>
                            </div>

                            <?php $cierre = $apertura->cierreCaja; ?>
                            <?php if($cierre): ?>
                                <div class="alert alert-light border small mb-3">
                                    Cierre provisional generado · Efectivo esperado actual:
                                    <strong>Bs. <?php echo e(number_format($cierre->efectivoesperado, 2)); ?></strong>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex gap-2 flex-wrap">
                                <?php if($puedeEditarApertura): ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                            data-bs-toggle="modal" data-bs-target="#editarAperturaModal"
                                            data-id="<?php echo e($apertura->id); ?>"
                                            data-caja="<?php echo e($apertura->caja?->nombre); ?>"
                                            data-monto="<?php echo e($apertura->montoinicial); ?>">
                                        Editar fondo inicial
                                    </button>
                                <?php endif; ?>
                                <?php if($puedeBajaApertura): ?>
                                    <form method="POST" action="<?php echo e(route('dashboard.caja.apertura.baja', $apertura)); ?>"
                                          onsubmit="return confirm('¿Anular la jornada abierta? Solo es posible si no tiene pagos aprobados.')">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Dar de baja apertura</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($apertura): ?>
                    
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">💸 Movimientos de caja</span>
                            <span class="badge text-bg-dark"><?php echo e($movimientos->count()); ?></span>
                        </div>
                        <div class="card-body">
                            <?php if($puedeRegistrarMovimiento): ?>
                                <form method="POST" action="<?php echo e(route('dashboard.caja.movimiento.store', $apertura)); ?>"
                                      class="row g-2 align-items-end mb-3">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small">Tipo *</label>
                                        <select name="tipomovimiento" class="form-select form-select-sm" required>
                                            <option value="INGRESO">Ingreso</option>
                                            <option value="EGRESO">Egreso</option>
                                        </select>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <label class="form-label small">Concepto *</label>
                                        <input type="text" name="concepto" class="form-control form-control-sm" maxlength="150" required
                                               placeholder="Ej.: compra de hielo">
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small">Monto (Bs.) *</label>
                                        <input type="number" name="monto" class="form-control form-control-sm"
                                               min="0.01" step="0.01" max="99999999.99" required placeholder="0.00">
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <label class="form-label small">Observación</label>
                                        <input type="text" name="observacion" class="form-control form-control-sm" maxlength="250">
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <button type="submit" class="btn btn-sm btn-brand w-100">Registrar</button>
                                    </div>
                                </form>
                            <?php endif; ?>

                            <?php if($movimientos->isEmpty()): ?>
                                <p class="text-muted text-center py-3 mb-0">Aún no hay movimientos en esta jornada.</p>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Fecha</th>
                                                <th>Tipo</th>
                                                <th>Concepto</th>
                                                <th class="text-end">Monto</th>
                                                <th>Registró</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="small text-muted"><?php echo e($movimiento->fechamovimiento?->format('d/m/Y H:i')); ?></td>
                                                    <td>
                                                        <span class="badge <?php echo e($movimiento->tipomovimiento === 'INGRESO' ? 'text-bg-success' : 'text-bg-danger'); ?>">
                                                            <?php echo e($movimiento->tipomovimiento); ?>

                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php echo e($movimiento->concepto); ?>

                                                        <?php if($movimiento->observacion): ?>
                                                            <div class="small text-muted"><?php echo e($movimiento->observacion); ?></div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-end fw-semibold <?php echo e($movimiento->tipomovimiento === 'INGRESO' ? 'text-success' : 'text-danger'); ?>">
                                                        <?php echo e($movimiento->tipomovimiento === 'INGRESO' ? '+' : '-'); ?> Bs. <?php echo e(number_format($movimiento->monto, 2)); ?>

                                                    </td>
                                                    <td class="small text-muted"><?php echo e($movimiento->empleado?->nombre); ?> <?php echo e($movimiento->empleado?->apellido); ?></td>
                                                    <td class="text-end">
                                                        <div class="d-flex gap-1 justify-content-end">
                                                            <?php if($puedeEditarMovimiento): ?>
                                                                <button type="button" class="btn btn-sm btn-outline-primary"
                                                                        data-bs-toggle="modal" data-bs-target="#editarMovimientoModal"
                                                                        data-id="<?php echo e($movimiento->id); ?>"
                                                                        data-tipo="<?php echo e($movimiento->tipomovimiento); ?>"
                                                                        data-concepto="<?php echo e($movimiento->concepto); ?>"
                                                                        data-monto="<?php echo e($movimiento->monto); ?>"
                                                                        data-observacion="<?php echo e($movimiento->observacion); ?>">
                                                                    Editar
                                                                </button>
                                                            <?php endif; ?>
                                                            <?php if($puedeBajaMovimiento): ?>
                                                                <form method="POST" action="<?php echo e(route('dashboard.caja.movimiento.baja', $movimiento)); ?>"
                                                                      onsubmit="return confirm('¿Eliminar este movimiento?')">
                                                                    <?php echo csrf_field(); ?>
                                                                    <button type="submit" class="btn btn-sm btn-outline-danger">Baja</button>
                                                                </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <?php if($puedeCerrar && $apertura): ?>
                        <?php $cierreActual = $apertura->cierreCaja; ?>
                        <div class="card tarjeta-producto mb-4">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <span class="fw-bold">🔒 Cierre de caja</span>
                                <?php if($cierreActual): ?>
                                    <span class="badge <?php echo e((float) $cierreActual->diferencia == 0 ? 'text-bg-success' : ((float) $cierreActual->diferencia > 0 ? 'text-bg-warning' : 'text-bg-secondary')); ?>">
                                        Esperado Bs. <?php echo e(number_format($cierreActual->efectivoesperado, 2)); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <?php if($cierreActual): ?>
                                    <div class="row g-2 small mb-3">
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Total ventas</div>
                                            <div class="fw-semibold">Bs. <?php echo e(number_format($cierreActual->totalventas, 2)); ?></div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Ingresos</div>
                                            <div class="fw-semibold text-success">+ Bs. <?php echo e(number_format($cierreActual->totalingresos, 2)); ?></div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Egresos</div>
                                            <div class="fw-semibold text-danger">- Bs. <?php echo e(number_format($cierreActual->totalegresos, 2)); ?></div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Efectivo esperado</div>
                                            <div class="fw-semibold">Bs. <?php echo e(number_format($cierreActual->efectivoesperado, 2)); ?></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <button type="button" class="btn btn-dark w-100" data-bs-toggle="modal" data-bs-target="#modalCerrarCaja">
                                    ⚠️ Cerrar caja
                                </button>
                            </div>
                        </div>

                        
                        <div class="modal fade" id="modalCerrarCaja" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <form method="POST" action="<?php echo e(route('dashboard.caja.cerrar', $apertura)); ?>" id="formCerrarCaja" class="modal-content border-0 shadow">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header bg-dark text-white">
                                        <h5 class="modal-title fw-bold">🔒 Cierre de caja</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                                    </div>
                                    <div class="modal-body">
                                        <?php if($cierreActual): ?>
                                            <div class="alert alert-light border mb-3">
                                                <div class="row g-2 small text-center">
                                                    <div class="col-6">
                                                        <div class="text-muted">Ventas</div>
                                                        <div class="fw-semibold">Bs. <?php echo e(number_format($cierreActual->totalventas, 2)); ?></div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Ingresos</div>
                                                        <div class="fw-semibold text-success">+ Bs. <?php echo e(number_format($cierreActual->totalingresos, 2)); ?></div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Egresos</div>
                                                        <div class="fw-semibold text-danger">- Bs. <?php echo e(number_format($cierreActual->totalegresos, 2)); ?></div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Esperado</div>
                                                        <div class="fw-semibold">Bs. <?php echo e(number_format($cierreActual->efectivoesperado, 2)); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <div class="mb-3">
                                            <label class="form-label fw-semibold">Efectivo contado (Bs.) *</label>
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-text">Bs.</span>
                                                <input type="number" name="efectivocontado" id="cerrarEfectivoContado" class="form-control"
                                                       min="0" step="0.01" max="99999999.99" required placeholder="0.00"
                                                       value="<?php echo e($cierreActual?->efectivoesperado ?? ''); ?>"
                                                       data-esperado="<?php echo e($cierreActual?->efectivoesperado ?? 0); ?>">
                                            </div>
                                            <div class="form-text">Ingresa el dinero real que hay en caja.</div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Observación</label>
                                            <input type="text" name="observacion" class="form-control" maxlength="250" placeholder="Opcional">
                                        </div>

                                        <?php if($cierreActual): ?>
                                            <div class="card border-0 bg-light">
                                                <div class="card-body py-2">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <span class="fw-semibold">Diferencia</span>
                                                        <span id="cerrarDiferencia" class="fs-5 fw-bold">Bs. 0.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="modal-footer bg-light">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-dark" id="btnConfirmarCierre">
                                            Confirmar cierre
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                
                <?php if($puedeHistorialCierres): ?>
                    <div class="card tarjeta-producto">
                        <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div>
                                <span class="fw-bold d-block">📑 Historial de cierres</span>
                                <small class="text-muted">Consulta y exporta a PDF los cierres por día o rango de fechas.</small>
                            </div>
                            <a href="<?php echo e(route('dashboard.caja.historial', ['idsucursal' => $sucursalActual->id])); ?>"
                               class="btn btn-dark">
                                Ver historial
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php if($apertura && $puedeEditarApertura): ?>
    <div class="modal fade" id="editarAperturaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-editar-apertura" class="modal-content border-0 shadow">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar fondo inicial</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label">Caja</label>
                    <input type="text" id="editarAperturaCaja" class="form-control" readonly disabled>
                    <div class="mt-3">
                        <label class="form-label">Fondo inicial (Bs.) *</label>
                        <input type="number" name="montoinicial" id="editarAperturaMonto" class="form-control"
                               min="0" step="0.01" max="99999999.99" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($apertura && $puedeEditarMovimiento): ?>
    <div class="modal fade" id="editarMovimientoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-editar-movimiento" class="modal-content border-0 shadow">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar movimiento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Tipo *</label>
                            <select name="tipomovimiento" id="editarMovTipo" class="form-select" required>
                                <option value="INGRESO">Ingreso</option>
                                <option value="EGRESO">Egreso</option>
                            </select>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Monto (Bs.) *</label>
                            <input type="number" name="monto" id="editarMovMonto" class="form-control"
                                   min="0.01" step="0.01" max="99999999.99" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Concepto *</label>
                            <input type="text" name="concepto" id="editarMovConcepto" class="form-control" maxlength="150" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observación</label>
                            <input type="text" name="observacion" id="editarMovObservacion" class="form-control" maxlength="250">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        <?php if($apertura && $puedeEditarApertura): ?>
        const modalEditarApertura = document.getElementById('editarAperturaModal');
        if (modalEditarApertura) {
            modalEditarApertura.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('editarAperturaCaja').value = boton.dataset.caja;
                document.getElementById('editarAperturaMonto').value = boton.dataset.monto;
                document.getElementById('form-editar-apertura').setAttribute(
                    'action',
                    '<?php echo e(route('dashboard.caja.apertura.update', ['apertura' => '__ID__'])); ?>'.replace('__ID__', boton.dataset.id)
                );
            });
        }
        <?php endif; ?>

        <?php if($apertura && $puedeEditarMovimiento): ?>
        const modalEditarMovimiento = document.getElementById('editarMovimientoModal');
        if (modalEditarMovimiento) {
            modalEditarMovimiento.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('editarMovTipo').value = boton.dataset.tipo;
                document.getElementById('editarMovConcepto').value = boton.dataset.concepto;
                document.getElementById('editarMovMonto').value = boton.dataset.monto;
                document.getElementById('editarMovObservacion').value = boton.dataset.observacion || '';
                document.getElementById('form-editar-movimiento').setAttribute(
                    'action',
                    '<?php echo e(route('dashboard.caja.movimiento.update', ['movimiento' => '__ID__'])); ?>'.replace('__ID__', boton.dataset.id)
                );
            });
        }
        <?php endif; ?>

        <?php if(($cierreActual ?? null) && $puedeCerrar): ?>
        function actualizarDiferenciaCierre() {
            const input = document.getElementById('cerrarEfectivoContado');
            const span = document.getElementById('cerrarDiferencia');
            if (!input || !span) return;

            const esperado = parseFloat(input.dataset.esperado) || 0;
            const contado = parseFloat(input.value) || 0;
            const diferencia = Math.round((contado - esperado) * 100) / 100;
            const simbolo = diferencia >= 0 ? '+' : '';

            span.textContent = 'Bs. ' + simbolo + diferencia.toFixed(2);
            span.className = 'fs-5 fw-bold ' + (diferencia === 0 ? 'text-success' : (diferencia > 0 ? 'text-warning' : 'text-danger'));
        }

        const cerrarEfectivoContado = document.getElementById('cerrarEfectivoContado');
        if (cerrarEfectivoContado) {
            cerrarEfectivoContado.addEventListener('input', actualizarDiferenciaCierre);
            actualizarDiferenciaCierre();

            const modalCerrarCaja = document.getElementById('modalCerrarCaja');
            if (modalCerrarCaja) {
                modalCerrarCaja.addEventListener('shown.bs.modal', actualizarDiferenciaCierre);
            }
        }
        <?php endif; ?>

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/caja/index.blade.php ENDPATH**/ ?>