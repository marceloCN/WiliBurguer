# Sesión — Permisos módulo de usuarios

Fecha: 2026-10-06  
Proyecto: Burguer-Willy (Laravel, auth `CuentaUsuario`, BD PostgreSQL `Burguer-Willy`)

## Contexto

Se implementó control de permisos por código en el módulo de usuarios (vistas datos, roles, seguridad + dashboard). Patrón del proyecto: `$permisosUsuario->contains('XXX')` en Blade + `UtilidadesFormulario.mostrarModalPermisoDenegado(accion, codigos)` + validación server-side en `UsuarioController`.

Permisos relevantes en BD (`permiso.codigo`):

| Código | Nombre | Asignado actualmente |
|--------|--------|----------------------|
| 100 | Crear nuevo empleado | ADMIN, GERENTE |
| 101 | Editar empleados | ADMIN, GERENTE |
| 102 | Listar empleados | ADMIN, GERENTE |
| 105 | Dar de baja a empleado | ADMIN, GERENTE |
| 106 | Modificar contraseña | ADMIN, GERENTE, CAJERO, MESERO |
| 107 | Listar empleados activos | Solo ADMIN |
| 108 | Listar empleados inactivos | Solo ADMIN |
| 206 | Asignar empleado a sucursal | — (asignar desde módulo) |
| 207 | (usado como) activar/desactivar empleado de sucursal | — (asignar desde módulo) |
| 208 | Listar empleados de sucursal | — (asignar desde módulo) |

## Cambios implementados

### 1. Filtro de estado por 107/108 (vistas datos/roles/seguridad)

- `UsuarioController::obtenerEmpleadosFiltrados()`:
  - 107+108 → aplica filtro `estado` del request (funcionalidad real).
  - Solo 107 → fuerza `estado = true`.
  - Solo 108 → fuerza `estado = false`.
  - Sin ninguno → no filtra por estado (lista base vía 102).
- `UsuarioController::vistaLista()`:
  - Normaliza `$estado` visible: request solo si tiene 107+108; si no, `''`.
- `resources/views/admin/usuarios/_filtros.blade.php`:
  - Ambos → select Todos/Activos/Inactivos.
  - Solo 107 → select solo "Activos".
  - Solo 108 → select solo "Inactivos".
  - Ninguno → botón tipo control que abre modal `107, 108`.
- Columna "Estado" (badges) siempre visible.
- Dashboard y PDF heredan la restricción de `obtenerEmpleadosFiltrados`.

### 2. Permiso 206 — gerente crea usuario en su sucursal

- `UsuarioController::store()`: si creador es GERENTE y no tiene 206 → error de negocio.
- Botón "+ Nuevo usuario" en `datos`, `roles`, `seguridad`, `dashboard`:
  - GERENTE: exige 100 y 206; sin 206 → modal `206`; sin 100 ni 206 → modal `100, 206`.
  - No gerente: solo exige 100 (como antes).

### 3. Permiso 208 — gerente accede a datos/roles/seguridad

- `UsuarioController::vistaLista()`: si hay `$sucursalGerente` (rol GERENTE con sucursal) y no tiene 208 → `abort(403)`.
- Aplica a datos, roles y seguridad (los tres usan `vistaLista`).
- Dashboard de usuarios NO exige 208.
- Al tener 208, el listado del gerente sigue restringido a sucursal + subordinados + él mismo.

### 4. Permiso 207 — gerente activa/desactiva empleados de su sucursal

- Ruta `dashboard.usuarios.estado`: `permiso:105,207` (OR en middleware).
- `UsuarioController::alternarEstado()`:
  - GERENTE sin 207 → error de negocio.
  - No gerente sin 105 → error de negocio.
  - Se mantiene `puedeOperarEmpleado()` (solo empleados de su sucursal/subordinados/él).
  - Bitácora: código `207` si gerente, `105` si no.
- Botón en `datos.blade.php`:
  - `$codigoEstado = $sucursalGerente ? '207' : '105'`.
  - Sin permiso → modal denegado con ese código.

**Nota:** usar `$idsucursal` como indicador de gerente es incorrecto (un admin al filtrar sucursal también lo trae). La señal correcta es `$sucursalGerente`.

## Archivos modificados

- `app/Http/Controllers/UsuarioController.php`
  - `store()`, `vistaLista()`, `obtenerEmpleadosFiltrados()`, `alternarEstado()`
- `routes/web.php` — middleware ruta estado → `permiso:105,207`
- `resources/views/admin/usuarios/_filtros.blade.php`
- `resources/views/admin/usuarios/datos.blade.php`
- `resources/views/admin/usuarios/roles.blade.php`
- `resources/views/admin/usuarios/seguridad.blade.php`
- `resources/views/admin/usuarios/dashboard.blade.php`

Pint: `vendor/bin/pint --dirty --format agent` → passed (tras cada turno con PHP).

## Pendientes / verificación del usuario

1. Asignar desde el módulo de permisos al rol GERENTE:
   - **208** → poder entrar a datos/roles/seguridad.
   - **206** → poder crear usuarios en su sucursal.
   - **207** → poder activar/desactivar empleados de su sucursal.
   - **107 / 108** → control del filtro/estado (si solo 107, solo activos; ambos, filtro completo).
2. Matriz de pruebas manual:
   - Admin (107+108): filtro estado completo.
   - Rol solo 107 / solo 108 / sin ninguno: según tabla de la sección 1.
   - Gerente sin 208: 403 en datos/roles/seguridad.
   - Gerente con 208 sin 207: modal `207` en botón estado; POST → error.
   - Gerente con 208+207: solo empleados de su sucursal.
   - Gerente con 100 sin 206: modal `206` en "+ Nuevo usuario"; POST store → error.
   - `?estado=0` sin 108: server lo ignora.
3. No se crearon feature tests (el proyecto casi no tiene; factories inexistentes). Opcional si se pide.

## Convenciones del proyecto (útiles al retomar)

- Auth model: `CuentaUsuario` (`config/auth.php`), no `User`.
- Cadena: `auth()->user()` → `empleado` → `rol` → `permisos` (`estado=true`).
- Helper: `Controller::codigosPermisoActuales(): Collection` (pluck de `codigo`).
- Modal denegado: `resources/js/utilidadesFormulario.js` → `mostrarModalPermisoDenegado(accion, permisos)`.
- Sin `.ai/rules` en el repo; skills en `.agents/skills` y `.claude/skills`.
