-- =============================================================================
-- APERTURA Y CIERRE DE CAJA (triggers)
-- Este bloque también está incluido al final de baseDeDatos.sql; este archivo
-- permite aplicarlo a una base ya cargada sin recrear las tablas.
-- -----------------------------------------------------------------------------
-- 1. trg_validar_apertura_caja: impide abrir DOS jornadas a la vez en la misma
--    caja (una sola apertura en estado ABIERTA por caja).
-- 2. trg_crear_cierre_inicial: al abrir la caja se crea automáticamente el
--    CierreCaja provisional (totales en 0 y efectivo esperado = fondo inicial);
--    así la apertura "produce" sus parámetros iniciales de cierre al insertarse.
-- 3. trg_calcular_parametros_cierre: recalcula automáticamente el cierre a
--    partir de los pagos en estado APROBADO de la apertura (separados en
--    efectivo, QR y tarjeta por el nombre del método de pago), de los
--    movimientos de caja (ingresos/egresos) y del fondo inicial de la apertura.
--    efectivoEsperado = fondoInicial + ventasEfectivo + ingresos - egresos.
--    diferencia = efectivoContado - efectivoEsperado.
-- =============================================================================

CREATE OR REPLACE FUNCTION fn_validar_apertura_caja() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_abiertas INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA';
    ELSE
        SELECT COUNT(*) INTO v_abiertas
          FROM aperturacaja
         WHERE idcaja = NEW.idcaja
           AND estado = 'ABIERTA'
           AND id <> NEW.id;
    END IF;

    IF v_abiertas > 0 THEN
        RAISE EXCEPTION 'Ya existe una apertura de caja abierta para esta caja; debes cerrarla antes de abrir una nueva jornada.';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validar_apertura_caja
BEFORE INSERT OR UPDATE ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_validar_apertura_caja();

CREATE OR REPLACE FUNCTION fn_crear_cierre_inicial() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO cierrecaja (
        fechacierre, fondoinicial,
        totalventasefectivo, totalventasqr, totalventastarjeta, totalventas,
        totalingresos, totalegresos,
        efectivoesperado, efectivocontado, diferencia,
        observacion, idaperturacaja, idempleado
    ) VALUES (
        NEW.fechaapertura, NEW.montoinicial,
        0, 0, 0, 0,
        0, 0,
        NEW.montoinicial, NEW.montoinicial, 0,
        'Cierre provisional: la jornada aún está en curso.', NEW.id, NEW.idempleado
    );
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_crear_cierre_inicial
AFTER INSERT ON aperturacaja
FOR EACH ROW EXECUTE FUNCTION fn_crear_cierre_inicial();

CREATE OR REPLACE FUNCTION fn_calcular_parametros_cierre() RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    v_efectivo NUMERIC(10,2) := 0;
    v_qr       NUMERIC(10,2) := 0;
    v_tarjeta  NUMERIC(10,2) := 0;
    v_ventas   NUMERIC(10,2) := 0;
    v_ingresos NUMERIC(10,2) := 0;
    v_egresos  NUMERIC(10,2) := 0;
    v_fondo    NUMERIC(10,2) := 0;
BEGIN
    SELECT COALESCE(SUM(CASE WHEN LOWER(mp.nombre) = 'efectivo' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0),
           COALESCE(SUM(CASE WHEN LOWER(mp.nombre) <> 'efectivo' AND LOWER(mp.nombre) NOT LIKE '%tarjeta%' THEN p.montopago ELSE 0 END), 0)
      INTO v_efectivo, v_tarjeta, v_qr
      FROM pago p
      JOIN metodopago mp ON mp.id = p.idmetodopago
     WHERE p.idaperturacaja = NEW.idaperturacaja
       AND p.estadopago = 'APROBADO';

    v_ventas := v_efectivo + v_qr + v_tarjeta;

    SELECT COALESCE(SUM(monto), 0)
      INTO v_ingresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'INGRESO';

    SELECT COALESCE(SUM(monto), 0)
      INTO v_egresos
      FROM movimientocaja
     WHERE idaperturacaja = NEW.idaperturacaja
       AND tipomovimiento = 'EGRESO';

    SELECT COALESCE(montoinicial, 0)
      INTO v_fondo
      FROM aperturacaja
     WHERE id = NEW.idaperturacaja;

    NEW.fondoinicial := v_fondo;
    NEW.totalventasefectivo := v_efectivo;
    NEW.totalventasqr := v_qr;
    NEW.totalventastarjeta := v_tarjeta;
    NEW.totalventas := v_ventas;
    NEW.totalingresos := v_ingresos;
    NEW.totalegresos := v_egresos;
    NEW.efectivoesperado := v_fondo + v_efectivo + v_ingresos - v_egresos;
    NEW.diferencia := NEW.efectivocontado - NEW.efectivoesperado;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_calcular_parametros_cierre
BEFORE INSERT OR UPDATE ON cierrecaja
FOR EACH ROW EXECUTE FUNCTION fn_calcular_parametros_cierre();

-- 4. trg_refrescar_cierre_por_movimiento: los ingresos/egresos también
--    recalculan el cierre en curso (igual patrón de "touch" sobre cierrecaja).
CREATE OR REPLACE FUNCTION fn_refrescar_cierre_por_movimiento() RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = OLD.idaperturacaja;
        RETURN OLD;
    END IF;
    UPDATE cierrecaja SET observacion = observacion WHERE idaperturacaja = NEW.idaperturacaja;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_refrescar_cierre_por_movimiento
AFTER INSERT OR UPDATE OR DELETE ON movimientocaja
FOR EACH ROW EXECUTE FUNCTION fn_refrescar_cierre_por_movimiento();