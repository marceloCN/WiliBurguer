<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['idsucursal', 'horaapertura', 'horacierre', 'activo', 'iddiaatencion'])]
class HorarioSucursal extends Model
{
    public $timestamps = false;

    protected $table = 'horariosucursal';

    protected $primaryKey = 'idhorariosucursal';

    protected function casts(): array
    {
        return [
            'activo' => 'boolean',
        ];
    }

    public function sucursal(): BelongsTo
    {
        return $this->belongsTo(Sucursal::class, 'idsucursal');
    }

    public function diaAtencion(): BelongsTo
    {
        return $this->belongsTo(DiaAtencion::class, 'iddiaatencion');
    }
}
