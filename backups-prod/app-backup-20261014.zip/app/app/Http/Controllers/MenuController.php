<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Producto;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MenuController extends Controller
{
    public function index(Request $request): View
    {
        $categorias = Categoria::withCount('productos')
            ->orderBy('nombre')
            ->get();

        $idcategoria = $request->integer('idcategoria');

        $categoriaActual = $categorias->firstWhere('id', $idcategoria)
            ?? $categorias->firstWhere('estado', true)
            ?? $categorias->first();

        $productos = $categoriaActual
            ? Producto::with('categoria')
                ->where('idcategoria', $categoriaActual->id)
                ->orderBy('nombre')
                ->paginate(9)
                ->withQueryString()
            : collect();

        return view('admin.menu.index', compact('categorias', 'idcategoria', 'categoriaActual', 'productos'));
    }

    public function buscar(Request $request): JsonResponse
    {
        $idcategoria = $request->integer('idcategoria');
        $q = mb_strtolower(trim((string) $request->query('q', '')));

        $productos = $idcategoria  ? Producto::with('categoria')
                ->where('idcategoria', $idcategoria)
                ->when($q !== '', fn ($query) => $query->whereRaw('LOWER(nombre) LIKE ?', ['%'.$q.'%']))
                ->orderBy('nombre')
                ->limit(100)
                ->get()
            : collect();

        return response()->json([
            'html' => $idcategoria
                ? view('admin.menu._productos', [ 'productos' => $productos,
                    'vacioMensaje' => $q !== '' ? "No se encontró ningún producto con «{$request->query('q')}»."
                        : 'No hay productos en esta categoría.', ])->render() : '',
            'total' => $productos->count(),
        ]);
    }
}
