# AGENTS.md

Laravel 13 app for a restaurant-management course project ("Burguer Willy", Spanish domain). Real domain code exists: auth, empleados, sucursales, mesas y pedidos. The Eloquent layer mirrors a PostgreSQL schema that already lives in the live DB.

## Data model lives in `baseDeDatos.sql` — and is already loaded in the live DB

- The authoritative schema is `baseDeDatos.sql` at the repo root (PostgreSQL DDL, Spanish names: `Sucursal`, `Empleado`, `CuentaUsuario`, `pedido`, `Caja`...). It defines 31 tables + 8 enums.
- Those tables **already exist** in the PostgreSQL DB configured in `.env` (db `Burguer-Willy`, 127.0.0.1:5432). Verify against the DB rather than guessing.
- **Names are stored lowercase** in the DB (`cuentausuario.idempleado`, `sucursal.idempleadogerente`), despite camelCase in the SQL file — PostgreSQL folded unquoted identifiers. Eloquent tables/columns must use lowercase names; `$table = 'CuentaUsuario'` would fail against the real `cuentausuario`.
- Uses PostgreSQL-only features: `CREATE TYPE ... AS ENUM`, `GENERATED ALWAYS AS IDENTITY`. In Eloquent, enum columns stay plain strings — no PHP enum classes.

## Database split (dev vs tests) — don't mix them up

- Local dev `.env` → PostgreSQL (`DB_CONNECTION=pgsql`). `.env.example` defaults to sqlite.
- Tests (`phpunit.xml`) → SQLite `:memory:`. Any migration/seeder you add must work on **both** — avoid PG-only SQL (e.g. `.enum()` with custom types won't exist on SQLite).
- The **only migration** is `2026_09_13_000001_create_configuracion_sistema_table.php` (deliberately DB-agnostic: `id`/`string`/`text`/`boolean` — no `enum()`). All other tables come from `baseDeDatos.sql` or manual DDL; the default Laravel migrations (`users`, `cache`, `jobs`, `sessions`, `password_reset_tokens`) and the `User` model were removed. `configuracion_sistema` is the only table **not** in `baseDeDatos.sql`. Don't build schema from migrations; mirror `baseDeDatos.sql` and keep any new migration portable.

## Auth is custom — don't assume Laravel defaults

- `CuentaUsuario` implements `Authenticatable` + `CanResetPassword`; `getAuthPassword()` returns `passwordhash` (`config/auth.php:67`).
- Login is hand-rolled in `LoginController`: username **or** email, 5 failed attempts → 15-min lock via `intentosfallidos`/`bloqueado`/`bloqueadohasta`, writes to `bitacoraacceso`.
- Password reset uses the framework `Password` broker (`config/auth.php:98` → table `password_reset_tokens`) + `ResetPasswordNotification`. That table has **no migration and isn't in `baseDeDatos.sql`** — it must already exist in the live PG DB (an agent regenerating default migrations won't find it). `.env` has a real Gmail SMTP account — never leak/commit those credentials.

## Routing and permission model

- All routes live in `routes/web.php` (no `api.php`; `bootstrap/app.php` renders JSON when the request expects it). `/` → `HomeController` (public cardápio).
- Guarded routes use the `permiso:CODIGO[,CODIGO...]` middleware alias (`bootstrap/app.php:17`) → `VerificarPermiso`: user has access if the role has **any** of the given numeric `codigo`s (OR semantics).
- `/dashboard/configuracion*` uses `permiso:50` (the ADMINISTRADOR role owns code `50` = "Registrar o modificar configuración del sistema"). The `admin` middleware alias (`VerificarAdministrador`, enforces `claverol === 'ADMINISTRADOR'`) and the `admin` alias remain registered for that one case but are currently unused. Do NOT put `$this->middleware(...)` in controller constructors — the base `Controller` has no `middleware()` method (only static `middleware()` arrays or route-level aliases work). It does host the shared `registrarAccion()` helper + `CALL_REGISTRAR_ACCION` const (wraps the `registrar_accion` PG procedure) so any controller can log to `bitacoraaccion`.
- `registrarAccion($idEmpleado, $accion, $tabla, $idRegistro, $codigoPermiso, $resultado='EXITOSO')` is the ONLY bitacora writer — per-controller `bitacora()`/`permisoIdFallback()` duplicates were removed. Used by `PerfilController`, `ConfiguracionController`, `UsuarioController`, `SucursalController`, `MesaController` and `PedidoController`. Semantics: `idempleado` = who performed the action, `tablaafectada` + `idregistroafectado` = the affected record (empleado id or cuentausuario id). `usuarios` has `POST /dashboard/usuarios/{cuenta}/actualizar` (`permiso:101`) to edit datos/attributes (nombre, apellido, teléfono, usuario, correo); rol and password remain separate existing routes. On `/dashboard/usuarios` the action column only has 2 buttons (Desactivar/Activar + Editar modal with tabs Datos/Rol/Seguridad), and the create-user modal auto-suggests a unique username from nombre+apellido (client-side against the lowercased `cuentausuario.usuario` list).
- Maintenance mode: `VerificarMantenimiento` is appended to the whole `web` group (`bootstrap/app.php`). If `configuracion_sistema.SITIO_MANTENIMIENTO_ACTIVO === '1'` it returns a 503 `mantenimiento` view for everyone except `ADMINISTRADOR`; login/logout/password routes are exempt so an admin can always log in to turn it off.
- The permission catalog is defined in `database/seeders/RolPermisoSeeder.php` — add new protected routes only with a new code seeded there. Codes 50 (configuración del sistema) y 100–506 (módulos): empleados 1xx, sucursales 2xx, mesas/horarios 2xx, catálogo/productos 3xx, caja 4xx, pedidos 5xx.

## Commands

- `composer test` → `php artisan config:clear` + `php artisan test` (intended way; not raw `phpunit`).
- `composer setup` → deps, `.env`, `key:generate`, `migrate --force`, `npm install --ignore-scripts`, `npm run build`.
- `composer dev` / `npm run dev` → dev servers (Vite + Tailwind v4, CSS-first config in `resources/css/app.css`, no `tailwind.config.js`).
- `vendor/bin/pint` → code style (framework defaults, no `pint.json`).
- `php artisan test --filter=ExampleTest` → single test/class.

## Models

- All 31 tables have an Eloquent model in `app/Models` (StudlyCase names, lowercase `$table` set explicitly). All set `$timestamps = false`.
- Pivot/odd PKs: `RolPermiso` (`rolpermiso`, `$primaryKey = 'idrol'`, `$incrementing = false`), `PromocionSucursalProducto` (composite PK), `HorarioSucursal` (`$primaryKey = 'idhorariosucursal'`).
- Money/quantity cast to `decimal:2`/`decimal:3`, timestamps to `datetime`, `estado`/`activo`/`bloqueado`/`disponibilidad` to booleans.
- `CuentaUsuario` hides `passwordhash` via `#[Hidden]`; `Pago` hides card fields.

## Gotchas

- **Boost is NOT installed.** `laravel/boost` is absent from `composer.json`; **`laravel/pao`** is present instead. It rewrites `php artisan test` output into compact one-line JSON for agents (opencode auto-detected). Use `PAO_DISABLE=1` for human-readable output.
- Laravel 13 models use PHP attributes, not properties: `#[Fillable([...])]` / `#[Hidden([...])]` — see `app/Models/CuentaUsuario.php:16`.
- `DatabaseSeeder` only runs `RolPermisoSeeder` (idempotent; upserts the catalog, wipes/re-wires `rolpermiso`, prunes stale codes). The admin account comes from `CuentaUsuarioSeeder` (run manually — `admin` / `admin123`), and it requires an `ADMINISTRADOR` row already in `rol` (matched by `claverol`). `ConfiguracionInicioSeeder` (also manual) seeds `configuracion_sistema` branding defaults; `ConfiguracionSistema::mapa()` falls back to its `POR_DEFECTO` constants when rows are missing, so the home page and maintenance flag still work without it.