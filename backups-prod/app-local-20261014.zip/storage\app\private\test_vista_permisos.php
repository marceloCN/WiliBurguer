<?php

require __DIR__ . '/../../../vendor/autoload.php';

$app = require_once __DIR__ . '/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$controller = new App\Http\Controllers\PermisoController();
$request = new Illuminate\Http\Request();

$response = $controller->index($request);
$html = $response->with('errors', new Illuminate\Support\ViewErrorBag())->render();

file_put_contents(__DIR__ . '/permisos_vista.html', $html);
echo "Vista renderizada en: " . __DIR__ . '/permisos_vista.html' . "\n";
echo "Tamaño: " . strlen($html) . " bytes\n";
