@extends('layouts.app')

@section('title', 'Configuración del sitio · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Configuración del sitio</h1>
                <p class="text-muted mb-0">Personaliza la página de inicio: datos, carrusel, secciones y tema.</p>
            </div>
            <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">← Volver al panel</a>
        </div>

        @if (session('exito'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('exito') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        @if ($errors->any())
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Revisa los datos:</strong>
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        <ul class="nav nav-pills flex-wrap gap-2 mb-4" id="configTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="tab-identidad-tab" data-bs-toggle="pill" data-bs-target="#tab-identidad" type="button" role="tab" aria-controls="tab-identidad" aria-selected="true">
                    🏪 Datos del negocio
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-carrusel-tab" data-bs-toggle="pill" data-bs-target="#tab-carrusel" type="button" role="tab" aria-controls="tab-carrusel" aria-selected="false">
                    🖼️ Carrusel de inicio
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-secciones-tab" data-bs-toggle="pill" data-bs-target="#tab-secciones" type="button" role="tab" aria-controls="tab-secciones" aria-selected="false">
                    🧩 Secciones visibles
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-tema-tab" data-bs-toggle="pill" data-bs-target="#tab-tema" type="button" role="tab" aria-controls="tab-tema" aria-selected="false">
                    🎨 Tema y colores
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-mantenimiento-tab" data-bs-toggle="pill" data-bs-target="#tab-mantenimiento" type="button" role="tab" aria-controls="tab-mantenimiento" aria-selected="false">
                    🛠️ Mantenimiento
                </button>
            </li>
        </ul>

        <form method="POST" action="{{ route('dashboard.configuracion.update') }}">
            @csrf

            <div class="tab-content" id="configTabsContent">
                {{-- ===================== IDENTIDAD ===================== --}}
                <div class="tab-pane fade show active" id="tab-identidad" role="tabpanel" aria-labelledby="tab-identidad-tab">
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-body p-4">
                            <h2 class="h5 fw-bold mb-1">Identidad del negocio</h2>
                            <p class="text-muted small mb-4">Estos datos aparecen en la página de inicio, la barra de navegación y el pie de página.</p>

                            <div class="row g-3">
                                <div class="col-md-8">
                                    <label class="form-label">Nombre del negocio *</label>
                                    <input type="text" name="SITIO_NOMBRE" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_NOMBRE') }}" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Teléfono</label>
                                    <input type="text" name="SITIO_TELEFONO" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_TELEFONO') }}">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Eslogan</label>
                                    <input type="text" name="SITIO_ESLOGAN" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_ESLOGAN') }}">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Correo de contacto</label>
                                    <input type="email" name="SITIO_EMAIL" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_EMAIL') }}">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Dirección</label>
                                    <input type="text" name="SITIO_DIRECCION" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_DIRECCION') }}">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Horario general</label>
                                    <input type="text" name="SITIO_HORARIO" class="form-control" maxlength="255"
                                           value="{{ $configuracion->get('SITIO_HORARIO') }}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ===================== CARRUSEL ===================== --}}
                <div class="tab-pane fade" id="tab-carrusel" role="tabpanel" aria-labelledby="tab-carrusel-tab">
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-body p-4">
                            <h2 class="h5 fw-bold mb-1">Carrusel de la portada</h2>
                            <p class="text-muted small mb-3">Sube tus propias imágenes (URL pública de cada diapositiva) para que el carrusel se vea correctamente.</p>

                            <div class="form-check form-switch mb-4">
                                <input class="form-check-input" type="checkbox" role="switch" id="SITIO_HABILITAR_CARRUSEL"
                                       name="SITIO_HABILITAR_CARRUSEL" value="1"
                                       @checked($configuracion->get('SITIO_HABILITAR_CARRUSEL') === '1')>
                                <label class="form-check-label" for="SITIO_HABILITAR_CARRUSEL">Mostrar el carrusel de imágenes en la página de inicio</label>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h3 class="h6 fw-bold mb-0">Diapositivas</h3>
                                <button type="button" class="btn btn-sm btn-outline-brand" id="agregarSlider">+ Agregar diapositiva</button>
                            </div>

                            <div id="slidersContainer" class="vstack gap-3">
                                @forelse ($sliders as $slider)
                                    @include('admin.configuracion._slider', ['slider' => $slider, 'indice' => $loop->index])
                                @empty
                                    @include('admin.configuracion._slider', ['slider' => [], 'indice' => 0])
                                @endforelse
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ===================== SECCIONES ===================== --}}
                <div class="tab-pane fade" id="tab-secciones" role="tabpanel" aria-labelledby="tab-secciones-tab">
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-body p-4">
                            <h2 class="h5 fw-bold mb-1">Secciones de la página de inicio</h2>
                            <p class="text-muted small mb-4">Activa o desactiva cada bloque de la portada.</p>

                            <div class="vstack gap-3">
                                @foreach ([
                                    'SITIO_HABILITAR_MENU' => 'Menú de productos por sucursal',
                                    'SITIO_HABILITAR_PROMOCIONES' => 'Promociones por sucursal',
                                    'SITIO_HABILITAR_SUCURSALES' => 'Sucursales, mapas y horarios',
                                ] as $clave => $etiqueta)
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" role="switch" id="{{ $clave }}"
                                               name="{{ $clave }}" value="1"
                                               @checked($configuracion->get($clave) === '1')>
                                        <label class="form-check-label" for="{{ $clave }}">{{ $etiqueta }}</label>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ===================== TEMA ===================== --}}
                <div class="tab-pane fade" id="tab-tema" role="tabpanel" aria-labelledby="tab-tema-tab">
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-body p-4">
                            <h2 class="h5 fw-bold mb-1">Tema y colores</h2>
                            <p class="text-muted small mb-4">Cambia el aspecto visual. Compatible con cualquier tipo de servicio: elige tus propios colores o usa un preset.</p>

                            <div class="mb-4">
                                <label class="form-label fw-semibold">Presets rápidos</label>
                                <div class="d-flex flex-wrap gap-2">
                                    <button type="button" class="btn btn-sm btn-outline-secondary preset-tema" data-preset="verde">Verde (burger)</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary preset-tema" data-preset="rojo">Rojo</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary preset-tema" data-preset="azul">Azul</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary preset-tema" data-preset="ambar">Ámbar</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary preset-tema" data-preset="noche">Noche</button>
                                </div>
                            </div>

                            <div class="row g-3">
                                @foreach ([
                                    'TEMA_COLOR_PRIMARIO' => 'Color principal',
                                    'TEMA_COLOR_PRIMARIO_OSCURO' => 'Primario oscuro',
                                    'TEMA_COLOR_FONDO' => 'Fondo de la página',
                                    'TEMA_COLOR_TEXTO' => 'Color de texto',
                                    'TEMA_COLOR_DETALLE' => 'Color de detalle',
                                ] as $clave => $etiqueta)
                                    <div class="col-md-4 col-lg-4 col-6">
                                        <label class="form-label small fw-bold">{{ $etiqueta }}</label>
                                        <div class="input-group">
                                            <input type="color" class="form-control form-control-color tema-color" data-texto="{{ $clave }}" name="{{ $clave }}"
                                                   value="{{ $configuracion->get($clave) }}" title="{{ $etiqueta }}">
                                            <input type="text" class="form-control tema-codigo" id="{{ $clave }}"
                                                   value="{{ $configuracion->get($clave) }}" maxlength="7">
                                        </div>
                                    </div>
                                @endforeach
                            </div>

                            <hr class="my-4">

                            <h3 class="h6 fw-bold mb-2">Vista previa</h3>
                            <div id="previewTema" class="card border-0 shadow-sm overflow-hidden">
                                <div id="previewBarra" class="px-3 py-2 d-flex justify-content-between align-items-center text-white">
                                    <span class="fw-bold">🥗 Mi negocio de comidas</span>
                                    <span class="badge text-bg-light">Inicio</span>
                                </div>
                                <div id="previewCuerpo" class="p-4">
                                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                        <div>
                                            <div class="small text-uppercase fw-bold" id="previewBadcillo">Bienvenido</div>
                                            <h3 class="fw-bolder mb-1" id="previewTitulo">Burguer Willy and Grill</h3>
                                            <p class="small mb-0" id="previewTexto">Personaliza colores, textos e imágenes desde el panel.</p>
                                        </div>
                                        <button type="button" class="btn btn-sm" id="previewBoton">Ver menú</button>
                                    </div>
                                    <div class="mt-4 d-flex gap-2 flex-wrap">
                                        <span class="badge" id="previewChip">Todos</span>
                                        <span class="badge border" id="previewChip2">Hamburguesas</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- ===================== MANTENIMIENTO ===================== --}}
                <div class="tab-pane fade" id="tab-mantenimiento" role="tabpanel" aria-labelledby="tab-mantenimiento-tab">
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-body p-4">
                            <h2 class="h5 fw-bold mb-1">Modo mantenimiento</h2>
                            <p class="text-muted small mb-4">Al activarlo, los visitantes y usuarios no administradores verán la página de mantenimiento en todo el sitio. El administrador siempre puede seguir accediendo para desactivarlo.</p>

                            <div class="form-check form-switch mb-4">
                                <input class="form-check-input" type="checkbox" role="switch" id="SITIO_MANTENIMIENTO_ACTIVO" name="SITIO_MANTENIMIENTO_ACTIVO" value="1"
                                       @checked($configuracion->get('SITIO_MANTENIMIENTO_ACTIVO') === '1')>
                                <label class="form-check-label" for="SITIO_MANTENIMIENTO_ACTIVO">Activar mantenimiento de la página</label>
                            </div>

                            <label class="form-label fw-semibold">Mensaje de mantenimiento</label>
                            <textarea name="SITIO_MANTENIMIENTO_MENSAJE" class="form-control" rows="3" maxlength="500"
                                      placeholder="Estamos realizando mejoras en la página. Volveremos muy pronto.">{{ $configuracion->get('SITIO_MANTENIMIENTO_MENSAJE') }}</textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">Cancelar</a>
                <button type="submit" class="btn btn-brand px-4">Guardar cambios</button>
            </div>
        </form>
    </div>
@endsection

@push('scripts')
    <script>
        // El bundle de Vite (jQuery + Bootstrap) llega como <script type="module"> (diferido);
        // se ejecuta antes de DOMContentLoaded, así que aquí $ y bootstrap ya están disponibles.
        document.addEventListener('DOMContentLoaded', function () {
        // ============ Carrusel: funciones expuestas en window para handlers inline ============
        function quitarFila(btn) {
            $(btn).closest('[data-slider-fila]').remove();
            renumerarDiapositivas();
        }

        function sliderImagenCargada(img) {
            var $marco = $(img).closest('[data-slider-vista]');
            if (!$marco.length) return;
            $(img).removeClass('d-none');
            $marco.find('.slider-vista-fallback').addClass('d-none');
        }

        function sliderImagenRota(img) {
            var $marco = $(img).closest('[data-slider-vista]');
            if (!$marco.length) return;
            $(img).addClass('d-none');
            $marco.find('.slider-vista-fallback').removeClass('d-none');
        }

        function renumerarDiapositivas() {
            $('#slidersContainer [data-slider-fila]').each(function (i) {
                $(this).find('.badge-diapositiva').text('Diapositiva #' + (i + 1));
            });
        }

        function actualizarVistaSlider(input) {
            var $fila = $(input).closest('[data-slider-fila]');
            var $marco = $fila.find('[data-slider-vista]');
            if (!$marco.length) return;
            var url = $(input).val().trim();
            if (!url) {
                $marco.addClass('d-none');
                return;
            }
            $marco.removeClass('d-none');
            var $img = $marco.find('.slider-vista-img');
            sliderImagenRota($img[0]);
            $img.attr('src', url);
        }

        window.quitarFila = quitarFila;
        window.sliderImagenCargada = sliderImagenCargada;
        window.sliderImagenRota = sliderImagenRota;

        // ============ Carrusel: agregar / quitar diapositivas ============
        function agregarDiapositiva() {
            var $contenedor = $('#slidersContainer');
            if (!$contenedor.length) return;
            var $fila = $(
                '<div class="card tarjeta-producto" data-slider-fila>' +
                '    <div class="card-body p-3">' +
                '        <div class="d-flex justify-content-between align-items-start mb-2">' +
                '            <span class="badge text-bg-brand badge-diapositiva">Diapositiva</span>' +
                '            <button type="button" class="btn btn-sm btn-outline-danger" onclick="quitarFila(this)">Quitar</button>' +
                '        </div>' +
                '        <div class="row g-3">' +
                '            <div class="col-md-7">' +
                '                <div class="vstack gap-3">' +
                '                    <div>' +
                '                        <label class="form-label small fw-bold mb-1">URL de la imagen</label>' +
                '                        <input type="text" name="slider[imagen][]" class="form-control" placeholder="https://ejemplo.com/imagen.jpg">' +
                '                    </div>' +
                '                    <div class="row g-3">' +
                '                        <div class="col-md-6">' +
                '                            <label class="form-label small fw-bold mb-1">Título</label>' +
                '                            <input type="text" name="slider[titulo][]" class="form-control" maxlength="255" placeholder="Texto principal">' +
                '                        </div>' +
                '                        <div class="col-md-6">' +
                '                            <label class="form-label small fw-bold mb-1">Subtítulo</label>' +
                '                            <input type="text" name="slider[subtitulo][]" class="form-control" maxlength="255" placeholder="Texto secundario">' +
                '                        </div>' +
                '                    </div>' +
                '                    <div class="row g-3">' +
                '                        <div class="col-md-6">' +
                '                            <label class="form-label small fw-bold mb-1">Texto del botón</label>' +
                '                            <input type="text" name="slider[boton_texto][]" class="form-control" maxlength="100" placeholder="Ver menú">' +
                '                        </div>' +
                '                        <div class="col-md-6">' +
                '                            <label class="form-label small fw-bold mb-1">Destino del botón (#id o URL)</label>' +
                '                            <input type="text" name="slider[boton_url][]" class="form-control" maxlength="255" placeholder="#menu">' +
                '                        </div>' +
                '                    </div>' +
                '                </div>' +
                '            </div>' +
                '            <div class="col-md-5">' +
                '                <label class="form-label small fw-bold mb-1 d-block">Vista previa</label>' +
                '                <div class="slider-vista d-none" data-slider-vista>' +
                '                    <div class="slider-vista-marco">' +
                '                        <span class="slider-vista-fallback">🍔</span>' +
                '                        <img class="slider-vista-img d-none" alt="Vista previa de la diapositiva"' +
                '                             onload="sliderImagenCargada(this)" onerror="sliderImagenRota(this)">' +
                '                    </div>' +
                '                </div>' +
                '                <div class="form-text">Vista previa automática según la URL ingresada.</div>' +
                '            </div>' +
                '        </div>' +
                '    </div>' +
                '</div>'
            );
            $contenedor.append($fila);
            renumerarDiapositivas();
            $fila[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        $(function () {
            $('#agregarSlider').on('click', agregarDiapositiva);

            // Vista previa en vivo al escribir la URL (incluye diapositivas agregadas dinámicamente)
            $('#slidersContainer')
                .on('input', 'input[name="slider[imagen][]"]', function () {
                    actualizarVistaSlider(this);
                })
                .find('input[name="slider[imagen][]"]')
                .each(function () { actualizarVistaSlider(this); });

            renumerarDiapositivas();

            // ============ Abrir pestaña desde el hash del submenú ============
            try {
                var hash = window.location.hash;
                if (hash) {
                    var $pestana = $('[data-bs-target="' + hash + '"]');
                    if ($pestana.length) {
                        bootstrap.Tab.getOrCreateInstance($pestana[0]).show();
                    }
                }
            } catch (e) {
                // Sin bootstrap o elemento inválido: no romper el resto de la página.
            }

            $('#configTabs [data-bs-toggle="pill"]').on('click', function () {
                history.replaceState(null, '', $(this).data('bsTarget'));
            });

            // ============ Tema: preset y vista previa ============
            var campos = {};
            ['TEMA_COLOR_PRIMARIO', 'TEMA_COLOR_PRIMARIO_OSCURO', 'TEMA_COLOR_FONDO', 'TEMA_COLOR_TEXTO', 'TEMA_COLOR_DETALLE']
                .forEach(function (clave) {
                    campos[clave] = {
                        color: $('input[name="' + clave + '"][type="color"]'),
                        codigo: $('#' + clave),
                    };
                    if (campos[clave].color.length && campos[clave].codigo.length) {
                        campos[clave].color.on('input', function () {
                            campos[clave].codigo.val(campos[clave].color.val());
                            aplicarVistaPrevia();
                        });
                        campos[clave].codigo.on('input', function () {
                            if (/^#[0-9a-fA-F]{6}$/.test(campos[clave].codigo.val())) {
                                campos[clave].color.val(campos[clave].codigo.val());
                                aplicarVistaPrevia();
                            }
                        });
                    }
                });

            var presets = {
                verde: { TEMA_COLOR_PRIMARIO: '#4a6741', TEMA_COLOR_PRIMARIO_OSCURO: '#3a5233', TEMA_COLOR_FONDO: '#faf6ef', TEMA_COLOR_TEXTO: '#2f2b26', TEMA_COLOR_DETALLE: '#d4a373' },
                rojo: { TEMA_COLOR_PRIMARIO: '#b23a3a', TEMA_COLOR_PRIMARIO_OSCURO: '#8f2d2d', TEMA_COLOR_FONDO: '#fdf5f3', TEMA_COLOR_TEXTO: '#331d1d', TEMA_COLOR_DETALLE: '#e8a87c' },
                azul: { TEMA_COLOR_PRIMARIO: '#2f5d75', TEMA_COLOR_PRIMARIO_OSCURO: '#24485c', TEMA_COLOR_FONDO: '#f2f7f9', TEMA_COLOR_TEXTO: '#132533', TEMA_COLOR_DETALLE: '#d9a441' },
                ambar: { TEMA_COLOR_PRIMARIO: '#c96f2e', TEMA_COLOR_PRIMARIO_OSCURO: '#a75820', TEMA_COLOR_FONDO: '#fdf6ec', TEMA_COLOR_TEXTO: '#33261a', TEMA_COLOR_DETALLE: '#7ea16b' },
                noche: { TEMA_COLOR_PRIMARIO: '#4b5563', TEMA_COLOR_PRIMARIO_OSCURO: '#374151', TEMA_COLOR_FONDO: '#f4f5f7', TEMA_COLOR_TEXTO: '#1f2937', TEMA_COLOR_DETALLE: '#10b981' },
            };

            $('.preset-tema').on('click', function () {
                var preset = presets[$(this).data('preset')];
                if (!preset) return;
                Object.keys(preset).forEach(function (clave) {
                    campos[clave].color.val(preset[clave]);
                    campos[clave].codigo.val(preset[clave]);
                });
                aplicarVistaPrevia();
            });

            function aplicarVistaPrevia() {
                if (!campos.TEMA_COLOR_PRIMARIO || !campos.TEMA_COLOR_PRIMARIO.color || !campos.TEMA_COLOR_PRIMARIO.color.length) return;
                var v = {};
                Object.keys(campos).forEach(function (k) { v[k] = campos[k].color.val(); });
                $('#previewBarra').css('backgroundColor', v.TEMA_COLOR_PRIMARIO);
                $('#previewCuerpo').css({ backgroundColor: v.TEMA_COLOR_FONDO, color: v.TEMA_COLOR_TEXTO });
                $('#previewBadcillo').css('color', v.TEMA_COLOR_PRIMARIO);
                $('#previewTitulo').css('color', v.TEMA_COLOR_TEXTO);
                $('#previewTexto').css('color', v.TEMA_COLOR_TEXTO);
                $('#previewBoton').css({ backgroundColor: v.TEMA_COLOR_PRIMARIO, borderColor: v.TEMA_COLOR_PRIMARIO, color: '#fff' });
                $('#previewChip').css({ backgroundColor: v.TEMA_COLOR_PRIMARIO, color: '#fff' });
                $('#previewChip2').css({ color: v.TEMA_COLOR_PRIMARIO, border: '1px solid ' + v.TEMA_COLOR_PRIMARIO });
            }

            aplicarVistaPrevia();
        });
        });
    </script>
@endpush