<?php

namespace App\Http\Controllers;

use App\Models\AperturaCaja;
use App\Models\Categoria;
use App\Models\Empleado;
use App\Models\HistorialProducto;
use App\Models\Producto;
use App\Models\Sucursal;
use App\Models\SucursalProducto;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class ProductoSucursalController extends Controller
{
    /**
     * Listado de productos por sucursal. Similar al menú de productos:
     * categorías a la izquierda y tarjetas de productos a la derecha,
     * pero mostrando el precio y la disponibilidad que tiene cada
     * producto en la sucursal seleccionada.
     */
    public function index(Request $request): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursales = $this->sucursalesPermitidas($empleado);

        if ($sucursales->isEmpty()) {
            abort(403, 'No tienes una sucursal asignada para ver sus productos.');
        }

        $idsucursal = $request->integer('idsucursal');

        $sucursalActual = $sucursales->firstWhere('id', $idsucursal)
            ?? $sucursales->first();

        $categorias = Categoria::withCount('productos')
            ->orderBy('nombre')
            ->get();

        $idcategoria = $request->integer('idcategoria');

        $categoriaActual = $categorias->firstWhere('id', $idcategoria)
            ?? $categorias->firstWhere('estado', true)
            ?? $categorias->first();

        $sucursalProductos = SucursalProducto::with('producto')
            ->where('idsucursal', $sucursalActual->id)
            ->get()
            ->keyBy('idproducto');

        $productos = $categoriaActual
            ? Producto::with('categoria')
                ->where('idcategoria', $categoriaActual->id)
                ->orderBy('nombre')
                ->paginate(9)
                ->withQueryString()
            : new LengthAwarePaginator([], 0, 9);

        $flags = $this->flagsDeOperacion($empleado, $sucursalActual);

        return view('admin.productos-sucursal.index', compact(
            'empleado',
            'sucursales',
            'idsucursal',
            'sucursalActual',
            'categorias',
            'idcategoria',
            'categoriaActual',
            'sucursalProductos',
            'productos',
        ) + $flags);
    }

    /**
     * Búsqueda JSON por nombre dentro de la categoría actual de la sucursal.
     */
    public function buscar(Request $request): JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalActualPermitida($empleado, $request->integer('idsucursal'));

        $idcategoria = $request->integer('idcategoria');
        $q = mb_strtolower(trim((string) $request->query('q', '')));

        $sucursalProductos = SucursalProducto::with('producto')
            ->where('idsucursal', $sucursalActual->id)
            ->get()
            ->keyBy('idproducto');

        $productos = $idcategoria
            ? Producto::with('categoria')
                ->where('idcategoria', $idcategoria)
                ->when($q !== '', fn ($query) => $query->whereRaw('LOWER(nombre) LIKE ?', ['%'.$q.'%']))
                ->orderBy('nombre')
                ->limit(100)
                ->get()
            : collect();

        $flags = $this->flagsDeOperacion($empleado, $sucursalActual);

        return response()->json([
            'html' => $idcategoria
                ? view('admin.productos-sucursal._productos', [
                    'productos' => $productos,
                    'sucursalProductos' => $sucursalProductos,
                    'sucursalActual' => $sucursalActual,
                    'vacioMensaje' => $q !== ''
                        ? "No se encontró ningún producto con «{$request->query('q')}» en esta sucursal."
                        : 'No hay productos en esta categoría.',
                ] + $flags)->render()
                : '',
            'total' => $productos->count(),
        ]);
    }

    /**
     * Registra un producto en la sucursal (permiso 316): define su precio
     * y su disponibilidad inicial en esa sucursal.
     */
    public function registrar(Request $request): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalActualPermitida($empleado, $request->integer('idsucursal'));

        $validated = $request->validate([
            'idproducto' => ['required', 'exists:producto,id'],
            'precioproducto' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'disponibilidad' => ['nullable', 'boolean'],
        ]);

        $producto = Producto::findOrFail($validated['idproducto']);

        $yaRegistrado = SucursalProducto::where('idsucursal', $sucursalActual->id)
            ->where('idproducto', $producto->id)
            ->exists();

        if ($yaRegistrado) {
            return back()->withInput()->with('error', "El producto {$producto->nombre} ya está registrado en esta sucursal.");
        }

        $sucursalProducto = SucursalProducto::create([
            'idsucursal' => $sucursalActual->id,
            'idproducto' => $producto->id,
            'precioproducto' => $validated['precioproducto'],
            'disponibilidad' => $request->boolean('disponibilidad'),
        ]);

        $this->registrarAccion($empleado->id, 'CREATE', 'sucursal_producto', $sucursalProducto->id, '316');

        return redirect()->route('dashboard.productos-sucursal.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "{$producto->nombre} registrado en {$sucursalActual->nombre}.");
    }

    /**
     * Edita el precio del producto en la sucursal (permiso 318).
     * Registra el cambio en el historial de precios.
     */
    public function actualizarPrecio(Request $request, SucursalProducto $sucursalProducto): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalProductoPermitido($empleado, $sucursalProducto);

        $validated = $request->validate([
            'precioproducto' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
        ]);

        $precioAnterior = (float) $sucursalProducto->precioproducto;
        $precioNuevo = (float) $validated['precioproducto'];

        if ($precioAnterior === $precioNuevo) {
            return back()->with('info', 'El precio no cambió.');
        }

        DB::transaction(function () use ($sucursalProducto, $precioAnterior, $precioNuevo) {
            $sucursalProducto->update(['precioproducto' => $precioNuevo]);

            HistorialProducto::create([
                'fecha_registro' => now(),
                'precioanterior' => $precioAnterior,
                'precionuevo' => $precioNuevo,
                'idproductosucursal' => $sucursalProducto->id,
            ]);
        });

        $this->registrarAccion($empleado->id, 'UPDATE', 'sucursal_producto', $sucursalProducto->id, '318');

        return redirect()->route('dashboard.productos-sucursal.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Precio de {$sucursalProducto->producto?->nombre} actualizado en {$sucursalActual->nombre}.");
    }

    /**
     * Alterna la disponibilidad del producto en la sucursal (permiso 319).
     */
    public function disponibilidad(SucursalProducto $sucursalProducto): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalProductoPermitido($empleado, $sucursalProducto);

        if ($this->operacionBloqueadaPorCaja($empleado, $sucursalActual)) {
            abort(403, 'Necesitas una apertura de caja abierta para esta operación.');
        }

        $sucursalProducto->update(['disponibilidad' => ! $sucursalProducto->disponibilidad]);

        $this->registrarAccion($empleado->id, 'UPDATE', 'sucursal_producto', $sucursalProducto->id, '319');

        $estado = $sucursalProducto->disponibilidad ? 'disponible' : 'no disponible';

        return redirect()->route('dashboard.productos-sucursal.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "{$sucursalProducto->producto?->nombre} marcado como {$estado} en {$sucursalActual->nombre}.");
    }

    /**
     * Devuelve el histórico de precios del producto en la sucursal (permiso 320).
     */
    public function historial(SucursalProducto $sucursalProducto): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalProductoPermitido($empleado, $sucursalProducto);

        $historial = HistorialProducto::where('idproductosucursal', $sucursalProducto->id)
            ->orderByDesc('fecha_registro')
            ->get();

        return view('admin.productos-sucursal._historial', compact('historial', 'sucursalProducto', 'sucursalActual'));
    }

    /**
     * Sucursales que el empleado puede operar (mismo criterio que el inventario):
     * ADMINISTRADOR → todas; GERENTE → las que gerencia; MESERO/CAJERO → la suya.
     */
    private function sucursalesPermitidas(Empleado $empleado): Collection
    {
        $claverol = $empleado->rol?->claverol;

        if ($claverol === 'ADMINISTRADOR') {
            return Sucursal::orderBy('nombre')->get();
        }

        if ($claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->orderBy('nombre')
                ->get();
        }

        return $empleado->idsucursal
            ? Sucursal::where('id', $empleado->idsucursal)->get()
            : collect();
    }

    private function sucursalActualPermitida(Empleado $empleado, int $idsucursal): Sucursal
    {
        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $idsucursal)
            ?? $this->sucursalesPermitidas($empleado)->first();

        abort_unless($sucursal, 403, 'No tienes acceso a esa sucursal.');

        return $sucursal;
    }

    private function sucursalProductoPermitido(Empleado $empleado, SucursalProducto $sucursalProducto): Sucursal
    {
        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $sucursalProducto->idsucursal);

        abort_unless($sucursal, 403, 'Ese producto no pertenece a una sucursal que puedas operar.');

        return $sucursal;
    }

    /**
     * Banderas para la vista según el rol y los permisos del empleado, más la
     * condición de caja abierta (mesero y cajero solo operan con caja abierta).
     */
    private function flagsDeOperacion(Empleado $empleado, Sucursal $sucursal): array
    {
        $claverol = $empleado->rol?->claverol;

        $codigos = $empleado->rol?->permisos
            ? $empleado->rol->permisos->where('estado', true)->pluck('codigo')
            : collect();

        $requiereCajaAbierta = in_array($claverol, ['MESERO', 'CAJERO'], true);

        $cajaAbierta = AperturaCaja::where('estado', 'ABIERTA')
            ->whereHas('caja', fn ($query) => $query->where('idsucursal', $sucursal->id))
            ->exists();

        return [
            'puedeRegistrar' => $codigos->contains('316'),
            'puedeEditarPrecio' => $codigos->contains('318'),
            'puedeDisponibilidad' => $codigos->contains('319'),
            'puedeHistorial' => $codigos->contains('320'),
            'esAdmin' => $claverol === 'ADMINISTRADOR',
            'esMesero' => $claverol === 'MESERO',
            'requiereCajaAbierta' => $requiereCajaAbierta,
            'cajaAbierta' => $cajaAbierta,
            'operacionBloqueada' => $requiereCajaAbierta && ! $cajaAbierta,
        ];
    }

    private function operacionBloqueadaPorCaja(Empleado $empleado, Sucursal $sucursal): bool
    {
        return $this->flagsDeOperacion($empleado, $sucursal)['operacionBloqueada'];
    }
}
