{{-- Detalle de un cierre de caja. Requiere $cierre (CierreCaja) y $sucursalActual. --}}
@php
    $apertura = $cierre->aperturaCaja;
@endphp

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <div>
        <h6 class="fw-bold mb-1">💵 {{ $cierre->aperturaCaja?->caja?->nombre }} · {{ $sucursalActual?->nombre }}</h6>
        <p class="small text-muted mb-0">
            Cerrado el {{ $cierre->fechacierre->format('d/m/Y H:i') }} por
            {{ $cierre->empleado?->nombre }} {{ $cierre->empleado?->apellido }}
        </p>
    </div>
    <span class="badge fs-6 {{ (float) $cierre->diferencia == 0 ? 'text-bg-success' : ((float) $cierre->diferencia > 0 ? 'text-bg-warning' : 'text-bg-danger') }}">
        Diferencia {{ $cierre->diferencia >= 0 ? '+' : '' }}Bs. {{ number_format($cierre->diferencia, 2) }}
    </span>
</div>

<div class="row g-3">
    <div class="col-12">
        <div class="table-responsive">
            <table class="table table-sm table-bordered align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Concepto</th>
                        <th class="text-end">Monto (Bs.)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Fondo inicial de la apertura</td>
                        <td class="text-end">{{ number_format($cierre->fondoinicial, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Ventas en efectivo</td>
                        <td class="text-end">{{ number_format($cierre->totalventasefectivo, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Ventas por QR / transferencia</td>
                        <td class="text-end">{{ number_format($cierre->totalventasqr, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Ventas con tarjeta</td>
                        <td class="text-end">{{ number_format($cierre->totalventastarjeta, 2) }}</td>
                    </tr>
                    <tr class="table-light">
                        <td class="fw-semibold">Total de ventas</td>
                        <td class="text-end fw-semibold">{{ number_format($cierre->totalventas, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Ingresos de caja</td>
                        <td class="text-end text-success">+{{ number_format($cierre->totalingresos, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Egresos de caja</td>
                        <td class="text-end text-danger">-{{ number_format($cierre->totalegresos, 2) }}</td>
                    </tr>
                    <tr class="table-light">
                        <td class="fw-semibold">Efectivo esperado</td>
                        <td class="text-end fw-semibold">{{ number_format($cierre->efectivoesperado, 2) }}</td>
                    </tr>
                    <tr>
                        <td>Efectivo contado</td>
                        <td class="text-end">{{ number_format($cierre->efectivocontado, 2) }}</td>
                    </tr>
                    <tr class="{{ (float) $cierre->diferencia == 0 ? 'table-success' : ((float) $cierre->diferencia > 0 ? 'table-warning' : 'table-danger') }}">
                        <td class="fw-semibold">Diferencia</td>
                        <td class="text-end fw-semibold">{{ $cierre->diferencia >= 0 ? '+' : '' }}{{ number_format($cierre->diferencia, 2) }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    @if ($cierre->observacion)
        <div class="col-12">
            <label class="form-label small fw-semibold">Observación</label>
            <p class="small mb-0 text-muted border rounded p-2 bg-light">{{ $cierre->observacion }}</p>
        </div>
    @endif
    @if ($apertura)
        <div class="col-12">
            <label class="form-label small fw-semibold">Jornada</label>
            <p class="small mb-0 text-muted">
                Abierta el {{ \Illuminate\Support\Carbon::parse($apertura->fechaapertura)->format('d/m/Y H:i') }}
                por {{ $apertura->empleado?->nombre }} {{ $apertura->empleado?->apellido ?? '' }}
                ({{ $apertura->caja?->nombre }})
            </p>
        </div>
    @endif
</div>