{{-- Tarjetas de productos por sucursal. Requiere $productos, $sucursalProductos, $sucursalActual y las banderas de permiso. --}}
<div class="row g-3">
    @forelse ($productos as $producto)
        @php
            $sp = $sucursalProductos->get($producto->id);
        @endphp
        <div class="col-12 col-sm-6 col-xl-4">
            <div class="card h-100 tarjeta-producto-menu border">
                <div class="ratio ratio-4x3 bg-light-subtle overflow-hidden rounded-top">
                    @if ($producto->photo)
                        <img src="{{ asset('storage/'.$producto->photo) }}" alt="{{ $producto->nombre }}"
                             class="object-fit-cover w-100" loading="lazy">
                    @else
                        <div class="d-flex align-items-center justify-content-center text-muted small">
                            Sin foto
                        </div>
                    @endif
                </div>
                <div class="card-body pb-2">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <h2 class="h6 fw-bold mb-1">{{ $producto->nombre }}</h2>
                        @if ($producto->estado)
                            <span class="badge text-bg-success">Activo</span>
                        @else
                            <span class="badge text-bg-secondary">Inactivo</span>
                        @endif
                    </div>

                    @if ($sp)
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <span class="fs-5 fw-bold">S/ {{ number_format($sp->precioproducto, 2) }}</span>
                            @if ($sp->disponibilidad)
                                <span class="badge text-bg-success">Disponible</span>
                            @else
                                <span class="badge text-bg-danger">Agotado</span>
                            @endif
                        </div>
                    @else
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <span class="text-muted">—</span>
                            <span class="badge text-bg-light border">Sin precio en esta sucursal</span>
                        </div>
                    @endif
                </div>
                @php
                    $puedeEditar = $puedeEditarPrecio && $puedeHistorial;
                    $puedeToggle = $puedeDisponibilidad && !$operacionBloqueada;
                @endphp
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2 flex-wrap">
                    @if ($puedeRegistrar && ! $sp)
                        <button class="btn btn-sm btn-brand flex-fill"
                                data-bs-toggle="modal"
                                data-bs-target="#registrarSucursalProductoModal"
                                data-id="{{ $producto->id }}"
                                data-nombre="{{ $producto->nombre }}"
                                data-url-foto="{{ $producto->photo ? asset('storage/'.$producto->photo) : '' }}">
                            + Registrar en sucursal
                        </button>
                    @endif

                    @if ($sp && ($puedeEditarPrecio || $puedeHistorial))
                        @if ($puedeEditarPrecio)
                            <button class="btn btn-sm btn-outline-brand"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editarPrecioSPModal"
                                    data-id="{{ $sp->id }}"
                                    data-nombre="{{ $producto->nombre }}"
                                    data-precio="{{ number_format($sp->precioproducto, 2, '.', '') }}">
                                Precio
                            </button>
                        @endif
                        @if ($puedeHistorial)
                            <button class="btn btn-sm btn-outline-secondary"
                                    data-historial-url="{{ route('dashboard.productos-sucursal.historial', $sp) }}"
                                    data-bs-toggle="modal"
                                    data-bs-target="#historialSPModal">
                                Historial
                            </button>
                        @endif
                    @endif

                    @if ($sp && $puedeDisponibilidad)
                        <form method="POST" action="{{ route('dashboard.productos-sucursal.disponibilidad', $sp) }}"
                              class="d-inline m-0 flex-fill">
                            @csrf
                            @if ($sp->disponibilidad)
                                <button class="btn btn-sm w-100 {{ $puedeToggle ? 'btn-outline-danger' : 'btn-outline-secondary' }}"
                                        @if (!$puedeToggle) disabled title="Necesitas una apertura de caja abierta para esta acción" @endif>
                                    Marcar agotado
                                </button>
                            @else
                                <button class="btn btn-sm w-100 {{ $puedeToggle ? 'btn-outline-success' : 'btn-outline-secondary' }}"
                                        @if (!$puedeToggle) disabled title="Necesitas una apertura de caja abierta para esta acción" @endif>
                                    Marcar disponible
                                </button>
                            @endif
                        </form>
                    @endif

                    @if ($sp && !$puedeEditar && !$puedeDisponibilidad && !$puedeHistorial && !$puedeRegistrar)
                        <span class="small text-muted w-100 text-center py-1">Solo lectura</span>
                    @endif
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="text-center text-muted py-4">
                {{ $vacioMensaje ?? 'No hay productos en esta categoría.' }}
            </div>
        </div>
    @endforelse
</div>