<?php

namespace App\Http\Controllers;

use App\Models\AperturaCaja;
use App\Models\DetallePedido;
use App\Models\Empleado;
use App\Models\Mesa;
use App\Models\MetodoPago;
use App\Models\Pago;
use App\Models\Pedido;
use App\Models\Promocion;
use App\Models\Sucursal;
use App\Models\SucursalProducto;
use App\Models\Venta;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class PedidoController extends Controller
{
    /**
     * Ventana de atención (POS): sucursal, estado de la apertura de caja,
     * categorías con productos, promociones, mesas y pedidos del día.
     */
    public function index(Request $request): View
    {
        $empleado = auth()->user()->empleado->load('rol');
        $rol = $empleado->rol;

        $sucursales = $this->sucursalesPermitidas($empleado);

        $sucursalActual = $sucursales->firstWhere('id', $request->integer('idsucursal'))
            ?? $sucursales->first();

        abort_unless($sucursalActual, 403, 'No tienes una sucursal asignada para atender pedidos.');

        $aperturaActiva = $this->aperturaActivaDeSucursal($sucursalActual);

        $aperturaAbierta = (bool) $aperturaActiva;

        $productosPOS = SucursalProducto::with('producto.categoria')
            ->where('idsucursal', $sucursalActual->id)
            ->get()
            ->filter(fn ($sp) => $sp->disponibilidad && $sp->producto?->estado && $sp->producto?->categoria)
            ->values();

        $categoriasPOS = $productosPOS
            ->groupBy(fn ($sp) => $sp->producto->categoria->id)
            ->map(fn ($items) => [
                'categoria' => $items->first()->producto->categoria,
                'productos' => $items
                    ->sortBy(fn ($sp) => mb_strtolower($sp->producto->nombre))
                    ->values(),
            ])
            ->sortBy(fn ($grupo) => mb_strtolower($grupo['categoria']->nombre))
            ->values();

        Promocion::marcarVencidas();

        $promocionesPOS = Promocion::with('sucursalesProducto.producto')
            ->where('activo', true)
            ->where('fechainicio', '<=', now())
            ->where('fechafin', '>=', now())
            ->whereHas('sucursalesProducto', fn ($query) => $query->where('idsucursal', $sucursalActual->id))
            ->orderBy('fechafin')
            ->get();

        // El mesero solo atiende con la caja abierta en su sucursal: sin apertura,
        // no ve la ventana de atención (solo perfil o cerrar sesión).
        $posBloqueado = $rol->claverol === 'MESERO' && ! $aperturaAbierta;

        $mesas = Mesa::where('idsucursal', $sucursalActual->id)
            ->where('estado', true)
            ->orderBy('numeromesa')
            ->get();

        $pedidos = $aperturaActiva
            ? $this->pedidosDelDia($aperturaActiva->id)
            : collect();

        $metodospago = MetodoPago::where('activo', true)->orderBy('nombre')->get();

        $codigos = $rol->permisos ? $rol->permisos->where('estado', true)->pluck('codigo') : collect();

        $requiereCajaAbierta = in_array($rol->claverol, ['MESERO', 'CAJERO'], true);

        return view('admin.generar-pedidos.index', array_merge(
            compact(
                'empleado',
                'rol',
                'sucursales',
                'sucursalActual',
                'aperturaAbierta',
                'posBloqueado',
                'categoriasPOS',
                'promocionesPOS',
                'mesas',
                'pedidos',
                'metodospago',
            ),
            [
                'puedeVerPromosPOS' => in_array($rol->claverol, ['GERENTE', 'CAJERO', 'MESERO'], true),
                'puedeCrear' => $codigos->contains('500'),
                'puedeEjecutar' => $codigos->contains('501'),
                'puedeAnular' => $codigos->contains('505'),
                'puedePagar' => $codigos->contains('440'),
                'esMesero' => $rol->claverol === 'MESERO',
                'esAdmin' => $rol->claverol === 'ADMINISTRADOR',
                'requiereCajaAbierta' => $requiereCajaAbierta,
                'operacionBloqueada' => $requiereCajaAbierta && ! $aperturaAbierta && ! $posBloqueado,
            ]
        ));
    }

    /**
     * Registra un pedido (permiso 500) con sus líneas y las promociones aplicadas.
     * Soporta el precio unitario ajustado por cantidad (p. ej. pedidos por volumen)
     * y la hora definida para ordenar/recoger (horarecogida).
     */
    public function store(Request $request): RedirectResponse|JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalActualPermitida($empleado, $request->input('idsucursal'));

        $apertura = $this->requerirAperturaActiva($sucursalActual);

        abort_unless($this->codigos($empleado)->contains('500'), 403, 'No tienes permiso para crear pedidos.');

        $validated = $this->validateStore($request);

        if ($validated['tipopedido'] === 'MESA') {
            $mesa = Mesa::where('idsucursal', $sucursalActual->id)
                ->where('estado', true)
                ->find($validated['idmesa']);

            abort_unless($mesa, 422, 'La mesa elegida no existe o no está activa.');
        }

        DB::transaction(function () use ($empleado, $sucursalActual, $apertura, $validated, &$pedido) {
            $nroPedido = (Pedido::where('idaperturacaja', $apertura->id)->max('nropedido') ?? 0) + 1;

            $pedidoModel = Pedido::create([
                'nropedido' => $nroPedido,
                'fecha' => now(),
                'horarecogida' => $validated['horarecogida'],
                'observaciones' => $validated['observaciones'] ?? null,
                'total' => 0,
                'estadopedido' => 'PENDIENTE',
                'tipopedido' => $validated['tipopedido'],
                'idsucursal' => $sucursalActual->id,
                'idempleado' => $empleado->id,
                'idmesa' => $validated['tipopedido'] === 'MESA' ? $validated['idmesa'] : null,
                'idaperturacaja' => $apertura->id,
                'subtotalpedido' => 0,
                'descuentopedido' => 0,
            ]);

            $subtotal = 0;
            $descuento = 0;

            foreach ($validated['items'] as $linea) {
                $sp = $this->productoDisponible($sucursalActual->id, $linea['idproductosucursal']);

                $subtotalLinea = round($linea['cantidad'] * $linea['preciounitario'], 2);

                DetallePedido::create([
                    'cantidad' => $linea['cantidad'],
                    'preciounitario' => $linea['preciounitario'],
                    'subtotal' => $subtotalLinea,
                    'descuento' => 0,
                    'total' => $subtotalLinea,
                    'idpedido' => $pedidoModel->id,
                    'idproductosucursal' => $sp->id,
                ]);

                $subtotal += $subtotalLinea;
            }

            foreach ($validated['promos'] as $lineaPromo) {
                $resultado = $this->lineasPromocion(
                    $sucursalActual->id,
                    $lineaPromo['idpromocion'],
                    $lineaPromo['cantidad'],
                    $pedidoModel->id
                );

                $subtotal += $resultado['subtotal'];
            }

            $subtotal = round($subtotal, 2);

            $pedidoModel->update([
                'subtotalpedido' => $subtotal,
                'descuentopedido' => 0,
                'total' => $subtotal,
            ]);

            $this->registrarAccion($empleado->id, 'CREATE', 'pedido', $pedidoModel->id, '500');

            $pedido = $pedidoModel;
        });

        $mensaje = "Pedido #{$pedido->nropedido} registrado por Bs. {$pedido->total}.";

        return $this->respuesta($request, $mensaje, ['idsucursal' => $sucursalActual->id]);
    }

    /**
     * Marca el pedido como ejecutado/entregado (permiso 501).
     */
    public function ejecutar(Request $request, int $pedido): RedirectResponse|JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $pedidoModel = $this->pedidoPermitido($empleado, $pedido);

        abort_unless($this->codigos($empleado)->contains('501'), 403, 'No tienes permiso para editar pedidos.');

        if ($pedidoModel->estadopedido !== 'PENDIENTE') {
            abort(422, 'Solo los pedidos pendientes pueden ejecutarse.');
        }

        $pedidoModel->update(['estadopedido' => 'EJECUTADO']);

        $this->registrarAccion($empleado->id, 'UPDATE', 'pedido', $pedidoModel->id, '501');

        return $this->respuesta($request, "Pedido #{$pedidoModel->nropedido} marcado como ejecutado.");
    }

    /**
     * Edita un pedido PENDIENTE (reemplaza líneas) o EJECUTADO (solo agrega líneas).
     * No permite editar pedidos cobrados o anulados.
     */
    public function editar(Request $request, int $pedido): RedirectResponse|JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $pedidoModel = $this->pedidoPermitido($empleado, $pedido);

        abort_unless($this->codigos($empleado)->contains('501') || $this->codigos($empleado)->contains('506'), 403, 'No tienes permiso para editar pedidos.');

        if (! in_array($pedidoModel->estadopedido, ['PENDIENTE', 'EJECUTADO'], true)) {
            abort(422, 'Solo se pueden editar pedidos pendientes o ejecutados.');
        }

        if ($pedidoModel->venta()->exists()) {
            abort(422, 'Un pedido ya cobrado no puede editarse.');
        }

        $validated = $this->validateStore($request);

        $sucursalActual = Sucursal::findOrFail($pedidoModel->idsucursal);

        $this->exigirCajaAbierta($empleado, $sucursalActual);

        DB::transaction(function () use ($empleado, $pedidoModel, $sucursalActual, $validated) {
            // PENDIENTE: reemplaza todo. EJECUTADO: solo agrega.
            if ($pedidoModel->estadopedido === 'PENDIENTE') {
                $pedidoModel->detalles()->delete();
                $subtotal = 0;
                $descuento = 0;
            } else {
                $subtotal = (float) $pedidoModel->subtotalpedido;
                $descuento = (float) $pedidoModel->descuentopedido;
            }

            foreach ($validated['items'] as $linea) {
                $sp = $this->productoDisponible($sucursalActual->id, $linea['idproductosucursal']);

                $subtotalLinea = round($linea['cantidad'] * $linea['preciounitario'], 2);

                DetallePedido::create([
                    'cantidad' => $linea['cantidad'],
                    'preciounitario' => $linea['preciounitario'],
                    'subtotal' => $subtotalLinea,
                    'descuento' => 0,
                    'total' => $subtotalLinea,
                    'idpedido' => $pedidoModel->id,
                    'idproductosucursal' => $sp->id,
                ]);

                $subtotal += $subtotalLinea;
            }

            foreach ($validated['promos'] as $lineaPromo) {
                $resultado = $this->lineasPromocion(
                    $sucursalActual->id,
                    $lineaPromo['idpromocion'],
                    $lineaPromo['cantidad'],
                    $pedidoModel->id
                );

                $subtotal += $resultado['subtotal'];
            }

            $subtotal = round($subtotal, 2);

            $pedidoModel->update([
                'subtotalpedido' => $subtotal,
                'descuentopedido' => 0,
                'total' => $subtotal,
                'observaciones' => $validated['observaciones'] ?? $pedidoModel->observaciones,
            ]);

            $this->registrarAccion($empleado->id, 'UPDATE', 'pedido', $pedidoModel->id, '501');
        });

        return $this->respuesta($request, "Pedido #{$pedidoModel->nropedido} actualizado.");
    }

    /**
     * Anula un pedido pendiente (permiso 505) y registra el motivo en observaciones.
     */
    public function anular(Request $request, int $pedido): RedirectResponse|JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $pedidoModel = $this->pedidoPermitido($empleado, $pedido);

        abort_unless($this->codigos($empleado)->contains('505'), 403, 'No tienes permiso para anular pedidos.');

        if (in_array($pedidoModel->estadopedido, ['ANULADO'], true)) {
            abort(422, 'El pedido ya está anulado.');
        }

        if ($pedidoModel->venta) {
            abort(422, 'Un pedido ya cobrado no puede anularse.');
        }

        $motivo = trim((string) ($request->input('motivo') ?? ''));
        $observaciones = $pedidoModel->observaciones ? $pedidoModel->observaciones."\n" : '';
        $observaciones .= '[Anulado el '.now()->format('d/m/Y H:i').']';
        if ($motivo !== '') {
            $observaciones .= ': '.$motivo;
        }

        $pedidoModel->update([
            'estadopedido' => 'ANULADO',
            'observaciones' => $observaciones,
        ]);

        $this->registrarAccion($empleado->id, 'DELETE', 'pedido', $pedidoModel->id, '505');

        return $this->respuesta($request, "Pedido #{$pedidoModel->nropedido} anulado.");
    }

    /**
     * Cobre el pedido (permiso 440) pasando por la pasarela de pago simulada
     * según el método elegido: EFECTIVO, TARJETA o BANCO. Genera la venta y el pago.
     */
    public function pagar(Request $request): RedirectResponse|JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        abort_unless($this->codigos($empleado)->contains('440'), 403, 'No tienes permiso para registrar ventas.');

        $validated = $request->validate([
            'idpedido' => ['required', 'integer'],
            'idmetodopago' => ['required', 'exists:metodopago,id'],
            'montorecibido' => ['nullable', 'numeric', 'min:0', 'max:99999999.99'],
            'referencia' => ['nullable', 'string', 'max:100'],
            'ultimos4' => ['nullable', 'string', 'size:4'],
            'marcatarjeta' => ['nullable', 'string', 'max:30'],
        ]);

        $pedidoModel = $this->pedidoPermitido($empleado, (int) $validated['idpedido']);

        if ($pedidoModel->estadopedido === 'ANULADO') {
            abort(422, 'No se puede cobrar un pedido anulado.');
        }

        if ($pedidoModel->venta()->exists()) {
            abort(422, 'El pedido ya fue cobrado.');
        }

        $sucursalActual = Sucursal::findOrFail($pedidoModel->idsucursal);

        $this->exigirCajaAbierta($empleado, $sucursalActual);

        // El pago pertenece a la jornada que registró el pedido (pedidos nuevos);
        // los legados (sin jornada) caen a la apertura abierta de la sucursal.
        $apertura = $pedidoModel->idaperturacaja !== null
            ? AperturaCaja::where('id', $pedidoModel->idaperturacaja)
                ->whereHas('caja', fn ($query) => $query->where('idsucursal', $sucursalActual->id))
                ->firstOrFail()
            : $this->requerirAperturaActiva($sucursalActual);

        abort_unless($apertura->estado === 'ABIERTA', 422, 'La jornada de caja que registró el pedido ya está cerrada.');

        $metodo = MetodoPago::findOrFail($validated['idmetodopago']);

        abort_unless($metodo->activo, 422, 'El método de pago no está disponible.');

        $total = (float) $pedidoModel->total;

        // ---------- Pasarela de pago simulada según el gateway del método ----------
        $intento = $this->simularPasarela($metodo->gateway, $total, $validated);
        $intento['idaperturacaja'] = $apertura->id;

        DB::transaction(function () use ($empleado, $pedidoModel, $metodo, $intento, $total) {
            $pedidoModel->update(['estadopedido' => 'EJECUTADO']);

            $venta = Venta::create([
                'fechaventa' => now(),
                'totalventa' => $total,
                'estadoventa' => 'PAGADA',
                'idempleado' => $empleado->id,
                'idpedido' => $pedidoModel->id,
            ]);

            Pago::create([
                'idventa' => $venta->id,
                'idmetodopago' => $metodo->id,
                'idaperturacaja' => $intento['idaperturacaja'],
                'montopago' => $total,
                'estadopago' => 'APROBADO',
                'montorecibido' => (float) $intento['montorecibido'],
                'cambioentregado' => (float) $intento['cambioentregado'],
                'referenciaexterna' => $intento['referenciaexterna'],
                'gateway' => $metodo->gateway,
                'codigoautorizacion' => $intento['codigoautorizacion'],
                'idtransaccion' => $intento['idtransaccion'],
                'ultimos4' => $intento['ultimos4'],
                'marcatarjeta' => $intento['marcatarjeta'],
                'fechapago' => now(),
                'observacionpago' => $intento['observacionpago'],
            ]);

            $this->registrarAccion($empleado->id, 'CREATE', 'venta', $venta->id, '440');
            $this->registrarAccion($empleado->id, 'UPDATE', 'pedido', $pedidoModel->id, '501');
        });

        $mensaje = "Pedido #{$pedidoModel->nropedido} cobrado por {$metodo->nombre} (autorización {$intento['codigoautorizacion']}).";

        return $this->respuesta($request, $mensaje, ['idsucursal' => $sucursalActual->id]);
    }

    /**
     * Detalle JSON/parcial de un pedido para el modal de la ventana de atención.
     */
    public function detalle(Request $request, int $pedido): JsonResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $pedidoModel = $this->pedidoPermitido($empleado, $pedido);

        $pedidoModel->load('mesa', 'detalles.sucursalProducto.producto', 'venta.empleado', 'venta.pagos.metodoPago', 'empleado');

        return response()->json([
            'html' => view('admin.generar-pedidos._detalle', ['pedido' => $pedidoModel])->render(),
        ]);
    }

    // ============================================================================
    // Helpers de negocio
    // ============================================================================

    private function validateStore(Request $request): array
    {
        $data = $request->validate([
            'idsucursal' => ['required', 'integer'],
            'tipopedido' => ['required', Rule::in(['MESA', 'PARA_LLEVAR'])],
            'idmesa' => ['nullable', 'integer'],
            'horarecogida' => ['nullable', 'date_format:Y-m-d\TH:i'],
            'observaciones' => ['nullable', 'string', 'max:255'],
            'items' => ['nullable', 'array'],
            'items.*.idproductosucursal' => ['required', 'integer'],
            'items.*.cantidad' => ['required', 'integer', 'min:1', 'max:9999'],
            'items.*.preciounitario' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'promos' => ['nullable', 'array'],
            'promos.*.idpromocion' => ['required', 'integer'],
            'promos.*.cantidad' => ['required', 'integer', 'min:1', 'max:9999'],
        ]);

        $items = collect($data['items'] ?? [])
            ->reject(fn ($linea) => (int) $linea['cantidad'] < 1)
            ->values()
            ->all();

        $promos = collect($data['promos'] ?? [])
            ->reject(fn ($linea) => (int) $linea['cantidad'] < 1)
            ->values()
            ->all();

        if (empty($items) && empty($promos)) {
            throw ValidationException::withMessages(['items' => 'Agrega al menos un producto o una promoción al pedido.']);
        }

        $horarecogida = null;

        if (! empty($data['horarecogida'])) {
            $fecha = \DateTime::createFromFormat('Y-m-d\TH:i', $data['horarecogida']);

            if ($fecha === false) {
                throw ValidationException::withMessages(['horarecogida' => 'La hora de recogida no es válida.']);
            }

            $horarecogida = $fecha;
        }

        return [
            'tipopedido' => $data['tipopedido'],
            'idmesa' => (int) ($data['idmesa'] ?? 0),
            'horarecogida' => $horarecogida,
            'items' => array_map(fn ($linea) => [
                'idproductosucursal' => (int) $linea['idproductosucursal'],
                'cantidad' => (int) $linea['cantidad'],
                'preciounitario' => $this->aNumero($linea['preciounitario']),
            ], $items),
            'promos' => array_map(fn ($promo) => [
                'idpromocion' => (int) $promo['idpromocion'],
                'cantidad' => (int) $promo['cantidad'],
            ], $promos),
        ];
    }

    /**
     * Calcula una línea de promoción como una sola unidad de venta. El precio
     * unitario es el total promocional (suma de productos menos descuento), de
     * modo que cantidad × precio unitario refleje el importe real a cobrar.
     */
    private function lineasPromocion(int $idsucursal, int $idpromocion, int $cantidad, int $idpedido): array
    {
        $promo = Promocion::where('activo', true)
            ->where('fechainicio', '<=', now())
            ->where('fechafin', '>=', now())
            ->whereHas('sucursalesProducto', fn ($query) => $query->where('idsucursal', $idsucursal))
            ->find($idpromocion);

        if (! $promo) {
            throw ValidationException::withMessages(['promos' => 'La promoción elegida ya no está vigente.']);
        }

        $productos = DB::table('promocion_sucursal_producto')
            ->join('sucursal_producto', 'sucursal_producto.id', '=', 'promocion_sucursal_producto.idsucursalproducto')
            ->where('promocion_sucursal_producto.idpromocion', $promo->id)
            ->where('sucursal_producto.idsucursal', $idsucursal)
            ->where('sucursal_producto.disponibilidad', true)
            ->get(['sucursal_producto.precioproducto', 'promocion_sucursal_producto.cantidad_producto']);

        if ($productos->isEmpty()) {
            throw ValidationException::withMessages(['promos' => "La promoción {$promo->nombre} no tiene productos disponibles en esta sucursal."]);
        }

        $baseUnitaria = $productos->sum(fn ($fila) => round((float) $fila->cantidad_producto * (float) $fila->precioproducto, 2));

        if ($promo->tipodescuento === 'PORCENTAJE') {
            $descuentoUnitario = round($baseUnitaria * ((float) $promo->valordescuento / 100), 2);
        } else {
            $descuentoUnitario = min(round((float) $promo->valordescuento, 2), $baseUnitaria);
        }

        $precioUnitario = round($baseUnitaria - $descuentoUnitario, 2);
        $subtotal = round($precioUnitario * $cantidad, 2);

        DetallePedido::create([
            'cantidad' => $cantidad,
            'preciounitario' => $precioUnitario,
            'subtotal' => $subtotal,
            'descuento' => 0,
            'total' => $subtotal,
            'idpedido' => $idpedido,
            'idproductosucursal' => null,
            'idpromocion' => $promo->id,
        ]);

        return ['subtotal' => $subtotal];
    }

    /**
     * Simula la pasarela de pago según el gateway del método elegido.
     * Efectivo: pide monto recibido y calcula el cambio.
     * Tarjeta: valida últimos 4 dígitos y marca; devuelve autorización y transacción.
     * Banco: valida la referencia de la transferencia.
     */
    private function simularPasarela(?string $gateway, float $total, array $validated): array
    {
        $gateway = strtoupper($gateway ?: 'EFECTIVO');

        $referencia = trim((string) ($validated['referencia'] ?? ''));
        $ultimos4 = trim((string) ($validated['ultimos4'] ?? ''));
        $marca = trim((string) ($validated['marcatarjeta'] ?? ''));
        $recibido = ! empty($validated['montorecibido'])
            ? $this->aNumero($validated['montorecibido'])
            : $total;

        return match ($gateway) {
            'TARJETA' => tap([
                'montorecibido' => 0.0,
                'cambioentregado' => 0.0,
                'referenciaexterna' => null,
                'ultimos4' => null,
                'marcatarjeta' => null,
                'observacionpago' => 'Pago con tarjeta (pasarela simulada)',
            ], function (&$dato) use ($ultimos4, $marca) {
                if (mb_strlen($ultimos4) !== 4 || $marca === '') {
                    abort(422, 'La pasarela rechazó el pago: se requieren los últimos 4 dígitos y la marca de la tarjeta.');
                }
                $dato['codigoautorizacion'] = strtoupper('PA-'.Str::random(8));
                $dato['idtransaccion'] = strtoupper('TX-'.Str::random(14));
                $dato['ultimos4'] = $ultimos4;
                $dato['marcatarjeta'] = $marca;
            }),
            'BANCO' => tap([
                'montorecibido' => 0.0,
                'cambioentregado' => 0.0,
                'ultimos4' => null,
                'marcatarjeta' => null,
            ], function (&$dato) use ($referencia) {
                if ($referencia === '') {
                    abort(422, 'La pasarela rechazó el pago: se requiere la referencia de la transferencia.');
                }
                $dato['codigoautorizacion'] = strtoupper('BA-'.Str::random(8));
                $dato['idtransaccion'] = strtoupper('TRX-'.Str::random(14));
                $dato['referenciaexterna'] = $referencia;
                $dato['observacionpago'] = 'Transferencia bancaria (pasarela simulada)';
            }),
            default => tap([
                'montorecibido' => $recibido,
                'cambioentregado' => round($recibido - $total, 2),
                'referenciaexterna' => null,
                'ultimos4' => null,
                'marcatarjeta' => null,
                'observacionpago' => 'Pago en efectivo',
            ], function (&$dato) use ($recibido, $total) {
                if ($recibido < $total) {
                    abort(422, 'El efectivo recibido es menor que el total a pagar.');
                }
                $dato['codigoautorizacion'] = null;
                $dato['idtransaccion'] = null;
            }),
        };
    }

    // ============================================================================
    // Helpers de acceso
    // ============================================================================

    private function sucursalesPermitidas(Empleado $empleado): Collection
    {
        $claverol = $empleado->rol?->claverol;

        if ($claverol === 'ADMINISTRADOR') {
            return Sucursal::orderBy('nombre')->get();
        }

        if ($claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->orderBy('nombre')
                ->get();
        }

        return $empleado->idsucursal
            ? Sucursal::where('id', $empleado->idsucursal)->get()
            : collect();
    }

    private function sucursalActualPermitida(Empleado $empleado, mixed $idsucursal): Sucursal
    {
        $sucursales = $this->sucursalesPermitidas($empleado);

        $sucursal = $sucursales->firstWhere('id', (int) $idsucursal)
            ?? $sucursales->first();

        abort_unless($sucursal, 403, 'No tienes acceso a esa sucursal.');

        return $sucursal;
    }

    private function pedidoPermitido(Empleado $empleado, int $idpedido): Pedido
    {
        $ids = $this->sucursalesPermitidas($empleado)->pluck('id');

        $pedido = Pedido::with('venta')->where('id', $idpedido)
            ->whereIn('idsucursal', $ids)
            ->first();

        abort_unless($pedido, 403, 'Ese pedido no pertenece a una sucursal que puedas operar.');

        return $pedido;
    }

    private function productoDisponible(int $idsucursal, int $idproductosucursal): SucursalProducto
    {
        $sp = SucursalProducto::with('producto')
            ->where('idsucursal', $idsucursal)
            ->find($idproductosucursal);

        abort_unless($sp?->disponibilidad && $sp->producto?->estado, 422, 'Un producto del pedido no está disponible en esta sucursal.');

        return $sp;
    }

    /**
     * Apertura de caja abierta más reciente de la sucursal (o null si no hay).
     */
    private function aperturaActivaDeSucursal(Sucursal $sucursal): ?AperturaCaja
    {
        return AperturaCaja::where('estado', 'ABIERTA')
            ->whereHas('caja', fn ($query) => $query->where('idsucursal', $sucursal->id))
            ->latest('id')
            ->first();
    }

    /**
     * Exige una apertura de caja abierta para operar el POS (todos los roles).
     */
    private function requerirAperturaActiva(Sucursal $sucursal): AperturaCaja
    {
        $apertura = $this->aperturaActivaDeSucursal($sucursal);

        abort_unless($apertura, 422, 'No hay una apertura de caja abierta en la sucursal; no puedes registrar pedidos.');

        return $apertura;
    }

    /**
     * Mesero y cajero solo operan con una apertura de caja abierta en la sucursal.
     */
    private function exigirCajaAbierta(Empleado $empleado, Sucursal $sucursal): void
    {
        if (! in_array($empleado->rol?->claverol, ['MESERO', 'CAJERO'], true)) {
            return;
        }

        $abierta = AperturaCaja::where('estado', 'ABIERTA')
            ->whereHas('caja', fn ($query) => $query->where('idsucursal', $sucursal->id))
            ->exists();

        abort_unless($abierta, 403, 'No hay una apertura de caja abierta en la sucursal.');
    }

    private function codigos(Empleado $empleado): Collection
    {
        return $empleado->rol?->permisos
            ? $empleado->rol->permisos->where('estado', true)->pluck('codigo')
            : collect();
    }

    /**
     * Pedidos de la jornada de caja actual (cada apertura reinicia nropedido).
     */
    private function pedidosDelDia(int $idaperturacaja): Collection
    {
        return Pedido::with('empleado', 'mesa', 'detalles.sucursalProducto.producto', 'venta.pagos.metodoPago')
            ->where('idaperturacaja', $idaperturacaja)
            ->orderByDesc('id')
            ->limit(80)
            ->get();
    }

    /**
     * Respuesta JSON para el POS (fetch) o redirección clásica con mensaje.
     */
    private function respuesta(Request $request, string $mensaje, array $parametros = []): RedirectResponse|JsonResponse
    {
        if ($request->expectsJson()) {
            return response()->json([
                'message' => $mensaje,
                'redirect' => route('dashboard.generar-pedidos.index', $parametros),
            ]);
        }

        return back()->with('exito', $mensaje);
    }

    private function aNumero(mixed $valor): float
    {
        return round((float) str_replace(',', '.', (string) $valor), 2);
    }
}
