@extends('layouts.app')

@section('title', 'Mantenimiento · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="d-flex align-items-center justify-content-center p-4" style="min-height: 70vh;">
        <div class="text-center">
            <div class="display-1 mb-3">🛠️</div>
            <h1 class="display-6 fw-bold mb-3">Página en mantenimiento</h1>
            <p class="lead text-muted mx-auto" style="max-width: 34rem;">
                {{ $mensajeMantenimiento ?? 'Estamos realizando mejoras en la página. Volveremos muy pronto.' }}
            </p>
            <p class="small text-muted">Inténtalo nuevamente en unos minutos.</p>
        </div>
    </div>
@endsection