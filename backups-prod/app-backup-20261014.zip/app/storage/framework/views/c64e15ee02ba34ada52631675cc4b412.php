<?php $__env->startSection('title', 'Menú de productos · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Menú de productos 🍔</h1>
                <p class="text-muted mb-0">Administra las categorías y los productos que se muestran en el menú.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <button class="btn btn-outline-brand" data-bs-toggle="modal" data-bs-target="#crearCategoriaModal">
                    + Nueva categoría
                </button>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearProductoModal"
                        <?php if(!$categorias->where('estado', true)->count()): ?> disabled title="Primero crea una categoría" <?php endif; ?>>
                    + Nuevo producto
                </button>
            </div>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <p class="small text-muted mb-3">
            Aquí administras el menú que ven tus clientes: las <strong>categorías</strong> y los <strong>productos</strong>.
            Con «+ Nueva categoría» creas una (ej. HAMBURGUESAS) y con «+ Nuevo producto» agregas un producto a la
            categoría activa. Dentro de cada tarjeta, «Editar» cambia nombre, descripción o foto, y «Dar de baja/alta»
            activa o desactiva el producto. En una categoría, «Editar categoría» la renombra y «Dar de baja» la desactiva
            junto a todos sus productos. Usa el buscador para filtrar por nombre los productos de la categoría actual.
        </p>

        <div class="row g-4">
            
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto h-100">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Categorías</span>
                        <span class="badge text-bg-dark"><?php echo e($categorias->count()); ?></span>
                    </div>
                    <div class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center gap-2
                                        <?php echo e($categoriaActual?->id === $categoria->id ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('dashboard.menu.index', ['idcategoria' => $categoria->id])); ?>"
                                   class="d-flex justify-content-between align-items-center gap-2 flex-grow-1 text-decoration-none overflow-hidden <?php echo e($categoriaActual?->id === $categoria->id ? 'text-white' : 'text-reset'); ?>">
                                    <span class="d-flex align-items-center gap-2 text-truncate">
                                        <span class="fw-semibold text-truncate"><?php echo e($categoria->nombre); ?></span>
                                        <?php if(!$categoria->estado): ?>
                                            <span class="badge rounded-pill <?php echo e($categoriaActual?->id === $categoria->id ? 'text-bg-light' : 'text-bg-secondary'); ?>">Inactiva</span>
                                        <?php endif; ?>
                                    </span>
                                    <span class="badge rounded-pill <?php echo e($categoriaActual?->id === $categoria->id ? 'text-bg-light' : 'text-bg-brand'); ?>">
                                        <?php echo e($categoria->productos_count); ?> prod.
                                    </span>
                                </a>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="list-group-item text-center text-muted py-4">
                                No hay categorías registradas. Crea una desde el botón "Nueva categoría".
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div class="col-12 col-lg-8">
                <div class="card tarjeta-producto">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span class="fw-bold">
                            <?php if($categoriaActual): ?>
                                Productos · <?php echo e($categoriaActual->nombre); ?>

                            <?php else: ?>
                                Productos
                            <?php endif; ?>
                        </span>
                        <?php if($categoriaActual): ?>
                            <div class="d-flex gap-2 flex-wrap">
                                <button class="btn btn-sm btn-outline-brand" data-bs-toggle="modal" data-bs-target="#editarCategoriaModal"
                                        data-id="<?php echo e($categoriaActual->id); ?>"
                                        data-nombre="<?php echo e($categoriaActual->nombre); ?>">
                                    Editar categoría
                                </button>
                                <?php if($categoriaActual->estado): ?>
                                    <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal"
                                            data-bs-target="#modal-confirmar-baja"
                                            data-accion="<?php echo e(route('dashboard.menu.categoria.baja', $categoriaActual)); ?>"
                                            data-mensaje="¿Dar de baja la categoría <?php echo e($categoriaActual->nombre); ?>?<?php echo e($categoriaActual->productos_count ? ' Quedará inactiva junto a sus '.$categoriaActual->productos_count.' productos.' : ''); ?>">
                                        Dar de baja
                                    </button>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('dashboard.menu.categoria.reactivar', $categoriaActual)); ?>" class="d-inline m-0">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="card-body">
                        <?php if(! $categoriaActual): ?>
                            <div class="text-center text-muted py-4">
                                Selecciona una categoría para ver sus productos.
                            </div>
                        <?php else: ?>
                            <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                                <div class="input-group" style="max-width: 360px;">
                                    <span class="input-group-text bg-white">🔍</span>
                                    <input type="search" id="buscadorProductos" class="form-control"
                                           placeholder="Buscar producto por nombre…"
                                           aria-label="Buscar producto por nombre" autocomplete="off">
                                </div>
                                <span class="small text-muted" id="contadorProductos"></span>
                            </div>

                            <div id="contenedorProductos">
                                <?php echo $__env->make('admin.menu._productos', ['productos' => $productos], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if($productos instanceof \Illuminate\Pagination\LengthAwarePaginator && $productos->hasPages()): ?>
                        <div class="card-footer bg-light-subtle border-top py-3" id="piePaginacion">
                            <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-muted">
                                <span>
                                    Mostrando <?php echo e($productos->firstItem()); ?>–<?php echo e($productos->lastItem()); ?>

                                    de <?php echo e($productos->total()); ?> productos
                                </span>
                                <nav aria-label="Paginación de productos">
                                    <?php echo e($productos->onEachSide(1)->links()); ?>

                                </nav>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="crearCategoriaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.menu.categoria.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nueva categoría</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <label class="form-label">Nombre *</label>
                        <input type="text" name="nombre" class="form-control" required maxlength="255" autofocus>
                        <div class="form-text">Ej.: HAMBURGUESAS, POSTRES, BEBIDAS. Las categorías agrupan los productos del menú.</div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear categoría</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarCategoriaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-categoria">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar categoría</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <label class="form-label">Nombre *</label>
                        <input type="text" name="nombre" id="editarCategoriaNombre" class="form-control" required maxlength="255">
                        <div class="form-text">Cambia el nombre o renombra la categoría. Los productos se mantienen.</div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="crearProductoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.menu.producto.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nuevo producto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="255">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Categoría *</label>
                                <select name="idcategoria" class="form-select" required>
                                    <?php $__currentLoopData = $categorias->where('estado', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id); ?>" <?php if($categoriaActual?->id === $categoria->id): echo 'selected'; endif; ?>>
                                            <?php echo e($categoria->nombre); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Foto del producto <span class="text-muted small">(opcional)</span></label>
                                <div class="btn-group w-100 mb-2" role="group" aria-label="Origen de la foto">
                                    <input type="radio" class="btn-check" name="origenFotoCrear"
                                           id="origenFotoCrearSubir" value="subir" checked>
                                    <label class="btn btn-outline-brand" for="origenFotoCrearSubir">Subir archivo</label>
                                    <input type="radio" class="btn-check" name="origenFotoCrear"
                                           id="origenFotoCrearUrl" value="url">
                                    <label class="btn btn-outline-brand" for="origenFotoCrearUrl">URL de imagen</label>
                                </div>

                                <div id="camposSubirCrear">
                                    <input type="file" name="photo" id="crearProductoFoto" class="form-control" accept="image/*">
                                    <div class="form-text">Elige una imagen desde tu equipo.</div>
                                </div>

                                <div id="camposUrlCrear" class="d-none">
                                    <input type="url" name="photo_url" id="crearProductoUrl" class="form-control"
                                           placeholder="https://ejemplo.com/imagen.jpg">
                                    <div class="form-text">Se descargará y guardará la imagen al registrar el producto.</div>
                                </div>

                                <div class="foto-preview-wrap mt-3">
                                    <span class="foto-preview-placeholder" id="crearPreviewPlaceholder">🖼️ Vista previa de la imagen</span>
                                    <img id="crearProductoVistaPrevia" class="foto-preview-img" alt="Vista previa de la imagen">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear producto</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarProductoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-producto" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar producto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" id="editarProductoNombre" class="form-control" required maxlength="255">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Categoría *</label>
                                <select name="idcategoria" id="editarProductoCategoria" class="form-select" required>
                                    <?php $__currentLoopData = $categorias->where('estado', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" id="editarProductoDescripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Foto actual</label>
                                        <div class="foto-actual-wrap">
                                            <img id="editarProductoVistaPrevia" class="foto-actual-img" src="" alt="Foto actual">
                                            <span class="foto-actual-sin" id="editarFotoActualSin">Sin foto</span>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Cambiar foto <span class="text-muted small">(opcional)</span></label>
                                        <div class="btn-group w-100 mb-2" role="group" aria-label="Origen de la foto">
                                            <input type="radio" class="btn-check" name="origenFotoEditar"
                                                   id="origenFotoEditarSubir" value="subir" checked>
                                            <label class="btn btn-outline-brand" for="origenFotoEditarSubir">Subir archivo</label>
                                            <input type="radio" class="btn-check" name="origenFotoEditar"
                                                   id="origenFotoEditarUrl" value="url">
                                            <label class="btn btn-outline-brand" for="origenFotoEditarUrl">URL de imagen</label>
                                        </div>

                                        <div id="camposSubirEditar">
                                            <input type="file" name="photo" id="editarProductoFoto" class="form-control" accept="image/*">
                                        </div>

                                        <div id="camposUrlEditar" class="d-none">
                                            <input type="url" name="photo_url" id="editarProductoUrl" class="form-control"
                                                   placeholder="https://ejemplo.com/imagen.jpg">
                                            <div class="form-text">Se descargará y guardará la imagen al guardar los cambios.</div>
                                        </div>

                                        <div class="foto-preview-wrap mt-3">
                                            <span class="foto-preview-placeholder" id="editarPreviewPlaceholder">🖼️ Vista previa de la imagen que vas a usar</span>
                                            <img id="editarProductoVistaNueva" class="foto-preview-img" alt="Vista previa de la imagen">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-confirmar-baja" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-confirmar-baja" class="modal-content">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h2 class="modal-title fs-5">⚠️ Confirmar baja</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0" id="texto-confirmar-baja"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">🗑️ Confirmar baja</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const elementosFoto = {
            crear: {
                archivo: document.getElementById('crearProductoFoto'),
                url: document.getElementById('crearProductoUrl'),
                preview: document.getElementById('crearProductoVistaPrevia'),
                placeholder: document.getElementById('crearPreviewPlaceholder'),
                grupoSubir: document.getElementById('camposSubirCrear'),
                grupoUrl: document.getElementById('camposUrlCrear'),
                radioSubir: document.getElementById('origenFotoCrearSubir'),
                radioUrl: document.getElementById('origenFotoCrearUrl'),
            },
            editar: {
                archivo: document.getElementById('editarProductoFoto'),
                url: document.getElementById('editarProductoUrl'),
                preview: document.getElementById('editarProductoVistaNueva'),
                placeholder: document.getElementById('editarPreviewPlaceholder'),
                grupoSubir: document.getElementById('camposSubirEditar'),
                grupoUrl: document.getElementById('camposUrlEditar'),
                radioSubir: document.getElementById('origenFotoEditarSubir'),
                radioUrl: document.getElementById('origenFotoEditarUrl'),
            },
        };

        function alternarModoFoto(modo) {
            const grupo = elementosFoto[modo];
            const esUrl = grupo.radioUrl.checked;
            grupo.grupoSubir.classList.toggle('d-none', esUrl);
            grupo.grupoUrl.classList.toggle('d-none', !esUrl);
        }

        function mostrarPreview(grupo, fuente) {
            if (fuente) {
                grupo.preview.src = fuente;
                grupo.preview.style.display = 'block';
                grupo.placeholder.style.display = 'none';
            } else {
                if (grupo.preview.src && grupo.preview.src.startsWith('blob:')) {
                    URL.revokeObjectURL(grupo.preview.src);
                }
                grupo.preview.removeAttribute('src');
                grupo.preview.style.display = 'none';
                grupo.placeholder.style.display = '';
            }
        }

        function alElegirArchivo(grupo) {
            const archivo = grupo.archivo.files && grupo.archivo.files[0];
            if (!archivo || !archivo.type.startsWith('image/')) {
                mostrarPreview(grupo, '');
                return;
            }
            mostrarPreview(grupo, URL.createObjectURL(archivo));
        }

        function limpiarFoto(grupo) {
            grupo.archivo.value = '';
            grupo.url.value = '';
            grupo.radioSubir.checked = true;
            alternarModoFoto(grupo.nombre);
            mostrarPreview(grupo, '');
        }

        ['crear', 'editar'].forEach(function (nombre) {
            const grupo = elementosFoto[nombre];
            grupo.nombre = nombre;
            grupo.radioSubir.addEventListener('change', () => alternarModoFoto(nombre));
            grupo.radioUrl.addEventListener('change', () => alternarModoFoto(nombre));
            grupo.archivo.addEventListener('change', () => {
                alElegirArchivo(grupo);
                if (grupo.url.value.trim() !== '') {
                    grupo.url.value = '';
                }
            });
            grupo.url.addEventListener('input', () => {
                mostrarPreview(grupo, grupo.url.value.trim());
                if (grupo.archivo.value) {
                    grupo.archivo.value = '';
                }
            });
        });

        const modalEditarProducto = document.getElementById('editarProductoModal');
        modalEditarProducto.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarProductoNombre').value = boton.dataset.nombre;
            document.getElementById('editarProductoDescripcion').value = boton.dataset.descripcion || '';
            document.getElementById('editarProductoCategoria').value = boton.dataset.idcategoria;
            document.getElementById('form-editar-producto').setAttribute(
                'action', '<?php echo e(route("dashboard.menu.producto.update", ["producto" => "__ID__"])); ?>'.replace('__ID__', boton.dataset.id)
            );

            const fotoActual = document.getElementById('editarProductoVistaPrevia');
            const sinFoto = document.getElementById('editarFotoActualSin');
            if (boton.dataset.tieneFoto === '1' && boton.dataset.urlFoto) {
                fotoActual.src = boton.dataset.urlFoto;
                fotoActual.style.display = 'block';
                sinFoto.style.display = 'none';
            } else {
                fotoActual.removeAttribute('src');
                fotoActual.style.display = 'none';
                sinFoto.style.display = '';
            }

            limpiarFoto(elementosFoto.editar);
        });

        const modalCrearProducto = document.getElementById('crearProductoModal');
        modalCrearProducto.addEventListener('show.bs.modal', function () {
            limpiarFoto(elementosFoto.crear);
        });

        const modalEditarCategoria = document.getElementById('editarCategoriaModal');
        modalEditarCategoria.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;
            if (!boton) return;

            document.getElementById('editarCategoriaNombre').value = boton.dataset.nombre;
            document.getElementById('form-editar-categoria').setAttribute(
                'action', '<?php echo e(route("dashboard.menu.categoria.update", ["categoria" => "__ID__"])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalBaja = document.getElementById('modal-confirmar-baja');
        if (modalBaja) {
            modalBaja.addEventListener('show.bs.modal', function (evento) {
                const disparador = evento.relatedTarget;
                if (!disparador) return;
                document.getElementById('form-confirmar-baja')
                    .setAttribute('action', disparador.getAttribute('data-accion'));
                document.getElementById('texto-confirmar-baja').textContent =
                    disparador.getAttribute('data-mensaje') || '¿Confirmas realizar esta acción?';
            });
        }

        (function () {
            const buscador = document.getElementById('buscadorProductos');
            if (!buscador) return;

            const contenedor = document.getElementById('contenedorProductos');
            const contador = document.getElementById('contadorProductos');
            const piePaginacion = document.getElementById('piePaginacion');
            const htmlInicial = contenedor.innerHTML;
            const urlBuscar = '<?php echo e(route('dashboard.menu.buscar')); ?>';
            const idCategoria = <?php echo e($categoriaActual?->id ?? 0); ?>;
            let temporizador = null;
            let abortador = null;

            function restaurarVista(limpiarCampo = true) {
                contenedor.innerHTML = htmlInicial;
                contador.textContent = '';
                if (piePaginacion) piePaginacion.style.display = '';
                if (limpiarCampo) buscador.value = '';
            }

            buscador.addEventListener('input', function () {
                clearTimeout(temporizador);
                const q = buscador.value.trim();

                if (q === '') {
                    restaurarVista(false);
                    return;
                }

                temporizador = setTimeout(function () {
                    if (abortador) abortador.abort();
                    abortador = new AbortController();

                    const url = urlBuscar + '?idcategoria=' + encodeURIComponent(idCategoria) + '&q=' + encodeURIComponent(q);

                    fetch(url, { signal: abortador.signal })
                        .then(function (respuesta) {
                            if (!respuesta.ok) throw new Error('Error de red');
                            return respuesta.json();
                        })
                        .then(function (datos) {
                            contenedor.innerHTML = datos.html;
                            contador.textContent = datos.total + ' resultado' + (datos.total === 1 ? '' : 's');
                            if (piePaginacion) piePaginacion.style.display = 'none';
                        })
                        .catch(function (error) {
                            if (error.name === 'AbortError') return;
                            contador.textContent = 'No se pudo realizar la búsqueda.';
                        });
                }, 250);
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .foto-preview-wrap {
            border: 2px dashed #cfd4da;
            border-radius: .9rem;
            background: #f8f9fa;
            min-height: 220px;
            max-height: 320px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            padding: .75rem;
        }

        .foto-preview-placeholder {
            color: #9aa4af;
            font-size: .95rem;
            text-align: center;
        }

        .foto-preview-img {
            max-width: 100%;
            max-height: 290px;
            object-fit: contain;
            border-radius: .5rem;
            box-shadow: 0 8px 24px rgba(0, 0, 0, .14);
            display: none;
        }

        .foto-actual-wrap {
            border: 1px solid #e3e7eb;
            border-radius: .75rem;
            padding: .5rem;
            min-height: 96px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
        }

        .foto-actual-img {
            max-width: 100%;
            max-height: 140px;
            object-fit: contain;
            border-radius: .5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, .1);
            display: none;
        }

        .foto-actual-sin {
            color: #adb5bd;
            font-size: .9rem;
        }

        .tarjeta-producto-menu {
            transition: transform .15s ease, box-shadow .15s ease;
        }

        .tarjeta-producto-menu:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(0, 0, 0, .1);
        }

        .list-group-item.active .text-bg-brand {
            color: var(--bs-card-bg);
            background-color: #fff;
        }

        .text-bg-brand {
            background-color: #dc3545;
            color: #fff;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/menu/index.blade.php ENDPATH**/ ?>