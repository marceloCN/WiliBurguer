<?php $__env->startSection('title', 'Insumos y recetas · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Insumos y recetas 📦</h1>
                <p class="text-muted mb-0">Administra unidades de medida, insumos y la receta de cada producto.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <button class="btn btn-outline-brand" data-bs-toggle="modal" data-bs-target="#crearUnidadModal">
                    + Nueva unidad
                </button>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearInsumoModal"
                        <?php if(!$unidades->where('estado', true)->count()): ?> disabled title="Primero crea una unidad de medida" <?php endif; ?>>
                    + Nuevo insumo
                </button>
            </div>
        </div>

        <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'insumos' ? 'active fw-bold' : 'text-reset'); ?>"
                   href="<?php echo e(route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $idunidadmedida])); ?>">
                    📦 Insumos
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e($tab === 'recetas' ? 'active fw-bold' : 'text-reset'); ?>"
                   href="<?php echo e(route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $idproducto])); ?>">
                    🍔 Recetas por producto
                </a>
            </li>
        </ul>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($tab === 'recetas'): ?>
            
            <p class="small text-muted mb-3">
                Aquí defines de qué está hecho cada producto: agrega los <strong>insumos</strong> que se necesitan para prepararlo
                (los mismos registrados en la pestaña «📦 Insumos») y la <strong>cantidad</strong> de cada uno según su unidad de medida.
            </p>
            <div class="row g-4">
                
                <div class="col-12 col-lg-4">
                    <div class="card tarjeta-producto h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Productos</span>
                            <span class="badge text-bg-dark"><?php echo e($productos->count()); ?></span>
                        </div>
                        <div class="accordion accordion-flush" id="acordeonCategoriasReceta">
                            <?php $__empty_1 = true; $__currentLoopData = $productosAgrupados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriaNombre => $productosCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $itemId = 'acc-rec-' . $loop->index;
                                    $expandida = $productosCategoria->contains(
                                        fn (App\Models\Producto $p) => $p->id === $productoActual?->id,
                                    );
                                ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button py-3 <?php echo e($expandida ? '' : 'collapsed'); ?>"
                                                type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#<?php echo e($itemId); ?>"
                                                aria-expanded="<?php echo e($expandida ? 'true' : 'false'); ?>"
                                                aria-controls="<?php echo e($itemId); ?>">
                                            <span class="fw-semibold text-uppercase small"><?php echo e($categoriaNombre); ?></span>
                                            <span class="badge text-bg-secondary ms-2"><?php echo e($productosCategoria->count()); ?></span>
                                        </button>
                                    </h2>
                                    <div id="<?php echo e($itemId); ?>"
                                         class="accordion-collapse collapse <?php echo e($expandida ? 'show' : ''); ?>"
                                         data-bs-parent="#acordeonCategoriasReceta">
                                        <div class="accordion-body p-0">
                                            <div class="list-group list-group-flush">
                                                <?php $__currentLoopData = $productosCategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="list-group-item d-flex justify-content-between align-items-center gap-2
                                                                <?php echo e($productoActual?->id === $producto->id ? 'active' : ''); ?>">
                                                        <a href="<?php echo e(route('dashboard.insumos.index', ['tab' => 'recetas', 'idproducto' => $producto->id])); ?>"
                                                           class="d-flex justify-content-between align-items-center gap-2 flex-grow-1 text-decoration-none overflow-hidden <?php echo e($productoActual?->id === $producto->id ? 'text-white' : 'text-reset'); ?>">
                                                            <span class="d-flex align-items-center gap-2 text-truncate">
                                                                <span class="fw-semibold text-truncate"><?php echo e($producto->nombre); ?></span>
                                                                <?php if(!$producto->estado): ?>
                                                                    <span class="badge rounded-pill <?php echo e($productoActual?->id === $producto->id ? 'text-bg-light' : 'text-bg-secondary'); ?>">Inactivo</span>
                                                                <?php endif; ?>
                                                            </span>
                                                            <span class="badge rounded-pill <?php echo e($productoActual?->id === $producto->id ? 'text-bg-light' : 'text-bg-brand'); ?>">
                                                                <?php echo e($producto->detalles_receta_count); ?> ing.
                                                            </span>
                                                        </a>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center text-muted py-4">
                                    No hay productos registrados. Créalos desde "Menú de productos".
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="col-12 col-lg-8">
                    <div class="card tarjeta-producto">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <?php if($productoActual): ?>
                                <span class="fw-bold">Receta · <?php echo e($productoActual->nombre); ?></span>
                                <div class="d-flex gap-2 flex-wrap align-items-center">
                                    <span class="badge text-bg-brand"><?php echo e($receta->count()); ?> insumo(s)</span>
                                    <button type="button" class="btn btn-sm btn-brand"
                                            data-bs-toggle="modal" data-bs-target="#crearRecetaModal"
                                            <?php if(! $insumosDisponibles->count()): ?> disabled title="Sin insumos disponibles para agregar" <?php endif; ?>>
                                        + Agregar insumo a la receta
                                    </button>
                                </div>
                            <?php else: ?>
                                <span class="fw-bold">Receta</span>
                            <?php endif; ?>
                        </div>

                        <?php if($productoActual): ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th>Insumo</th>
                                                <th>Unidad de medida</th>
                                                <th>Cantidad</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $receta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td>
                                                        <span class="fw-semibold"><?php echo e($detalle->insumo?->nombre); ?></span>
                                                        <br>
                                                        <span class="small text-muted"><?php echo e(\Illuminate\Support\Str::limit($detalle->insumo?->descripcion, 45)); ?></span>
                                                    </td>
                                                    <td>
                                                        <span class="badge text-bg-light border">
                                                            <?php echo e($detalle->insumo?->unidadMedida?->abreviatura ?? '—'); ?>

                                                        </span>
                                                        <span class="small text-muted ms-1"><?php echo e($detalle->insumo?->unidadMedida?->nombre); ?></span>
                                                    </td>
                                                    <td class="fw-semibold"><?php echo e(rtrim(rtrim(number_format($detalle->cantidad, 3, '.', ''), '0'), '.')); ?></td>
                                                    <td class="text-end">
                                                        <button class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editarCantidadModal"
                                                                data-id="<?php echo e($detalle->id); ?>"
                                                                data-insumo="<?php echo e($detalle->insumo?->nombre); ?>"
                                                                data-cantidad="<?php echo e(number_format($detalle->cantidad, 3, '.', '')); ?>">
                                                            Editar
                                                        </button>
                                                        <button class="btn btn-sm btn-outline-danger"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#modal-confirmar-baja"
                                                                data-accion="<?php echo e(route('dashboard.insumos.receta.baja', $detalle)); ?>"
                                                                data-mensaje="¿Quitar el insumo <?php echo e($detalle->insumo?->nombre); ?> de la receta de <?php echo e($productoActual->nombre); ?>?">
                                                            Quitar
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center py-4 text-muted">
                                                        Este producto aún no tiene receta. Pulsa "+ Agregar insumo a la receta".
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="card-body">
                                <div class="text-center text-muted py-4">Registra productos para poder armar sus recetas.</div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            
            <p class="small text-muted mb-3">
                Primero crea la <strong>unidad de medida</strong> (ej. gramos, litros, unidades): es la forma en que se cuenta cada ingrediente.
                Luego crea el <strong>insumo</strong> asignándole una de esas unidades. Con los insumos registrados podrás armar la receta de cada producto en la pestaña «🍔 Recetas por producto».
            </p>
            <div class="row g-4">
                
                <div class="col-12 col-lg-4">
                    <div class="card tarjeta-producto h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">Unidades de medida</span>
                            <span class="badge text-bg-dark"><?php echo e($unidades->count()); ?></span>
                        </div>
                        <div class="list-group">
                            <?php $__empty_1 = true; $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center gap-2
                                            <?php echo e($unidadActual?->id === $unidad->id ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('dashboard.insumos.index', ['tab' => 'insumos', 'idunidadmedida' => $unidad->id])); ?>"
                                       class="d-flex justify-content-between align-items-center gap-2 flex-grow-1 text-decoration-none overflow-hidden <?php echo e($unidadActual?->id === $unidad->id ? 'text-white' : 'text-reset'); ?>">
                                        <span class="d-flex align-items-center gap-2 text-truncate">
                                            <span class="fw-semibold text-truncate"><?php echo e($unidad->nombre); ?></span>
                                            <?php if(!$unidad->estado): ?>
                                                <span class="badge rounded-pill <?php echo e($unidadActual?->id === $unidad->id ? 'text-bg-light' : 'text-bg-secondary'); ?>">Inactiva</span>
                                            <?php endif; ?>
                                        </span>
                                        <span class="badge rounded-pill <?php echo e($unidadActual?->id === $unidad->id ? 'text-bg-light' : 'text-bg-brand'); ?>">
                                            <?php echo e($unidad->insumos_count); ?> ins.
                                        </span>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="list-group-item text-center text-muted py-4">
                                    No hay unidades registradas. Crea una desde "Nueva unidad".
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="col-12 col-lg-8">
                    <div class="card tarjeta-producto">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <span class="fw-bold">
                                <?php if($unidadActual): ?>
                                    Insumos · <?php echo e($unidadActual->nombre); ?> (<?php echo e($unidadActual->abreviatura); ?>)
                                <?php else: ?>
                                    Insumos
                                <?php endif; ?>
                            </span>
                            <?php if($unidadActual): ?>
                                <div class="d-flex gap-2 flex-wrap">
                                    <button class="btn btn-sm btn-outline-brand" data-bs-toggle="modal"
                                            data-bs-target="#editarUnidadModal"
                                            data-id="<?php echo e($unidadActual->id); ?>"
                                            data-nombre="<?php echo e($unidadActual->nombre); ?>"
                                            data-abreviatura="<?php echo e($unidadActual->abreviatura); ?>"
                                            data-tipo="<?php echo e($unidadActual->tipo); ?>">
                                        Editar unidad
                                    </button>
                                    <?php if($unidadActual->estado): ?>
                                        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal"
                                                data-bs-target="#modal-confirmar-baja"
                                                data-accion="<?php echo e(route('dashboard.insumos.unidad.baja', $unidadActual)); ?>"
                                                data-mensaje="¿Dar de baja la unidad <?php echo e($unidadActual->nombre); ?> (<?php echo e($unidadActual->abreviatura); ?>)?<?php echo e($unidadActual->insumos_count ? ' Está usada por '.$unidadActual->insumos_count.' insumos y no se podrá completar la baja.' : ''); ?>">
                                            Dar de baja
                                        </button>
                                    <?php else: ?>
                                        <form method="POST" action="<?php echo e(route('dashboard.insumos.unidad.reactivar', $unidadActual)); ?>" class="d-inline m-0">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="card-body">
                            <?php if(! $unidadActual): ?>
                                <div class="text-center text-muted py-4">
                                    Selecciona una unidad de medida para ver sus insumos.
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th>Insumo</th>
                                                <th>Descripción</th>
                                                <th>Unidad</th>
                                                <th>Estado</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="fw-semibold"><?php echo e($insumo->nombre); ?></td>
                                                    <td class="small text-muted">
                                                        <?php echo e(\Illuminate\Support\Str::limit($insumo->descripcion, 55)); ?>

                                                    </td>
                                                    <td>
                                                        <span class="badge text-bg-light border"><?php echo e($insumo->unidadMedida?->abreviatura); ?></span>
                                                    </td>
                                                    <td>
                                                        <?php if($insumo->estado): ?>
                                                            <span class="badge text-bg-success">Activo</span>
                                                        <?php else: ?>
                                                            <span class="badge text-bg-secondary">Inactivo</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="text-end">
                                                        <button class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editarInsumoModal"
                                                                data-id="<?php echo e($insumo->id); ?>"
                                                                data-nombre="<?php echo e($insumo->nombre); ?>"
                                                                data-descripcion="<?php echo e($insumo->descripcion); ?>"
                                                                data-idunidadmedida="<?php echo e($insumo->idunidadmedida); ?>">
                                                            Editar
                                                        </button>
                                                        <?php if($insumo->estado): ?>
                                                            <button class="btn btn-sm btn-outline-danger"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#modal-confirmar-baja"
                                                                    data-accion="<?php echo e(route('dashboard.insumos.baja', $insumo)); ?>"
                                                                    data-mensaje="¿Dar de baja el insumo <?php echo e($insumo->nombre); ?>?">
                                                                Dar de baja
                                                            </button>
                                                        <?php else: ?>
                                                            <form method="POST" action="<?php echo e(route('dashboard.insumos.reactivar', $insumo)); ?>" class="d-inline m-0">
                                                                <?php echo csrf_field(); ?>
                                                                <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center py-4 text-muted">
                                                        No hay insumos en esta unidad. Pulsa "+ Nuevo insumo".
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="modal fade" id="crearUnidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.insumos.unidad.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nueva unidad de medida</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="50" placeholder="Gramos">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Abreviatura *</label>
                                <input type="text" name="abreviatura" class="form-control" required maxlength="10"
                                       placeholder="gr" oninput="this.value=this.value.toUpperCase()">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo *</label>
                                <select name="tipo" class="form-select" required>
                                    <?php $__currentLoopData = \App\Http\Controllers\UnidadMedidaController::TIPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipo); ?>" <?php if(old('tipo') === $tipo): echo 'selected'; endif; ?>><?php echo e($tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear unidad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarUnidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-unidad">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar unidad de medida</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" id="editarUnidadNombre" class="form-control" required maxlength="50">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Abreviatura *</label>
                                <input type="text" name="abreviatura" id="editarUnidadAbreviatura" class="form-control"
                                       required maxlength="10" oninput="this.value=this.value.toUpperCase()">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo *</label>
                                <select name="tipo" id="editarUnidadTipo" class="form-select" required>
                                    <?php $__currentLoopData = \App\Http\Controllers\UnidadMedidaController::TIPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipo); ?>"><?php echo e($tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="crearInsumoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.insumos.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nuevo insumo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="100" autofocus>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Unidad de medida *</label>
                                <select name="idunidadmedida" class="form-select" required>
                                    <?php $__currentLoopData = $unidades->where('estado', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unidad->id); ?>" <?php if($unidadActual?->id === $unidad->id): echo 'selected'; endif; ?>>
                                            <?php echo e($unidad->nombre); ?> (<?php echo e($unidad->abreviatura); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear insumo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarInsumoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-insumo">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar insumo</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" id="editarInsumoNombre" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Descripción</label>
                                <textarea name="descripcion" id="editarInsumoDescripcion" rows="2" class="form-control"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Unidad de medida *</label>
                                <select name="idunidadmedida" id="editarInsumoUnidad" class="form-select" required>
                                    <?php $__currentLoopData = $unidades->where('estado', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unidad->id); ?>"><?php echo e($unidad->nombre); ?> (<?php echo e($unidad->abreviatura); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="crearRecetaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.insumos.receta.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if($productoActual): ?>
                        <input type="hidden" name="idproducto" value="<?php echo e($productoActual->id); ?>">
                    <?php endif; ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">
                            Agregar insumo a la receta
                            <?php if($productoActual): ?> — <?php echo e($productoActual->nombre); ?> <?php endif; ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Insumo *</label>
                                <select name="idinsumo" class="form-select" required>
                                    <?php $__currentLoopData = $insumosDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($insumo->id); ?>">
                                            <?php echo e($insumo->nombre); ?> (<?php echo e($insumo->unidadMedida?->abreviatura); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-text">Solo se muestran insumos activos que aún no están en esta receta.</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Cantidad *</label>
                                <input type="number" name="cantidad" class="form-control" required
                                       step="0.001" min="0.001" placeholder="Ej. 0.250">
                                <div class="form-text">La cantidad se expresa en la unidad de medida del insumo.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Agregar a la receta</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarCantidadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-cantidad">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Editar cantidad</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <label class="form-label" id="label-editar-cantidad">Cantidad *</label>
                        <input type="number" name="cantidad" id="editarCantidadValor" class="form-control" required
                               step="0.001" min="0.001">
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="modal-confirmar-baja" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-confirmar-baja" class="modal-content">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h2 class="modal-title fs-5">⚠️ Confirmar baja</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0" id="texto-confirmar-baja"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">🗑️ Confirmar baja</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const modalEditarUnidad = document.getElementById('editarUnidadModal');
        modalEditarUnidad.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarUnidadNombre').value = boton.dataset.nombre;
            document.getElementById('editarUnidadAbreviatura').value = boton.dataset.abreviatura;
            document.getElementById('editarUnidadTipo').value = boton.dataset.tipo;
            document.getElementById('form-editar-unidad').setAttribute(
                'action', '<?php echo e(route("dashboard.insumos.unidad.update", ["unidad" => "__ID__"])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalEditarInsumo = document.getElementById('editarInsumoModal');
        modalEditarInsumo.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarInsumoNombre').value = boton.dataset.nombre;
            document.getElementById('editarInsumoDescripcion').value = boton.dataset.descripcion || '';
            document.getElementById('editarInsumoUnidad').value = boton.dataset.idunidadmedida;
            document.getElementById('form-editar-insumo').setAttribute(
                'action', '<?php echo e(route("dashboard.insumos.update", ["insumo" => "__ID__"])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalEditarCantidad = document.getElementById('editarCantidadModal');
        modalEditarCantidad.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('label-editar-cantidad').textContent = 'Cantidad de ' + boton.dataset.insumo + ' *';
            document.getElementById('editarCantidadValor').value = boton.dataset.cantidad;
            document.getElementById('form-editar-cantidad').setAttribute(
                'action', '<?php echo e(route("dashboard.insumos.receta.update", ["detalle" => "__ID__"])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });

        const modalBaja = document.getElementById('modal-confirmar-baja');
        if (modalBaja) {
            modalBaja.addEventListener('show.bs.modal', function (evento) {
                const disparador = evento.relatedTarget;
                if (!disparador) return;
                document.getElementById('form-confirmar-baja')
                    .setAttribute('action', disparador.getAttribute('data-accion'));
                document.getElementById('texto-confirmar-baja').textContent =
                    disparador.getAttribute('data-mensaje') || '¿Confirmas realizar esta acción?';
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/insumos/index.blade.php ENDPATH**/ ?>