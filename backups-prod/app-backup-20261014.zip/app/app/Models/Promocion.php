<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

#[Fillable(['nombre', 'tipodescuento', 'valordescuento', 'fechainicio', 'fechafin', 'activo', 'photo'])]
class Promocion extends Model
{
    public $timestamps = false;

    protected $table = 'promocion';

    protected function casts(): array
    {
        return [
            'valordescuento' => 'decimal:2',
            'fechainicio' => 'datetime',
            'fechafin' => 'datetime',
            'activo' => 'boolean',
        ];
    }

    public function sucursalesProducto(): BelongsToMany
    {
        return $this->belongsToMany(SucursalProducto::class, 'promocion_sucursal_producto', 'idpromocion', 'idsucursalproducto')
            ->withPivot('cantidad_producto');
    }

    /**
     * Marca como inactivas (baja automática) las promociones activas cuya fecha
     * de fin ya pasó. Devuelve cuántas promociones fueron dadas de baja.
     */
    public static function marcarVencidas(): int
    {
        return static::query()
            ->where('activo', true)
            ->where('fechafin', '<', now())
            ->update(['activo' => false]);
    }
}
