@extends('layouts.app')

@section('title', 'Sucursales · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Sucursales</h1>
                <p class="text-muted mb-0">Administra los datos, gerentes y horarios de cada sucursal.</p>
            </div>
            @if (auth()->user()->empleado?->rol?->claverol === 'ADMINISTRADOR')
                <a href="{{ route('dashboard.sucursales.crear') }}" class="btn btn-brand">
                    + Nueva sucursal
                </a>
            @endif
        </div>

        @include('partials.mensajes')

        @if ($sucursales->isEmpty())
            <div class="alert alert-light">No tienes sucursales disponibles.</div>
        @else
            <div class="row g-3">
                @foreach ($sucursales as $sucursal)
                    <div class="col-12 col-md-6 col-xl-4">
                        <div class="card tarjeta-producto h-100">
                            <div id="mapa-sucursal-{{ $sucursal->id }}" class="sucursal-mapa"
                                     data-lat="{{ number_format((float) $sucursal->latitud, 6, '.', '') }}"
                                     data-lng="{{ number_format((float) $sucursal->longitud, 6, '.', '') }}"></div>
                            <div class="card-body d-flex flex-column">
                                <h2 class="h5 fw-bold mb-1">{{ $sucursal->nombre }}</h2>
                                <p class="small text-muted mb-1">📍 {{ $sucursal->direccion }}</p>
                                <p class="small text-muted mb-1">📞 {{ $sucursal->telefono }}</p>
                                <p class="small text-muted mb-3">
                                    🌐 {{ number_format((float) $sucursal->latitud, 6) }}, {{ number_format((float) $sucursal->longitud, 6) }}
                                    @if ($sucursal->gerente)
                                        · Gerente: {{ $sucursal->gerente->nombre }} {{ $sucursal->gerente->apellido }}
                                    @endif
                                </p>
                                <div class="mt-auto">
                                    <a href="{{ route('dashboard.sucursales.editar', $sucursal) }}" class="btn btn-brand btn-sm">
                                        Editar sucursal
                                    </a>
                                    <span class="small text-muted ms-1">
                                        {{ $sucursal->horarios->count() }} horario(s)
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
@endsection

@push('styles')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        .sucursal-mapa {
            height: 170px;
            border-radius: 1rem 1rem 0 0;
            background: #eee;
        }
    </style>
@endpush

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        document.querySelectorAll('[id^="mapa-sucursal-"]').forEach(function (contenedor) {
            const id = contenedor.id.replace('mapa-sucursal-', '');
            const lat = parseFloat(contenedor.dataset.lat);
            const lng = parseFloat(contenedor.dataset.lng);
            const mapa = L.map(contenedor.id, { scrollWheelZoom: false }).setView([lat, lng], 15);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(mapa);
            L.marker([lat, lng]).addTo(mapa);
        });
    </script>
@endpush