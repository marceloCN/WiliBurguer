<!DOCTYPE html>
<html lang="es" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', $configuracionSitio->get('SITIO_NOMBRE')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        :root {
            --brand: <?php echo e($configuracionSitio->get('TEMA_COLOR_PRIMARIO')); ?>;
            --brand-dark: <?php echo e($configuracionSitio->get('TEMA_COLOR_PRIMARIO_OSCURO')); ?>;
            --brand-bg: <?php echo e($configuracionSitio->get('TEMA_COLOR_FONDO')); ?>;
            --brand-ink: <?php echo e($configuracionSitio->get('TEMA_COLOR_TEXTO')); ?>;
            --brand-gold: <?php echo e($configuracionSitio->get('TEMA_COLOR_DETALLE')); ?>;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="d-flex flex-column h-100 overflow-hidden">
    <nav class="navbar navbar-expand-lg navbar-dark bg-brand shadow-sm flex-shrink-0">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('inicio')); ?>">
                <?php echo e($configuracionSitio->get('SITIO_NOMBRE')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                aria-controls="navbarMain" aria-expanded="false" aria-label="Abrir menú">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->empleado?->rol): ?>
                            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Panel</a></li>
                        <?php endif; ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="d-none d-lg-inline">👤</span>
                                <?php echo e(auth()->user()->empleado?->nombre ?? auth()->user()->usuario); ?>

                                <span
                                    class="badge text-bg-light ms-1"><?php echo e(auth()->user()->empleado?->rol?->claverol); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo e(route('dashboard.perfil.index')); ?>">Mi perfil</a>
                                </li>
                                <?php if(auth()->user()->empleado?->rol?->claverol === 'ADMINISTRADOR'): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('dashboard.configuracion.index')); ?>">⚙️
                                            configuración</a></li>
                                <?php endif; ?>
                                <?php if(auth()->user()->empleado?->rol?->claverol === 'GERENTE' || auth()->user()->empleado?->rol?->claverol === 'CAJERO'): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('dashboard', ['panel' => 1])); ?>">🗂️ Panel de
                                            administración</a></li>
                                <?php endif; ?>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger">Cerrar sesión</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('inicio')); ?>#menu">Menú</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('inicio')); ?>#promociones">Promociones</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('inicio')); ?>#sucursales">Sucursales y
                                horarios</a></li>
                        <li class="nav-item ms-lg-3">
                            <a class="btn btn-outline-light btn-sm" href="<?php echo e(route('login')); ?>">Iniciar sesión</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <main class="flex-fill overflow-auto" style="min-height: 0;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-dark text-white-50 py-3 flex-shrink-0">
        <div class="container text-center small">
            © <?php echo e(date('Y')); ?> <?php echo e($configuracionSitio->get('SITIO_NOMBRE')); ?>

        </div>
    </footer>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>