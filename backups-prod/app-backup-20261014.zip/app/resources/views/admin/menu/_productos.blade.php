{{-- Tarjetas de productos del menú. Requiere $productos y opcional $vacioMensaje. --}}
<div class="row g-3">
    @forelse ($productos as $producto)
        <div class="col-12 col-sm-6 col-xl-4">
            <div class="card h-100 tarjeta-producto-menu border">
                <div class="ratio ratio-4x3 bg-light-subtle overflow-hidden rounded-top">
                    @if ($producto->photo)
                        <img src="{{ asset('storage/'.$producto->photo) }}" alt="{{ $producto->nombre }}"
                             class="object-fit-cover w-100" loading="lazy">
                    @else
                        <div class="d-flex align-items-center justify-content-center text-muted small">
                            Sin foto
                        </div>
                    @endif
                </div>
                <div class="card-body pb-2">
                    <div class="d-flex justify-content-between align-items-start gap-2">
                        <h2 class="h6 fw-bold mb-1">{{ $producto->nombre }}</h2>
                        @if ($producto->estado)
                            <span class="badge text-bg-success">Activo</span>
                        @else
                            <span class="badge text-bg-secondary">Inactivo</span>
                        @endif
                    </div>
                    <p class="small text-muted mb-0">
                        {{ \Illuminate\Support\Str::limit($producto->descripcion, 80) }}
                    </p>
                </div>
                <div class="card-footer bg-transparent border-top-0 d-flex gap-2">
                    <button class="btn btn-sm btn-outline-brand flex-fill"
                            data-bs-toggle="modal"
                            data-bs-target="#editarProductoModal"
                            data-id="{{ $producto->id }}"
                            data-nombre="{{ $producto->nombre }}"
                            data-descripcion="{{ $producto->descripcion }}"
                            data-idcategoria="{{ $producto->idcategoria }}"
                            data-tiene-foto="{{ $producto->photo ? '1' : '0' }}"
                            data-url-foto="{{ $producto->photo ? asset('storage/'.$producto->photo) : '' }}">
                        Editar
                    </button>
                    @if ($producto->estado)
                        <button class="btn btn-sm btn-outline-danger"
                                data-bs-toggle="modal"
                                data-bs-target="#modal-confirmar-baja"
                                data-accion="{{ route('dashboard.menu.producto.baja', $producto) }}"
                                data-mensaje="¿Dar de baja el producto {{ $producto->nombre }}?">
                            Dar de baja
                        </button>
                    @else
                        <form method="POST" action="{{ route('dashboard.menu.producto.reactivar', $producto) }}" class="d-inline">
                            @csrf
                            <button class="btn btn-sm btn-outline-success">Dar de alta</button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="text-center text-muted py-4">
                {{ $vacioMensaje ?? 'No hay productos en esta categoría. Pulsa "+ Nuevo producto".' }}
            </div>
        </div>
    @endforelse
</div>