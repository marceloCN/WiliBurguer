<?php $__env->startSection('title', 'Administración de usuarios · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Administración de usuarios</h1>
                <p class="text-muted mb-0">Gestiona empleados y sus cuentas de acceso.</p>
            </div>
            <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearUsuarioModal">
                + Nuevo usuario
            </button>
        </div>

        <?php if(session('exito')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('exito')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>

        <?php if($sucursalGerente): ?>
            <div class="alert alert-info alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
                <span>🗺️</span>
                <span>
                    Estás gestionando la sucursal <strong><?php echo e($sucursalGerente->nombre); ?></strong>.
                    Solo puedes crear y administrar usuarios <strong>cajero o mesero</strong> de esta sucursal.
                </span>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Revisa los datos:</strong>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>

        <div class="card tarjeta-producto mb-3">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('dashboard.usuarios.index')); ?>" class="row g-2 align-items-end">
                    <div class="col-12 col-md-5">
                        <label for="busqueda" class="form-label small fw-bold">Buscar</label>
                        <div class="input-group">
                            <input type="text" name="busqueda" id="busqueda" class="form-control"
                                   placeholder="Nombre, apellido, usuario o correo…"
                                   value="<?php echo e($busqueda); ?>">
                            <button type="submit" class="btn btn-brand">Buscar</button>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <label for="idrol" class="form-label small fw-bold">Rol</label>
                        <select name="idrol" id="idrol" class="form-select">
                            <option value="">Todos</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rol->id); ?>" <?php if($idrol == $rol->id): echo 'selected'; endif; ?>><?php echo e($rol->nombrerol); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <label for="estado" class="form-label small fw-bold">Estado</label>
                        <select name="estado" id="estado" class="form-select">
                            <option value="">Todos</option>
                            <option value="1" <?php if($estado === '1'): echo 'selected'; endif; ?>>Activos</option>
                            <option value="0" <?php if($estado === '0'): echo 'selected'; endif; ?>>Inactivos</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-2 d-flex gap-2">
                        <?php if($busqueda || $idrol || $estado !== null && $estado !== ''): ?>
                            <a href="<?php echo e(route('dashboard.usuarios.index')); ?>" class="btn btn-outline-secondary">Limpiar</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card tarjeta-producto">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Empleado</th>
                            <th>Usuario / correo</th>
                            <th>Rol</th>
                            <th>Sucursal</th>
                            <th>Estado</th>
                            <th>Último acceso</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellido); ?></div>
                                    <div class="text-muted small"><?php echo e($empleado->telefono); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($empleado->cuentaUsuario?->usuario); ?></div>
                                    <div class="text-muted small"><?php echo e($empleado->cuentaUsuario?->correo); ?></div>
                                </td>
                                <td><span class="badge text-bg-dark"><?php echo e($empleado->rol?->nombrerol); ?></span></td>
                                <td class="small"><?php echo e($empleado->sucursal?->nombre ?? '—'); ?></td>
                                <td>
                                    <?php if(!$empleado->cuentaUsuario): ?>
                                        <span class="badge text-bg-secondary">Sin cuenta</span>
                                    <?php elseif($empleado->estado && !$empleado->cuentaUsuario->bloqueado): ?>
                                        <span class="badge text-bg-success">Activo</span>
                                    <?php elseif(!$empleado->estado): ?>
                                        <span class="badge text-bg-danger">Inactivo</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-warning">Bloqueado</span>
                                    <?php endif; ?>
                                </td>
                                <td class="small">
                                    <?php echo e($empleado->cuentaUsuario?->ultimoacceso?->format('d/m/Y H:i') ?? '—'); ?>

                                </td>
                                <td class="text-end">
                                    
                                    <?php if($empleado->cuentaUsuario): ?>
                                        
                                        <?php if($empleado->id !== auth()->user()->empleado->id): ?>
                                            <form method="POST" action="<?php echo e(route('dashboard.usuarios.estado', $empleado->cuentaUsuario)); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm <?php echo e($empleado->estado ? 'btn-outline-danger' : 'btn-outline-success'); ?>">
                                                    <?php echo e($empleado->estado ? 'Desactivar' : 'Activar'); ?>

                                                </button>
                                            </form>
                                            <button class="btn btn-sm btn-outline-brand" data-bs-toggle="modal" data-bs-target="#editarUsuarioModal"
                                                    data-usuario="<?php echo e($empleado->cuentaUsuario->usuario); ?>" data-correo="<?php echo e($empleado->cuentaUsuario->correo); ?>"
                                                    data-nombre="<?php echo e($empleado->nombre); ?>" data-apellido="<?php echo e($empleado->apellido); ?>"
                                                    data-telefono="<?php echo e($empleado->telefono); ?>" data-rol-actual="<?php echo e($empleado->rol?->id); ?>"
                                                    data-url-rol="<?php echo e(route('dashboard.usuarios.rol', $empleado->cuentaUsuario)); ?>"
                                                    data-url-password="<?php echo e(route('dashboard.usuarios.password', $empleado->cuentaUsuario)); ?>"
                                                    data-url-actualizar="<?php echo e(route('dashboard.usuarios.actualizar', $empleado->cuentaUsuario)); ?>">
                                                Editar
                                            </button>
                                        <?php else: ?>
                                            <span class="badge text-bg-light border">Tú</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted small">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">No hay empleados registrados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($empleados->hasPages()): ?>
                <div class="card-footer bg-light-subtle border-top py-3">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-muted">
                        <span>
                            Mostrando <?php echo e($empleados->firstItem()); ?>–<?php echo e($empleados->lastItem()); ?>

                            de <?php echo e($empleados->total()); ?> usuarios
                        </span>
                        <nav aria-label="Paginación de usuarios">
                            <?php echo e($empleados->onEachSide(1)->links()); ?>

                        </nav>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="modal fade" id="editarUsuarioModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small mb-3">
                        Empleado: <strong id="editarUsuarioNombre"></strong><br>
                        Usuario: <strong id="editarUsuarioUsuario"></strong>
                    </p>
                    <ul class="nav nav-tabs mb-3" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="tabDatosTab" data-bs-toggle="tab"
                                    data-bs-target="#tabDatos" type="button" role="tab" aria-controls="tabDatos"
                                    aria-selected="true">Datos</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="tabRolTab" data-bs-toggle="tab"
                                    data-bs-target="#tabRol" type="button" role="tab" aria-controls="tabRol"
                                    aria-selected="false">Rol</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="tabSeguridadTab" data-bs-toggle="tab"
                                    data-bs-target="#tabSeguridad" type="button" role="tab" aria-controls="tabSeguridad"
                                    aria-selected="false">Seguridad</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="editarUsuarioTabs">

                        <div class="tab-pane fade show active" id="tabDatos" role="tabpanel" aria-labelledby="tabDatosTab">
                            <form method="POST" id="actualizarDatosForm">
                                <?php echo csrf_field(); ?>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Nombre *</label>
                                        <input type="text" name="nombre" id="editarNombre" class="form-control" required maxlength="100">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Apellido *</label>
                                        <input type="text" name="apellido" id="editarApellido" class="form-control" required maxlength="100">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Teléfono</label>
                                        <input type="text" name="telefono" id="editarTelefono" class="form-control" maxlength="15">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Usuario *</label>
                                        <input type="text" name="usuario" id="editarUsuarioCampo" class="form-control" required maxlength="255">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label">Correo *</label>
                                        <input type="email" name="correo" id="editarCorreo" class="form-control" required maxlength="255">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-brand mt-3">Guardar datos</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="tabRol" role="tabpanel" aria-labelledby="tabRolTab">
                            <form method="POST" id="cambiarRolForm">
                                <?php echo csrf_field(); ?>
                                <label class="form-label">Nuevo rol *</label>
                                <select name="idrol" id="cambiarRolSelect" class="form-select" required>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->nombrerol); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-brand mt-3">Guardar rol</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="tabSeguridad" role="tabpanel" aria-labelledby="tabSeguridadTab">
                            <form method="POST" id="resetPassForm">
                                <?php echo csrf_field(); ?>
                                <label class="form-label">Nueva contraseña *</label>
                                <input type="password" name="password" class="form-control" required minlength="6">
                                <button type="submit" class="btn btn-brand mt-3">Guardar contraseña</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="crearUsuarioModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.usuarios.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nuevo usuario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Apellido *</label>
                                <input type="text" name="apellido" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Teléfono</label>
                                <input type="text" name="telefono" class="form-control" maxlength="15">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Rol *</label>
                                <select name="idrol" class="form-select" required>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rol->id); ?>"><?php echo e($rol->nombrerol); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Usuario *</label>
                                <input type="text" name="usuario" class="form-control" required maxlength="255">
                                <div class="form-text">Sugerido automáticamente según nombre y apellido.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Correo *</label>
                                <input type="email" name="correo" class="form-control" required maxlength="255">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contraseña *</label>
                                <input type="password" name="password" class="form-control" required minlength="6">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const editarUsuarioModal = document.getElementById('editarUsuarioModal');
        editarUsuarioModal.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarUsuarioNombre').textContent =
                `${boton.dataset.nombre} ${boton.dataset.apellido}`;
            document.getElementById('editarUsuarioUsuario').textContent = boton.dataset.usuario;

            document.getElementById('editarNombre').value = boton.dataset.nombre;
            document.getElementById('editarApellido').value = boton.dataset.apellido;
            document.getElementById('editarTelefono').value = boton.dataset.telefono || '';
            document.getElementById('editarUsuarioCampo').value = boton.dataset.usuario;
            document.getElementById('editarCorreo').value = boton.dataset.correo || '';

            document.getElementById('cambiarRolSelect').value = boton.dataset.rolActual;
            document.getElementById('cambiarRolForm').setAttribute('action', boton.dataset.urlRol);
            document.getElementById('resetPassForm').setAttribute('action', boton.dataset.urlPassword);
            document.getElementById('actualizarDatosForm').setAttribute('action', boton.dataset.urlActualizar);
        });

        const nombresUsuarios = new Set(<?php echo json_encode($usuariosExistentes, 15, 512) ?>);

        function slugificarUsuario(texto) {
            return texto.toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-z0-9]+/g, '.')
                .replace(/^\.+|\.+$/g, '')
                .replace(/\.{2,}/g, '.');
        }

        function sugerirUsuario(nombre, apellido) {
            const base = slugificarUsuario(`${nombre || ''} ${apellido || ''}`);
            if (!base) return '';
            if (!nombresUsuarios.has(base)) return base;

            let sufijo = 1;
            while (nombresUsuarios.has(base + sufijo)) sufijo++;
            return base + sufijo;
        }

        const crearModal = document.getElementById('crearUsuarioModal');
        const crearNombre = crearModal.querySelector('input[name="nombre"]');
        const crearApellido = crearModal.querySelector('input[name="apellido"]');
        const crearUsuario = crearModal.querySelector('input[name="usuario"]');
        let usuarioGenerado = false;

        function regenerarUsuario() {
            if (usuarioGenerado || !crearUsuario.value) {
                crearUsuario.value = sugerirUsuario(crearNombre.value, crearApellido.value);
                usuarioGenerado = true;
            }
        }

        crearNombre.addEventListener('input', regenerarUsuario);
        crearApellido.addEventListener('input', regenerarUsuario);
        crearUsuario.addEventListener('input', function () {
            usuarioGenerado = false;
        });
        crearModal.addEventListener('hidden.bs.modal', function () {
            usuarioGenerado = false;
            crearUsuario.value = '';
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/usuarios/index.blade.php ENDPATH**/ ?>