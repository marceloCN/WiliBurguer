<?php

namespace App\Http\Controllers;

use App\Models\CuentaUsuario;
use App\Models\Empleado;
use App\Models\Rol;
use App\Models\Sucursal;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class UsuarioController extends Controller
{
    private const ROLES_GERENTE = ['CAJERO', 'MESERO'];

    public function index(Request $request): View
    {
        $busqueda = $request->input('busqueda');
        $idrol = $request->input('idrol');
        $estado = $request->input('estado');

        //carga la sucursal si es un gerente, sino null si es un administrador
        $sucursalGerente = $this->contextoSucursalGerente();
        
        //si el gerente no cuenta con una sucursal
        $this->bloquearGerenteSinSucursal($sucursalGerente);

        $empleados = Empleado::with(['rol', 'sucursal', 'cuentaUsuario'])
            ->when($sucursalGerente, fn ($query) => $query->where('idsucursal', $sucursalGerente->id))
            ->when($busqueda, function ($query, string $busqueda) {
                $termino = '%'.mb_strtolower($busqueda).'%';

                $query->where(function ($q) use ($termino) {
                    $q->whereRaw('LOWER(nombre) LIKE ?', [$termino])
                        ->orWhereRaw('LOWER(apellido) LIKE ?', [$termino])
                        ->orWhereRaw('LOWER(telefono) LIKE ?', [$termino])
                        ->orWhereHas('cuentaUsuario', function ($cuenta) use ($termino) {
                            $cuenta->whereRaw('LOWER(usuario) LIKE ?', [$termino])
                                ->orWhereRaw('LOWER(correo) LIKE ?', [$termino]);
                        });
                });
            })
            ->when($idrol, fn ($query) => $query->where('idrol', $idrol))
            ->when($estado === '1', fn ($query) => $query->where('estado', true))
            ->when($estado === '0', fn ($query) => $query->where('estado', false))
            ->orderBy('nombre')
            ->paginate(10)
            ->withQueryString();

        $roles = $this->rolesDisponibles($sucursalGerente);

        $usuariosExistentes = CuentaUsuario::query()
            ->pluck('usuario')
            ->map(fn ($usuario) => mb_strtolower(trim($usuario)))
            ->all();

        return view('admin.usuarios.index', compact('empleados', 'roles', 'busqueda', 'idrol', 'estado', 'sucursalGerente', 'usuariosExistentes'));
    }

    public function store(Request $request): RedirectResponse
    {
        $sucursalGerente = $this->contextoSucursalGerente();

        if (auth()->user()->empleado->rol?->claverol === 'GERENTE' && $sucursalGerente === null) {
            return back()->with('error', 'Como gerente necesitas tener una sucursal asignada para crear usuarios.');
        }

        $rolesPermitidos = $this->rolesDisponibles($sucursalGerente)
            ->pluck('id')
            ->all();

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'apellido' => ['required', 'string', 'max:100'],
            'telefono' => ['nullable', 'string', 'max:15'],
            'idrol' => ['required', 'exists:rol,id'],
            'usuario' => ['required', 'string', 'max:255', 'unique:cuentausuario,usuario'],
            'correo' => ['required', 'email', 'max:255', 'unique:cuentausuario,correo'],
            'password' => ['required', 'string', 'min:6'],
        ]);

        if ($sucursalGerente && ! in_array($validated['idrol'], $rolesPermitidos)) {
            return back()->with('error', 'Como gerente solo puedes crear usuarios cajero o mesero.');
        }

       
        
        $empleadoCreador = auth()->user()->empleado;
        $rol = Rol::find($validated['idrol']);

        // GERENTE → idjefe = administrador que lo crea.
        // CAJERO/MESERO por gerente → idjefe = gerente.
        // CAJERO/MESERO por administrador → NULL (su gerente se asigna vía sucursal).
        // Otros → NULL.
        if ($rol->claverol === 'GERENTE') {
            $idjefe = $empleadoCreador->id;
        } elseif (in_array($rol->claverol, ['CAJERO', 'MESERO'], true) && $sucursalGerente) {
            $idjefe = $empleadoCreador->id;
        } else {
            $idjefe = null;
        }

        $empleado = Empleado::create([
            'nombre' => $validated['nombre'],
            'apellido' => $validated['apellido'],
            'telefono' => $validated['telefono'],
            'estado' => true,
            'fecharegistro' => now(),
            'idjefe' => $idjefe,
            'idrol' => $validated['idrol'],
            'idsucursal' => $sucursalGerente?->id,
        ]);

        CuentaUsuario::create([
            'idempleado' => $empleado->id,
            'usuario' => $validated['usuario'],
            'correo' => $validated['correo'],
            'passwordhash' => Hash::make($validated['password']),
            'intentosfallidos' => 0,
            'bloqueado' => false,
            'fechacreacion' => now(),
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'empleado', $empleado->id, '100');

        return redirect()->route('dashboard.usuarios.index')
            ->with('exito', "Empleado {$empleado->nombre} {$empleado->apellido} creado.");
    }

    public function alternarEstado(CuentaUsuario $cuenta): RedirectResponse
    {
        if ($cuenta->id === auth()->id()) {
            return back()->with('error', 'No puedes desactivar tu propia cuenta.');
        }

        if (! $this->puedeOperarEmpleado($cuenta->empleado)) {
            return back()->with('error', 'Ese empleado no pertenece a tu sucursal.');
        }

        $empleado = $cuenta->empleado;
        $empleado->update(['estado' => ! $empleado->estado]);
        $cuenta->update(['bloqueado' => ! $cuenta->bloqueado]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'cuentausuario', $cuenta->id, '105');

        return back()->with('exito', 'Estado de la cuenta actualizado.');
    }

    public function actualizar(CuentaUsuario $cuenta, Request $request): RedirectResponse
    {
        if (! $this->puedeOperarEmpleado($cuenta->empleado)) {
            return back()->with('error', 'Ese empleado no pertenece a tu sucursal.');
        }

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'apellido' => ['required', 'string', 'max:100'],
            'telefono' => ['nullable', 'string', 'max:15'],
            'usuario' => ['required', 'string', 'max:255', "unique:cuentausuario,usuario,{$cuenta->id}"],
            'correo' => ['required', 'email', 'max:255', "unique:cuentausuario,correo,{$cuenta->id}"],
        ]);

        $empleado = $cuenta->empleado;

        $cambiaEmpleado = $empleado->nombre !== $validated['nombre']
            || $empleado->apellido !== $validated['apellido']
            || ($empleado->telefono ?? '') !== ($validated['telefono'] ?? '');

        $cambiaCuenta = $cuenta->usuario !== $validated['usuario']
            || $cuenta->correo !== $validated['correo'];

        $empleado->update([
            'nombre' => $validated['nombre'],
            'apellido' => $validated['apellido'],
            'telefono' => $validated['telefono'],
        ]);

        $cuenta->update([
            'usuario' => $validated['usuario'],
            'correo' => $validated['correo'],
        ]);

        if ($cambiaEmpleado) {
            $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'empleado', $empleado->id, '101');
        }

        if ($cambiaCuenta) {
            $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'cuentausuario', $cuenta->id, '106');
        }

        return back()->with('exito', 'Datos del empleado actualizados.');
    }

    public function reiniciarPassword(CuentaUsuario $cuenta, Request $request): RedirectResponse
    {
        if (! $this->puedeOperarEmpleado($cuenta->empleado)) {
            return back()->with('error', 'Ese empleado no pertenece a tu sucursal.');
        }

        $validated = $request->validate([
            'password' => ['required', 'string', 'min:6'],
        ]);

        $cuenta->update([
            'passwordhash' => Hash::make($validated['password']),
            'intentosfallidos' => 0,
            'bloqueado' => false,
            'bloqueadohasta' => null,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'cuentausuario', $cuenta->id, '106');

        return back()->with('exito', 'Contraseña actualizada.');
    }

    public function cambiarRol(CuentaUsuario $cuenta, Request $request): RedirectResponse
    {
        if ($cuenta->id === auth()->id()) {
            return back()->with('error', 'No puedes cambiar tu propio rol.');
        }

        if (! $this->puedeOperarEmpleado($cuenta->empleado)) {
            return back()->with('error', 'Ese empleado no pertenece a tu sucursal.');
        }

        $validated = $request->validate([
            'idrol' => ['required', 'exists:rol,id'],
        ]);

        $sucursalGerente = $this->contextoSucursalGerente();
        $rolesGerente = $this->rolesDisponibles($sucursalGerente)->pluck('id')->all();

        if ($sucursalGerente && ! in_array($validated['idrol'], $rolesGerente)) {
            return back()->with('error', 'Como gerente solo puedes asignar roles cajero o mesero.');
        }

        $rolAnterior = $cuenta->empleado->rol?->claverol;
        $nuevoRol = Rol::find($validated['idrol']);

        if ($rolAnterior === 'ADMINISTRADOR' && $nuevoRol->claverol !== 'ADMINISTRADOR') {
            $administradores = Empleado::where('idrol', $cuenta->empleado->idrol)
                ->where('estado', true)
                ->count();

            if ($administradores <= 1) {
                return back()->with('error', 'No puedes quitar el rol Administrador al último administrador activo.');
            }
        }

        $updates = ['idrol' => $validated['idrol']];

        // Promocionado a GERENTE: idjefe = administrador que lo promociona
        if ($rolAnterior !== 'GERENTE' && $nuevoRol->claverol === 'GERENTE') {
            $updates['idjefe'] = auth()->user()->empleado->id;
        }
        // Removido de GERENTE: idjefe = null (ya no es gerente)
        if ($rolAnterior === 'GERENTE' && $nuevoRol->claverol !== 'GERENTE') {
            $updates['idjefe'] = null;
        }

        $cuenta->empleado->update($updates);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'empleado', $cuenta->empleado->id, '101');

        return back()->with('exito', "Rol de {$cuenta->empleado->nombre} actualizado: {$rolAnterior} → {$nuevoRol->claverol}.");
    }

    private function contextoSucursalGerente(): ?Sucursal
    {
        $empleado = auth()->user()->empleado->load('rol');

        if ($empleado->rol?->claverol !== 'GERENTE') {
            return null;
        }

        return Sucursal::where('idempleadogerente', $empleado->id)
            ->where('estado', true)
            ->first();
    }

    private function rolesDisponibles(?Sucursal $sucursalGerente): Collection
    {
        $roles = Rol::orderBy('nombrerol')->get();

        if ($sucursalGerente) {
            $roles = $roles->whereIn('claverol', self::ROLES_GERENTE)->values();
        }

        return $roles;
    }

    private function puedeOperarEmpleado(Empleado $empleado): bool
    {
        $sucursalGerente = $this->contextoSucursalGerente();

        // Un gerente sin sucursal asignada no puede operar ningún empleado.
        if (auth()->user()->empleado->rol?->claverol === 'GERENTE' && $sucursalGerente === null) {
            return false;
        }

        return $sucursalGerente === null || $empleado->idsucursal === $sucursalGerente->id;
    }

    private function bloquearGerenteSinSucursal(?Sucursal $sucursalGerente): void
    {
        if (auth()->user()->empleado->rol?->claverol === 'GERENTE' && $sucursalGerente === null) {
            abort(403, 'Como gerente necesitas tener una sucursal asignada para gestionar usuarios.');
        }
    }
}
