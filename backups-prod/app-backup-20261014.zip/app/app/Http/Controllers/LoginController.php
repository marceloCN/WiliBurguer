<?php

namespace App\Http\Controllers;

use App\Models\CuentaUsuario;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class LoginController extends Controller
{
    public function show(): RedirectResponse|View
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }

        return view('auth.login');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'usuario' => ['required', 'string', 'max:255'],
            'password' => ['required', 'string'],
        ]);

        $cuenta = CuentaUsuario::with('empleado')
            ->where('usuario', $validated['usuario'])
            ->orWhere('correo', $validated['usuario'])
            ->first();

        $ip = $request->ip();

        // la cuenta no fue encontrada
        if (! $cuenta) {
            $this->registrarAcceso(null, 'LOGIN', $ip, 'FALLIDO', 'Cuenta no encontrada');

            return back()->withErrors(['usuario' => 'Tu cuenta de usuario es incorrecta.'])->onlyInput('usuario');
        }

        // la cuenta de empleado que esta bloqueada intenta ingresar
        if (! $cuenta->empleado->estado) {
            $this->registrarAcceso($cuenta->idempleado, 'LOGIN', $ip, 'FALLIDO', 'Cuenta de empleado bloqueado intentando ingresar');
            return back()->withErrors(['usuario' => 'Cuenta de empleado bloqueado intentando ingresar.'])
                ->onlyInput('usuario');
        }

        //la cuenta de usuario esta bloqueada, verifica si ya paso los 15 min
        if ($cuenta->bloqueado) {
            $verificar_cuenta = DB::selectOne('SELECT verificar_bloqueo_y_desbloquear(?) AS desbloqueado', [$cuenta->idempleado]);
            if (!$verificar_cuenta->desbloqueado) {
                $this->registrarAcceso($cuenta->idempleado, 'LOGIN', $ip, 'FALLIDO', 'Cuenta bloqueada');
                return back()->withErrors(['usuario' => 'Cuenta bloqueada temporalmente.'])->onlyInput('usuario');
            }
        }
        // si no es correcta la contraseña encriptada, son 3 intentos
        if (! Hash::check($validated['password'], $cuenta->passwordhash)) {
            $nuevosIntentos = ($cuenta->intentosfallidos ?? 0) + 1;
            $update = ['intentosfallidos' => $nuevosIntentos];
            if ($nuevosIntentos >= 3) {
                $update['bloqueado'] = true;
                $update['bloqueadohasta'] = now()->addMinutes(15);
            }
            $cuenta->update($update);
            $this->registrarAcceso($cuenta->idempleado, 'LOGIN', $ip, 'FALLIDO', 'Contraseña incorrecta');
            return back()->withErrors([
                'password' => 'Credenciales incorrectas. Intentos restantes: ' . max(0, 3 - $nuevosIntentos)])->onlyInput('usuario');
        }

        if ($cuenta->bloqueado && $cuenta->bloqueadohasta?->isFuture()) {
            $this->registrarAcceso($cuenta->idempleado, 'LOGIN', $ip, 'FALLIDO', 'Cuenta bloqueada');
            return back()->withErrors(['usuario' => 'Cuenta bloqueada temporalmente.'])->onlyInput('usuario');
        }

        //genero la session de logeo y lo registro
        Auth::login($cuenta, $request->boolean('remember'));

        $this->registrarAcceso($cuenta->idempleado, 'LOGIN', $ip, 'EXITOSO', 'Acceso correcto');

        $request->session()->regenerate();

        return redirect()->intended(route('dashboard'));
    }

    public function destroy(Request $request): RedirectResponse
    {
        $cuenta = Auth::user();

        if ($cuenta && $cuenta->empleado) {
            $this->registrarAcceso($cuenta->idempleado, 'LOGOUT', $request->ip(), 'EXITOSO', 'Sesión cerrada');
        }

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('inicio');
    }
}
