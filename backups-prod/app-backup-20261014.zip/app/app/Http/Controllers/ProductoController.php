<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProductoController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validar($request);

        $descripcion = $validated['descripcion'] ?? '';

        $rutaFoto = $this->guardarFoto($request);

        if ($request->filled('photo_url') && ! $rutaFoto) {
            return back()->withInput()->with('error', 'No se pudo descargar la imagen desde la URL proporcionada.');
        }

        $existente = $this->productoPorNombre(mb_trim($validated['nombre']));

        if ($existente && $existente->estado) {
            return back()->withInput()->with('error', 'Ya existe un producto activo con ese nombre.');
        }

        if ($existente) {
            $existente->update([
                'nombre' => mb_trim($validated['nombre']),
                'descripcion' => $descripcion,
                'idcategoria' => $validated['idcategoria'],
                'photo' => $rutaFoto ?? $existente->photo,
                'estado' => true,
            ]);

            $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'producto', $existente->id, '310');

            return redirect()->route('dashboard.menu.index', ['idcategoria' => $existente->idcategoria])
                ->with('exito', "Producto {$existente->nombre} reactivado.");
        }

        $producto = Producto::create([
            'nombre' => mb_trim($validated['nombre']),
            'descripcion' => $descripcion,
            'idcategoria' => $validated['idcategoria'],
            'photo' => $rutaFoto,
            'estado' => true,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'producto', $producto->id, '310');

        return redirect()->route('dashboard.menu.index', ['idcategoria' => $producto->idcategoria])
            ->with('exito', "Producto {$producto->nombre} creado.");
    }

    public function update(Request $request, Producto $producto): RedirectResponse
    {
        $validated = $this->validar($request);

        $descripcion = $validated['descripcion'] ?? '';

        $rutaFoto = $this->guardarFoto($request);

        if ($request->filled('photo_url') && ! $rutaFoto) {
            return back()->withInput()->with('error', 'No se pudo descargar la imagen desde la URL proporcionada.');
        }

        if ($rutaFoto && $producto->photo && $producto->photo !== $rutaFoto) {
            Storage::disk('public')->delete($producto->photo);
        }

        $producto->update([
            'nombre' => mb_trim($validated['nombre']),
            'descripcion' => $descripcion,
            'idcategoria' => $validated['idcategoria'],
            'photo' => $rutaFoto ?? $producto->photo,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'producto', $producto->id, '311');

        return back()->with('exito', "Producto {$producto->nombre} actualizado.");
    }

    public function baja(Producto $producto): RedirectResponse
    {
        $producto->update(['estado' => false]);

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'producto', $producto->id, '315');

        return back()->with('exito', "Producto {$producto->nombre} dado de baja.");
    }

    public function reactivar(Producto $producto): RedirectResponse
    {
        if ($producto->estado) {
            return back()->with('info', "El producto {$producto->nombre} ya está activo.");
        }

        $producto->update(['estado' => true]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'producto', $producto->id, '310');

        return redirect()->route('dashboard.menu.index', ['idcategoria' => $producto->idcategoria])
            ->with('exito', "Producto {$producto->nombre} reactivado.");
    }

    private function productoPorNombre(string $nombre, ?int $ignorarId = null): ?Producto
    {
        return Producto::whereRaw('LOWER(nombre) = ?', [mb_strtolower($nombre)])
            ->when($ignorarId, fn ($query) => $query->where('id', '!=', $ignorarId))
            ->first();
    }

    private function validar(Request $request): array
    {
        return $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'descripcion' => ['nullable', 'string'],
            'idcategoria' => ['required', 'exists:categoria,id'],
            'photo' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,webp', 'max:5120'],
            'photo_url' => ['nullable', 'url', 'max:2048'],
        ]);
    }

    private function guardarFoto(Request $request): ?string
    {
        if ($request->hasFile('photo')) {
            return $request->file('photo')->store('productos', 'public');
        }

        if ($request->filled('photo_url')) {
            return $this->descargarFotoUrl($request->input('photo_url'));
        }

        return null;
    }

    private function descargarFotoUrl(string $url): ?string
    {
        try {
            $contexto = stream_context_create([
                'http' => [
                    'timeout' => 20,
                    'ignore_errors' => true,
                    'user_agent' => 'Mozilla/5.0 (compatible; BurguerWilly/1.0)',
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                ],
            ]);

            $contenido = @file_get_contents($url, false, $contexto);
            if ($contenido === false) {
                return null;
            }

            $info = @getimagesizefromstring($contenido);
            if ($info === false) {
                return null;
            }

            $mime = $info['mime'] ?? '';
            $extension = match ($mime) {
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/gif' => 'gif',
                'image/webp' => 'webp',
                default => null,
            };

            if ($extension === null) {
                return null;
            }

            if (strlen($contenido) > 5 * 1024 * 1024) {
                return null;
            }

            $nombre = 'productos/'.Str::random(40).'.'.$extension;
            Storage::disk('public')->put($nombre, $contenido);

            return $nombre;
        } catch (\Exception) {
            return null;
        }
    }
}