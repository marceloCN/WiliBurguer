<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['idpromocion', 'idsucursalproducto','cantidad_producto'])]
class PromocionSucursalProducto extends Model
{
    public $timestamps = false;

    protected $table = 'promocion_sucursal_producto';

    public function promocion(): BelongsTo
    {
        return $this->belongsTo(Promocion::class, 'idpromocion');
    }

    public function sucursalProducto(): BelongsTo
    {
        return $this->belongsTo(SucursalProducto::class, 'idsucursalproducto');
    }
}
