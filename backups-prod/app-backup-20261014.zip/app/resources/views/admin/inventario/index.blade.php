@extends('layouts.app')

@section('title', 'Inventario · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Inventario 📊</h1>
                <p class="text-muted mb-0">Registra entradas, salidas y ajustes de stock por sucursal.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-brand" data-bs-toggle="modal" data-bs-target="#reporteModal">
                    📄 Reportes PDF
                </button>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#nuevoMovimientoModal"
                        @if ($insumos->isEmpty()) disabled title="Primero crea insumos en Insumos y recetas" @endif>
                    + Registrar movimiento
                </button>
            </div>
        </div>

        @include('partials.mensajes')

        <p class="small text-muted mb-3">
            Cada registro es un <strong>movimiento</strong> que actualiza el stock de un insumo en la sucursal seleccionada:
            <strong>ENTRADA</strong> suma cantidad (ej. compras o reposiciones),
            <strong>SALIDA</strong> resta (ej. consumo o despacho), y
            <strong>AJUSTE</strong> deja la cantidad exacta que indiques (ej. conteo físico o merma).
            Para usarlo pulsa «+ Registrar movimiento», elige el insumo, el tipo, la cantidad y una observación opcional.
        </p>

        <div class="row g-4">
            {{-- Columna izquierda: sucursales disponibles (solo administrador) --}}
            @if ($esAdmin)
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto h-100">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursales</span>
                        <span class="badge text-bg-dark">{{ $sucursales->count() }}</span>
                    </div>
                    @if ($sucursales->count() <= 1)
                        <div class="card-body">
                            <div class="fw-semibold">{{ $sucursalActual->nombre }}</div>
                            @if ($empleado->sucursal && $sucursalActual->id === $empleado->sucursal->id)
                                <div class="small text-muted">Tu sucursal asignada</div>
                            @endif
                        </div>
                    @else
                        <div class="list-group">
                            @foreach ($sucursales as $sucursal)
                                <a href="{{ route('dashboard.inventario.index', ['idsucursal' => $sucursal->id]) }}"
                                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                          {{ $sucursalActual->id === $sucursal->id ? 'active' : '' }}">
                                    <span class="fw-semibold">{{ $sucursal->nombre }}</span>
                                    @if (!$sucursal->estado)
                                        <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                    @endif
                                </a>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
            @endif

            {{-- Columna derecha: inventario + movimientos --}}
            <div class="{{ $esAdmin ? 'col-12 col-lg-8' : 'col-12' }}">
                @if (! $esAdmin)
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="badge text-bg-brand">{{ $sucursalActual->nombre }}</span>
                        <span class="text-muted small">Inventario de tu sucursal</span>
                    </div>
                @endif
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span class="fw-bold">Stock · {{ $sucursalActual->nombre }}</span>
                        <span class="badge text-bg-brand">{{ $inventario->count() }} insumo(s)</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Insumo</th>
                                        <th>Unidad</th>
                                        <th>Cantidad</th>
                                        <th>Mínimo</th>
                                        <th>Estado</th>
                                        <th class="text-end">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($inventario as $item)
                                        @php
                                            $stockBajo = $item->cantidadminima !== null && $item->cantidad <= $item->cantidadminima;
                                        @endphp
                                        <tr>
                                            <td class="fw-semibold">{{ $item->insumo?->nombre }}</td>
                                            <td>
                                                <span class="badge text-bg-light border">{{ $item->insumo?->unidadMedida?->abreviatura ?? '—' }}</span>
                                            </td>
                                            <td class="fw-semibold">{{ rtrim(rtrim(number_format($item->cantidad, 3, '.', ''), '0'), '.') }}</td>
                                            <td>{{ $item->cantidadminima !== null ? rtrim(rtrim(number_format($item->cantidadminima, 3, '.', ''), '0'), '.') : '—' }}</td>
                                            <td>
                                                @if ($item->cantidad <= 0)
                                                    <span class="badge text-bg-danger">Sin stock</span>
                                                @elseif ($stockBajo)
                                                    <span class="badge text-bg-warning">Bajo</span>
                                                @else
                                                    <span class="badge text-bg-success">OK</span>
                                                @endif
                                            </td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-outline-brand"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#editarMinimoModal"
                                                        data-id="{{ $item->id }}"
                                                        data-insumo="{{ $item->insumo?->nombre }}"
                                                        data-minimo="{{ $item->cantidadminima }}">
                                                    Editar mín.
                                                </button>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center py-4 text-muted">
                                                No hay insumos cargados en esta sucursal. Pulsa "+ Registrar movimiento" para comenzar.
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Movimientos recientes</span>
                        <span class="badge text-bg-dark">{{ $movimientos->count() }}</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Tipo</th>
                                        <th>Insumo</th>
                                        <th>Cantidad</th>
                                        <th>Stock: anterior → nuevo</th>
                                        <th>Empleado</th>
                                        <th>Observación</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($movimientos as $movimiento)
                                        <tr>
                                            <td class="small">{{ $movimiento->fechamovimiento->format('d/m/Y H:i') }}</td>
                                            <td>
                                                @php
                                                    $tipoClase = match ($movimiento->tipomovimiento) {
                                                        'ENTRADA' => 'text-bg-success',
                                                        'SALIDA' => 'text-bg-danger',
                                                        default => 'text-bg-warning',
                                                    };
                                                @endphp
                                                <span class="badge {{ $tipoClase }}">{{ $movimiento->tipomovimiento }}</span>
                                            </td>
                                            <td class="fw-semibold">{{ $movimiento->inventarioSucursal?->insumo?->nombre }}</td>
                                            <td class="fw-semibold">{{ rtrim(rtrim(number_format($movimiento->cantidad, 3, '.', ''), '0'), '.') }}</td>
                                            <td class="small">
                                                {{ rtrim(rtrim(number_format($movimiento->cantidadanterior, 3, '.', ''), '0'), '.') }} → {{ rtrim(rtrim(number_format($movimiento->cantidadnueva, 3, '.', ''), '0'), '.') }}
                                            </td>
                                            <td class="small text-muted">
                                                @if ($movimiento->empleado)
                                                    {{ $movimiento->empleado->nombre }} {{ $movimiento->empleado->apellido }}
                                                @else
                                                    —
                                                @endif
                                            </td>
                                            <td class="small text-muted">{{ $movimiento->observacion ?? '—' }}</td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="7" class="text-center py-4 text-muted">
                                                Aún no hay movimientos registrados en esta sucursal.
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ================= Modal nuevo movimiento ================= --}}
    <div class="modal fade" id="nuevoMovimientoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="{{ route('dashboard.inventario.movimiento.store') }}">
                    @csrf
                    <input type="hidden" name="idsucursal" value="{{ $sucursalActual->id }}">
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Registrar movimiento de inventario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Sucursal</label>
                                <div class="fw-semibold text-muted">{{ $sucursalActual->nombre }}</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Insumo *</label>
                                <select name="idinsumo" class="form-select" required>
                                    <option value="" selected disabled>Selecciona un insumo…</option>
                                    @foreach ($insumos as $insumo)
                                        <option value="{{ $insumo->id }}" @selected(old('idinsumo') == $insumo->id)>
                                            {{ $insumo->nombre }} ({{ $insumo->unidadMedida?->abreviatura }})
                                            {{ $insumosDisponibles->contains('id', $insumo->id) ? '· nuevo en esta sucursal' : '' }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo de movimiento *</label>
                                <select name="tipo" class="form-select" required>
                                    @foreach (\App\Http\Controllers\InventarioController::TIPOS as $tipo)
                                        <option value="{{ $tipo }}" @selected(old('tipo') === $tipo)>{{ $tipo }}</option>
                                    @endforeach
                                </select>
                                <div class="form-text">
                                    Entrada: suma stock · Salida: resta stock · Ajuste: fija la cantidad exacta.
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cantidad *</label>
                                <input type="number" name="cantidad" class="form-control" required
                                       step="0.001" min="0.001" value="{{ old('cantidad') }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cantidad mínima</label>
                                <input type="number" name="cantidadminima" class="form-control"
                                       step="0.001" min="0" placeholder="Solo al crear el insumo en esta sucursal"
                                       value="{{ old('cantidadminima') }}">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Observación</label>
                                <textarea name="observacion" rows="2" class="form-control" maxlength="255"
                                          placeholder="Ej.: Compra semanal, merma, conteo físico…">{{ old('observacion') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Registrar movimiento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal editar cantidad mínima ================= --}}
    <div class="modal fade" id="editarMinimoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-minimo">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Cantidad mínima de inventario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p class="text-muted mb-3">
                            Cuando el stock de <strong id="minimoInsumoNombre"></strong> sea
                            <strong>menor o igual</strong> a la cantidad mínima, se mostrará la alerta de stock bajo.
                        </p>
                        <label class="form-label">Cantidad mínima</label>
                        <input type="number" name="cantidadminima" id="minimoCantidad" class="form-control"
                               step="0.001" min="0" placeholder="Deja vacío para sin mínimo">
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar mínimo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- ================= Modal reportes PDF ================= --}}
    <div class="modal fade" id="reporteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="GET" action="{{ route('dashboard.inventario.reporte') }}">
                    @if (! $esAdmin)
                        <input type="hidden" name="idsucursal" value="{{ $sucursalActual->id }}">
                    @endif
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Reportes PDF · {{ $sucursalActual->nombre }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-light border small mb-3">
                            Descarga un PDF con el estado actual del inventario o con los movimientos
                            (entradas, salidas y ajustes) de <strong>{{ $sucursalActual->nombre }}</strong>.
                        </div>
                        <div class="row g-3">
                            @if ($esAdmin && $sucursales->count() > 1)
                                <div class="col-12">
                                    <label class="form-label">Sucursal *</label>
                                    <select name="idsucursal" class="form-select" required>
                                        @foreach ($sucursales as $sucursal)
                                            <option value="{{ $sucursal->id }}" @selected($sucursalActual->id === $sucursal->id)>
                                                {{ $sucursal->nombre }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                            <div class="col-12">
                                <label class="form-label">Tipo de detalle *</label>
                                <select name="tipo" class="form-select" id="reporteTipo" required>
                                    <option value="estado">Estado actual de inventario</option>
                                    <option value="movimientos">Movimientos de entrada, salida y ajuste</option>
                                </select>
                            </div>
                            <div class="col-12" id="reporteFechaDesde" style="display:none;">
                                <label class="form-label">Desde qué fecha *</label>
                                <input type="date" name="fecha_desde" class="form-control"
                                       value="{{ old('fecha_desde', now()->startOfMonth()->format('Y-m-d')) }}">
                                <div class="form-text">Se listarán los movimientos desde esa fecha hasta hoy.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Descargar PDF</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        document.querySelectorAll('[data-bs-target="#editarMinimoModal"]').forEach(function (boton) {
            boton.addEventListener('click', function () {
                var id = boton.getAttribute('data-id');
                var insumo = boton.getAttribute('data-insumo');
                var minimo = boton.getAttribute('data-minimo');

                document.getElementById('form-editar-minimo').action = '{{ route('dashboard.inventario.minimo', 'ID') }}'.replace('ID', id);
                document.getElementById('minimoInsumoNombre').textContent = insumo;
                document.getElementById('minimoCantidad').value = (minimo !== '' && minimo !== null) ? minimo : '';
            });
        });

        var selectTipo = document.getElementById('reporteTipo');
        var campoFecha = document.getElementById('reporteFechaDesde');
        function alternarFechaReporte() {
            campoFecha.style.display = selectTipo.value === 'movimientos' ? '' : 'none';
            var fecha = document.querySelector('input[name="fecha_desde"]');
            if (fecha) {
                fecha.required = selectTipo.value === 'movimientos';
            }
        }
        if (selectTipo) {
            selectTipo.addEventListener('change', alternarFechaReporte);
            alternarFechaReporte();
        }
    </script>
@endpush
