<?php $__env->startSection('title', 'Panel de administración · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">
                    Panel de administración <span class="badge text-bg-brand ms-1"><?php echo e($rol->claverol); ?></span>
                </h1>
                <p class="text-muted mb-0">👤 <?php echo e($empleado->nombre); ?> · Administra el restaurante desde estos módulos.</p>
            </div>
            <?php if(isset($permisos['pedidos'])): ?>
                <a href="<?php echo e(route('dashboard.generar-pedidos.index')); ?>" class="btn btn-brand">
                    🧾 Ir a Generar pedidos
                </a>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($sinSucursal): ?>
            <div class="alert alert-warning shadow-sm">
                ⏳ Aún no tienes una sucursal asignada. Contacta al administrador para que te asigne una y
                puedas comenzar a operar los módulos que requieren sucursal.
            </div>
        <?php endif; ?>

        <div class="row g-3">
            <?php $__empty_1 = true; $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo => $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($modulo['activo'] && $modulo['ruta']): ?>
                    <div class="col-12 col-sm-6 col-lg-4 col-xxl-3">
                        <a href="<?php echo e(route($modulo['ruta'], $modulo['parametros'] ?? [])); ?>"
                           class="card tarjeta-producto h-100 text-decoration-none">
                            <div class="card-body">
                                <div class="d-flex align-items-center gap-3">
                                    <span class="badge <?php echo e($modulo['color']); ?> p-3 rounded-3 fs-4"><?php echo e($modulo['icono']); ?></span>
                                    <div class="min-w-0">
                                        <h2 class="h6 fw-bold mb-0 text-dark"><?php echo e($modulo['titulo']); ?></h2>
                                    </div>
                                </div>
                                <p class="text-muted small mt-2 mb-0"><?php echo e($modulo['descripcion']); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-info shadow-sm mb-0">
                        Tu rol no tiene módulos asignados en este panel.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>