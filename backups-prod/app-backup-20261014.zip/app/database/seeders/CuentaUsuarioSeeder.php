<?php

namespace Database\Seeders;

use App\Models\CuentaUsuario;
use App\Models\Empleado;
use App\Models\Rol;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class CuentaUsuarioSeeder extends Seeder
{
    public function run(): void
    {
        $rol = Rol::where('claverol', 'ADMINISTRADOR')->first();

        if (! $rol) {
            $this->command->error('No existe el rol ADMINISTRADOR.');

            return;
        }

        $cuenta = CuentaUsuario::where('correo', 'cruznogalesmarcelo@gmail.com')->first();

        $empleado = $cuenta?->empleado ?? Empleado::firstOrCreate(
            ['nombre' => 'Marcelo', 'apellido' => 'Cruz Nogales', 'telefono' => null, 'idrol' => $rol->id, 'idsucursal' => null],
            ['estado' => true, 'idjefe' => null]
        );

        if ($cuenta) {
            $cuenta->update([
                'usuario' => 'admin',
                'passwordhash' => Hash::make('admin123'),
                'intentosfallidos' => 0,
                'bloqueado' => false,
                'bloqueadohasta' => null,
            ]);
        } else {
            CuentaUsuario::create([
                'idempleado' => $empleado->id,
                'usuario' => 'admin',
                'correo' => 'cruznogalesmarcelo@gmail.com',
                'passwordhash' => Hash::make('admin123'),
                'intentosfallidos' => 0,
                'bloqueado' => false,
            ]);
        }

        $this->command->info('Usuario administrador listo: admin / admin123');
    }
}
