<?php $__env->startSection('title', 'Generar pedidos · ' . $configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .pos-ventana {
            border: 1px solid rgba(var(--brand-rgb, 78, 62, 50), .25);
            border-radius: 1rem;
            box-shadow: 0 .75rem 2rem rgba(0, 0, 0, .08);
            overflow: hidden;
            background: #fff;
        }

        .pos-cabecera {
            background: linear-gradient(180deg, color-mix(in srgb, var(--brand) 96%, #000) 0%, color-mix(in srgb, var(--brand) 82%, #000) 100%);
            color: #fff;
        }

        .pos-cabecera .nav-tabs .nav-link {
            color: rgba(255, 255, 255, .75);
            border: 1px solid transparent;
            border-radius: .375rem .375rem 0 0;
        }

        .pos-cabecera .nav-tabs .nav-link:hover {
            color: #fff;
            border-color: rgba(255, 255, 255, .2) rgba(255, 255, 255, .2) transparent;
        }

        .pos-cabecera .nav-tabs .nav-link.active {
            color: var(--brand-dark, #241a13);
            background-color: #fff;
            border-color: transparent;
            font-weight: 600;
        }

        .pos-cat {
            border-radius: 2rem;
            white-space: nowrap;
        }

        .pos-cat.active {
            background-color: var(--brand) !important;
            color: #fff !important;
            border-color: var(--brand) !important;
        }

        .pos-producto {
            transition: transform .15s ease, box-shadow .15s ease;
        }

        .pos-producto:hover {
            transform: translateY(-2px);
            box-shadow: 0 .5rem 1.25rem rgba(0, 0, 0, .10);
        }

        .pos-grupo-cat {
            transition: opacity .15s ease;
        }

        .pos-grupo-heading {
            border-left: 4px solid var(--brand);
            padding-left: .65rem;
            margin-bottom: .75rem !important;
        }

        .pos-grupo-promo .pos-grupo-heading {
            border-left-color: #dc3545;
        }

        .pos-grupo-promo {
            background: #fff5f5;
            border-radius: .5rem;
            padding: .75rem;
        }

        .pos-pedido-item {
            transition: background .15s ease, box-shadow .15s ease;
        }

        .pos-pedido-item:hover {
            background: #f8f9fa;
            box-shadow: 0 1px 4px rgba(0, 0, 0, .06);
        }

        .pos-cart {
            position: sticky;
            top: 1rem;
        }

        .pos-cart-lista {
            max-height: 40vh;
            overflow-y: auto;
        }

        .pos-lista-pedidos {
            max-height: 320px;
            overflow-y: auto;
        }

        .pos-foto {
            width: 100%;
            height: 110px;
            object-fit: cover;
            border-radius: .5rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl py-3">
        <?php if($posBloqueado): ?>
            
            <div class="row justify-content-center">
                <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                    <div class="card tarjeta-producto shadow-sm text-center py-5 px-4">
                        <div class="fs-1 mb-3">🔒</div>
                        <h1 class="h4 fw-bold mb-2">Caja cerrada</h1>
                        <p class="text-muted mb-1">
                            No hay una apertura de caja abierta en la sucursal
                            <?php echo e($sucursalActual?->nombre ? '«' . $sucursalActual->nombre . '»' : ''); ?>.
                        </p>
                        <p class="text-muted mb-4">
                            Para comenzar a atender pedidos, el cajero o el gerente debe abrir la caja en esta sucursal.
                            Mientras tanto solo puedes ver o modificar tu perfil.
                        </p>
                        <div class="d-flex justify-content-center gap-2 flex-wrap">
                            <a href="<?php echo e(route('dashboard.perfil.index')); ?>" class="btn btn-brand">👤 Mi perfil</a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="m-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-danger">🚪 Cerrar sesión</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-0 pos-ventana">


                
                <div class="col-12 bg-body-tertiary p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                        <div>
                            <h1 class="h4 fw-bold mb-0">🧾 Generar pedidos</h1>
                            <p class="text-muted small mb-0"><?php echo e($sucursalActual->nombre); ?></p>
                        </div>
                        <div class="d-flex gap-2 flex-wrap">
                            <?php if($operacionBloqueada): ?>
                                <span class="badge text-bg-warning">🔒 Opera el cajero o gerente con la caja abierta.</span>
                            <?php else: ?>
                                <span class="badge <?php echo e($aperturaAbierta ? 'text-bg-success' : 'text-bg-warning'); ?>">
                                    <?php echo e($aperturaAbierta ? '🔓 Caja abierta' : '🔒 Sin apertura de caja'); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div class="row g-3">
                        
                        <div class="col-12 col-xl-8">
                            
                            <ul class="nav nav-pills mb-3 gap-1" id="posTabs">
                                <li class="nav-item">
                                    <button type="button" class="nav-link active" data-pos-tab="generar">🧾 Generar
                                        pedidos</button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" data-pos-tab="ver">📋 Ver pedidos y sus
                                        estados</button>
                                </li>
                            </ul>

                            
                            <div id="posTab-generar">
                                <div class="card tarjeta-producto shadow-sm mb-3">
                                    <div class="card-header bg-white d-flex flex-wrap gap-2 align-items-center">
                                        <div class="btn-group btn-group-sm flex-wrap" role="group">
                                            <button type="button" class="btn btn-outline-secondary pos-cat active"
                                                data-pos-cat="todos">🍔 Todos</button>
                                            <?php $__currentLoopData = $categoriasPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <button type="button" class="btn btn-outline-secondary pos-cat"
                                                    data-pos-cat="c-<?php echo e($grupo['categoria']->id); ?>">
                                                    <?php echo e($grupo['categoria']->nombre); ?>

                                                    <span
                                                        class="badge text-bg-light ms-1"><?php echo e($grupo['productos']->count()); ?></span>
                                                </button>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($puedeVerPromosPOS): ?>
                                                <button type="button" class="btn btn-outline-danger pos-cat"
                                                    data-pos-cat="promociones">
                                                    🏷️ Promociones
                                                    <span
                                                        class="badge text-bg-light ms-1"><?php echo e($promocionesPOS->count()); ?></span>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                        <input type="search" class="form-control form-control-sm ms-auto" id="posBusqueda"
                                            placeholder="🔍 Buscar producto o promoción…" style="max-width: 240px;">
                                    </div>
                                    <div class="card-body">
                                        <div id="posGrupos">
                                            <?php $__empty_1 = true; $__currentLoopData = $categoriasPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <section class="pos-grupo-cat mb-4"
                                                    data-grupo="c-<?php echo e($grupo['categoria']->id); ?>">
                                                    <h3 class="h5 fw-bold mb-2 pos-grupo-heading">
                                                        <?php echo e($grupo['categoria']->nombre); ?> <span
                                                            class="badge text-bg-light"><?php echo e($grupo['productos']->count()); ?></span>
                                                    </h3>
                                                    <div class="row g-3">
                                                        <?php $__currentLoopData = $grupo['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-6 col-sm-4 col-lg-3 pos-item-producto"
                                                                data-pos-buscar="<?php echo e(mb_strtolower($sp->producto->nombre)); ?> <?php echo e(mb_strtolower($sp->producto->descripcion)); ?>">
                                                                <div class="card tarjeta-producto pos-producto h-100"
                                                                    data-pos-id="p-<?php echo e($sp->id); ?>"
                                                                    data-pos-nombre="<?php echo e($sp->producto->nombre); ?>"
                                                                    data-pos-precio="<?php echo e(number_format((float) $sp->precioproducto, 2, '.', '')); ?>">
                                                                    <div class="card-body p-2">
                                                                        <?php if($sp->producto->photo): ?>
                                                                            <img src="<?php echo e(asset('storage/' . $sp->producto->photo)); ?>"
                                                                                class="pos-foto"
                                                                                alt="<?php echo e($sp->producto->nombre); ?>">
                                                                        <?php else: ?>
                                                                            <div
                                                                                class="pos-foto d-flex align-items-center justify-content-center bg-light fs-1">
                                                                                🍔</div>
                                                                        <?php endif; ?>
                                                                        <h6 class="fw-bold small mt-2 mb-0">
                                                                            <?php echo e($sp->producto->nombre); ?></h6>
                                                                        <p class="text-muted small mb-2"
                                                                            style="min-height: 2em;">
                                                                            <?php echo e(mb_strlen($sp->producto->descripcion) > 60 ? mb_substr($sp->producto->descripcion, 0, 57) . '&hellip;' : $sp->producto->descripcion); ?>

                                                                        </p>
                                                                        <div
                                                                            class="d-flex justify-content-between align-items-center">
                                                                            <span class="fw-bold text-brand">Bs
                                                                                <?php echo e(number_format((float) $sp->precioproducto, 2)); ?></span>
                                                                            <button type="button"
                                                                                class="btn btn-brand btn-sm pos-agregar"
                                                                                title="Agregar al pedido">+</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </section>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <div class="text-center text-muted py-4">Esta sucursal no tiene productos
                                                    disponibles. Regístralos en «Productos por sucursal».</div>
                                            <?php endif; ?>
                                            <?php if($puedeVerPromosPOS): ?>
                                                <section class="pos-grupo-cat mb-4 pos-grupo-promo"
                                                    data-grupo="promociones">
                                                    <h3 class="h5 fw-bold mb-2 pos-grupo-heading">🏷️ Promociones <span
                                                            class="badge text-bg-light"><?php echo e($promocionesPOS->count()); ?></span>
                                                    </h3>
                                                    <div class="row g-3">
                                                        <?php $__empty_1 = true; $__currentLoopData = $promocionesPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <div class="col-6 col-sm-4 col-lg-3 pos-item-promo"
                                                                data-pos-buscar="<?php echo e(Str::lower($promo->nombre)); ?> <?php echo e(Str::lower($promo->tipodescuento === 'PORCENTAJE' ? '-' . number_format((float) $promo->valordescuento, 0) . '%' : '-Bs. ' . number_format((float) $promo->valordescuento, 2))); ?> <?php echo e($promo->sucursalesProducto->where('idsucursal', $sucursalActual->id)->map(fn($sp) => $sp->producto?->nombre)->join(' ')); ?>">
                                                                <?php
                                                                    $promoSubtotal = $promo->sucursalesProducto->filter(fn($sp) => $sp->idsucursal == $sucursalActual->id)->sum(fn($sp) => (float) ($sp->pivot->cantidad_producto ?? 1) * (float) $sp->precioproducto);
                                                                    $promoTotal = $promo->tipodescuento === 'PORCENTAJE'
                                                                        ? $promoSubtotal * (1 - (float) $promo->valordescuento / 100)
                                                                        : max(0, $promoSubtotal - (float) $promo->valordescuento);
                                                                    $promoTotal = round($promoTotal, 2);
                                                                ?>
                                                                <div class="card tarjeta-producto pos-producto border-danger h-100"
                                                                    data-pos-id="q-<?php echo e($promo->id); ?>"
                                                                    data-pos-nombre="<?php echo e($promo->nombre); ?>"
                                                                    data-pos-precio="<?php echo e(number_format($promoTotal, 2, '.', '')); ?>"
                                                                    data-pos-info="<?php echo e($promo->tipodescuento === 'PORCENTAJE' ? '-' . number_format((float) $promo->valordescuento, 0) . '%' : '-Bs. ' . number_format((float) $promo->valordescuento, 2)); ?>">
                                                                    <div class="card-body p-2">
                                                                        <?php if($promo->photo): ?>
                                                                            <img src="<?php echo e(asset('storage/' . $promo->photo)); ?>"
                                                                                class="pos-foto"
                                                                                alt="<?php echo e($promo->nombre); ?>">
                                                                        <?php else: ?>
                                                                            <div
                                                                                class="pos-foto d-flex align-items-center justify-content-center bg-danger-subtle fs-1">
                                                                                🏷️</div>
                                                                        <?php endif; ?>
                                                                        <h6 class="fw-bold small mt-2 mb-0">
                                                                            <?php echo e($promo->nombre); ?>

                                                                            <span
                                                                                class="badge text-bg-danger ms-1"><?php echo e($promo->tipodescuento === 'PORCENTAJE' ? '-' . number_format((float) $promo->valordescuento, 0) . '%' : '-Bs. ' . number_format((float) $promo->valordescuento, 2)); ?></span>
                                                                        </h6>
                                                                        <p class="text-muted small mb-2">
                                                                            <?php $__currentLoopData = $promo->sucursalesProducto->filter(fn($sp) => $sp->idsucursal == $sucursalActual->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php echo e((int) ($sp->pivot->cantidad_producto ?? 1)); ?>×
                                                                                <?php echo e($sp->producto?->nombre); ?><?php if(!$loop->last): ?>
                                                                                    ·
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </p>
                                                                        <div
                                                                            class="d-flex justify-content-between align-items-center">
                                                                            <span class="small text-muted">Oferta
                                                                                vigente</span>
                                                                            <button type="button"
                                                                                class="btn btn-outline-danger btn-sm pos-agregar"
                                                                                title="Agregar">+</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <div class="col-12 text-center text-muted py-4">No hay
                                                                promociones activas hoy.</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </section>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div id="posTab-ver" class="d-none">
                                <div class="card tarjeta-producto shadow-sm" id="posListaPedidos">
                                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                        <h2 class="h6 fw-bold mb-0">📋 Pedidos de hoy</h2>
                                        <span class="small text-muted"><?php echo e($pedidos->count()); ?> pedido(s)</span>
                                    </div>
                                    <div class="card-body">
                                        <?php
                                            $conteoEstados = [
                                                'todos' => $pedidos->count(),
                                                'pendiente' => $pedidos
                                                    ->filter(
                                                        fn($p) => !$p->venta()->exists() &&
                                                            $p->estadopedido === 'PENDIENTE',
                                                    )
                                                    ->count(),
                                                'ejecutado' => $pedidos
                                                    ->filter(
                                                        fn($p) => !$p->venta()->exists() &&
                                                            $p->estadopedido === 'EJECUTADO',
                                                    )
                                                    ->count(),
                                                'cobrado' => $pedidos->filter(fn($p) => $p->venta()->exists())->count(),
                                                'anulado' => $pedidos
                                                    ->filter(fn($p) => $p->estadopedido === 'ANULADO')
                                                    ->count(),
                                            ];
                                            $etiquetasEstados = [
                                                'todos' => ['Todos', 'text-bg-dark'],
                                                'pendiente' => ['Pendientes', 'text-bg-warning'],
                                                'ejecutado' => ['Ejecutados', 'text-bg-secondary'],
                                                'cobrado' => ['Cobrados', 'text-bg-success'],
                                                'anulado' => ['Anulados', 'text-bg-danger'],
                                            ];
                                        ?>
                                        <ul class="nav nav-pills nav-fill mb-3 small" id="posFiltroPedidos">
                                            <?php $__currentLoopData = $conteoEstados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <button type="button"
                                                        class="nav-link w-100 pos-filtro-estado <?php if($loop->first): ?> active <?php endif; ?>"
                                                        data-filtro-estado="<?php echo e($clave); ?>">
                                                        <span
                                                            class="badge <?php echo e($etiquetasEstados[$clave][1]); ?> rounded-pill"><?php echo e($total); ?></span>
                                                        <?php echo e($etiquetasEstados[$clave][0]); ?>

                                                    </button>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="pos-pedidos-lista">
                                            <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                    $filaEstado = $pedido->venta()->exists()
                                                        ? 'cobrado'
                                                        : ($pedido->estadopedido === 'EJECUTADO'
                                                            ? 'ejecutado'
                                                            : ($pedido->estadopedido === 'ANULADO'
                                                                ? 'anulado'
                                                                : 'pendiente'));
                                                    $badgeEstado = $pedido->venta()->exists()
                                                        ? ['text-bg-success', '💳 Cobrado']
                                                        : ($pedido->estadopedido === 'PENDIENTE'
                                                            ? ['text-bg-warning', 'Pendiente']
                                                            : ($pedido->estadopedido === 'EJECUTADO'
                                                                ? ['text-bg-secondary', 'Ejecutado']
                                                                : ['text-bg-danger', 'Anulado']));
                                                ?>
                                                <div class="pos-pedido-item border rounded p-3 mb-2"
                                                    data-estado-fila="<?php echo e($filaEstado); ?>">
                                                    <div class="d-flex justify-content-between align-items-start">
                                                        <div>
                                                            <strong class="fs-6">#<?php echo e($pedido->nropedido); ?></strong>
                                                            <span
                                                                class="text-muted small ms-2"><?php echo e(optional($pedido->fecha)->format('d/m H:i')); ?></span>
                                                            <div class="mt-1">
                                                                <?php if($pedido->tipopedido === 'MESA'): ?>
                                                                    <span class="badge text-bg-primary">🍽️ Mesa
                                                                        <?php echo e($pedido->mesa?->numeromesa); ?></span>
                                                                <?php else: ?>
                                                                    <span class="badge text-bg-info">🛍️ Para llevar</span>
                                                                    <?php if($pedido->horarecogida): ?>
                                                                        <span class="badge text-bg-info ms-1">🕒
                                                                            <?php echo e(\Illuminate\Support\Carbon::parse($pedido->horarecogida)->format('H:i')); ?></span>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="text-end">
                                                            <div class="fs-6 fw-bold">Bs.
                                                                <?php echo e(number_format((float) $pedido->total, 2)); ?></div>
                                                            <?php if((float) $pedido->descuentopedido > 0): ?>
                                                                <div class="small text-danger">-Bs.
                                                                    <?php echo e(number_format((float) $pedido->descuentopedido, 2)); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                            <span
                                                                class="badge mt-1 <?php echo e($badgeEstado[0]); ?>"><?php echo e($badgeEstado[1]); ?></span>
                                                        </div>
                                                    </div>
                                                    <div class="small text-muted mt-1">
                                                        <?php echo e($pedido->detalles->count()); ?> línea(s) ·
                                                        <?php echo e($pedido->empleado?->nombre ?? '—'); ?>

                                                        <?php if($pedido->venta()->exists()): ?>
                                                            · 💳 <?php echo e($pedido->venta->pagos->first()?->metodoPago?->nombre); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="mt-2 d-flex justify-content-end gap-1 flex-wrap">
                                                        <button type="button" class="btn btn-sm btn-outline-secondary"
                                                            data-bs-toggle="modal" data-bs-target="#posDetalleModal"
                                                            data-detalle-url="<?php echo e(route('dashboard.generar-pedidos.detalle', $pedido->id)); ?>">🔍
                                                            Detalle</button>

                                                        <?php if(!$pedido->venta()->exists() && in_array($pedido->estadopedido, ['PENDIENTE', 'EJECUTADO']) && $puedeEjecutar): ?>
                                                            <?php
                                                                $detallesJson = json_encode($pedido->detalles->map(fn($d) => [
                                                                    'idproductosucursal' => $d->idproductosucursal,
                                                                    'nombre' => $d->sucursalProducto?->producto?->nombre ?? 'Producto',
                                                                    'precio' => (float) $d->preciounitario,
                                                                    'cantidad' => $d->cantidad,
                                                                ])->values());
                                                                $observacionesJson = json_encode($pedido->observaciones ?? '');
                                                            ?>
                                                            <button type="button"
                                                                class="btn btn-sm btn-outline-info pos-editar"
                                                                data-pedido-id="<?php echo e($pedido->id); ?>"
                                                                data-pedido-estado="<?php echo e($pedido->estadopedido); ?>"
                                                                data-editar-url="<?php echo e(route('dashboard.generar-pedidos.editar', $pedido->id)); ?>"
                                                                data-detalles='<?php echo $detallesJson; ?>'
                                                                data-pedido-observaciones='<?php echo $observacionesJson; ?>'>
                                                                ✏️ Editar
                                                            </button>
                                                        <?php endif; ?>

                                                        <?php if($pedido->estadopedido === 'PENDIENTE' && !$pedido->venta()->exists()): ?>
                                                            <?php if($puedeEjecutar): ?>
                                                                <button type="button"
                                                                    class="btn btn-sm btn-outline-primary pos-ejecutar"
                                                                    data-url="<?php echo e(route('dashboard.generar-pedidos.ejecutar', $pedido->id)); ?>"
                                                                    data-pedido-id="<?php echo e($pedido->id); ?>">✅
                                                                    Ejecutar</button>
                                                            <?php endif; ?>
                                                            <?php if($puedePagar): ?>
                                                                <button type="button"
                                                                    class="btn btn-sm btn-success pos-cobrar"
                                                                    data-pedido-id="<?php echo e($pedido->id); ?>"
                                                                    data-pedido-total="<?php echo e(number_format((float) $pedido->total, 2, '.', '')); ?>"
                                                                    data-pedido-info="#<?php echo e($pedido->nropedido); ?> · Bs. <?php echo e(number_format((float) $pedido->total, 2)); ?>">💳
                                                                    Cobrar</button>
                                                            <?php endif; ?>
                                                            <?php if($puedeAnular): ?>
                                                                <button type="button"
                                                                    class="btn btn-sm btn-outline-danger pos-anular"
                                                                    data-url="<?php echo e(route('dashboard.generar-pedidos.anular', $pedido->id)); ?>"
                                                                    data-pedido-id="<?php echo e($pedido->id); ?>"
                                                                    data-pedido-info="#<?php echo e($pedido->nropedido); ?> · Bs. <?php echo e(number_format((float) $pedido->total, 2)); ?>">🗑️
                                                                    Anular</button>
                                                            <?php endif; ?>
                                                        <?php endif; ?>

                                                        <?php if($pedido->estadopedido === 'EJECUTADO' && !$pedido->venta()->exists() && $puedePagar): ?>
                                                            <button type="button"
                                                                class="btn btn-sm btn-success pos-cobrar"
                                                                data-pedido-id="<?php echo e($pedido->id); ?>"
                                                                data-pedido-total="<?php echo e(number_format((float) $pedido->total, 2, '.', '')); ?>"
                                                                data-pedido-info="#<?php echo e($pedido->nropedido); ?> · Bs. <?php echo e(number_format((float) $pedido->total, 2)); ?>">💳
                                                                Cobrar</button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <div class="text-center text-muted py-3">Aún no hay pedidos registrados
                                                    hoy.</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-12 col-xl-4">
                            <div class="card tarjeta-producto shadow-sm pos-cart">
                                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                    <h2 class="h6 fw-bold mb-0">🧾 Pedido actual</h2>
                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                        id="posVaciar">Vaciar</button>
                                </div>
                                <div class="card-body">
                                    <div class="pos-cart-lista" id="posCarrito">
                                        <p class="text-muted small text-center py-4" id="posCarritoVacio">
                                            Aún no agregas productos ni promociones. Toca «+» en el menú para armar el pedido.
                                        </p>
                                        <div class="list-group list-group-flush d-none" id="posCarritoItems"></div>
                                    </div>

                                    <div class="alert alert-light border small d-none mb-3" id="posResumenInfo"></div>
                                    <input type="hidden" id="posIdsucursal" value="<?php echo e($sucursalActual->id); ?>">

                                    <div class="border rounded p-3 bg-light-subtle mb-3" id="posDetallesPedido">
                                        <div class="small fw-semibold text-muted text-uppercase mb-2">Detalles del pedido
                                        </div>

                                        <div class="mb-2">
                                            <label class="form-label small fw-semibold d-block mb-1">Tipo de pedido</label>
                                            <div class="btn-group w-100" role="group" aria-label="Tipo de pedido">
                                                <input type="radio" class="btn-check" name="posTipopedido"
                                                    id="posTipoMesa" value="MESA" data-pos-tipo="mesa" checked>
                                                <label class="btn btn-outline-secondary btn-sm" for="posTipoMesa">🍽️
                                                    Mesa</label>
                                                <input type="radio" class="btn-check" name="posTipopedido"
                                                    id="posTipoLlevar" value="PARA_LLEVAR" data-pos-tipo="llevar">
                                                <label class="btn btn-outline-secondary btn-sm" for="posTipoLlevar">🛍️
                                                    Para llevar</label>
                                            </div>
                                        </div>

                                        <div id="posBloqueMesas">
                                            <label class="form-label small fw-semibold mb-1" for="posMesa">Mesa</label>
                                            <select class="form-select form-select-sm" id="posMesa">
                                                <option value="">— Elige una mesa —</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $mesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($mesa->id); ?>">Mesa <?php echo e($mesa->numeromesa); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="" disabled>No hay mesas activas en la sucursal.
                                                    </option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <div id="posBloqueLlevar" class="d-none">
                                            <label class="form-label small fw-semibold mb-1" for="posHorarecogida">Hora de
                                                recogida</label>
                                            <input type="datetime-local" id="posHorarecogida"
                                                class="form-control form-control-sm">
                                            <div class="form-text small text-muted">Opcional: hora para ordenar y recoger.
                                            </div>

                                            <label class="form-label small fw-semibold mb-1 mt-2"
                                                for="posObservaciones">Observación (opcional)</label>
                                            <textarea id="posObservaciones" class="form-control form-control-sm" rows="2"
                                                placeholder="Descripción adicional del pedido…"></textarea>
                                        </div>
                                    </div>

                                    <hr class="my-3">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="text-muted small">Subtotal</span>
                                        <span class="fw-bold" id="posSubtotal">Bs. 0.00</span>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span class="text-muted small">Total del pedido</span>
                                        <span class="fs-5 fw-bold text-brand" id="posTotal">Bs. 0.00</span>
                                    </div>

                                    <?php if(!$puedeCrear): ?>
                                        <div class="alert alert-warning small mb-2">Tu rol no puede registrar pedidos.
                                        </div>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-brand w-100" id="posConfirmar"
                                            <?php if($requiereCajaAbierta && !$aperturaAbierta): ?> disabled title="Abre la caja para registrar el pedido." <?php endif; ?>>
                                            ✅ Confirmar pedido
                                        </button>
                                        <?php if($requiereCajaAbierta && !$aperturaAbierta): ?>
                                            <p class="small text-muted text-center mt-2 mb-0">
                                                🔒 Sin apertura de caja: un cajero debe abrir la caja para registrar
                                                pedidos.
                                            </p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="modal fade" id="posAnularModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title fw-bold">🗑️ Anular pedido <span id="anularInfo"
                            class="small opacity-75"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-1">¿Estás seguro de anular el pedido <strong>#<span id="anularNro"></span></strong>?
                    </p>
                    <p class="small text-muted mb-3">Esta acción no se puede deshacer. El pedido pasará a estado
                        <strong>Anulado</strong>.
                    </p>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold" for="anularMotivo">Motivo (opcional)</label>
                        <textarea id="anularMotivo" class="form-control form-control-sm" rows="2"
                            placeholder="Motivo de la anulación…"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="anularConfirmar">Sí, anular</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="posDetalleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">🧾 Detalle del pedido</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body" id="posDetalleCuerpo">
                    <div class="text-center text-muted py-4">Cargando…</div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="posCobrarModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title fw-bold">💳 Cobrar pedido <span id="cobrarInfo"
                            class="small opacity-75"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <form id="posCobrarForm">
                        <input type="hidden" id="cobrarPedidoId" name="idpedido">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold" for="cobrarMetodo">Método de pago</label>
                            <select class="form-select" id="cobrarMetodo" name="idmetodopago" required>
                                <?php $__currentLoopData = $metodospago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mp->id); ?>" data-gateway="<?php echo e(strtoupper($mp->gateway ?: 'EFECTIVO')); ?>">
                                        <?php echo e($mp->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div id="cobrarCamposEfectivo" class="d-none">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold" for="cobrarRecibido">Monto recibido
                                    (Bs.)</label>
                                <input type="number" step="0.01" min="0" class="form-control" id="cobrarRecibido"
                                    name="montorecibido" placeholder="0.00">
                                <div class="form-text small">El sistema calculará el cambio.</div>
                            </div>
                            <div class="alert alert-light border small mb-0">
                                <div class="d-flex justify-content-between">
                                    <span>Total a pagar:</span>
                                    <strong id="cobrarTotalEfectivo">Bs. 0.00</strong>
                                </div>
                                <div class="d-flex justify-content-between text-success fw-bold mt-1">
                                    <span>Cambio:</span>
                                    <span id="cobrarCambio">Bs. 0.00</span>
                                </div>
                            </div>
                        </div>

                        <div id="cobrarCamposTarjeta" class="d-none">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold" for="cobrarMarca">Marca de tarjeta</label>
                                <select class="form-select" id="cobrarMarca" name="marcatarjeta">
                                    <option value="">— Marca —</option>
                                    <option value="Visa">Visa</option>
                                    <option value="Mastercard">Mastercard</option>
                                    <option value="American Express">American Express</option>
                                    <option value="Diners Club">Diners Club</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-semibold" for="cobrarUltimos4">Últimos 4 dígitos</label>
                                <input type="text" class="form-control" id="cobrarUltimos4" name="ultimos4"
                                    maxlength="4" inputmode="numeric" placeholder="0000">
                            </div>
                        </div>

                        <div id="cobrarCamposBanco" class="d-none">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold" for="cobrarReferencia">Referencia / N° de
                                    transferencia</label>
                                    <input type="text" class="form-control" id="cobrarReferencia" name="referencia"
                                    maxlength="100" placeholder="Ej. TRX-123456">
                                <div class="form-text small">Ingresa el código de la transferencia o QR.</div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-success" id="cobrarConfirmar">
                        <span class="spinner-border spinner-border-sm d-none" id="cobrarSpinner"></span>
                        Confirmar cobro
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="posToasts" style="z-index: 2000;"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        if (typeof $ === 'undefined' || typeof bootstrap === 'undefined') {
            console.error('jQuery o Bootstrap no se cargaron correctamente. Revisa los assets (npm run build).');
            return;
        }

        const csrf = $('meta[name="csrf-token"]').attr('content');
        const urlStore = "<?php echo e(route('dashboard.generar-pedidos.store')); ?>";
        const urlPagar = "<?php echo e(route('dashboard.generar-pedidos.pagar')); ?>";
        const puedeCrear = <?php echo e($puedeCrear ? 'true' : 'false'); ?>;
        const requiereCajaAbierta = <?php echo e($requiereCajaAbierta ? 'true' : 'false'); ?>;
        const aperturaAbierta = <?php echo e($aperturaAbierta ? 'true' : 'false'); ?>;

        let urlAnularActual = null;
        let carrito = [];
        let modoEdicion = { activo: false, id: null, url: null, estado: null };

        function toast(mensaje, tipo = 'success') {
            const $contenedor = $('#posToasts');
            const $toast = $(`
                <div class="toast align-items-center border-0 text-bg-${tipo} show" role="alert">
                    <div class="d-flex">
                        <div class="toast-body"></div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                </div>
            `);
            $toast.find('.toast-body').text(mensaje);
            $contenedor.append($toast);
            setTimeout(function() {
                $toast.remove();
            }, 5000);
        }

        function formatMoney(valor) {
            return 'Bs. ' + Number(valor || 0).toFixed(2);
        }

        function escapeHtml(texto) {
            const div = document.createElement('div');
            div.textContent = texto;
            return div.innerHTML;
        }

        function obtenerTipoPedido() {
            return $('input[name="posTipopedido"]:checked').val() || 'MESA';
        }

        function renderCarrito() {
            const $lista = $('#posCarritoItems');
            const $vacio = $('#posCarritoVacio');

            $lista.empty();

            if (carrito.length === 0) {
                $vacio.removeClass('d-none');
                $lista.addClass('d-none');
                $('#posResumenInfo').addClass('d-none').text('');
            } else {
                $vacio.addClass('d-none');
                $lista.removeClass('d-none');

                carrito.forEach((item, indice) => {
                    const lineaTotal = item.cantidad * item.precio;
                    const infoExtra = item.info ? `<div class="small text-muted">${escapeHtml(item.info)}</div>` : '';
                    const bloqueado = item.bloqueado === true;
                    const controles = bloqueado
                        ? `<span class="badge text-bg-secondary">Entregado</span>`
                        : `<div class="btn-group btn-group-sm mt-1" role="group">
                               <button type="button" class="btn btn-outline-secondary pos-cantidad-menos">−</button>
                               <span class="btn btn-light disabled px-2">${item.cantidad}</span>
                               <button type="button" class="btn btn-outline-secondary pos-cantidad-mas">+</button>
                           </div>
                           <button type="button" class="btn btn-link btn-sm text-danger pos-quitar ms-1 p-0" title="Quitar">✕</button>`;

                    $lista.append(`
                        <div class="list-group-item pos-pedido-item px-2 py-2 ${bloqueado ? 'bg-light' : ''}" data-indice="${indice}">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="flex-fill me-2">
                                    <div class="fw-semibold small">${escapeHtml(item.nombre)}</div>
                                    ${infoExtra}
                                    <div class="small text-brand">${formatMoney(item.precio)} c/u</div>
                                </div>
                                <div class="text-end">
                                    <div class="fw-bold small">${formatMoney(lineaTotal)}</div>
                                    ${controles}
                                </div>
                            </div>
                        </div>
                    `);
                });
            }

            actualizarTotales();
        }

        function actualizarTotales() {
            const subtotal = carrito.reduce((suma, item) => suma + (item.cantidad * item.precio), 0);
            $('#posSubtotal').text(formatMoney(subtotal));
            $('#posTotal').text(formatMoney(subtotal));
        }

        function agregarAlCarrito($card) {
            const id = $card.data('pos-id');
            const nombre = $card.data('pos-nombre');
            const precio = parseFloat($card.data('pos-precio')) || 0;
            const info = $card.data('pos-info') || '';

            if (!id || !nombre) {
                console.error('No se pudieron leer los datos del producto/promoción.', $card);
                toast('Error al agregar el producto.', 'danger');
                return;
            }

            const tipo = String(id).startsWith('q-') ? 'promocion' : 'producto';

            const existente = carrito.find(item => item.id === id);

            if (existente) {
                existente.cantidad += 1;
            } else {
                carrito.push({
                    id,
                    tipo,
                    nombre,
                    precio,
                    info,
                    cantidad: 1,
                    idproductosucursal: tipo === 'producto' ? parseInt(id.replace('p-', ''), 10) : null,
                    idpromocion: tipo === 'promocion' ? parseInt(id.replace('q-', ''), 10) : null,
                });
            }

            renderCarrito();
            toast('Agregado al pedido actual', 'success');
        }

        function recolectarPedido() {
            const tipopedido = obtenerTipoPedido();
            const items = carrito
                .filter(item => item.tipo === 'producto')
                .map(item => ({
                    idproductosucursal: item.idproductosucursal,
                    cantidad: item.cantidad,
                    preciounitario: item.precio,
                }));
            const promos = carrito
                .filter(item => item.tipo === 'promocion')
                .map(item => ({
                    idpromocion: item.idpromocion,
                    cantidad: item.cantidad,
                }));

            return {
                idsucursal: $('#posIdsucursal').val(),
                tipopedido,
                idmesa: tipopedido === 'MESA' ? $('#posMesa').val() : null,
                horarecogida: $('#posHorarecogida').val() || null,
                observaciones: $('#posObservaciones').val().trim() || null,
                items,
                promos,
            };
        }

        function validarPedido(datos) {
            if (datos.items.length === 0 && datos.promos.length === 0) {
                return 'Agrega al menos un producto o una promoción al pedido.';
            }
            if (datos.tipopedido === 'MESA' && !datos.idmesa) {
                return 'Selecciona una mesa para el pedido.';
            }
            return null;
        }

        // ── Tabs ──
        $(document).on('click', '[data-pos-tab]', function() {
            const tab = $(this).data('pos-tab');
            $('[data-pos-tab]').removeClass('active');
            $(this).addClass('active');
            $('#posTab-generar, #posTab-ver').addClass('d-none');
            $('#posTab-' + tab).removeClass('d-none');
        });

        // ── Filtro de categorías ──
        $(document).on('click', '[data-pos-cat]', function() {
            const categoria = $(this).data('pos-cat');
            $('[data-pos-cat]').removeClass('active');
            $(this).addClass('active');

            if (categoria === 'todos') {
                $('[data-grupo]').removeClass('d-none');
            } else if (categoria === 'promociones') {
                $('[data-grupo]').addClass('d-none');
                $('[data-grupo="promociones"]').removeClass('d-none');
            } else {
                $('[data-grupo]').addClass('d-none');
                $('[data-grupo="' + categoria + '"]').removeClass('d-none');
            }
        });

        // ── Búsqueda ──
        $('#posBusqueda').on('input', function() {
            const texto = $(this).val().trim().toLowerCase();

            if (texto === '') {
                $('.pos-item-producto, .pos-item-promo').removeClass('d-none');
                return;
            }

            $('.pos-item-producto, .pos-item-promo').each(function() {
                const buscar = $(this).data('pos-buscar') || '';
                $(this).toggleClass('d-none', !buscar.includes(texto));
            });
        });

        // ── Agregar al carrito ──
        $(document).on('click', '.pos-agregar', function(e) {
            e.preventDefault();
            const $card = $(this).closest('.pos-producto');
            agregarAlCarrito($card);
        });

        // ── Cantidades en el carrito ──
        $(document).on('click', '.pos-cantidad-mas', function() {
            const indice = $(this).closest('[data-indice]').data('indice');
            if (carrito[indice] && !carrito[indice].bloqueado) {
                carrito[indice].cantidad += 1;
                renderCarrito();
            }
        });

        $(document).on('click', '.pos-cantidad-menos', function() {
            const indice = $(this).closest('[data-indice]').data('indice');
            if (carrito[indice] && !carrito[indice].bloqueado) {
                if (carrito[indice].cantidad > 1) {
                    carrito[indice].cantidad -= 1;
                } else {
                    carrito.splice(indice, 1);
                }
                renderCarrito();
            }
        });

        $(document).on('click', '.pos-quitar', function() {
            const indice = $(this).closest('[data-indice]').data('indice');
            if (carrito[indice] && !carrito[indice].bloqueado) {
                carrito.splice(indice, 1);
                renderCarrito();
            }
        });

        // ── Vaciar carrito / cancelar edición ──
        $('#posVaciar').on('click', function() {
            if (modoEdicion.activo) {
                if (!confirm('¿Cancelar la edición del pedido?')) return;
                salirModoEdicion();
                return;
            }
            if (carrito.length === 0) return;
            if (!confirm('¿Vaciar el pedido actual?')) return;
            carrito = [];
            renderCarrito();
        });

        function salirModoEdicion() {
            modoEdicion = { activo: false, id: null, url: null, estado: null };
            carrito = [];
            renderCarrito();
            $('#posConfirmar').html('✅ Confirmar pedido');
            $('#posObservaciones').val('');
            $('#posVaciar').text('Vaciar');
        }

        // ── Tipo de pedido (mesa / para llevar) ──
        $('input[name="posTipopedido"]').on('change', function() {
            const tipo = $(this).data('pos-tipo');
            if (tipo === 'mesa') {
                $('#posBloqueMesas').removeClass('d-none');
                $('#posBloqueLlevar').addClass('d-none');
            } else {
                $('#posBloqueMesas').addClass('d-none');
                $('#posBloqueLlevar').removeClass('d-none');
            }
        });

        // ── Confirmar pedido / guardar edición ──
        $('#posConfirmar').on('click', function() {
            if (!modoEdicion.activo && !puedeCrear) {
                toast('Tu rol no puede registrar pedidos.', 'warning');
                return;
            }
            if (requiereCajaAbierta && !aperturaAbierta) {
                toast('Abre la caja para registrar pedidos.', 'warning');
                return;
            }

            const $boton = $(this);
            const datos = recolectarPedido();

            // En edición de ejecutado solo enviamos las líneas nuevas (no bloqueadas)
            if (modoEdicion.activo && modoEdicion.estado === 'EJECUTADO') {
                datos.items = carrito
                    .filter(item => item.tipo === 'producto' && !item.bloqueado)
                    .map(item => ({
                        idproductosucursal: item.idproductosucursal,
                        cantidad: item.cantidad,
                        preciounitario: item.precio,
                    }));
                datos.promos = carrito
                    .filter(item => item.tipo === 'promocion' && !item.bloqueado)
                    .map(item => ({
                        idpromocion: item.idpromocion,
                        cantidad: item.cantidad,
                    }));
            }

            const error = validarPedido(datos);
            if (error) {
                toast(error, 'danger');
                return;
            }

            const esEdicion = modoEdicion.activo;
            const url = esEdicion ? modoEdicion.url : urlStore;
            const textoCargando = esEdicion ? 'Guardando…' : 'Registrando…';
            const textoExito = esEdicion ? '✅ Guardar cambios' : '✅ Confirmar pedido';

            $boton.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> ' + textoCargando);

            $.ajax({
                url: url,
                type: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf,
                },
                data: datos,
                dataType: 'json',
            })
            .done(function(respuesta) {
                salirModoEdicion();
                toast(respuesta.message || 'Pedido guardado correctamente.', 'success');
                setTimeout(function() {
                    window.location.href = respuesta.redirect || window.location.href;
                }, 700);
            })
            .fail(function(xhr) {
                let mensaje = 'No se pudo guardar el pedido.';
                if (xhr.responseJSON) {
                    mensaje = xhr.responseJSON.message || mensaje;
                    if (xhr.responseJSON.errors) {
                        const errores = xhr.responseJSON.errors;
                        const primeraClave = Object.keys(errores)[0];
                        if (primeraClave) mensaje = errores[primeraClave][0];
                    }
                }
                toast(mensaje, 'danger');
            })
            .always(function() {
                $boton.prop('disabled', false).html(textoExito);
            });
        });

        // ── Filtro de estados en "Ver pedidos" ──
        $(document).on('click', '[data-filtro-estado]', function() {
            const filtro = $(this).data('filtro-estado');
            $('[data-filtro-estado]').removeClass('active');
            $(this).addClass('active');

            $('[data-estado-fila]').each(function() {
                const estado = $(this).data('estado-fila');
                $(this).toggleClass('d-none', filtro !== 'todos' && estado !== filtro);
            });
        });

        // ── Cobrar pedido (modal pasarela) ──
        let cobrarTotal = 0;

        $(document).on('click', '.pos-cobrar', function() {
            const $boton = $(this);
            const pedidoId = $boton.data('pedido-id');
            const pedidoInfo = $boton.data('pedido-info');
            const pedidoTotal = parseFloat($boton.data('pedido-total')) || 0;

            $('#cobrarPedidoId').val(pedidoId);
            $('#cobrarInfo').text(pedidoInfo ? ' (' + pedidoInfo + ')' : '');

            // Seleccionar efectivo por defecto (primera opción con gateway EFECTIVO)
            const $metodoEfectivo = $('#cobrarMetodo option[data-gateway="EFECTIVO"]').first();
            $('#cobrarMetodo').val($metodoEfectivo.length ? $metodoEfectivo.val() : '').trigger('change');

            $('#cobrarRecibido, #cobrarUltimos4, #cobrarReferencia').val('');
            $('#cobrarMarca').val('');

            cobrarTotal = pedidoTotal;
            $('#cobrarTotalEfectivo').text(formatMoney(cobrarTotal));
            $('#cobrarCambio').text(formatMoney(0));

            const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('posCobrarModal'));
            modal.show();
        });

        $('#cobrarMetodo').on('change', function() {
            const gateway = $('option:selected', this).data('gateway') || 'EFECTIVO';
            $('#cobrarCamposEfectivo, #cobrarCamposTarjeta, #cobrarCamposBanco').addClass('d-none');

            if (gateway === 'EFECTIVO') {
                $('#cobrarCamposEfectivo').removeClass('d-none');
            } else if (gateway === 'TARJETA') {
                $('#cobrarCamposTarjeta').removeClass('d-none');
            } else if (gateway === 'BANCO') {
                $('#cobrarCamposBanco').removeClass('d-none');
            }
        });

        $('#cobrarRecibido').on('input', function() {
            const recibido = parseFloat($(this).val()) || 0;
            const cambio = Math.max(0, recibido - cobrarTotal);
            $('#cobrarCambio').text(formatMoney(cambio));
        });

        //cuando clickea confirmar pago, en esta situacion se debe de modificar la pasarela de pago
        $('#cobrarConfirmar').on('click', function() {
            const $boton = $(this);
            const idmetodopago = $('#cobrarMetodo').val();

            if (!idmetodopago) {
                toast('Selecciona un método de pago.', 'danger');
                return;
            }

            const gateway = $('#cobrarMetodo option:selected').data('gateway') || 'EFECTIVO';
            const datos = {
                idpedido: $('#cobrarPedidoId').val(),
                idmetodopago,
            };

            if (gateway === 'EFECTIVO') {
                datos.montorecibido = $('#cobrarRecibido').val();
            } else if (gateway === 'TARJETA') {
                datos.ultimos4 = $('#cobrarUltimos4').val();
                datos.marcatarjeta = $('#cobrarMarca').val();
            } else if (gateway === 'BANCO') {
                datos.referencia = $('#cobrarReferencia').val();
            }

            $boton.prop('disabled', true);
            $('#cobrarSpinner').removeClass('d-none');
            $.ajax({
                url: urlPagar,
                type: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf,
                },
                data: datos,
                dataType: 'json',
            }).done(function(respuesta) {
                bootstrap.Modal.getInstance(document.getElementById('posCobrarModal')).hide();
                toast(respuesta.message || 'Pago registrado correctamente.', 'success');
                setTimeout(function() {
                    window.location.href = respuesta.redirect || window.location.href;
                }, 700);
            }).fail(function(xhr) {
                let mensaje = 'No se pudo registrar el pago.';
                if (xhr.responseJSON) {
                    mensaje = xhr.responseJSON.message || mensaje;
                    if (xhr.responseJSON.errors) {
                        const errores = xhr.responseJSON.errors;
                        const primeraClave = Object.keys(errores)[0];
                        if (primeraClave) mensaje = errores[primeraClave][0];
                    }
                }
                toast(mensaje, 'danger');
            }).always(function() {
                $boton.prop('disabled', false);
                $('#cobrarSpinner').addClass('d-none');
            });
        });

        // ── Editar pedido ──
        $(document).on('click', '.pos-editar', function() {
            const $boton = $(this);
            const pedidoId = $boton.data('pedido-id');
            const estado = $boton.data('pedido-estado');
            const url = $boton.data('editar-url');
            const detalles = $boton.data('detalles') || [];
            let observaciones = '';
            try {
                observaciones = JSON.parse($boton.attr('data-pedido-observaciones') || '""');
            } catch (e) {
                observaciones = $boton.attr('data-pedido-observaciones') || '';
            }

            modoEdicion = { activo: true, id: pedidoId, url: url, estado: estado };

            carrito = detalles.map(function(d) {
                return {
                    id: 'p-' + d.idproductosucursal,
                    tipo: 'producto',
                    idproductosucursal: d.idproductosucursal,
                    nombre: d.nombre,
                    precio: d.precio,
                    info: '',
                    cantidad: d.cantidad,
                    bloqueado: estado === 'EJECUTADO',
                };
            });

            renderCarrito();

            $('#posObservaciones').val(observaciones);
            $('#posConfirmar').html('✅ Guardar cambios');
            $('#posVaciar').text('Cancelar edición');

            // Cambiar al tab de generar pedidos
            $('[data-pos-tab="generar"]').trigger('click');

            toast('Editando pedido #' + pedidoId + '. Las líneas entregadas no se pueden quitar.', 'info');
        });

        // ── Anular pedido ──
        $(document).on('click', '.pos-anular', function(e) {
            e.preventDefault();

            const $boton = $(this);
            const pedidoId = $boton.data('pedido-id');
            const pedidoInfo = $boton.data('pedido-info');
            const url = $boton.data('url');

            urlAnularActual = url;
            $('#anularNro').text(pedidoId);
            $('#anularInfo').text(pedidoInfo ? ' (' + pedidoInfo + ')' : '');
            $('#anularMotivo').val('');

            const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('posAnularModal'));
            modal.show();
        });

        $(document).on('click', '#anularConfirmar', function(e) {
            e.preventDefault();

            if (!urlAnularActual) {
                toast('No se encontró la URL para anular el pedido.', 'danger');
                return;
            }

            const $boton = $(this);
            const motivo = $('#anularMotivo').val().trim();

            $boton.prop('disabled', true).html('⏳ Anulando...');

            $.ajax({
                url: urlAnularActual,
                type: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf
                },
                data: { motivo: motivo || null },
                dataType: 'json'
            })
            .done(function(respuesta) {
                const modal = bootstrap.Modal.getInstance(document.getElementById('posAnularModal'));
                if (modal) modal.hide();

                toast(respuesta.message || 'Pedido anulado correctamente.', 'success');
                setTimeout(function() {
                    window.location.href = respuesta.redirect || window.location.href;
                }, 600);
            })
            .fail(function(xhr) {
                let mensaje = 'No se pudo anular el pedido.';
                if (xhr.responseJSON) {
                    mensaje = xhr.responseJSON.message || mensaje;
                    if (xhr.responseJSON.errors) {
                        const errores = xhr.responseJSON.errors;
                        const primeraClave = Object.keys(errores)[0];
                        if (primeraClave) mensaje = errores[primeraClave][0];
                    }
                }
                toast(mensaje, 'danger');
            })
            .always(function() {
                $boton.prop('disabled', false).html('Sí, anular');
            });
        });

        // ── Ejecutar pedido ──
        $(document).on('click', '.pos-ejecutar', function(e) {
            e.preventDefault();

            const $boton = $(this);
            const url = $boton.data('url');

            if (!url) {
                toast('No se encontró la URL para ejecutar el pedido.', 'danger');
                return;
            }

            $boton.prop('disabled', true).html('⏳ Ejecutando...');

            $.ajax({
                url: url,
                type: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': csrf
                },
                dataType: 'json'
            })
            .done(function(respuesta) {
                toast(respuesta.message || 'Pedido ejecutado correctamente.', 'success');
                setTimeout(function() {
                    window.location.href = respuesta.redirect || window.location.href;
                }, 600);
            })
            .fail(function(xhr) {
                let mensaje = 'No se pudo ejecutar el pedido.';
                if (xhr.responseJSON) mensaje = xhr.responseJSON.message || mensaje;
                toast(mensaje, 'danger');
            })
            .always(function() {
                $boton.prop('disabled', false).html('✅ Ejecutar');
            });
        });

        // ── Detalle de pedido ──
        $(document).on('click', '[data-detalle-url]', function(e) {
            e.preventDefault();

            const url = $(this).data('detalle-url');
            $('#posDetalleCuerpo').html('<div class="text-center text-muted py-4">Cargando…</div>');

            $.ajax({
                url: url,
                type: 'GET',
                headers: { 'Accept': 'application/json' },
                dataType: 'json'
            })
            .done(function(respuesta) {
                $('#posDetalleCuerpo').html(respuesta.html);
            })
            .fail(function(xhr) {
                console.error('ERROR REAL DEL DETALLE', xhr.status, xhr.responseText);
                $('#posDetalleCuerpo').html(`
                    <div class="alert alert-danger">
                        <strong>Error:</strong> No se pudo cargar el detalle del pedido.
                    </div>
                `);
            });
        });
    });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/generar-pedidos/index.blade.php ENDPATH**/ ?>