<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RolPermisoSeeder extends Seeder
{
    private const PERMISOS = [
        // CONFIGURACIÓN DEL SISTEMA
        '50' => 'Registrar o modificar configuración del sistema',
        // EMPLEADOS
        '100' => 'Crear nuevo empleado',
        '101' => 'Editar empleados',
        '102' => 'Listar empleados',
        '105' => 'Dar de baja a empleado',
        '106' => 'Modificar contraseña de empleado',
        '107' => 'Listar empleados activos',
        '108' => 'Listar empleados inactivos',
        '150' => 'Listar bitácora de acceso de empleados',
        '151' => 'Listar bitácora de acciones de empleados',
        // SUCURSALES
        '200' => 'Crear nueva sucursal',
        '201' => 'Editar datos de sucursal',
        '202' => 'Listar sucursales',
        '204' => 'Asignar gerente a sucursal',
        '205' => 'Dar de baja a sucursal',
        '206' => 'Asignar empleado a sucursal',
        '207' => 'Quitar empleado de sucursal',
        '208' => 'Listar empleados de sucursal',
        // MESAS Y HORARIOS
        '210' => 'Registrar mesa',
        '211' => 'Editar mesa',
        '212' => 'Listar mesas',
        '215' => 'Dar de baja a mesa',
        '220' => 'Registrar horario de atención de sucursal',
        '221' => 'Editar horario de atención de sucursal',
        '222' => 'Listar horario de atención de sucursal',
        '225' => 'Dar de baja a horario de atención de sucursal',
        // CATEGORÍAS Y PRODUCTOS
        '300' => 'Crear nueva categoría',
        '301' => 'Editar categoría',
        '302' => 'Listar categorías',
        '305' => 'Dar de baja a categoría',
        '310' => 'Crear producto',
        '311' => 'Editar producto',
        '312' => 'Listar productos',
        '315' => 'Dar de baja a producto',
        '316' => 'Registrar precio y disponibilidad de producto por sucursal',
        '317' => 'Listar productos disponibles de sucursal',
        '318' => 'Editar precio de producto de sucursal',
        '319' => 'Deshabilitar disponibilidad de producto',
        '320' => 'Listar historial de producto por sucursal',
        // UNIDAD DE MEDIDA, INSUMOS E INVENTARIOS
        '330' => 'Crear unidad de medida',
        '331' => 'Editar unidad de medida',
        '335' => 'Dar de baja unidad de medida',
        '336' => 'Crear insumo',
        '337' => 'Editar datos de insumo',
        '338' => 'Dar de baja insumo',
        '340' => 'Crear detalle de receta',
        '341' => 'Modificar detalle de receta',
        '345' => 'Dar de baja detalle de receta',
        '346' => 'Registrar movimiento de inventario',
        '347' => 'Listar inventario y movimientos de sucursal',
        '348' => 'Establecer cantidad mínima de inventario',
        // PROMOCIONES Y CUPONES
        '350' => 'Crear promoción en una sucursal',
        '351' => 'Editar promoción de sucursal',
        '352' => 'Listar promociones',
        '355' => 'Dar de baja a promoción de sucursal',
        // CAJA
        '400' => 'Crear nueva caja',
        '401' => 'Editar datos de caja',
        '402' => 'Listar cajas',
        '405' => 'Dar de baja a caja',
        '410' => 'Crear apertura de caja',
        '411' => 'Editar apertura de caja',
        '412' => 'Listar historial de aperturas por caja',
        '415' => 'Dar de baja a apertura de caja',
        // MOVIMIENTOS Y CIERRE
        '420' => 'Registrar movimiento de caja',
        '421' => 'Editar movimiento de caja',
        '422' => 'Listar movimientos de caja',
        '425' => 'Dar de baja a movimiento de caja',
        '430' => 'Crear cierre de caja',
        '436' => 'Ver detalle de cierre de caja',
        '437' => 'Listar historial de cierre de caja',
        // VENTAS Y PAGOS
        '440' => 'Registrar venta',
        '441' => 'Editar venta',
        '442' => 'Listar ventas',
        '445' => 'Anular venta',
        '446' => 'Registrar método de pago',
        '447' => 'Dar de baja a método de pago',
        '448' => 'Listar métodos de pago',
        // PEDIDOS
        '500' => 'Crear pedido',
        '501' => 'Editar pedido',
        '502' => 'Listar pedidos',
        '505' => 'Dar de baja a pedido',
        '506' => 'Editar detalle de pedido',
    ];

    private const ROLES_POR_PERMISO = [
        'MESERO' => ['106', '212', '302', '500', '501', '502', '505', '506'],
        'CAJERO' => ['106', '210', '211', '212', '215', '222', '302', '317', '319', '352',
            '402', '410', '411', '412', '420', '421', '422', '425', '430', '436', '437',
            '346', '347', '348',
            '440', '441', '442', '445', '448', '500', '501', '502', '505', '506'],
        'GERENTE' => ['100', '101', '102', '105', '106',
            '201', '206', '207', '208',
            '210', '211', '212', '215', '220', '221', '222', '225',
            '316', '317', '318', '319', '320', '330', '331', '335', '336', '337', '338',
            '340', '341', '345', '346', '347', '348',
            '350', '351', '352', '355',
            '400', '401', '402', '405', '410', '411', '412', '415', '420', '421', '422',
            '425', '430', '436', '437', '440', '441', '442', '445', '448',
            '500', '501', '502', '505', '506'],
    ];

    public function run(): void
    {
        foreach (self::PERMISOS as $codigo => $nombre) {
            DB::table('permiso')->updateOrInsert(
                ['codigo' => $codigo],
                ['nombre' => $nombre, 'estado' => true]
            );
        }

        $this->limpiarPermisosAntiguos();

        // El ADMINISTRADOR recibe el catálogo completo (acceso total).
        $asignaciones = self::ROLES_POR_PERMISO;
        $asignaciones['ADMINISTRADOR'] = array_keys(self::PERMISOS);

        foreach ($asignaciones as $clave => $codigos) {
            $idRol = DB::table('rol')->where('claverol', $clave)->value('id');

            DB::table('rolpermiso')->where('idrol', $idRol)->delete();

            foreach ($codigos as $codigo) {
                $idPermiso = DB::table('permiso')->where('codigo', $codigo)->value('id');

                DB::table('rolpermiso')->insertOrIgnore([
                    'idrol' => $idRol,
                    'idpermiso' => $idPermiso,
                ]);
            }
        }
    }

    /**
     * Elimina permisos que ya no forman parte del catálogo (p. ej. los VER_* anteriores),
     * reasignando primero las bitácoras que los referencian.
     */
    private function limpiarPermisosAntiguos(): void
    {
        $catalogo = array_keys(self::PERMISOS);

        $antiguos = DB::table('permiso')
            ->whereNotIn('codigo', $catalogo)
            ->pluck('id');

        if ($antiguos->isEmpty()) {
            return;
        }

        $reemplazo = DB::table('permiso')->where('codigo', '102')->value('id')
            ?? DB::table('permiso')->first()->id;

        DB::table('bitacoraaccion')
            ->whereIn('idpermiso', $antiguos)
            ->update(['idpermiso' => $reemplazo]);

        DB::table('rolpermiso')->whereIn('idpermiso', $antiguos)->delete();

        DB::table('permiso')->whereIn('id', $antiguos)->delete();
    }
}
