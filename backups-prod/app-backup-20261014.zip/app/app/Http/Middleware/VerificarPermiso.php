<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class VerificarPermiso
{
    public function handle(Request $request, Closure $next, string ...$permisos): Response
    {
        $user = $request->user();

        if (! $user?->empleado?->rol) {
            abort(403, 'No tienes permiso para acceder a este módulo.');
        }

        $usuarioPermisos = $user->empleado->rol->permisos
            ->where('estado', true)
            ->pluck('codigo');

        $tieneAlguno = collect($permisos)->intersect($usuarioPermisos)->isNotEmpty();

        if (! $tieneAlguno) {
            abort(403, 'No tienes permiso para acceder a este módulo.');
        }

        return $next($request);
    }
}
