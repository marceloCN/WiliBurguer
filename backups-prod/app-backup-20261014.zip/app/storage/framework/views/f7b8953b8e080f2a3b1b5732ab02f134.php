<?php $__env->startSection('title', 'Sucursales · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Sucursales</h1>
                <p class="text-muted mb-0">Administra los datos, gerentes y horarios de cada sucursal.</p>
            </div>
            <?php if(auth()->user()->empleado?->rol?->claverol === 'ADMINISTRADOR'): ?>
                <a href="<?php echo e(route('dashboard.sucursales.crear')); ?>" class="btn btn-brand">
                    + Nueva sucursal
                </a>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if($sucursales->isEmpty()): ?>
            <div class="alert alert-light">No tienes sucursales disponibles.</div>
        <?php else: ?>
            <div class="row g-3">
                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-6 col-xl-4">
                        <div class="card tarjeta-producto h-100">
                            <div id="mapa-sucursal-<?php echo e($sucursal->id); ?>" class="sucursal-mapa"
                                     data-lat="<?php echo e(number_format((float) $sucursal->latitud, 6, '.', '')); ?>"
                                     data-lng="<?php echo e(number_format((float) $sucursal->longitud, 6, '.', '')); ?>"></div>
                            <div class="card-body d-flex flex-column">
                                <h2 class="h5 fw-bold mb-1"><?php echo e($sucursal->nombre); ?></h2>
                                <p class="small text-muted mb-1">📍 <?php echo e($sucursal->direccion); ?></p>
                                <p class="small text-muted mb-1">📞 <?php echo e($sucursal->telefono); ?></p>
                                <p class="small text-muted mb-3">
                                    🌐 <?php echo e(number_format((float) $sucursal->latitud, 6)); ?>, <?php echo e(number_format((float) $sucursal->longitud, 6)); ?>

                                    <?php if($sucursal->gerente): ?>
                                        · Gerente: <?php echo e($sucursal->gerente->nombre); ?> <?php echo e($sucursal->gerente->apellido); ?>

                                    <?php endif; ?>
                                </p>
                                <div class="mt-auto">
                                    <a href="<?php echo e(route('dashboard.sucursales.editar', $sucursal)); ?>" class="btn btn-brand btn-sm">
                                        Editar sucursal
                                    </a>
                                    <span class="small text-muted ms-1">
                                        <?php echo e($sucursal->horarios->count()); ?> horario(s)
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        .sucursal-mapa {
            height: 170px;
            border-radius: 1rem 1rem 0 0;
            background: #eee;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        document.querySelectorAll('[id^="mapa-sucursal-"]').forEach(function (contenedor) {
            const id = contenedor.id.replace('mapa-sucursal-', '');
            const lat = parseFloat(contenedor.dataset.lat);
            const lng = parseFloat(contenedor.dataset.lng);
            const mapa = L.map(contenedor.id, { scrollWheelZoom: false }).setView([lat, lng], 15);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap'
            }).addTo(mapa);
            L.marker([lat, lng]).addTo(mapa);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/sucursales/index.blade.php ENDPATH**/ ?>