<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['nombredia', 'numerodia'])]
class DiaAtencion extends Model
{
    public $timestamps = false;

    protected $table = 'diaatencion';

    protected function casts(): array
    {
        return [
            'numerodia' => 'integer',
        ];
    }

    public function horarios(): HasMany
    {
        return $this->hasMany(HorarioSucursal::class, 'iddiaatencion');
    }
}
