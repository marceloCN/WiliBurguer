<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use App\Models\Sucursal;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\View\View;

class DashboardController extends Controller
{
    /**
     * Módulos agrupados por dominio. Cada módulo define los códigos de permiso
     * (ver baseDeDatos.sql) que permiten verlo/operarlo.
     */
    private const MODULOS = [
        'pedidos' => [
            'titulo' => 'Generar pedidos',
            'descripcion' => 'Atiende pedidos de mesa o para llevar, aplica descuentos y registra el cobro.',
            'icono' => '🧾',
            'color' => 'text-bg-success',
            'ruta' => 'dashboard.generar-pedidos.index',
            'activo' => true,
            'restriccion' => 'con_sucursal',
            'permisos' => ['500', '501', '502', '505', '506'],
        ],
        'empleados' => [
            'titulo' => 'Empleados',
            'descripcion' => 'Registra y administra empleados y sus cuentas.',
            'icono' => '🧑‍💼',
            'color' => 'text-bg-primary',
            'ruta' => 'dashboard.usuarios.index',
            'activo' => true,
            'restriccion' => 'admin_o_gerente_con_sucursal',
            'permisos' => ['100', '101', '102', '105'],
        ],
        'sucursales' => [
            'titulo' => 'Sucursales',
            'descripcion' => 'Administra sucursales, su ubicación y horarios.',
            'icono' => '🏬',
            'color' => 'text-bg-warning',
            'ruta' => 'dashboard.sucursales.index',
            'activo' => true,
            'restriccion' => 'solo_admin',
            'permisos' => ['200', '201', '202', '204', '205', '206', '207', '208'],
        ],
        'horarios' => [
            'titulo' => 'Horarios de atención',
            'descripcion' => 'Gestiona los horarios de atención de la sucursal.',
            'icono' => '🕒',
            'color' => 'text-bg-info',
            'ruta' => 'dashboard.sucursales.index',
            'activo' => true,
            'restriccion' => 'admin_o_gerente_con_sucursal_unica',
            'permisos' => ['220', '221', '222', '225'],
        ],
        'menu' => [
            'titulo' => 'Menú de productos',
            'descripcion' => 'Administra categorías y productos del menú en una sola pantalla.',
            'icono' => '🍔',
            'color' => 'text-bg-success',
            'ruta' => 'dashboard.menu.index',
            'activo' => true,
            'restriccion' => 'solo_admin',
            'permisos' => ['300', '301', '302', '305', '310', '311', '312', '315'],
        ],
        'insumos' => [
            'titulo' => 'Insumos y recetas',
            'descripcion' => 'Administra unidades de medida, insumos y la receta de cada producto.',
            'icono' => '📦',
            'color' => 'text-bg-secondary',
            'ruta' => 'dashboard.insumos.index',
            'activo' => true,
            'permisos' => ['330', '331', '335', '336', '337', '338', '340', '341', '345'],
        ],
        'inventario' => [
            'titulo' => 'Inventario',
            'descripcion' => 'Registra movimientos de entrada y salida de insumos por sucursal.',
            'icono' => '📊',
            'color' => 'text-bg-warning',
            'ruta' => 'dashboard.inventario.index',
            'activo' => true,
            'restriccion' => 'con_sucursal',
            'permisos' => ['346', '347', '348'],
        ],
        'productos-sucursal' => [
            'titulo' => 'Productos por sucursal',
            'descripcion' => 'Define qué productos existen en cada sucursal, su precio y su disponibilidad.',
            'icono' => '🧾',
            'color' => 'text-bg-warning',
            'ruta' => 'dashboard.productos-sucursal.index',
            'activo' => true,
            'restriccion' => 'con_sucursal',
            'permisos' => ['316', '317', '318', '319', '320'],
        ],
        'promociones' => [
            'titulo' => 'Promociones',
            'descripcion' => 'Crea y administra promociones por sucursal.',
            'icono' => '🏷️',
            'color' => 'text-bg-info',
            'ruta' => 'dashboard.promociones.index',
            'activo' => true,
            'restriccion' => 'con_sucursal',
            'permisos' => ['350', '351', '352', '355'],
        ],
        'caja' => [
            'titulo' => 'Caja y jornadas',
            'descripcion' => 'Abre la caja, registra movimientos y cierra la jornada.',
            'icono' => '🔐',
            'color' => 'text-bg-success',
            'ruta' => 'dashboard.caja.index',
            'activo' => true,
            'restriccion' => 'con_sucursal',
            'permisos' => ['410', '411', '412', '415', '420', '421', '422', '425', '430', '436', '437'],
        ],
        'ventas' => [
            'titulo' => 'Ventas y pagos',
            'descripcion' => 'Registra ventas y métodos de pago.',
            'icono' => '💳',
            'color' => 'text-bg-primary',
            'ruta' => null,
            'activo' => false,
            'permisos' => ['440', '441', '442', '445', '446', '447', '448'],
        ],
        'bitacoras' => [
            'titulo' => 'Bitácoras',
            'descripcion' => 'Audita accesos y acciones del sistema.',
            'icono' => '📜',
            'color' => 'text-bg-secondary',
            'ruta' => null,
            'activo' => false,
            'permisos' => ['150', '151'],
        ],
    ];

    public function index(Request $request): View|RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');
        $rol = $empleado->rol;

        // El mesero aterriza directamente en la ventana de atención (Generar
        // pedidos); si no hay apertura de caja, la vista le muestra el mensaje
        // correspondiente. Cajero y gerente entran al panel de administración
        // (dashboard) como inicio y desde allí abren la caja o generan pedidos.
        if ($rol->claverol === 'MESERO' && ! $request->has('panel')) {
            return redirect()->route('dashboard.generar-pedidos.index', ['idsucursal' => $request->integer('idsucursal')]);
        }

        $sinSucursal = ! $this->empleadoTieneSucursal($empleado);

        $permisos = $sinSucursal
            ? []
            : $this->modulosDisponibles(
                $rol->permisos->where('estado', true)->pluck('codigo'),
                $empleado
            );

        return view('dashboard', compact(
            'empleado',
            'rol',
            'permisos',
            'sinSucursal',
        ));
    }

    /** Sucursales que el empleado puede operar (misma regla que promociones/caja). */
    private function sucursalesPermitidas(Empleado $empleado): Collection
    {
        $claverol = $empleado->rol?->claverol;

        if ($claverol === 'ADMINISTRADOR') {
            return Sucursal::orderBy('nombre')->get();
        }

        if ($claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->orderBy('nombre')
                ->get();
        }

        return $empleado->idsucursal
            ? Sucursal::where('id', $empleado->idsucursal)->get()
            : collect();
    }

    private function empleadoTieneSucursal(Empleado $empleado): bool
    {
        if ($empleado->rol->claverol === 'ADMINISTRADOR') {
            return true;
        }

        if ($empleado->rol->claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->exists();
        }

        return $empleado->idsucursal !== null;
    }

    private function modulosDisponibles(Collection $codigos, Empleado $empleado): array
    {
        $modulos = [];

        foreach (self::MODULOS as $clave => $modulo) {
            $tieneAlguno = collect($modulo['permisos'])->intersect($codigos)->isNotEmpty();

            if ($tieneAlguno && isset($modulo['restriccion'])) {
                $tieneAlguno = $this->cumpleRestriccion($modulo['restriccion'], $empleado);
            }

            if ($tieneAlguno && $clave === 'horarios' && $empleado->rol->claverol === 'GERENTE') {
                $modulo = $this->rutaHorariosGerente($modulo, $empleado);
            }

            if ($tieneAlguno) {
                $modulos[$clave] = $modulo;
            }
        }

        return $modulos;
    }

    private function rutaHorariosGerente(array $modulo, Empleado $empleado): array
    {
        $sucursal = $empleado->sucursalesGerenciadas()
            ->where('estado', true)
            ->first();

        if ($sucursal) {
            $modulo['ruta'] = 'dashboard.sucursales.editar';
            $modulo['parametros'] = ['sucursal' => $sucursal->id];
        }

        return $modulo;
    }

    private function cumpleRestriccion(string $restriccion, Empleado $empleado): bool
    {
        return match ($restriccion) {
            'admin_o_gerente_con_sucursal' => $this->empleadoPuedeUsuarios($empleado),
            'admin_o_gerente_con_sucursal_unica' => $this->empleadoEsAdminOGerenteSucursalUnica($empleado),
            'solo_admin' => $empleado->rol->claverol === 'ADMINISTRADOR',
            'con_sucursal' => $this->empleadoTieneSucursal($empleado),
            default => true,
        };
    }

    private function empleadoEsAdminOGerenteSucursalUnica(Empleado $empleado): bool
    {
        if ($empleado->rol->claverol === 'ADMINISTRADOR') {
            return true;
        }

        if ($empleado->rol->claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->count() === 1;
        }

        return false;
    }

    private function empleadoPuedeUsuarios(Empleado $empleado): bool
    {
        if ($empleado->rol->claverol === 'ADMINISTRADOR') {
            return true;
        }

        if ($empleado->rol->claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->exists();
        }

        return false;
    }
}
