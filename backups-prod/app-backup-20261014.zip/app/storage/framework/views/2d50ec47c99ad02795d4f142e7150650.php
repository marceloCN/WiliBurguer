<?php $__env->startSection('title', 'Promociones · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .promo-foto { width: 100%; max-height: 220px; object-fit: cover; border-radius: .5rem .5rem 0 0; }
        .promo-foto-preview { max-width: 100%; max-height: 160px; object-fit: cover; margin-top: .5rem; border-radius: .5rem; border: 1px solid #dee2e6; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Promociones 🏷️</h1>
                <p class="text-muted mb-0">Crea y administra promociones por sucursal.</p>
            </div>
            <?php if($puedeCrear): ?>
                <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearPromocionModal">
                    + Nueva promoción
                </button>
            <?php endif; ?>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <p class="small text-muted mb-3">
            Las promociones aplican un <strong>descuento</strong> (por porcentaje o monto fijo) a uno o más
            <strong>productos</strong> de la sucursal durante un periodo definido (<strong>fecha de inicio</strong> y
            <strong>fin</strong>). Solo <strong>gerentes y administradores</strong> pueden crearlas, editarlas o darlas
            de baja; <strong>cajeros y meseros</strong> solo consultan el listado.
        </p>

        <div class="row g-4">
            
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursal</span>
                        <span class="badge text-bg-dark"><?php echo e($sucursales->count()); ?></span>
                    </div>
                    <div class="list-group">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('dashboard.promociones.index', ['idsucursal' => $sucursal->id])); ?>"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                      <?php echo e($sucursalActual->id === $sucursal->id ? 'active' : ''); ?>">
                                <span class="fw-semibold"><?php echo e($sucursal->nombre); ?></span>
                                <?php if(!$sucursal->estado): ?>
                                    <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light">
                        <span class="fw-bold">Resumen</span>
                    </div>
                    <div class="card-body small">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="text-muted">Promociones</span>
                            <span class="fw-bold"><?php echo e($promociones->count()); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-1">
                            <span class="text-muted">Vigentes hoy</span>
                            <span class="fw-bold"><?php echo e($promociones->filter(fn ($p) => $p->activo && $p->fechainicio <= now() && $p->fechafin >= now())->count()); ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted">Productos aptos</span>
                            <span class="fw-bold"><?php echo e($sucursalProductos->count()); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-12 col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                    <span class="badge text-bg-brand"><?php echo e($sucursalActual->nombre); ?></span>
                    <span class="text-muted small">Promociones aplicables a esta sucursal</span>
                </div>

                <div class="d-grid gap-3">
                    <?php $__empty_1 = true; $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promocion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card tarjeta-producto">
                            <?php if($promocion->photo): ?>
                                <img src="<?php echo e(asset('storage/'.$promocion->photo)); ?>"
                                     class="promo-foto" alt="Imagen de la promoción <?php echo e($promocion->nombre); ?>">
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                                    <div class="min-w-0">
                                        <h2 class="h5 fw-bold mb-1"><?php echo e($promocion->nombre); ?></h2>
                                        <p class="small text-muted mb-1">
                                            📅 <?php echo e($promocion->fechainicio->format('d/m/Y H:i')); ?>

                                            → <?php echo e($promocion->fechafin->format('d/m/Y H:i')); ?>

                                        </p>
                                        <p class="mb-0 small text-muted">
                                            Productos:
                                            <?php $__empty_2 = true; $__currentLoopData = $promocion->sucursalesProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <span class="badge rounded-pill text-bg-light border me-1">
                                                    <?php echo e((int) ($sp->pivot->cantidad_producto ?? 1)); ?>× <?php echo e($sp->producto?->nombre); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <span class="text-secondary">Sin productos asignados</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="text-end d-flex flex-column align-items-end gap-2">
                                        <span class="badge fs-6
                                            <?php if(! $promocion->activo): ?> text-bg-secondary
                                            <?php elseif($promocion->fechainicio > now()): ?> text-bg-warning
                                            <?php elseif($promocion->fechafin < now()): ?> text-bg-dark
                                            <?php else: ?> text-bg-success <?php endif; ?>">
                                            <?php echo e($promocion->tipodescuento === 'PORCENTAJE' ? number_format($promocion->valordescuento, 2).' %' : 'Bs. '.number_format($promocion->valordescuento, 2)); ?>

                                        </span>
                                        <span class="badge rounded-pill <?php echo e($promocion->activo ? 'text-bg-success' : ($promocion->fechafin < now() ? 'text-bg-secondary' : 'text-bg-dark')); ?>">
                                            <?php echo e($promocion->activo ? 'Activa' : ($promocion->fechafin < now() ? 'Vencida' : 'Dada de baja')); ?>

                                        </span>
                                        <?php if($puedeEditar || $puedeBaja): ?>
                                            <div class="d-flex gap-2">
                                                <?php if($puedeEditar && $promocion->activo): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                                            data-bs-toggle="modal" data-bs-target="#editarPromocionModal"
                                                            data-id="<?php echo e($promocion->id); ?>"
                                                            data-nombre="<?php echo e($promocion->nombre); ?>"
                                                            data-tipo="<?php echo e($promocion->tipodescuento); ?>"
                                                            data-valor="<?php echo e($promocion->valordescuento); ?>"
data-inicio="<?php echo e($promocion->fechainicio->format('Y-m-d\TH:i')); ?>"
                                                             data-fin="<?php echo e($promocion->fechafin->format('Y-m-d\TH:i')); ?>"
                                                             data-productos='<?php echo json_encode($promocion->sucursalesProducto->mapWithKeys(fn ($sp) => [$sp->id => (int) ($sp->pivot->cantidad_producto ?? 1)]), 15, 512) ?>'
                                                             data-photo="<?php echo e($promocion->photo); ?>">
                                                        Editar
                                                    </button>
                                                <?php endif; ?>
                                                <?php if($puedeBaja && $promocion->activo): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                                            data-bs-toggle="modal" data-bs-target="#bajaPromocionModal"
                                                            data-id="<?php echo e($promocion->id); ?>"
                                                            data-nombre="<?php echo e($promocion->nombre); ?>"
                                                            data-titulo="<?php echo e($promocion->tipodescuento === 'PORCENTAJE' ? number_format($promocion->valordescuento, 2).' %' : 'Bs. '.number_format($promocion->valordescuento, 2)); ?>"
                                                            data-fin="<?php echo e($promocion->fechafin->format('d/m/Y H:i')); ?>"
                                                            data-photo="<?php echo e($promocion->photo); ?>">
                                                        Baja
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="card tarjeta-producto">
                            <div class="card-body text-center text-muted py-5">
                                <div class="display-6 mb-3">🏷️</div>
                                No hay promociones registradas en <?php echo e($sucursalActual->nombre); ?>.
                                <?php if($puedeCrear): ?>
                                    Usa «+ Nueva promoción» para crear la primera.
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    
    <?php if($puedeCrear): ?>
    <div class="modal fade" id="crearPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <form method="POST" action="<?php echo e(route('dashboard.promociones.store')); ?>" enctype="multipart/form-data" class="modal-content border-0 shadow">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="idsucursal" value="<?php echo e($sucursalActual->id); ?>">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Nueva promoción en <?php echo e($sucursalActual->nombre); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre de la promoción *</label>
                            <input type="text" name="nombre" class="form-control" maxlength="100" required
                                   placeholder="Ej.: Lunes de doble hamburguesa">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de descuento *</label>
                            <select name="tipodescuento" class="form-select tipo-descuento" required>
                                <option value="MONTO_FIJO">Monto fijo (Bs.)</option>
                                <option value="PORCENTAJE">Porcentaje (%)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor del descuento *</label>
                            <input type="number" name="valordescuento" class="form-control valor-descuento"
                                   min="0" max="99999999.99" step="0.01" required placeholder="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de inicio *</label>
                            <input type="datetime-local" name="fechainicio" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de fin *</label>
                            <input type="datetime-local" name="fechafin" class="form-control" required>
                            <div class="form-text">La fecha de fin debe ser posterior a la de inicio.</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Imagen publicitaria de la promoción</label>
                            <input type="file" name="photo" id="crearPromoFoto" class="form-control"
                                   accept="image/jpeg,image/png,image/webp">
                            <div class="form-text">JPG, PNG o WebP · máx. 2 MB. Se muestra como banner de la promoción en la página.</div>
                            <img id="crearPromoFotoPreview" src="#" alt="Vista previa" class="promo-foto-preview d-none">
                        </div>
                    </div>

                    <label class="form-label">Productos incluidos en <?php echo e($sucursalActual->nombre); ?> *</label>
                    <div class="border rounded p-2" style="max-height: 260px; overflow-y: auto;">
                        <?php $__empty_1 = true; $__currentLoopData = $sucursalProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex align-items-center justify-content-between gap-2 py-1 border-bottom border-light-subtle">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" type="checkbox" name="idproductos[]" value="<?php echo e($sp->id); ?>"
                                           id="crearPromoProd<?php echo e($sp->id); ?>">
                                    <label class="form-check-label" for="crearPromoProd<?php echo e($sp->id); ?>">
                                        <?php echo e($sp->producto?->nombre); ?>

                                    </label>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small text-muted">Bs. <?php echo e(number_format($sp->precioproducto, 2)); ?> <?php if (! ($sp->disponibilidad)): ?> · agotado <?php endif; ?></span>
                                    <input type="number" name="cantidades[]" class="form-control form-control-sm promo-cantidad"
                                           style="width: 78px" min="1" max="100" value="1" disabled
                                           data-idproducto="<?php echo e($sp->id); ?>"
                                           title="Cantidad de unidades de este producto incluidas en la promoción">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted py-3">
                                Esta sucursal no tiene productos registrados. Regístralos primero en
                                «Productos por sucursal».
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-text">
                        Indica cuántas unidades de cada producto conforman la promoción
                        (ej.: <em>2 simples</em> a un precio más accesible).
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Crear promoción</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($puedeEditar): ?>
    <div class="modal fade" id="editarPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <form method="POST" id="form-editar-promocion" enctype="multipart/form-data" class="modal-content border-0 shadow">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar promoción</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre de la promoción *</label>
                            <input type="text" name="nombre" id="editPromoNombre" class="form-control" maxlength="100" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de descuento *</label>
                            <select name="tipodescuento" id="editPromoTipo" class="form-select tipo-descuento" required>
                                <option value="MONTO_FIJO">Monto fijo (Bs.)</option>
                                <option value="PORCENTAJE">Porcentaje (%)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor del descuento *</label>
                            <input type="number" name="valordescuento" id="editPromoValor" class="form-control valor-descuento"
                                   min="0" max="99999999.99" step="0.01" required placeholder="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de inicio *</label>
                            <input type="datetime-local" name="fechainicio" id="editPromoInicio" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de fin *</label>
                            <input type="datetime-local" name="fechafin" id="editPromoFin" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Imagen publicitaria de la promoción</label>
                            <input type="file" name="photo" id="editPromoFoto" class="form-control"
                                   accept="image/jpeg,image/png,image/webp">
                            <div class="form-text">
                                JPG, PNG o WebP · máx. 2 MB. Deja vacío para conservar la imagen actual.
                            </div>
                            <img id="editPromoFotoPreview" src="#" alt="Vista previa" class="promo-foto-preview d-none">
                        </div>
                    </div>

                    <label class="form-label">Productos incluidos en <?php echo e($sucursalActual->nombre); ?> *</label>
                    <div class="border rounded p-2" style="max-height: 260px; overflow-y: auto;" id="editPromoProductos">
                        <?php $__empty_1 = true; $__currentLoopData = $sucursalProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex align-items-center justify-content-between gap-2 py-1 border-bottom border-light-subtle">
                                <div class="form-check mb-0">
                                    <input class="form-check-input editar-promo-check" type="checkbox" name="idproductos[]"
                                           value="<?php echo e($sp->id); ?>" id="editPromoProd<?php echo e($sp->id); ?>">
                                    <label class="form-check-label" for="editPromoProd<?php echo e($sp->id); ?>">
                                        <?php echo e($sp->producto?->nombre); ?>

                                    </label>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small text-muted">Bs. <?php echo e(number_format($sp->precioproducto, 2)); ?> <?php if (! ($sp->disponibilidad)): ?> · agotado <?php endif; ?></span>
                                    <input type="number" name="cantidades[]" id="editPromoQty<?php echo e($sp->id); ?>"
                                           class="form-control form-control-sm promo-cantidad-edit" style="width: 78px"
                                           min="1" max="100" value="1" disabled
                                           data-idproducto="<?php echo e($sp->id); ?>"
                                           title="Cantidad de unidades de este producto incluidas en la promoción">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted py-3">Esta sucursal no tiene productos registrados.</div>
                        <?php endif; ?>
                    </div>
                    <div class="form-text">
                        Indica cuántas unidades de cada producto conforman la promoción
                        (ej.: <em>2 simples</em> a un precio más accesible).
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($puedeBaja): ?>
    <div class="modal fade" id="bajaPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-baja-promocion" class="modal-content border-0 shadow">
                <?php echo csrf_field(); ?>
                <div class="modal-body text-center p-4">
                    <img id="bajaPromoFoto" src="#" alt="Imagen de la promoción"
                         class="mx-auto mb-3"
                         style="display: none; max-width: 100%; max-height: 160px; object-fit: cover; border-radius: 1rem;">
                    <div class="display-6 mb-2">🗑️</div>
                    <h5 class="fw-bold" id="bajaPromoNombre"></h5>
                    <p class="text-muted mb-1" id="bajaPromoDetalle"></p>
                    <p class="small text-muted mb-3">
                        Al dar de baja, la promoción dejará de mostrarse en la página de inicio y
                        en este listado.
                    </p>
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Sí, dar de baja</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Sincroniza cada checkbox de producto con su input de cantidad:
        // solo se envía la cantidad si el producto está seleccionado.
        function sincronizarCantidades(contenedor) {
            const filas = contenedor.querySelectorAll('.form-check-input');
            filas.forEach(function (check) {
                const id = check.value;
                const cantidad = contenedor.querySelector('.promo-cantidad[data-idproducto="' + id + '"], .promo-cantidad-edit[data-idproducto="' + id + '"]');
                if (!cantidad) return;

                function actualizar() {
                    cantidad.disabled = !check.checked;
                    if (!check.checked) cantidad.value = 1;
                }

                check.addEventListener('change', actualizar);
                actualizar();
            });
        }

        const crearModal = document.getElementById('crearPromocionModal');
        if (crearModal) sincronizarCantidades(crearModal);

        const editarModal = document.getElementById('editarPromocionModal');
        if (editarModal) sincronizarCantidades(editarModal);

        // Limita el valor del descuento a 100 cuando el tipo es PORCENTAJE.
        document.querySelectorAll('.tipo-descuento').forEach(function (select) {
            select.addEventListener('change', function () {
                const contenedor = select.closest('.modal');
                const valor = contenedor ? contenedor.querySelector('.valor-descuento') : null;
                if (valor) valor.max = select.value === 'PORCENTAJE' ? 100 : 99999999.99;
            });
        });

        <?php if($puedeEditar): ?>
        document.addEventListener('click', function (evento) {
            const boton = evento.target.closest('[data-bs-target="#editarPromocionModal"]');
            if (!boton) return;

            document.getElementById('editPromoNombre').value = boton.dataset.nombre;
            document.getElementById('editPromoTipo').value = boton.dataset.tipo;
            document.getElementById('editPromoValor').value = boton.dataset.valor;
            document.getElementById('editPromoInicio').value = boton.dataset.inicio;
            document.getElementById('editPromoFin').value = boton.dataset.fin;

            const seleccionados = JSON.parse(boton.dataset.productos || '{}');
            document.querySelectorAll('#editPromoProductos .editar-promo-check').forEach(function (check) {
                check.checked = Object.prototype.hasOwnProperty.call(seleccionados, check.value);
                const cantidad = document.getElementById('editPromoQty' + check.value);
                if (cantidad) {
                    cantidad.value = check.checked ? (seleccionados[check.value] || 1) : 1;
                    cantidad.disabled = !check.checked;
                }
            });

            const fotoActual = boton.dataset.photo;
            const previewEditar = document.getElementById('editPromoFotoPreview');
            if (fotoActual) {
                previewEditar.src = '<?php echo e(asset('storage/__FOTO__')); ?>'.replace('__FOTO__', fotoActual);
                previewEditar.classList.remove('d-none');
            } else {
                previewEditar.classList.add('d-none');
            }
            document.getElementById('editPromoFoto').value = '';

            document.getElementById('form-editar-promocion').setAttribute(
                'action',
                '<?php echo e(route('dashboard.promociones.update', ['promocion' => '__ID__'])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });
        <?php endif; ?>

        <?php if($puedeBaja): ?>
        document.addEventListener('click', function (evento) {
            const boton = evento.target.closest('[data-bs-target="#bajaPromocionModal"]');
            if (!boton) return;

            document.getElementById('bajaPromoNombre').textContent = boton.dataset.nombre;
            document.getElementById('bajaPromoDetalle').textContent =
                'Descuento: ' + boton.dataset.titulo + ' · Vigencia hasta: ' + boton.dataset.fin;

            const fotoBaja = document.getElementById('bajaPromoFoto');
            if (boton.dataset.photo) {
                fotoBaja.src = '<?php echo e(asset('storage/__FOTO__')); ?>'.replace('__FOTO__', boton.dataset.photo);
                fotoBaja.style.display = 'block';
            } else {
                fotoBaja.style.display = 'none';
            }

            document.getElementById('form-baja-promocion').setAttribute(
                'action',
                '<?php echo e(route('dashboard.promociones.baja', ['promocion' => '__ID__'])); ?>'.replace('__ID__', boton.dataset.id)
            );
        });
        <?php endif; ?>

        // Vista previa de la imagen publicitaria al seleccionar un archivo.
        [['crearPromoFoto', 'crearPromoFotoPreview'], ['editPromoFoto', 'editPromoFotoPreview']].forEach(function (par) {
            const inputFoto = document.getElementById(par[0]);
            const vistaPrevia = document.getElementById(par[1]);
            if (!inputFoto || !vistaPrevia) return;

            inputFoto.addEventListener('change', function () {
                const archivo = inputFoto.files[0];
                if (!archivo) return;
                const lector = new FileReader();
                lector.onload = function (evento) {
                    vistaPrevia.src = evento.target.result;
                    vistaPrevia.classList.remove('d-none');
                };
                lector.readAsDataURL(archivo);
            });
        });
    });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/promociones/index.blade.php ENDPATH**/ ?>