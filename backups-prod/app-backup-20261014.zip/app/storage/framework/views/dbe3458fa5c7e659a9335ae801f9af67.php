<div class="table-responsive">
    <table class="table small align-middle mb-3">
        <thead class="table-light">
            <tr>
                <th>Producto</th>
                <th class="text-center">Cant.</th>
                <th class="text-end">Precio</th>
                <th class="text-end">Subtotal</th>
                <th class="text-end">Descuento</th>
                <th class="text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedido->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="fw-semibold">
                        <?php if($detalle->idpromocion): ?>
                            🏷️ <?php echo e($detalle->promocion?->nombre ?? 'Promoción N° '.$detalle->idpromocion); ?>

                        <?php else: ?>
                            <?php echo e($detalle->sucursalProducto?->producto?->nombre ?? 'Producto N° '.$detalle->idproductosucursal); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo e($detalle->cantidad); ?></td>
                    <td class="text-end">Bs. <?php echo e(number_format((float) $detalle->preciounitario, 2)); ?></td>
                    <td class="text-end">Bs. <?php echo e(number_format((float) $detalle->subtotal, 2)); ?></td>
                    <td class="text-end">
                        <?php if((float) $detalle->descuento > 0): ?>
                            <span class="text-danger">-Bs. <?php echo e(number_format((float) $detalle->descuento, 2)); ?></span>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end fw-semibold">Bs. <?php echo e(number_format((float) $detalle->total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="table-light">
            <tr>
                <td colspan="5" class="text-end text-muted">Subtotal</td>
                <td class="text-end">Bs. <?php echo e(number_format((float) $pedido->subtotalpedido, 2)); ?></td>
            </tr>
            <?php if((float) $pedido->descuentopedido > 0): ?>
                <tr>
                    <td colspan="5" class="text-end text-danger">Descuentos aplicados</td>
                    <td class="text-end text-danger">-Bs. <?php echo e(number_format((float) $pedido->descuentopedido, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <td colspan="5" class="text-end fw-bold">TOTAL</td>
                <td class="text-end fw-bold fs-6">Bs. <?php echo e(number_format((float) $pedido->total, 2)); ?></td>
            </tr>
        </tfoot>
    </table>
</div>

<div class="row g-2 small">
    <div class="col-md-6">
        <div class="border rounded p-2 bg-light-subtle h-100">
            <div><strong>Pedido:</strong> #<?php echo e($pedido->nropedido); ?> · <?php echo e(optional($pedido->fecha)->format('d/m/Y H:i')); ?></div>
            <div><strong>Tipo:</strong>
                <?php if($pedido->tipopedido === 'MESA'): ?>
                    🍽️ Mesa <?php echo e($pedido->mesa?->numeromesa ?? '—'); ?>

                <?php else: ?>
                    🛍️ Para llevar
                <?php endif; ?>
            </div>
            <?php if($pedido->horarecogida): ?>
                <div><strong>Recogida:</strong> 🕒 <?php echo e(optional(\Illuminate\Support\Carbon::parse($pedido->horarecogida))->format('d/m/Y H:i')); ?></div>
            <?php endif; ?>
            <div><strong>Estado:</strong>
                <?php if($pedido->venta()->exists()): ?>
                    <span class="badge text-bg-success">💳 Cobrado</span>
                <?php elseif($pedido->estadopedido === 'PENDIENTE'): ?>
                    <span class="badge text-bg-warning">Pendiente</span>
                <?php elseif($pedido->estadopedido === 'EJECUTADO'): ?>
                    <span class="badge text-bg-secondary">Ejecutado</span>
                <?php else: ?>
                    <span class="badge text-bg-danger">Anulado</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="border rounded p-2 bg-light-subtle h-100">
            <?php
                $pago = $pedido->venta?->pagos->first();
            ?>
            <?php if($pedido->venta()->exists() && $pago): ?>
                <div><strong>Venta:</strong> 💳 pagada por <?php echo e($pago->metodoPago?->nombre ?? 'método no disponible'); ?></div>
                <div><strong>Monto pagado:</strong> Bs. <?php echo e(number_format((float) $pago->montopago, 2)); ?></div>
                <?php if((float) $pago->montorecibido > 0): ?>
                    <div><strong>Efectivo recibido:</strong> Bs. <?php echo e(number_format((float) $pago->montorecibido, 2)); ?></div>
                <?php endif; ?>
                <?php if((float) $pago->cambioentregado > 0): ?>
                    <div><strong>Cambio:</strong> Bs. <?php echo e(number_format((float) $pago->cambioentregado, 2)); ?></div>
                <?php endif; ?>
                <?php if($pago->gateway): ?>
                    <div><strong>Pasarela:</strong> <?php echo e($pago->gateway); ?></div>
                <?php endif; ?>
                <?php if($pago->codigoautorizacion): ?>
                    <div><strong>Autorización:</strong> <?php echo e($pago->codigoautorizacion); ?></div>
                <?php endif; ?>
                <?php if($pago->referenciaexterna): ?>
                    <div><strong>Referencia:</strong> <?php echo e($pago->referenciaexterna); ?></div>
                <?php endif; ?>
                <div><strong>Cobrado por:</strong> <?php echo e($pedido->venta->empleado?->nombre ?? '—'); ?></div>
                <div><strong>Fecha de pago:</strong> <?php echo e(optional($pago->fechapago)->format('d/m/Y H:i')); ?></div>
            <?php elseif($pedido->estadopedido === 'ANULADO'): ?>
                <div class="text-danger fw-semibold mb-1">Pedido anulado</div>
                <?php if(! empty($pedido->observaciones)): ?>
                    <div><strong>Motivo / observación:</strong></div>
                    <div class="text-muted" style="white-space: pre-line;"><?php echo e($pedido->observaciones); ?></div>
                <?php else: ?>
                    <div class="text-muted">Sin observación de anulación.</div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-muted">Este pedido aún no se ha cobrado.</div>
            <?php endif; ?>
            <div class="mt-1"><strong>Registrado por:</strong> <?php echo e($pedido->empleado?->nombre ?? '—'); ?></div>
            <?php if(! empty($pedido->observaciones) && $pedido->estadopedido !== 'ANULADO'): ?>
                <div><strong>Observación:</strong> <?php echo e($pedido->observaciones); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/admin/generar-pedidos/_detalle.blade.php ENDPATH**/ ?>