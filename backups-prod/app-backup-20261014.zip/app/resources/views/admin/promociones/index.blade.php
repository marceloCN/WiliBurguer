@extends('layouts.app')

@section('title', 'Promociones · '.$configuracionSitio->get('SITIO_NOMBRE'))

@push('styles')
    <style>
        .promo-foto { width: 100%; max-height: 220px; object-fit: cover; border-radius: .5rem .5rem 0 0; }
        .promo-foto-preview { max-width: 100%; max-height: 160px; object-fit: cover; margin-top: .5rem; border-radius: .5rem; border: 1px solid #dee2e6; }
    </style>
@endpush

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Promociones 🏷️</h1>
                <p class="text-muted mb-0">Crea y administra promociones por sucursal.</p>
            </div>
            @if ($puedeCrear)
                <button type="button" class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearPromocionModal">
                    + Nueva promoción
                </button>
            @endif
        </div>

        @include('partials.mensajes')

        <p class="small text-muted mb-3">
            Las promociones aplican un <strong>descuento</strong> (por porcentaje o monto fijo) a uno o más
            <strong>productos</strong> de la sucursal durante un periodo definido (<strong>fecha de inicio</strong> y
            <strong>fin</strong>). Solo <strong>gerentes y administradores</strong> pueden crearlas, editarlas o darlas
            de baja; <strong>cajeros y meseros</strong> solo consultan el listado.
        </p>

        <div class="row g-4">
            {{-- ================= Columna izquierda: SUCURSAL ================= --}}
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursal</span>
                        <span class="badge text-bg-dark">{{ $sucursales->count() }}</span>
                    </div>
                    <div class="list-group">
                        @foreach ($sucursales as $sucursal)
                            <a href="{{ route('dashboard.promociones.index', ['idsucursal' => $sucursal->id]) }}"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                      {{ $sucursalActual->id === $sucursal->id ? 'active' : '' }}">
                                <span class="fw-semibold">{{ $sucursal->nombre }}</span>
                                @if (!$sucursal->estado)
                                    <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                @endif
                            </a>
                        @endforeach
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light">
                        <span class="fw-bold">Resumen</span>
                    </div>
                    <div class="card-body small">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="text-muted">Promociones</span>
                            <span class="fw-bold">{{ $promociones->count() }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-1">
                            <span class="text-muted">Vigentes hoy</span>
                            <span class="fw-bold">{{ $promociones->filter(fn ($p) => $p->activo && $p->fechainicio <= now() && $p->fechafin >= now())->count() }}</span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted">Productos aptos</span>
                            <span class="fw-bold">{{ $sucursalProductos->count() }}</span>
                        </div>
                    </div>
                </div>
            </div>

            {{-- ================= Columna derecha: LISTADO ================= --}}
            <div class="col-12 col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                    <span class="badge text-bg-brand">{{ $sucursalActual->nombre }}</span>
                    <span class="text-muted small">Promociones aplicables a esta sucursal</span>
                </div>

                <div class="d-grid gap-3">
                    @forelse ($promociones as $promocion)
                        <div class="card tarjeta-producto">
                            @if ($promocion->photo)
                                <img src="{{ asset('storage/'.$promocion->photo) }}"
                                     class="promo-foto" alt="Imagen de la promoción {{ $promocion->nombre }}">
                            @endif
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                                    <div class="min-w-0">
                                        <h2 class="h5 fw-bold mb-1">{{ $promocion->nombre }}</h2>
                                        <p class="small text-muted mb-1">
                                            📅 {{ $promocion->fechainicio->format('d/m/Y H:i') }}
                                            → {{ $promocion->fechafin->format('d/m/Y H:i') }}
                                        </p>
                                        <p class="mb-0 small text-muted">
                                            Productos:
                                            @forelse ($promocion->sucursalesProducto as $sp)
                                                <span class="badge rounded-pill text-bg-light border me-1">
                                                    {{ (int) ($sp->pivot->cantidad_producto ?? 1) }}× {{ $sp->producto?->nombre }}
                                                </span>
                                            @empty
                                                <span class="text-secondary">Sin productos asignados</span>
                                            @endforelse
                                        </p>
                                    </div>
                                    <div class="text-end d-flex flex-column align-items-end gap-2">
                                        <span class="badge fs-6
                                            @if (! $promocion->activo) text-bg-secondary
                                            @elseif ($promocion->fechainicio > now()) text-bg-warning
                                            @elseif ($promocion->fechafin < now()) text-bg-dark
                                            @else text-bg-success @endif">
                                            {{ $promocion->tipodescuento === 'PORCENTAJE' ? number_format($promocion->valordescuento, 2).' %' : 'Bs. '.number_format($promocion->valordescuento, 2) }}
                                        </span>
                                        <span class="badge rounded-pill {{ $promocion->activo ? 'text-bg-success' : ($promocion->fechafin < now() ? 'text-bg-secondary' : 'text-bg-dark') }}">
                                            {{ $promocion->activo ? 'Activa' : ($promocion->fechafin < now() ? 'Vencida' : 'Dada de baja') }}
                                        </span>
                                        @if ($puedeEditar || $puedeBaja)
                                            <div class="d-flex gap-2">
                                                @if ($puedeEditar && $promocion->activo)
                                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                                            data-bs-toggle="modal" data-bs-target="#editarPromocionModal"
                                                            data-id="{{ $promocion->id }}"
                                                            data-nombre="{{ $promocion->nombre }}"
                                                            data-tipo="{{ $promocion->tipodescuento }}"
                                                            data-valor="{{ $promocion->valordescuento }}"
data-inicio="{{ $promocion->fechainicio->format('Y-m-d\TH:i') }}"
                                                             data-fin="{{ $promocion->fechafin->format('Y-m-d\TH:i') }}"
                                                             data-productos='@json($promocion->sucursalesProducto->mapWithKeys(fn ($sp) => [$sp->id => (int) ($sp->pivot->cantidad_producto ?? 1)]))'
                                                             data-photo="{{ $promocion->photo }}">
                                                        Editar
                                                    </button>
                                                @endif
                                                @if ($puedeBaja && $promocion->activo)
                                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                                            data-bs-toggle="modal" data-bs-target="#bajaPromocionModal"
                                                            data-id="{{ $promocion->id }}"
                                                            data-nombre="{{ $promocion->nombre }}"
                                                            data-titulo="{{ $promocion->tipodescuento === 'PORCENTAJE' ? number_format($promocion->valordescuento, 2).' %' : 'Bs. '.number_format($promocion->valordescuento, 2) }}"
                                                            data-fin="{{ $promocion->fechafin->format('d/m/Y H:i') }}"
                                                            data-photo="{{ $promocion->photo }}">
                                                        Baja
                                                    </button>
                                                @endif
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="card tarjeta-producto">
                            <div class="card-body text-center text-muted py-5">
                                <div class="display-6 mb-3">🏷️</div>
                                No hay promociones registradas en {{ $sucursalActual->nombre }}.
                                @if ($puedeCrear)
                                    Usa «+ Nueva promoción» para crear la primera.
                                @endif
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    {{-- ================= Modal crear promoción (permiso 350) ================= --}}
    @if ($puedeCrear)
    <div class="modal fade" id="crearPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <form method="POST" action="{{ route('dashboard.promociones.store') }}" enctype="multipart/form-data" class="modal-content border-0 shadow">
                @csrf
                <input type="hidden" name="idsucursal" value="{{ $sucursalActual->id }}">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Nueva promoción en {{ $sucursalActual->nombre }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre de la promoción *</label>
                            <input type="text" name="nombre" class="form-control" maxlength="100" required
                                   placeholder="Ej.: Lunes de doble hamburguesa">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de descuento *</label>
                            <select name="tipodescuento" class="form-select tipo-descuento" required>
                                <option value="MONTO_FIJO">Monto fijo (Bs.)</option>
                                <option value="PORCENTAJE">Porcentaje (%)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor del descuento *</label>
                            <input type="number" name="valordescuento" class="form-control valor-descuento"
                                   min="0" max="99999999.99" step="0.01" required placeholder="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de inicio *</label>
                            <input type="datetime-local" name="fechainicio" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de fin *</label>
                            <input type="datetime-local" name="fechafin" class="form-control" required>
                            <div class="form-text">La fecha de fin debe ser posterior a la de inicio.</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Imagen publicitaria de la promoción</label>
                            <input type="file" name="photo" id="crearPromoFoto" class="form-control"
                                   accept="image/jpeg,image/png,image/webp">
                            <div class="form-text">JPG, PNG o WebP · máx. 2 MB. Se muestra como banner de la promoción en la página.</div>
                            <img id="crearPromoFotoPreview" src="#" alt="Vista previa" class="promo-foto-preview d-none">
                        </div>
                    </div>

                    <label class="form-label">Productos incluidos en {{ $sucursalActual->nombre }} *</label>
                    <div class="border rounded p-2" style="max-height: 260px; overflow-y: auto;">
                        @forelse ($sucursalProductos as $sp)
                            <div class="d-flex align-items-center justify-content-between gap-2 py-1 border-bottom border-light-subtle">
                                <div class="form-check mb-0">
                                    <input class="form-check-input" type="checkbox" name="idproductos[]" value="{{ $sp->id }}"
                                           id="crearPromoProd{{ $sp->id }}">
                                    <label class="form-check-label" for="crearPromoProd{{ $sp->id }}">
                                        {{ $sp->producto?->nombre }}
                                    </label>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small text-muted">Bs. {{ number_format($sp->precioproducto, 2) }} @unless($sp->disponibilidad) · agotado @endunless</span>
                                    <input type="number" name="cantidades[]" class="form-control form-control-sm promo-cantidad"
                                           style="width: 78px" min="1" max="100" value="1" disabled
                                           data-idproducto="{{ $sp->id }}"
                                           title="Cantidad de unidades de este producto incluidas en la promoción">
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3">
                                Esta sucursal no tiene productos registrados. Regístralos primero en
                                «Productos por sucursal».
                            </div>
                        @endforelse
                    </div>
                    <div class="form-text">
                        Indica cuántas unidades de cada producto conforman la promoción
                        (ej.: <em>2 simples</em> a un precio más accesible).
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Crear promoción</button>
                </div>
            </form>
        </div>
    </div>
    @endif

    {{-- ================= Modal editar promoción (permiso 351) ================= --}}
    @if ($puedeEditar)
    <div class="modal fade" id="editarPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <form method="POST" id="form-editar-promocion" enctype="multipart/form-data" class="modal-content border-0 shadow">
                @csrf
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar promoción</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Nombre de la promoción *</label>
                            <input type="text" name="nombre" id="editPromoNombre" class="form-control" maxlength="100" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipo de descuento *</label>
                            <select name="tipodescuento" id="editPromoTipo" class="form-select tipo-descuento" required>
                                <option value="MONTO_FIJO">Monto fijo (Bs.)</option>
                                <option value="PORCENTAJE">Porcentaje (%)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Valor del descuento *</label>
                            <input type="number" name="valordescuento" id="editPromoValor" class="form-control valor-descuento"
                                   min="0" max="99999999.99" step="0.01" required placeholder="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de inicio *</label>
                            <input type="datetime-local" name="fechainicio" id="editPromoInicio" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Fecha de fin *</label>
                            <input type="datetime-local" name="fechafin" id="editPromoFin" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Imagen publicitaria de la promoción</label>
                            <input type="file" name="photo" id="editPromoFoto" class="form-control"
                                   accept="image/jpeg,image/png,image/webp">
                            <div class="form-text">
                                JPG, PNG o WebP · máx. 2 MB. Deja vacío para conservar la imagen actual.
                            </div>
                            <img id="editPromoFotoPreview" src="#" alt="Vista previa" class="promo-foto-preview d-none">
                        </div>
                    </div>

                    <label class="form-label">Productos incluidos en {{ $sucursalActual->nombre }} *</label>
                    <div class="border rounded p-2" style="max-height: 260px; overflow-y: auto;" id="editPromoProductos">
                        @forelse ($sucursalProductos as $sp)
                            <div class="d-flex align-items-center justify-content-between gap-2 py-1 border-bottom border-light-subtle">
                                <div class="form-check mb-0">
                                    <input class="form-check-input editar-promo-check" type="checkbox" name="idproductos[]"
                                           value="{{ $sp->id }}" id="editPromoProd{{ $sp->id }}">
                                    <label class="form-check-label" for="editPromoProd{{ $sp->id }}">
                                        {{ $sp->producto?->nombre }}
                                    </label>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small text-muted">Bs. {{ number_format($sp->precioproducto, 2) }} @unless($sp->disponibilidad) · agotado @endunless</span>
                                    <input type="number" name="cantidades[]" id="editPromoQty{{ $sp->id }}"
                                           class="form-control form-control-sm promo-cantidad-edit" style="width: 78px"
                                           min="1" max="100" value="1" disabled
                                           data-idproducto="{{ $sp->id }}"
                                           title="Cantidad de unidades de este producto incluidas en la promoción">
                                </div>
                            </div>
                        @empty
                            <div class="text-center text-muted py-3">Esta sucursal no tiene productos registrados.</div>
                        @endforelse
                    </div>
                    <div class="form-text">
                        Indica cuántas unidades de cada producto conforman la promoción
                        (ej.: <em>2 simples</em> a un precio más accesible).
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
    @endif

    {{-- ================= Modal dar de baja promoción (permiso 355) ================= --}}
    @if ($puedeBaja)
    <div class="modal fade" id="bajaPromocionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-baja-promocion" class="modal-content border-0 shadow">
                @csrf
                <div class="modal-body text-center p-4">
                    <img id="bajaPromoFoto" src="#" alt="Imagen de la promoción"
                         class="mx-auto mb-3"
                         style="display: none; max-width: 100%; max-height: 160px; object-fit: cover; border-radius: 1rem;">
                    <div class="display-6 mb-2">🗑️</div>
                    <h5 class="fw-bold" id="bajaPromoNombre"></h5>
                    <p class="text-muted mb-1" id="bajaPromoDetalle"></p>
                    <p class="small text-muted mb-3">
                        Al dar de baja, la promoción dejará de mostrarse en la página de inicio y
                        en este listado.
                    </p>
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">Sí, dar de baja</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    @endif
@endsection

@push('scripts')
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Sincroniza cada checkbox de producto con su input de cantidad:
        // solo se envía la cantidad si el producto está seleccionado.
        function sincronizarCantidades(contenedor) {
            const filas = contenedor.querySelectorAll('.form-check-input');
            filas.forEach(function (check) {
                const id = check.value;
                const cantidad = contenedor.querySelector('.promo-cantidad[data-idproducto="' + id + '"], .promo-cantidad-edit[data-idproducto="' + id + '"]');
                if (!cantidad) return;

                function actualizar() {
                    cantidad.disabled = !check.checked;
                    if (!check.checked) cantidad.value = 1;
                }

                check.addEventListener('change', actualizar);
                actualizar();
            });
        }

        const crearModal = document.getElementById('crearPromocionModal');
        if (crearModal) sincronizarCantidades(crearModal);

        const editarModal = document.getElementById('editarPromocionModal');
        if (editarModal) sincronizarCantidades(editarModal);

        // Limita el valor del descuento a 100 cuando el tipo es PORCENTAJE.
        document.querySelectorAll('.tipo-descuento').forEach(function (select) {
            select.addEventListener('change', function () {
                const contenedor = select.closest('.modal');
                const valor = contenedor ? contenedor.querySelector('.valor-descuento') : null;
                if (valor) valor.max = select.value === 'PORCENTAJE' ? 100 : 99999999.99;
            });
        });

        @if ($puedeEditar)
        document.addEventListener('click', function (evento) {
            const boton = evento.target.closest('[data-bs-target="#editarPromocionModal"]');
            if (!boton) return;

            document.getElementById('editPromoNombre').value = boton.dataset.nombre;
            document.getElementById('editPromoTipo').value = boton.dataset.tipo;
            document.getElementById('editPromoValor').value = boton.dataset.valor;
            document.getElementById('editPromoInicio').value = boton.dataset.inicio;
            document.getElementById('editPromoFin').value = boton.dataset.fin;

            const seleccionados = JSON.parse(boton.dataset.productos || '{}');
            document.querySelectorAll('#editPromoProductos .editar-promo-check').forEach(function (check) {
                check.checked = Object.prototype.hasOwnProperty.call(seleccionados, check.value);
                const cantidad = document.getElementById('editPromoQty' + check.value);
                if (cantidad) {
                    cantidad.value = check.checked ? (seleccionados[check.value] || 1) : 1;
                    cantidad.disabled = !check.checked;
                }
            });

            const fotoActual = boton.dataset.photo;
            const previewEditar = document.getElementById('editPromoFotoPreview');
            if (fotoActual) {
                previewEditar.src = '{{ asset('storage/__FOTO__') }}'.replace('__FOTO__', fotoActual);
                previewEditar.classList.remove('d-none');
            } else {
                previewEditar.classList.add('d-none');
            }
            document.getElementById('editPromoFoto').value = '';

            document.getElementById('form-editar-promocion').setAttribute(
                'action',
                '{{ route('dashboard.promociones.update', ['promocion' => '__ID__']) }}'.replace('__ID__', boton.dataset.id)
            );
        });
        @endif

        @if ($puedeBaja)
        document.addEventListener('click', function (evento) {
            const boton = evento.target.closest('[data-bs-target="#bajaPromocionModal"]');
            if (!boton) return;

            document.getElementById('bajaPromoNombre').textContent = boton.dataset.nombre;
            document.getElementById('bajaPromoDetalle').textContent =
                'Descuento: ' + boton.dataset.titulo + ' · Vigencia hasta: ' + boton.dataset.fin;

            const fotoBaja = document.getElementById('bajaPromoFoto');
            if (boton.dataset.photo) {
                fotoBaja.src = '{{ asset('storage/__FOTO__') }}'.replace('__FOTO__', boton.dataset.photo);
                fotoBaja.style.display = 'block';
            } else {
                fotoBaja.style.display = 'none';
            }

            document.getElementById('form-baja-promocion').setAttribute(
                'action',
                '{{ route('dashboard.promociones.baja', ['promocion' => '__ID__']) }}'.replace('__ID__', boton.dataset.id)
            );
        });
        @endif

        // Vista previa de la imagen publicitaria al seleccionar un archivo.
        [['crearPromoFoto', 'crearPromoFotoPreview'], ['editPromoFoto', 'editPromoFotoPreview']].forEach(function (par) {
            const inputFoto = document.getElementById(par[0]);
            const vistaPrevia = document.getElementById(par[1]);
            if (!inputFoto || !vistaPrevia) return;

            inputFoto.addEventListener('change', function () {
                const archivo = inputFoto.files[0];
                if (!archivo) return;
                const lector = new FileReader();
                lector.onload = function (evento) {
                    vistaPrevia.src = evento.target.result;
                    vistaPrevia.classList.remove('d-none');
                };
                lector.readAsDataURL(archivo);
            });
        });
    });
    </script>
@endpush