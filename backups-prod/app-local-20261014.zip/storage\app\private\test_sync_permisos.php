<?php

require __DIR__ . '/../../../vendor/autoload.php';

$app = require_once __DIR__ . '/../../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$rol = App\Models\Rol::where('claverol', 'MESERO')->first();
$permisosAntes = $rol->permisos()->pluck('permiso.id')->toArray();
echo "Permisos antes: " . implode(', ', $permisosAntes) . "\n";

// Probar sync con todos los permisos
$todosLosPermisos = App\Models\Permiso::where('estado', true)->pluck('id')->toArray();
$rol->permisos()->sync($todosLosPermisos);

$permisosDespues = $rol->permisos()->pluck('permiso.id')->toArray();
echo "Permisos despues (todos): " . count($permisosDespues) . " permisos\n";

// Restaurar
$rol->permisos()->sync($permisosAntes);
echo "Restaurado a: " . implode(', ', $permisosAntes) . "\n";
