<?php

namespace App\Http\Controllers;

use App\Models\AperturaCaja;
use App\Models\Caja;
use App\Models\CierreCaja;
use App\Models\Empleado;
use App\Models\MovimientoCaja;
use App\Models\Pago;
use App\Models\Sucursal;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CajaController extends Controller
{
    /**
     * Pantalla única del módulo de caja (permisos de apertura 410-415, de
     * movimientos 420-425 y de cierre 430-437). Con escoger la sucursal se
     * muestran: la caja/jornada actual, sus movimientos, el cierre y los
     * historiales de aperturas y cierres.
     */
    public function index(Request $request): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursales = $this->sucursalesPermitidas($empleado);

        if ($sucursales->isEmpty()) {
            abort(403, 'No tienes una sucursal asignada para operar la caja.');
        }

        $sucursalActual = $sucursales->firstWhere('id', $request->integer('idsucursal'))
            ?? $sucursales->first();

        $cajas = Caja::where('idsucursal', $sucursalActual->id)
            ->orderBy('activo', 'desc')
            ->orderBy('nombre')
            ->get();

        $apertura = AperturaCaja::with(['caja', 'empleado', 'cierreCaja'])
            ->where('estado', 'ABIERTA')
            ->whereHas('caja', fn ($query) => $query->where('idsucursal', $sucursalActual->id))
            ->first();

        $movimientos = $apertura
            ? $apertura->movimientosCaja()
                ->with('empleado')
                ->orderByDesc('fechamovimiento')
                ->get()
            : collect();

        return view('admin.caja.index', compact(
            'empleado',
            'sucursales',
            'sucursalActual',
            'cajas',
            'apertura',
            'movimientos',
        ) + $this->flagsDeOperacion($empleado));
    }

    /**
     * Abre la caja (permiso 410). El trigger crea automáticamente el cierre
     * provisional con los parámetros iniciales.
     */
    public function abrir(Request $request): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->sucursalActualPermitida($empleado, $request->integer('idsucursal'));

        $validated = $request->validate([
            'idcaja' => ['required', 'integer', 'exists:caja,id'],
            'montoinicial' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
        ]);

        $caja = Caja::findOrFail($validated['idcaja']);

        abort_if($caja->idsucursal !== $sucursalActual->id, 403, 'Esa caja no pertenece a la sucursal seleccionada.');
        abort_if(! $caja->activo, 403, 'La caja está dada de baja; no se puede abrir.');

        $yaAbierta = AperturaCaja::where('estado', 'ABIERTA')
            ->where('idcaja', $caja->id)
            ->exists();

        if ($yaAbierta) {
            return back()->with('error', "La caja {$caja->nombre} ya tiene una jornada abierta.");
        }

        try {
            $apertura = AperturaCaja::create([
                'fechaapertura' => now(),
                'montoinicial' => $validated['montoinicial'],
                'estado' => 'ABIERTA',
                'idcaja' => $caja->id,
                'idempleado' => $empleado->id,
            ]);
        } catch (QueryException $e) {
            if (str_contains($e->getMessage(), 'Ya existe una apertura de caja abierta')) {
                return back()->with('error', 'Ya existe una apertura de caja abierta para esa caja.');
            }

            throw $e;
        }

        $this->registrarAccion($empleado->id, 'CREATE', 'aperturacaja', $apertura->id, '410');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Jornada abierta en {$caja->nombre} con S/ {$validated['montoinicial']} de fondo inicial.");
    }

    /**
     * Edita el monto inicial de la apertura abierta (permiso 411).
     */
    public function editarApertura(Request $request, AperturaCaja $apertura): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $apertura);

        abort_unless($apertura->estado === 'ABIERTA', 403, 'Solo se puede editar una jornada abierta.');

        $validated = $request->validate([
            'montoinicial' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
        ]);

        DB::transaction(function () use ($apertura, $validated) {
            $apertura->update(['montoinicial' => $validated['montoinicial']]);

            $apertura->cierreCaja()?->update(['efectivocontado' => $validated['montoinicial']]);
        });

        $this->registrarAccion($empleado->id, 'UPDATE', 'aperturacaja', $apertura->id, '411');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', 'Fondo inicial de la jornada actualizado.');
    }

    /**
     * Da de baja (anula) la apertura abierta (permiso 415). Solo si la jornada
     * aún no tiene pagos aprobados.
     */
    public function bajaApertura(Request $request, AperturaCaja $apertura): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $apertura);

        abort_unless($apertura->estado === 'ABIERTA', 403, 'La jornada ya no se encuentra abierta.');

        $pagosAprobados = $apertura->pagos()
            ->where('estadopago', 'APROBADO')
            ->exists();

        if ($pagosAprobados) {
            return back()->with('error', 'No se puede anular la apertura porque ya tiene pagos aprobados; ciérrala con su cierre de caja.');
        }

        DB::transaction(function () use ($apertura) {
            $apertura->cierreCaja()?->update([
                'fechacierre' => now(),
                'observacion' => 'Apertura anulada (dar de baja).',
            ]);

            $apertura->update(['estado' => 'CERRADA']);
        });

        $this->registrarAccion($empleado->id, 'DELETE', 'aperturacaja', $apertura->id, '415');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', 'Jornada anulada correctamente.');
    }

    /**
     * Registra un movimiento de caja en la jornada abierta (permiso 420).
     */
    public function movimientoStore(Request $request, AperturaCaja $apertura): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $apertura);

        abort_unless($apertura->estado === 'ABIERTA', 403, 'Registra los movimientos con la jornada abierta.');

        $validated = $request->validate([
            'tipomovimiento' => ['required', 'in:INGRESO,EGRESO'],
            'concepto' => ['required', 'string', 'max:150'],
            'monto' => ['required', 'numeric', 'gt:0', 'max:99999999.99'],
            'observacion' => ['nullable', 'string', 'max:250'],
        ]);

        $movimiento = MovimientoCaja::create([
            'fechamovimiento' => now(),
            'tipomovimiento' => $validated['tipomovimiento'],
            'concepto' => $validated['concepto'],
            'monto' => $validated['monto'],
            'observacion' => $validated['observacion'] ?? null,
            'idaperturacaja' => $apertura->id,
            'idempleado' => $empleado->id,
        ]);

        $this->registrarAccion($empleado->id, 'CREATE', 'movimientocaja', $movimiento->id, '420');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', 'Movimiento de caja registrado.');
    }

    /**
     * Edita un movimiento de caja (permiso 421) mientras la jornada siga abierta.
     */
    public function movimientoUpdate(Request $request, MovimientoCaja $movimiento): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $movimiento->aperturaCaja);

        abort_unless($movimiento->aperturaCaja->estado === 'ABIERTA', 403, 'Solo editas movimientos con la jornada abierta.');

        $validated = $request->validate([
            'tipomovimiento' => ['required', 'in:INGRESO,EGRESO'],
            'concepto' => ['required', 'string', 'max:150'],
            'monto' => ['required', 'numeric', 'gt:0', 'max:99999999.99'],
            'observacion' => ['nullable', 'string', 'max:250'],
        ]);

        $movimiento->update([
            'tipomovimiento' => $validated['tipomovimiento'],
            'concepto' => $validated['concepto'],
            'monto' => $validated['monto'],
            'observacion' => $validated['observacion'] ?? null,
        ]);

        $this->registrarAccion($empleado->id, 'UPDATE', 'movimientocaja', $movimiento->id, '421');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', 'Movimiento de caja actualizado.');
    }

    /**
     * Da de baja un movimiento de caja (permiso 425) mientras la jornada siga abierta.
     */
    public function movimientoBaja(Request $request, MovimientoCaja $movimiento): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $movimiento->aperturaCaja);

        abort_unless($movimiento->aperturaCaja->estado === 'ABIERTA', 403, 'Solo eliminas movimientos con la jornada abierta.');

        $movimiento->delete();

        $this->registrarAccion($empleado->id, 'DELETE', 'movimientocaja', $movimiento->id, '425');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', 'Movimiento de caja eliminado.');
    }

    /**
     * Cierra la jornada (permiso 430). Actualiza el cierre (el trigger recalcula
     * los totales y la diferencia) y marca la apertura como CERRADA.
     */
    public function cerrar(Request $request, AperturaCaja $apertura): RedirectResponse
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursalActual = $this->aperturaPermitida($empleado, $apertura);

        abort_unless($apertura->estado === 'ABIERTA', 403, 'La jornada ya se encuentra cerrada.');

        $validated = $request->validate([
            'efectivocontado' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'observacion' => ['nullable', 'string', 'max:250'],
        ]);

        DB::transaction(function () use ($apertura, $validated) {
            $apertura->cierreCaja()?->update([
                'fechacierre' => now(),
                'efectivocontado' => $validated['efectivocontado'],
                'observacion' => $validated['observacion'] ?? null,
            ]);

            $apertura->update(['estado' => 'CERRADA']);
        });

        $this->registrarAccion($empleado->id, 'CREATE', 'cierrecaja', $apertura->cierreCaja?->id, '430');

        return redirect()->route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])
            ->with('exito', "Cierre de caja procesado en {$sucursalActual->nombre}.");
    }

    /**
     * Detalle de un cierre (permiso 436) en un modal (patch de vista parcial).
     */
    public function detalleCierre(CierreCaja $cierre): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $cierre->aperturaCaja?->caja?->idsucursal);

        abort_unless($sucursal, 403, 'Ese cierre no pertenece a una sucursal que puedas consultar.');

        return view('admin.caja._detalle_cierre', ['cierre' => $cierre, 'sucursalActual' => $sucursal]);
    }

    /**
     * Historial de cierres en su propia vista (permiso 437) con filtro por
     * rango de fechas. Cada fila permite ver el detalle y descargar el PDF de
     * la jornada (quien la ejecutó, pedidos y métodos de pago).
     */
    public function historial(Request $request): View
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursales = $this->sucursalesPermitidas($empleado);

        abort_unless($sucursales->isNotEmpty(), 403, 'No tienes una sucursal asignada para consultar cierres.');

        $sucursalActual = $sucursales->firstWhere('id', $request->integer('idsucursal'))
            ?? $sucursales->first();

        [$desde, $hasta] = $this->rangoFechas($request);

        $cierres = $this->cierresEnRango($sucursalActual->id, $desde, $hasta)
            ->orderByDesc('fechacierre')
            ->paginate(10)
            ->appends($request->only(['idsucursal', 'desde', 'hasta']));

        return view('admin.caja.historial', compact(
            'empleado',
            'sucursalActual',
            'cierres',
            'desde',
            'hasta',
        ) + $this->flagsDeOperacion($empleado));
    }

    /**
     * PDF del histatal de cierres por día o rango de fechas (permiso 437).
     */
    public function historialPdf(Request $request): Response
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursales = $this->sucursalesPermitidas($empleado);

        abort_unless($sucursales->isNotEmpty(), 403, 'No tienes una sucursal asignada para consultar cierres.');

        $sucursalActual = $sucursales->firstWhere('id', $request->integer('idsucursal'))
            ?? $sucursales->first();

        [$desde, $hasta] = $this->rangoFechas($request);

        $cierres = $this->cierresEnRango($sucursalActual->id, $desde, $hasta)
            ->orderBy('fechacierre')
            ->get();

        $pdf = Pdf::loadView(
            'admin.caja.pdf.historial',
            compact('sucursalActual', 'cierres', 'desde', 'hasta', 'empleado'),
        )->setPaper('a4', 'landscape');

        $rango = $desde ? ($hasta ? "{$desde}_al_{$hasta}" : "desde_{$desde}") : ($hasta ? "hasta_{$hasta}" : 'todas');

        return $pdf->download('reporte-cierres-'.$sucursalActual->id.'-'.$rango.'.pdf');
    }

    /**
     * PDF del cierre de una apertura (permiso 436): quien lo ejecutó, los
     * pedidos/ventas de la jornada y el método de pago de cada uno.
     */
    public function cierrePdf(CierreCaja $cierre): Response
    {
        $empleado = auth()->user()->empleado->load('rol');

        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $cierre->aperturaCaja?->caja?->idsucursal);

        abort_unless($sucursal, 403, 'Ese cierre no pertenece a una sucursal que puedas consultar.');

        $cierre->load('aperturaCaja.caja', 'aperturaCaja.empleado', 'empleado');

        $pagos = Pago::where('idaperturacaja', $cierre->idaperturacaja)
            ->where('estadopago', 'APROBADO')
            ->with([
                'metodoPago',
                'venta.empleado',
                'venta.pedido.mesa',
                'venta.pedido.empleado',
                'venta.pedido.detalles.promocion',
                'venta.pedido.detalles.sucursalProducto.producto',
            ])
            ->orderBy('id')
            ->get();

        $movimientos = $cierre->aperturaCaja
            ? $cierre->aperturaCaja->movimientosCaja()->with('empleado')->orderBy('fechamovimiento')->get()
            : collect();

        $pdf = Pdf::loadView(
            'admin.caja.pdf.cierre',
            compact('cierre', 'pagos', 'movimientos', 'sucursal', 'empleado'),
        )->setPaper('a4', 'portrait');

        $caja = Str::slug($cierre->aperturaCaja?->caja?->nombre ?? 'caja');

        return $pdf->download("cierre-{$caja}-{$cierre->id}.pdf");
    }

    /**
     * Construye la consulta de cierres de una sucursal aplicando el rango de fechas.
     */
    private function cierresEnRango(int $idsucursal, ?string $desde, ?string $hasta)
    {
        return CierreCaja::with('aperturaCaja.caja', 'aperturaCaja.empleado', 'empleado')
            ->whereHas('aperturaCaja.caja', fn ($query) => $query->where('idsucursal', $idsucursal))
            ->when($desde, fn ($query) => $query->whereDate('fechacierre', '>=', $desde))
            ->when($hasta, fn ($query) => $query->whereDate('fechacierre', '<=', $hasta));
    }

    /**
     * Parsea los parámetros desde/hasta (formato Y-m-d) devolviendo null si no
     * son válidos, de modo que un rango inexistente equivale a "sin filtro".
     */
    private function rangoFechas(Request $request): array
    {
        $desde = trim((string) $request->input('desde', ''));
        $hasta = trim((string) $request->input('hasta', ''));

        $desdeOk = $desde !== '' && \DateTime::createFromFormat('!Y-m-d', $desde) !== false;
        $hastaOk = $hasta !== '' && \DateTime::createFromFormat('!Y-m-d', $hasta) !== false;

        return [
            $desdeOk ? $desde : null,
            $hastaOk ? $hasta : null,
        ];
    }

    /** Sumariza los cierres de un rango para la cabecera del reporte. */
    private function totalesDeCierres(Collection $cierres): array
    {
        return [
            'ventas' => $cierres->sum('totalventas'),
            'efectivo' => $cierres->sum('totalventasefectivo'),
            'qr' => $cierres->sum('totalventasqr'),
            'tarjeta' => $cierres->sum('totalventastarjeta'),
            'ingresos' => $cierres->sum('totalingresos'),
            'egresos' => $cierres->sum('totalegresos'),
            'diferencia' => $cierres->sum('diferencia'),
        ];
    }

    /** Sucursales que el empleado puede operar (mismo criterio que productos-sucursal). */
    private function sucursalesPermitidas(Empleado $empleado): Collection
    {
        $claverol = $empleado->rol?->claverol;

        if ($claverol === 'ADMINISTRADOR') {
            return Sucursal::orderBy('nombre')->get();
        }

        if ($claverol === 'GERENTE') {
            return $empleado->sucursalesGerenciadas()
                ->where('estado', true)
                ->orderBy('nombre')
                ->get();
        }

        return $empleado->idsucursal
            ? Sucursal::where('id', $empleado->idsucursal)->get()
            : collect();
    }

    private function sucursalActualPermitida(Empleado $empleado, int $idsucursal): Sucursal
    {
        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $idsucursal)
            ?? $this->sucursalesPermitidas($empleado)->first();

        abort_unless($sucursal, 403, 'No tienes acceso a esa sucursal.');

        return $sucursal;
    }

    private function aperturaPermitida(Empleado $empleado, AperturaCaja $apertura): Sucursal
    {
        $apertura->loadMissing('caja');

        $sucursal = $this->sucursalesPermitidas($empleado)
            ->firstWhere('id', $apertura->caja?->idsucursal);

        abort_unless($sucursal, 403, 'La jornada no pertenece a una sucursal que puedas operar.');

        return $sucursal;
    }

    private function flagsDeOperacion(Empleado $empleado): array
    {
        $codigos = $empleado->rol?->permisos
            ? $empleado->rol->permisos->where('estado', true)->pluck('codigo')
            : collect();

        return [
            'puedeAbrir' => $codigos->contains('410'),
            'puedeEditarApertura' => $codigos->contains('411'),
            'puedeBajaApertura' => $codigos->contains('415'),
            'puedeRegistrarMovimiento' => $codigos->contains('420'),
            'puedeEditarMovimiento' => $codigos->contains('421'),
            'puedeBajaMovimiento' => $codigos->contains('425'),
            'puedeCerrar' => $codigos->contains('430'),
            'puedeDetalleCierre' => $codigos->contains('436'),
            'puedeHistorialAperturas' => $codigos->contains('412'),
            'puedeHistorialCierres' => $codigos->contains('437'),
        ];
    }
}
