<?php $__env->startSection('title', 'Mantenimiento · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-center p-4" style="min-height: 70vh;">
        <div class="text-center">
            <div class="display-1 mb-3">🛠️</div>
            <h1 class="display-6 fw-bold mb-3">Página en mantenimiento</h1>
            <p class="lead text-muted mx-auto" style="max-width: 34rem;">
                <?php echo e($mensajeMantenimiento ?? 'Estamos realizando mejoras en la página. Volveremos muy pronto.'); ?>

            </p>
            <p class="small text-muted">Inténtalo nuevamente en unos minutos.</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/mantenimiento.blade.php ENDPATH**/ ?>