<div class="table-responsive">
    <table class="table small align-middle mb-3">
        <thead class="table-light">
            <tr>
                <th>Producto</th>
                <th class="text-center">Cant.</th>
                <th class="text-end">Precio</th>
                <th class="text-end">Subtotal</th>
                <th class="text-end">Descuento</th>
                <th class="text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($pedido->detalles as $detalle)
                <tr>
                    <td class="fw-semibold">
                        @if ($detalle->idpromocion)
                            🏷️ {{ $detalle->promocion?->nombre ?? 'Promoción N° '.$detalle->idpromocion }}
                        @else
                            {{ $detalle->sucursalProducto?->producto?->nombre ?? 'Producto N° '.$detalle->idproductosucursal }}
                        @endif
                    </td>
                    <td class="text-center">{{ $detalle->cantidad }}</td>
                    <td class="text-end">Bs. {{ number_format((float) $detalle->preciounitario, 2) }}</td>
                    <td class="text-end">Bs. {{ number_format((float) $detalle->subtotal, 2) }}</td>
                    <td class="text-end">
                        @if ((float) $detalle->descuento > 0)
                            <span class="text-danger">-Bs. {{ number_format((float) $detalle->descuento, 2) }}</span>
                        @else
                            <span class="text-muted">—</span>
                        @endif
                    </td>
                    <td class="text-end fw-semibold">Bs. {{ number_format((float) $detalle->total, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
        <tfoot class="table-light">
            <tr>
                <td colspan="5" class="text-end text-muted">Subtotal</td>
                <td class="text-end">Bs. {{ number_format((float) $pedido->subtotalpedido, 2) }}</td>
            </tr>
            @if ((float) $pedido->descuentopedido > 0)
                <tr>
                    <td colspan="5" class="text-end text-danger">Descuentos aplicados</td>
                    <td class="text-end text-danger">-Bs. {{ number_format((float) $pedido->descuentopedido, 2) }}</td>
                </tr>
            @endif
            <tr>
                <td colspan="5" class="text-end fw-bold">TOTAL</td>
                <td class="text-end fw-bold fs-6">Bs. {{ number_format((float) $pedido->total, 2) }}</td>
            </tr>
        </tfoot>
    </table>
</div>

<div class="row g-2 small">
    <div class="col-md-6">
        <div class="border rounded p-2 bg-light-subtle h-100">
            <div><strong>Pedido:</strong> #{{ $pedido->nropedido }} · {{ optional($pedido->fecha)->format('d/m/Y H:i') }}</div>
            <div><strong>Tipo:</strong>
                @if ($pedido->tipopedido === 'MESA')
                    🍽️ Mesa {{ $pedido->mesa?->numeromesa ?? '—' }}
                @else
                    🛍️ Para llevar
                @endif
            </div>
            @if ($pedido->horarecogida)
                <div><strong>Recogida:</strong> 🕒 {{ optional(\Illuminate\Support\Carbon::parse($pedido->horarecogida))->format('d/m/Y H:i') }}</div>
            @endif
            <div><strong>Estado:</strong>
                @if ($pedido->venta()->exists())
                    <span class="badge text-bg-success">💳 Cobrado</span>
                @elseif ($pedido->estadopedido === 'PENDIENTE')
                    <span class="badge text-bg-warning">Pendiente</span>
                @elseif ($pedido->estadopedido === 'EJECUTADO')
                    <span class="badge text-bg-secondary">Ejecutado</span>
                @else
                    <span class="badge text-bg-danger">Anulado</span>
                @endif
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="border rounded p-2 bg-light-subtle h-100">
            @php
                $pago = $pedido->venta?->pagos->first();
            @endphp
            @if ($pedido->venta()->exists() && $pago)
                <div><strong>Venta:</strong> 💳 pagada por {{ $pago->metodoPago?->nombre ?? 'método no disponible' }}</div>
                <div><strong>Monto pagado:</strong> Bs. {{ number_format((float) $pago->montopago, 2) }}</div>
                @if ((float) $pago->montorecibido > 0)
                    <div><strong>Efectivo recibido:</strong> Bs. {{ number_format((float) $pago->montorecibido, 2) }}</div>
                @endif
                @if ((float) $pago->cambioentregado > 0)
                    <div><strong>Cambio:</strong> Bs. {{ number_format((float) $pago->cambioentregado, 2) }}</div>
                @endif
                @if ($pago->gateway)
                    <div><strong>Pasarela:</strong> {{ $pago->gateway }}</div>
                @endif
                @if ($pago->codigoautorizacion)
                    <div><strong>Autorización:</strong> {{ $pago->codigoautorizacion }}</div>
                @endif
                @if ($pago->referenciaexterna)
                    <div><strong>Referencia:</strong> {{ $pago->referenciaexterna }}</div>
                @endif
                <div><strong>Cobrado por:</strong> {{ $pedido->venta->empleado?->nombre ?? '—' }}</div>
                <div><strong>Fecha de pago:</strong> {{ optional($pago->fechapago)->format('d/m/Y H:i') }}</div>
            @elseif ($pedido->estadopedido === 'ANULADO')
                <div class="text-danger fw-semibold mb-1">Pedido anulado</div>
                @if (! empty($pedido->observaciones))
                    <div><strong>Motivo / observación:</strong></div>
                    <div class="text-muted" style="white-space: pre-line;">{{ $pedido->observaciones }}</div>
                @else
                    <div class="text-muted">Sin observación de anulación.</div>
                @endif
            @else
                <div class="text-muted">Este pedido aún no se ha cobrado.</div>
            @endif
            <div class="mt-1"><strong>Registrado por:</strong> {{ $pedido->empleado?->nombre ?? '—' }}</div>
            @if (! empty($pedido->observaciones) && $pedido->estadopedido !== 'ANULADO')
                <div><strong>Observación:</strong> {{ $pedido->observaciones }}</div>
            @endif
        </div>
    </div>
</div>