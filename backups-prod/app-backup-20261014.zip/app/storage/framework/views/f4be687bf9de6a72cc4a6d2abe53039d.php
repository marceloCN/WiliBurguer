<?php $__env->startSection('title', 'Editar sucursal · ' . $sucursal->nombre . ' · ' . $configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Editar sucursal</h1>
                <p class="text-muted mb-0">
                    Estás editando: <strong><?php echo e($sucursal->nombre); ?></strong>
                    <span class="badge <?php echo e($sucursal->estado ? 'text-bg-success' : 'text-bg-secondary'); ?> ms-1">
                        <?php echo e($sucursal->estado ? 'Activa' : 'Inactiva'); ?>

                    </span>
                </p>
            </div>
            <a href="<?php echo e(route('dashboard.sucursales.index')); ?>" class="btn btn-outline-secondary btn-sm">← Volver</a>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <ul class="nav nav-pills seccion-tabs mb-4 flex-wrap gap-2" id="sucursalTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="tab-datos-tab" data-bs-toggle="pill" data-bs-target="#tab-datos"
                    type="button" role="tab" aria-controls="tab-datos" aria-selected="true">🏪 Datos y ubicación</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-horarios-tab" data-bs-toggle="pill" data-bs-target="#tab-horarios"
                    type="button" role="tab" aria-controls="tab-horarios" aria-selected="false">🕒 Horarios</button>
            </li>
            <?php if($puedeGestionarMesas): ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-mesas-tab" data-bs-toggle="pill" data-bs-target="#tab-mesas"
                        type="button" role="tab" aria-controls="tab-mesas" aria-selected="false">🪑 Mesas</button>
                </li>
            <?php endif; ?>
            <?php if($puedeGestionarCajas): ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tab-cajas-tab" data-bs-toggle="pill" data-bs-target="#tab-cajas"
                        type="button" role="tab" aria-controls="tab-cajas" aria-selected="false">🛢️ Cajas</button>
                </li>
            <?php endif; ?>
        </ul>

        <div class="tab-content" id="sucursalTabsContent">
            
            <div class="tab-pane fade show active" id="tab-datos" role="tabpanel" aria-labelledby="tab-datos-tab">
                <div class="row g-4">
                    <?php if($esAdmin): ?>
                        <div class="col-12">
                            <div class="card tarjeta-producto mb-4 border-warning-subtle">
                                <div class="card-body">
                                    <div class="d-flex align-items-center gap-2 mb-3">
                                        <span class="badge text-bg-brand px-3 py-2">👤 Gerente asignado</span>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('dashboard.sucursales.gerente', $sucursal)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label">Gerente del sistema *</label>
                                                <div class="row g-2">
                                                    <div class="col-md-9">
                                                        <select name="idempleadogerente" class="form-select" required>
                                                            <?php if($sucursal->gerente): ?>
                                                                <option value="<?php echo e($sucursal->gerente->id); ?>" <?php if(true): echo 'selected'; endif; ?>>
                                                                    <?php echo e($sucursal->gerente->nombre); ?>

                                                                    <?php echo e($sucursal->gerente->apellido); ?> (actual)
                                                                </option>
                                                            <?php endif; ?>
                                                            <option value="">— Sin gerente —</option>
                                                            <?php $__currentLoopData = $gerentesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gerente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($gerente->id); ?>"
                                                                    <?php if(old('idempleadogerente') == $gerente->id): echo 'selected'; endif; ?>>
                                                                    <?php echo e($gerente->nombre); ?> <?php echo e($gerente->apellido); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 d-grid">
                                                        <button type="submit" class="btn btn-brand">
                                                            <i class="bi bi-person-check"></i> Asignar gerente
                                                        </button>
                                                    </div>
                                                </div>
                                                <p class="small text-muted mt-2 mb-0">
                                                    Solo se muestran gerentes del sistema que no están asignados a otra
                                                    sucursal.
                                                </p>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="<?php echo e($esAdmin ? 'col-xl-7' : 'col-12'); ?>">
                        <form method="POST" action="<?php echo e(route('dashboard.sucursales.update', $sucursal)); ?>" id="form-datos-sucursal">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="latitud" id="latitud-envio"
                                value="<?php echo e(old('latitud', $sucursal->latitud)); ?>">
                            <input type="hidden" name="longitud" id="longitud-envio"
                                value="<?php echo e(old('longitud', $sucursal->longitud)); ?>">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Datos generales</h2>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Nombre <span class="text-danger">*</span></label>
                                            <input type="text" name="nombre" class="form-control" required
                                                value="<?php echo e(old('nombre', $sucursal->nombre)); ?>" maxlength="255">
                                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Teléfono <span class="text-danger">*</span></label>
                                            <input type="text" name="telefono" class="form-control" required
                                                value="<?php echo e(old('telefono', $sucursal->telefono)); ?>" maxlength="15">
                                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Dirección <span class="text-danger">*</span></label>
                                            <input type="text" name="direccion" class="form-control" required
                                                value="<?php echo e(old('direccion', $sucursal->direccion)); ?>" maxlength="255">
                                            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer bg-light-subtle border-top">
                                    <button type="submit" class="btn btn-brand">💾 Guardar sucursal</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="<?php echo e($esAdmin ? 'col-xl-5' : 'col-12'); ?>">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-1">Ubicación en el mapa</h2>
                                <p class="small text-muted mb-3">
                                    Busca una dirección, haz clic en el mapa o arrastra el marcador para fijar la
                                    ubicación exacta.
                                </p>

                                <div class="input-group mb-3">
                                    <input type="text" id="buscarLugar" class="form-control"
                                        placeholder="Buscar dirección o lugar…">
                                    <button type="button" id="btnBuscarLugar" class="btn btn-brand">
                                        <i class="bi bi-search"></i> Buscar
                                    </button>
                                </div>

                                <div id="mapa-editar" class="mapa-editar mb-3"></div>

                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Latitud <span
                                                class="text-danger">*</span></label>
                                        <input type="number" step="any" name="latitud" id="latitud"
                                            class="form-control" value="<?php echo e(old('latitud', $sucursal->latitud)); ?>"
                                            required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Longitud <span
                                                class="text-danger">*</span></label>
                                        <input type="number" step="any" name="longitud" id="longitud"
                                            class="form-control" value="<?php echo e(old('longitud', $sucursal->longitud)); ?>"
                                            required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="tab-horarios" role="tabpanel" aria-labelledby="tab-horarios-tab">
                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-1">Agregar horario</h2>
                                    <p class="small text-muted mb-3">
                                        Define el horario de atención de cada día: la <strong>hora de cierre debe ser
                                        posterior a la apertura</strong> y solo puede existir <strong>un horario por día</strong>.
                                        Si un día no atienden, déjalo sin registrar.
                                    </p>
                                <form method="POST"
                                    action="<?php echo e(route('dashboard.sucursales.horario.store', $sucursal)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label small fw-bold">Día <span
                                                    class="text-danger">*</span></label>
                                            <select name="iddiaatencion" class="form-select" required>
                                                <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($dia->id); ?>"><?php echo e($dia->nombredia); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label small fw-bold">Apertura <span
                                                    class="text-danger">*</span></label>
                                            <input type="time" name="horaapertura" class="form-control" required
                                                value="<?php echo e(old('horaapertura')); ?>">
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label small fw-bold">Cierre <span
                                                    class="text-danger">*</span></label>
                                            <input type="time" name="horacierre" class="form-control" required
                                                value="<?php echo e(old('horacierre')); ?>">
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label small fw-bold">Estado inicial</label>
                                            <select name="activo" class="form-select">
                                                <option value="1" <?php if(old('activo', 1)): echo 'selected'; endif; ?>>Activo</option>
                                                <option value="0" <?php if(old('activo') === '0'): echo 'selected'; endif; ?>>Inactivo</option>
                                            </select>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-brand w-100">+ Agregar horario</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="card tarjeta-producto">
                            <div class="card-body">
                                <h2 class="h5 fw-bold mb-3">Horarios registrados</h2>
                                <?php if($sucursal->horarios->isEmpty()): ?>
                                    <div class="alert alert-light text-center mb-0">
                                        Esta sucursal aún no tiene horarios registrados.
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table align-middle mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Día</th>
                                                    <th>Horario</th>
                                                    <th>Estado</th>
                                                    <th class="text-end">Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $sucursal->horarios->sortBy(fn($h) => $h->diaAtencion?->numerodia); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <span class="fw-semibold">
                                                                <?php echo e($horario->diaAtencion?->nombredia ?? 'Sin asignar'); ?>

                                                            </span>
                                                        </td>
                                                        <td class="font-monospace">
                                                            <?php echo e(substr($horario->horaapertura, 0, 5)); ?> –
                                                            <?php echo e(substr($horario->horacierre, 0, 5)); ?>

                                                        </td>
                                                        <td>
                                                            <span
                                                                class="badge rounded-pill <?php echo e($horario->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                                                <?php echo e($horario->activo ? 'Activo' : 'Inactivo'); ?>

                                                            </span>
                                                        </td>
                                                        <td class="text-end">
                                                            <button type="button" class="btn btn-sm btn-outline-brand"
                                                                data-bs-toggle="collapse"
                                                                data-bs-target="#editar-horario-<?php echo e($horario->idhorariosucursal); ?>"
                                                                aria-expanded="false"
                                                                aria-controls="editar-horario-<?php echo e($horario->idhorariosucursal); ?>">
                                                                ✏️ Editar
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    <tr class="table-light">
                                                        <td colspan="4" class="p-0 border-0">
                                                            <div class="collapse"
                                                                id="editar-horario-<?php echo e($horario->idhorariosucursal); ?>">
                                                                <div class="p-3">
                                                                    <form method="POST"
                                                                        action="<?php echo e(route('dashboard.sucursales.horario.update', [$sucursal, $horario])); ?>"
                                                                        class="row g-2 align-items-end">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="col-6 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Día</label>
                                                                            <select name="iddiaatencion"
                                                                                class="form-select form-select-sm">
                                                                                <?php $__currentLoopData = $dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($dia->id); ?>"
                                                                                        <?php if($horario->iddiaatencion === $dia->id): echo 'selected'; endif; ?>>
                                                                                        <?php echo e($dia->nombredia); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-5 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Apertura</label>
                                                                            <input type="time" name="horaapertura"
                                                                                value="<?php echo e(substr($horario->horaapertura, 0, 5)); ?>"
                                                                                class="form-control form-control-sm"
                                                                                required>
                                                                        </div>
                                                                        <div
                                                                            class="col-2 col-md-1 text-center text-muted pb-1">
                                                                            –
                                                                        </div>
                                                                        <div class="col-5 col-md-3">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Cierre</label>
                                                                            <input type="time" name="horacierre"
                                                                                value="<?php echo e(substr($horario->horacierre, 0, 5)); ?>"
                                                                                class="form-control form-control-sm"
                                                                                required>
                                                                        </div>
                                                                        <div class="col-6 col-md-2">
                                                                            <label
                                                                                class="form-label small fw-bold d-block">Estado</label>
                                                                            <select name="activo"
                                                                                class="form-select form-select-sm">
                                                                                <option value="1"
                                                                                    <?php if($horario->activo): echo 'selected'; endif; ?>>Activo</option>
                                                                                <option value="0"
                                                                                    <?php if(!$horario->activo): echo 'selected'; endif; ?>>Inactivo
                                                                                </option>
                                                                            </select>
                                                                        </div>
                                                                        <div class="col-6 col-md-3 d-flex gap-1">
                                                                            <button type="submit"
                                                                                class="btn btn-sm btn-brand flex-fill">
                                                                                ✓ Guardar
                                                                            </button>
                                                                            <button type="button"
                                                                                class="btn btn-sm btn-outline-secondary"
                                                                                data-bs-toggle="collapse"
                                                                                data-bs-target="#editar-horario-<?php echo e($horario->idhorariosucursal); ?>">
                                                                                Cancelar
                                                                            </button>
                                                                        </div>
                                                                    </form>
                                                                    <button type="button"
                                                                        class="btn btn-sm btn-outline-danger mt-2"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#modal-confirmar-baja"
                                                                        data-accion="<?php echo e(route('dashboard.sucursales.horario.baja', [$sucursal, $horario])); ?>"
                                                                        data-mensaje="¿Eliminar el horario del <?php echo e($horario->diaAtencion?->nombredia ?? 'día seleccionado'); ?>?">
                                                                        🗑️ Eliminar
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <?php if($puedeGestionarMesas): ?>
                <div class="tab-pane fade" id="tab-mesas" role="tabpanel" aria-labelledby="tab-mesas-tab">
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-1">Registrar mesa</h2>
                                    <p class="small text-muted mb-3">
                                        Asigna a cada mesa un <strong>número</strong> y cuántas <strong>personas</strong>
                                        puede sentar. El número de mesa <strong>no puede repetirse</strong> dentro de
                                        esta sucursal.
                                    </p>
                                    <form method="POST" action="<?php echo e(route('dashboard.sucursales.mesa.store', $sucursal)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="row g-3">
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Número <span
                                                            class="text-danger">*</span></label>
                                                    <input type="number" name="numeromesa" class="form-control" min="1"
                                                        required value="<?php echo e(old('numeromesa')); ?>">
                                                </div>
                                                <div class="col-6">
                                                    <label class="form-label small fw-bold">Capacidad <span
                                                            class="text-danger">*</span></label>
                                                    <input type="number" name="capacidad" class="form-control" min="1"
                                                        required value="<?php echo e(old('capacidad', 4)); ?>">
                                                </div>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-brand w-100">+ Registrar mesa</button>
                                                </div>
                                            </div>
                                        </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Mesas de esta sucursal</h2>
                                    <?php if($sucursal->mesas->isEmpty()): ?>
                                        <div class="alert alert-light text-center mb-0">
                                            Esta sucursal aún no tiene mesas registradas.
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table align-middle mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Mesa</th>
                                                        <th>Capacidad</th>
                                                        <th>Estado</th>
                                                        <th class="text-end">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $sucursal->mesas->sortBy('numeromesa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <span class="fw-semibold">Mesa <?php echo e($mesa->numeromesa); ?></span>
                                                            </td>
                                                            <td>
                                                                <?php echo e($mesa->capacidad); ?>

                                                                <span class="text-muted small">personas</span>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge rounded-pill <?php echo e($mesa->estado ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                                                    <?php echo e($mesa->estado ? 'Activa' : 'Inactiva'); ?>

                                                                </span>
                                                            </td>
                                                            <td class="text-end">
                                                                <button type="button" class="btn btn-sm btn-outline-brand"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#editar-mesa-<?php echo e($mesa->id); ?>"
                                                                    aria-expanded="false"
                                                                    aria-controls="editar-mesa-<?php echo e($mesa->id); ?>">
                                                                    ✏️ Editar
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <tr class="table-light">
                                                            <td colspan="4" class="p-0 border-0">
                                                                <div class="collapse" id="editar-mesa-<?php echo e($mesa->id); ?>">
                                                                    <div class="p-3">
                                                                        <form method="POST"
                                                                            action="<?php echo e(route('dashboard.sucursales.mesa.update', [$sucursal, $mesa])); ?>"
                                                                            class="row g-2 align-items-end">
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Número</label>
                                                                                <input type="number" name="numeromesa"
                                                                                    class="form-control form-control-sm"
                                                                                    min="1" value="<?php echo e($mesa->numeromesa); ?>"
                                                                                    required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Capacidad</label>
                                                                                <input type="number" name="capacidad"
                                                                                    class="form-control form-control-sm"
                                                                                    min="1" value="<?php echo e($mesa->capacidad); ?>"
                                                                                    required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Estado</label>
                                                                                <select name="estado"
                                                                                    class="form-select form-select-sm">
                                                                                    <option value="1" <?php if($mesa->estado): echo 'selected'; endif; ?>>Activa
                                                                                    </option>
                                                                                    <option value="0" <?php if(!$mesa->estado): echo 'selected'; endif; ?>>Inactiva
                                                                                    </option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-6 col-md-3 gap-1 d-flex">
                                                                                <button type="submit"
                                                                                    class="btn btn-sm btn-brand flex-fill">
                                                                                    ✓ Guardar
                                                                                </button>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-secondary"
                                                                                    data-bs-toggle="collapse"
                                                                                    data-bs-target="#editar-mesa-<?php echo e($mesa->id); ?>">
                                                                                    Cancelar
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                        <?php if($mesa->estado): ?>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-danger mt-2"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#modal-confirmar-baja"
                                                                                    data-accion="<?php echo e(route('dashboard.sucursales.mesa.baja', [$sucursal, $mesa])); ?>"
                                                                                    data-mensaje="¿Dar de baja la Mesa <?php echo e($mesa->numeromesa); ?>?">
                                                                                    🗑️ Dar de baja
                                                                                </button>
                                                                            <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <?php if($puedeGestionarCajas): ?>
                <div class="tab-pane fade" id="tab-cajas" role="tabpanel" aria-labelledby="tab-cajas-tab">
                    <div class="row g-4">
                        <div class="col-lg-5">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-1">Registrar caja</h2>
                                    <p class="small text-muted mb-3">
                                        Cada caja recibe un <strong>nombre</strong> que no puede repetirse dentro de esta
                                        sucursal, y solo puede haber <strong>dos cajas activas</strong> a la vez.
                                        La caja no se asocia a un cajero: sirve para identificar la apertura y cualquier
                                        cajero puede abrirla con solo conocer su nombre.
                                    </p>
                                    <form method="POST"
                                        action="<?php echo e(route('dashboard.sucursales.caja.store', $sucursal)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label small fw-bold">Nombre <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="nombre" class="form-control" required
                                                    maxlength="100" value="<?php echo e(old('nombre')); ?>"
                                                    placeholder="Ej. Caja 1">
                                            </div>
                                            <div class="col-12">
                                                <label class="form-label small fw-bold">Estado inicial</label>
                                                <select name="activo" class="form-select">
                                                    <option value="1" <?php if(old('activo', 1)): echo 'selected'; endif; ?>>Activa</option>
                                                    <option value="0" <?php if(old('activo') === '0'): echo 'selected'; endif; ?>>Inactiva</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <button type="submit" class="btn btn-brand w-100">Registrar
                                                    caja</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <div class="card tarjeta-producto">
                                <div class="card-body">
                                    <h2 class="h5 fw-bold mb-3">Cajas de esta sucursal</h2>
                                    <?php if($sucursal->cajas->isEmpty()): ?>
                                        <div class="alert alert-light text-center mb-0">
                                            Esta sucursal aún no tiene cajas registradas.
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table align-middle mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Caja</th>
                                                        <th>Estado</th>
                                                        <th class="text-end">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $sucursal->cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td>
                                                                <span class="fw-semibold"><?php echo e($caja->nombre); ?></span>
                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="badge rounded-pill <?php echo e($caja->activo ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                                                    <?php echo e($caja->activo ? 'Activa' : 'Inactiva'); ?>

                                                                </span>
                                                            </td>
                                                            <td class="text-end">
                                                                <button type="button"
                                                                    class="btn btn-sm btn-outline-brand"
                                                                    data-bs-toggle="collapse"
                                                                    data-bs-target="#editar-caja-<?php echo e($caja->id); ?>"
                                                                    aria-expanded="false"
                                                                    aria-controls="editar-caja-<?php echo e($caja->id); ?>">
                                                                    ✏️ Editar
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <tr class="table-light">
                                                            <td colspan="3" class="p-0 border-0">
                                                                <div class="collapse" id="editar-caja-<?php echo e($caja->id); ?>">
                                                                    <div class="p-3">
                                                                        <form method="POST"
                                                                            action="<?php echo e(route('dashboard.sucursales.caja.update', [$sucursal, $caja])); ?>"
                                                                            class="row g-2 align-items-end">
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="col-6 col-md-4">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Nombre</label>
                                                                                <input type="text" name="nombre"
                                                                                    class="form-control form-control-sm"
                                                                                    maxlength="100"
                                                                                    value="<?php echo e($caja->nombre); ?>" required>
                                                                            </div>
                                                                            <div class="col-6 col-md-3">
                                                                                <label
                                                                                    class="form-label small fw-bold d-block">Estado</label>
                                                                                <select name="activo"
                                                                                    class="form-select form-select-sm">
                                                                                    <option value="1"
                                                                                        <?php if($caja->activo): echo 'selected'; endif; ?>>Activa
                                                                                    </option>
                                                                                    <option value="0"
                                                                                        <?php if(!$caja->activo): echo 'selected'; endif; ?>>Inactiva
                                                                                    </option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="col-12 col-md-5 gap-1 d-flex">
                                                                                <button type="submit"
                                                                                    class="btn btn-sm btn-brand flex-fill">
                                                                                    ✓ Guardar
                                                                                </button>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-secondary"
                                                                                    data-bs-toggle="collapse"
                                                                                    data-bs-target="#editar-caja-<?php echo e($caja->id); ?>">
                                                                                    Cancelar
                                                                                </button>
                                                                            </div>
                                                                        </form>
                                                                        <?php if($caja->activo): ?>
                                                                                <button type="button"
                                                                                    class="btn btn-sm btn-outline-danger mt-2"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#modal-confirmar-baja"
                                                                                    data-accion="<?php echo e(route('dashboard.sucursales.caja.baja', [$sucursal, $caja])); ?>"
                                                                                    data-mensaje="¿Dar de baja la caja <?php echo e($caja->nombre); ?>?">
                                                                                    🗑️ Dar de baja
                                                                                </button>
                                                                            <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="modal fade" id="modal-confirmar-baja" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <form method="POST" id="form-confirmar-baja" class="modal-content">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h2 class="modal-title fs-5">⚠️ Confirmar baja</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p class="mb-0" id="texto-confirmar-baja"></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-danger">🗑️ Confirmar baja</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        .mapa-editar {
            height: 340px;
            border-radius: 0.75rem;
            background: #eee;
            z-index: 0;
        }

        .seccion-tabs .nav-link {
            border-radius: 2rem;
            padding: .5rem 1.1rem;
            font-weight: 600;
        }

        .seccion-tabs .nav-link.active {
            background-color: var(--brand);
            color: #fff;
        }

        @media (max-width: 575.98px) {
            .mapa-editar {
                height: 280px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        const latInicial = <?php echo e((float) $sucursal->latitud); ?>;
        const lngInicial = <?php echo e((float) $sucursal->longitud); ?>;

        const campoLat = document.getElementById('latitud');
        const campoLng = document.getElementById('longitud');
        const latitudEnvio = document.getElementById('latitud-envio');
        const longitudEnvio = document.getElementById('longitud-envio');

        function sincronizarEnvio() {
            latitudEnvio.value = campoLat.value;
            longitudEnvio.value = campoLng.value;
        }

        const mapa = L.map('mapa-editar').setView([latInicial, lngInicial], 16);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(mapa);

        const marcador = L.marker([latInicial, lngInicial], { draggable: true }).addTo(mapa);

        function fijarCoordenadas(lat, lng) {
            campoLat.value = lat.toFixed(6);
            campoLng.value = lng.toFixed(6);
            sincronizarEnvio();
        }

        fijarCoordenadas(latInicial, lngInicial);

        marcador.on('dragend', function() {
            const posicion = marcador.getLatLng();
            fijarCoordenadas(posicion.lat, posicion.lng);
        });

        mapa.on('click', function(evento) {
            marcador.setLatLng(evento.latlng);
            fijarCoordenadas(evento.latlng.lat, evento.latlng.lng);
        });

        [campoLat, campoLng].forEach(function(input) {
            input.addEventListener('change', function() {
                const lat = parseFloat(campoLat.value);
                const lng = parseFloat(campoLng.value);
                if (Number.isFinite(lat) && Number.isFinite(lng)) {
                    marcador.setLatLng([lat, lng]);
                    mapa.panTo([lat, lng]);
                    sincronizarEnvio();
                }
            });
        });

        document.getElementById('form-datos-sucursal').addEventListener('submit', sincronizarEnvio);

        // Buscador de direcciones (Nominatim / OpenStreetMap)
        const inputBusqueda = document.getElementById('buscarLugar');
        const botonBusqueda = document.getElementById('btnBuscarLugar');

        function buscarLugar() {
            const texto = inputBusqueda.value.trim();
            if (!texto) return;
            fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(texto))
                .then(function(respuesta) {
                    if (!respuesta.ok) throw new Error('Error de red');
                    return respuesta.json();
                })
                .then(function(resultados) {
                    if (!resultados.length) {
                        alert('No se encontró el lugar buscado.');
                        return;
                    }
                    const lat = parseFloat(resultados[0].lat);
                    const lng = parseFloat(resultados[0].lon);
                    nombre = resultados[0].display_name;
                    // Si el campo dirección está vacío o es el valor por defecto, lo completamos.
                    const campoDireccion = document.querySelector('input[name="direccion"]');
                    if (campoDireccion && !campoDireccion.value.trim()) {
                        campoDireccion.value = nombre;
                    }
                    marcador.setLatLng([lat, lng]);
                    mapa.panTo([lat, lng], 16);
                    fijarCoordenadas(lat, lng);
                })
                .catch(function() {
                    alert('No se pudo realizar la búsqueda. Revisa tu conexión.');
                });
        }

        botonBusqueda.addEventListener('click', buscarLugar);
        inputBusqueda.addEventListener('keydown', function(evento) {
            if (evento.key === 'Enter') {
                evento.preventDefault();
                buscarLugar();
            }
        });

        // Modal de confirmación de bajas: copia la acción y el mensaje del botón disparador.
        const modalBaja = document.getElementById('modal-confirmar-baja');
        if (modalBaja) {
            modalBaja.addEventListener('show.bs.modal', function(evento) {
                const disparador = evento.relatedTarget;
                if (!disparador) return;
                document.getElementById('form-confirmar-baja')
                    .setAttribute('action', disparador.getAttribute('data-accion'));
                document.getElementById('texto-confirmar-baja').textContent =
                    disparador.getAttribute('data-mensaje') || '¿Confirmas realizar esta acción?';
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/sucursales/editar.blade.php ENDPATH**/ ?>