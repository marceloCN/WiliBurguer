

<?php $__env->startSection('title', 'Inventario · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Inventario 📊</h1>
                <p class="text-muted mb-0">Registra entradas, salidas y ajustes de stock por sucursal.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-brand" data-bs-toggle="modal" data-bs-target="#reporteModal">
                    📄 Reportes PDF
                </button>
                <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#nuevoMovimientoModal"
                        <?php if($insumos->isEmpty()): ?> disabled title="Primero crea insumos en Insumos y recetas" <?php endif; ?>>
                    + Registrar movimiento
                </button>
            </div>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <p class="small text-muted mb-3">
            Cada registro es un <strong>movimiento</strong> que actualiza el stock de un insumo en la sucursal seleccionada:
            <strong>ENTRADA</strong> suma cantidad (ej. compras o reposiciones),
            <strong>SALIDA</strong> resta (ej. consumo o despacho), y
            <strong>AJUSTE</strong> deja la cantidad exacta que indiques (ej. conteo físico o merma).
            Para usarlo pulsa «+ Registrar movimiento», elige el insumo, el tipo, la cantidad y una observación opcional.
        </p>

        <div class="row g-4">
            
            <?php if($esAdmin): ?>
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto h-100">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursales</span>
                        <span class="badge text-bg-dark"><?php echo e($sucursales->count()); ?></span>
                    </div>
                    <?php if($sucursales->count() <= 1): ?>
                        <div class="card-body">
                            <div class="fw-semibold"><?php echo e($sucursalActual->nombre); ?></div>
                            <?php if($empleado->sucursal && $sucursalActual->id === $empleado->sucursal->id): ?>
                                <div class="small text-muted">Tu sucursal asignada</div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="list-group">
                            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('dashboard.inventario.index', ['idsucursal' => $sucursal->id])); ?>"
                                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                          <?php echo e($sucursalActual->id === $sucursal->id ? 'active' : ''); ?>">
                                    <span class="fw-semibold"><?php echo e($sucursal->nombre); ?></span>
                                    <?php if(!$sucursal->estado): ?>
                                        <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            
            <div class="<?php echo e($esAdmin ? 'col-12 col-lg-8' : 'col-12'); ?>">
                <?php if(! $esAdmin): ?>
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <span class="badge text-bg-brand"><?php echo e($sucursalActual->nombre); ?></span>
                        <span class="text-muted small">Inventario de tu sucursal</span>
                    </div>
                <?php endif; ?>
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <span class="fw-bold">Stock · <?php echo e($sucursalActual->nombre); ?></span>
                        <span class="badge text-bg-brand"><?php echo e($inventario->count()); ?> insumo(s)</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Insumo</th>
                                        <th>Unidad</th>
                                        <th>Cantidad</th>
                                        <th>Mínimo</th>
                                        <th>Estado</th>
                                        <th class="text-end">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $stockBajo = $item->cantidadminima !== null && $item->cantidad <= $item->cantidadminima;
                                        ?>
                                        <tr>
                                            <td class="fw-semibold"><?php echo e($item->insumo?->nombre); ?></td>
                                            <td>
                                                <span class="badge text-bg-light border"><?php echo e($item->insumo?->unidadMedida?->abreviatura ?? '—'); ?></span>
                                            </td>
                                            <td class="fw-semibold"><?php echo e(rtrim(rtrim(number_format($item->cantidad, 3, '.', ''), '0'), '.')); ?></td>
                                            <td><?php echo e($item->cantidadminima !== null ? rtrim(rtrim(number_format($item->cantidadminima, 3, '.', ''), '0'), '.') : '—'); ?></td>
                                            <td>
                                                <?php if($item->cantidad <= 0): ?>
                                                    <span class="badge text-bg-danger">Sin stock</span>
                                                <?php elseif($stockBajo): ?>
                                                    <span class="badge text-bg-warning">Bajo</span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-success">OK</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-outline-brand"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#editarMinimoModal"
                                                        data-id="<?php echo e($item->id); ?>"
                                                        data-insumo="<?php echo e($item->insumo?->nombre); ?>"
                                                        data-minimo="<?php echo e($item->cantidadminima); ?>">
                                                    Editar mín.
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4 text-muted">
                                                No hay insumos cargados en esta sucursal. Pulsa "+ Registrar movimiento" para comenzar.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Movimientos recientes</span>
                        <span class="badge text-bg-dark"><?php echo e($movimientos->count()); ?></span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Fecha</th>
                                        <th>Tipo</th>
                                        <th>Insumo</th>
                                        <th>Cantidad</th>
                                        <th>Stock: anterior → nuevo</th>
                                        <th>Empleado</th>
                                        <th>Observación</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="small"><?php echo e($movimiento->fechamovimiento->format('d/m/Y H:i')); ?></td>
                                            <td>
                                                <?php
                                                    $tipoClase = match ($movimiento->tipomovimiento) {
                                                        'ENTRADA' => 'text-bg-success',
                                                        'SALIDA' => 'text-bg-danger',
                                                        default => 'text-bg-warning',
                                                    };
                                                ?>
                                                <span class="badge <?php echo e($tipoClase); ?>"><?php echo e($movimiento->tipomovimiento); ?></span>
                                            </td>
                                            <td class="fw-semibold"><?php echo e($movimiento->inventarioSucursal?->insumo?->nombre); ?></td>
                                            <td class="fw-semibold"><?php echo e(rtrim(rtrim(number_format($movimiento->cantidad, 3, '.', ''), '0'), '.')); ?></td>
                                            <td class="small">
                                                <?php echo e(rtrim(rtrim(number_format($movimiento->cantidadanterior, 3, '.', ''), '0'), '.')); ?> → <?php echo e(rtrim(rtrim(number_format($movimiento->cantidadnueva, 3, '.', ''), '0'), '.')); ?>

                                            </td>
                                            <td class="small text-muted">
                                                <?php if($movimiento->empleado): ?>
                                                    <?php echo e($movimiento->empleado->nombre); ?> <?php echo e($movimiento->empleado->apellido); ?>

                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>
                                            <td class="small text-muted"><?php echo e($movimiento->observacion ?? '—'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-4 text-muted">
                                                Aún no hay movimientos registrados en esta sucursal.
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="nuevoMovimientoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="<?php echo e(route('dashboard.inventario.movimiento.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="idsucursal" value="<?php echo e($sucursalActual->id); ?>">
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Registrar movimiento de inventario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Sucursal</label>
                                <div class="fw-semibold text-muted"><?php echo e($sucursalActual->nombre); ?></div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Insumo *</label>
                                <select name="idinsumo" class="form-select" required>
                                    <option value="" selected disabled>Selecciona un insumo…</option>
                                    <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($insumo->id); ?>" <?php if(old('idinsumo') == $insumo->id): echo 'selected'; endif; ?>>
                                            <?php echo e($insumo->nombre); ?> (<?php echo e($insumo->unidadMedida?->abreviatura); ?>)
                                            <?php echo e($insumosDisponibles->contains('id', $insumo->id) ? '· nuevo en esta sucursal' : ''); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Tipo de movimiento *</label>
                                <select name="tipo" class="form-select" required>
                                    <?php $__currentLoopData = \App\Http\Controllers\InventarioController::TIPOS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tipo); ?>" <?php if(old('tipo') === $tipo): echo 'selected'; endif; ?>><?php echo e($tipo); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-text">
                                    Entrada: suma stock · Salida: resta stock · Ajuste: fija la cantidad exacta.
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cantidad *</label>
                                <input type="number" name="cantidad" class="form-control" required
                                       step="0.001" min="0.001" value="<?php echo e(old('cantidad')); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cantidad mínima</label>
                                <input type="number" name="cantidadminima" class="form-control"
                                       step="0.001" min="0" placeholder="Solo al crear el insumo en esta sucursal"
                                       value="<?php echo e(old('cantidadminima')); ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Observación</label>
                                <textarea name="observacion" rows="2" class="form-control" maxlength="255"
                                          placeholder="Ej.: Compra semanal, merma, conteo físico…"><?php echo e(old('observacion')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Registrar movimiento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="editarMinimoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="POST" id="form-editar-minimo">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Cantidad mínima de inventario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <p class="text-muted mb-3">
                            Cuando el stock de <strong id="minimoInsumoNombre"></strong> sea
                            <strong>menor o igual</strong> a la cantidad mínima, se mostrará la alerta de stock bajo.
                        </p>
                        <label class="form-label">Cantidad mínima</label>
                        <input type="number" name="cantidadminima" id="minimoCantidad" class="form-control"
                               step="0.001" min="0" placeholder="Deja vacío para sin mínimo">
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Guardar mínimo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="reporteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow">
                <form method="GET" action="<?php echo e(route('dashboard.inventario.reporte')); ?>">
                    <?php if(! $esAdmin): ?>
                        <input type="hidden" name="idsucursal" value="<?php echo e($sucursalActual->id); ?>">
                    <?php endif; ?>
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Reportes PDF · <?php echo e($sucursalActual->nombre); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-light border small mb-3">
                            Descarga un PDF con el estado actual del inventario o con los movimientos
                            (entradas, salidas y ajustes) de <strong><?php echo e($sucursalActual->nombre); ?></strong>.
                        </div>
                        <div class="row g-3">
                            <?php if($esAdmin && $sucursales->count() > 1): ?>
                                <div class="col-12">
                                    <label class="form-label">Sucursal *</label>
                                    <select name="idsucursal" class="form-select" required>
                                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sucursal->id); ?>" <?php if($sucursalActual->id === $sucursal->id): echo 'selected'; endif; ?>>
                                                <?php echo e($sucursal->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            <?php endif; ?>
                            <div class="col-12">
                                <label class="form-label">Tipo de detalle *</label>
                                <select name="tipo" class="form-select" id="reporteTipo" required>
                                    <option value="estado">Estado actual de inventario</option>
                                    <option value="movimientos">Movimientos de entrada, salida y ajuste</option>
                                </select>
                            </div>
                            <div class="col-12" id="reporteFechaDesde" style="display:none;">
                                <label class="form-label">Desde qué fecha *</label>
                                <input type="date" name="fecha_desde" class="form-control"
                                       value="<?php echo e(old('fecha_desde', now()->startOfMonth()->format('Y-m-d'))); ?>">
                                <div class="form-text">Se listarán los movimientos desde esa fecha hasta hoy.</div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Descargar PDF</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.querySelectorAll('[data-bs-target="#editarMinimoModal"]').forEach(function (boton) {
            boton.addEventListener('click', function () {
                var id = boton.getAttribute('data-id');
                var insumo = boton.getAttribute('data-insumo');
                var minimo = boton.getAttribute('data-minimo');

                document.getElementById('form-editar-minimo').action = '<?php echo e(route('dashboard.inventario.minimo', 'ID')); ?>'.replace('ID', id);
                document.getElementById('minimoInsumoNombre').textContent = insumo;
                document.getElementById('minimoCantidad').value = (minimo !== '' && minimo !== null) ? minimo : '';
            });
        });

        var selectTipo = document.getElementById('reporteTipo');
        var campoFecha = document.getElementById('reporteFechaDesde');
        function alternarFechaReporte() {
            campoFecha.style.display = selectTipo.value === 'movimientos' ? '' : 'none';
            var fecha = document.querySelector('input[name="fecha_desde"]');
            if (fecha) {
                fecha.required = selectTipo.value === 'movimientos';
            }
        }
        if (selectTipo) {
            selectTipo.addEventListener('change', alternarFechaReporte);
            alternarFechaReporte();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/inventario/index.blade.php ENDPATH**/ ?>