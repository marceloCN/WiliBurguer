<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ResetPasswordNotification extends Notification
{
    use Queueable;

    public function __construct(public string $token) {}

    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $nombre = $notifiable->empleado?->nombre;
        $apellido = $notifiable->empleado?->apellido;

        $url = route('password.reset', [
            'token' => $this->token,
            'correo' => $notifiable->getEmailForPasswordReset(),
        ]);

        $saludo = $nombre
            ? "Hola, {$nombre} {$apellido}"
            : 'Hola';

        return (new MailMessage)
            ->from(config('mail.from.address'), $nombre ? "{$nombre} {$apellido}" : 'Burguer Willy')
            ->subject('Recuperación de contraseña · Burguer Willy')
            ->greeting($saludo.',')
            ->line('Recibimos una solicitud para restablecer la contraseña de tu cuenta en Burguer Willy.')
            ->line('Para continuar, haz clic en el siguiente botón y elige tu nueva contraseña.')
            ->action('Cambiar mi contraseña', $url)
            ->line('Si no solicitaste este cambio, puedes ignorar este correo.')
            ->line('Este enlace expirará en 60 minutos.');
    }
}
