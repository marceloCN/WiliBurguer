<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\DiaAtencion;
use App\Models\Empleado;
use App\Models\HorarioSucursal;
use App\Models\Mesa;
use App\Models\Sucursal;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SucursalController extends Controller
{
    public function index(): View
    {
        $esGerente = $this->esGerente();

        $sucursales = Sucursal::with(['gerente', 'horarios.diaAtencion'])
            ->when($esGerente, function ($query) {
                $query->where('idempleadogerente', auth()->user()->empleado->id);
            })
            ->where('estado', true)
            ->orderBy('nombre')
            ->get();

        return view('admin.sucursales.index', compact('sucursales'));
    }

    public function create(): View
    {
        return view('admin.sucursales.create', [
            'gerentesDisponibles' => $this->gerentesDisponibles(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'direccion' => ['required', 'string', 'max:255'],
            'telefono' => ['required', 'string', 'max:15'],
            'latitud' => ['required', 'numeric', 'between:-90,90'],
            'longitud' => ['required', 'numeric', 'between:-180,180'],
            'idempleadogerente' => ['nullable', 'exists:empleado,id'],
        ]);

        if (! empty($validated['idempleadogerente'])) {
            $this->asegurarGerente($validated['idempleadogerente']);
        }

        $sucursal = Sucursal::create([
            'nombre' => $validated['nombre'],
            'direccion' => $validated['direccion'],
            'telefono' => $validated['telefono'],
            'latitud' => $validated['latitud'],
            'longitud' => $validated['longitud'],
            'estado' => true,
            'idempleadogerente' => $validated['idempleadogerente'] ?? null,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'sucursal', $sucursal->id, '200');

        if (! empty($validated['idempleadogerente'])) {
            $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'sucursal', $sucursal->id, '204');
        }

        return redirect()
            ->route('dashboard.sucursales.editar', $sucursal)
            ->with('exito', 'Sucursal creada correctamente.');
    }

    public function edit(Sucursal $sucursal): View
    {
        $this->autorizarSucursal($sucursal);

        $sucursal->load(['gerente', 'horarios.diaAtencion', 'mesas', 'cajas']);

        $dias = DiaAtencion::orderBy('numerodia')->get();

        $codigos = $this->codigosPermisoActuales();

        return view('admin.sucursales.editar', [
            'sucursal' => $sucursal,
            'dias' => $dias,
            'gerentesDisponibles' => $this->gerentesDisponibles(),
            'esAdmin' => $this->esAdmin(),
            'puedeGestionarMesas' => $codigos->intersect(['210', '211', '215'])->isNotEmpty(),
            'puedeAperturaCaja' => $codigos->intersect(['400', '401', '402', '405', '410', '411', '412', '415'])->isNotEmpty(),
            'puedeGestionarCajas' => $codigos->intersect(['400', '401', '405'])->isNotEmpty(),
        ]);
    }

    public function asignarGerente(Request $request, Sucursal $sucursal): RedirectResponse
    {
        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'idempleadogerente' => ['nullable', 'exists:empleado,id'],
        ]);

        if (! empty($validated['idempleadogerente'])) {
            $this->asegurarGerente($validated['idempleadogerente']);
        }

        $jefeAnterior = $sucursal->idempleadogerente;
        $jefeNuevo = $validated['idempleadogerente'] ?? null;

        if ($jefeAnterior !== $jefeNuevo) {
            $this->reasignarSubordinados($jefeAnterior, $jefeNuevo, $sucursal->id);
        }

        $sucursal->update([
            'idempleadogerente' => $jefeNuevo,
        ]);

        // El gerente asignado también queda registrado como empleado de la sucursal.
        if ($jefeNuevo !== null) {
            Empleado::where('id', $jefeNuevo)
                ->update(['idsucursal' => $sucursal->id]);
        }

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'sucursal', $sucursal->id, '204');

        return back()->with('exito', 'Gerente asignado correctamente.');
    }

    public function update(Request $request, Sucursal $sucursal): RedirectResponse
    {
        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
            'direccion' => ['required', 'string', 'max:255'],
            'telefono' => ['required', 'string', 'max:15'],
            'latitud' => ['required', 'numeric', 'between:-90,90'],
            'longitud' => ['required', 'numeric', 'between:-180,180'],
        ]);

        $sucursal->update($validated);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'sucursal', $sucursal->id, '201');

        return back()->with('exito', 'Sucursal actualizada correctamente.');
    }

    public function horarioStore(Request $request, Sucursal $sucursal): RedirectResponse
    {
        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'iddiaatencion' => ['required', 'exists:diaatencion,id'],
            'horaapertura' => ['required', 'date_format:H:i'],
            'horacierre' => ['required', 'date_format:H:i', 'after:horaapertura'],
            'activo' => ['nullable', 'boolean'],
        ]);

        $existe = HorarioSucursal::where('idsucursal', $sucursal->id)
            ->where('iddiaatencion', $validated['iddiaatencion'])
            ->exists();

        if ($existe) {
            return back()->with('error', 'Ya existe un horario para ese día.');
        }

        $horario = HorarioSucursal::create([
            'idsucursal' => $sucursal->id,
            'iddiaatencion' => $validated['iddiaatencion'],
            'horaapertura' => $validated['horaapertura'].':00',
            'horacierre' => $validated['horacierre'].':00',
            'activo' => $request->boolean('activo'),
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'horariosucursal', $horario->idhorariosucursal, '220');

        return back()->with('exito', 'Horario agregado.');
    }

    public function horarioUpdate(Request $request, Sucursal $sucursal, HorarioSucursal $horario): RedirectResponse
    {
        $this->autorizarSucursal($horario->sucursal);

        $validated = $request->validate([
            'iddiaatencion' => ['required', 'exists:diaatencion,id'],
            'horaapertura' => ['required', 'date_format:H:i'],
            'horacierre' => ['required', 'date_format:H:i', 'after:horaapertura'],
            'activo' => ['nullable', 'boolean'],
        ]);

        $duplicado = HorarioSucursal::where('idsucursal', $horario->idsucursal)
            ->where('iddiaatencion', $validated['iddiaatencion'])
            ->where('idhorariosucursal', '!=', $horario->idhorariosucursal)
            ->exists();

        if ($duplicado) {
            return back()->with('error', 'Ya existe un horario para ese día.');
        }

        $horario->update([
            'iddiaatencion' => $validated['iddiaatencion'],
            'horaapertura' => $validated['horaapertura'].':00',
            'horacierre' => $validated['horacierre'].':00',
            'activo' => $request->boolean('activo'),
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'horariosucursal', $horario->idhorariosucursal, '221');

        return back()->with('exito', 'Horario actualizado.');
    }

    public function horarioBaja(Sucursal $sucursal, HorarioSucursal $horario): RedirectResponse
    {
        $this->autorizarSucursal($horario->sucursal);

        $horario->delete();

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'horariosucursal', $horario->idhorariosucursal, '225');

        return back()->with('exito', 'Horario eliminado.');
    }

    public function cajaStore(Request $request, Sucursal $sucursal): RedirectResponse
    {
        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'activo' => ['nullable', 'boolean'],
        ]);

        try {
            $id = DB::selectOne('SELECT registrar_caja(?, ?, ?) AS id', [$sucursal->id, $validated['nombre'], $request->boolean('activo')])->id;
        } catch (QueryException $e) {
            return back()->with('error', $this->mensajeErrorProcedimiento($e));
        }

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'caja', $id, '400');

        return back()->with('exito', "Caja {$validated['nombre']} registrada.");
    }

    public function cajaUpdate(Request $request, Sucursal $sucursal, Caja $caja): RedirectResponse
    {
        abort_unless($caja->idsucursal === $sucursal->id, 403, 'La caja no pertenece a esta sucursal.');

        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:100'],
            'activo' => ['nullable', 'boolean'],
        ]);

        try {
            DB::statement('SELECT actualizar_caja(?, ?, ?, ?)', [$caja->id,  $caja->idsucursal, $validated['nombre'], $request->boolean('activo'),]);
        } catch (QueryException $e) {
            return back()->with('error', $this->mensajeErrorProcedimiento($e));
        }

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'caja', $caja->id, '401');

        return back()->with('exito', "Caja {$validated['nombre']} actualizada.");
    }

    public function cajaBaja(Sucursal $sucursal, Caja $caja): RedirectResponse
    {
        abort_unless($caja->idsucursal === $sucursal->id, 403, 'La caja no pertenece a esta sucursal.');

        $this->autorizarSucursal($sucursal);
        //la misma funcion genera la baja y actualiza la bitacora de accion
        DB::statement('CALL dar_baja_caja(?, ?, ?, ?, ?)', [$caja->id,auth()->user()->empleado->id, '405', request()->userAgent(), request()->ip(),]);

        return back()->with('exito', "Caja {$caja->nombre} dada de baja.");
    }

    public function mesaStore(Request $request, Sucursal $sucursal): RedirectResponse
    {
        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'numeromesa' => ['required', 'integer', 'min:1'],
            'capacidad' => ['required', 'integer', 'min:1'],
        ]);

        try {
            DB::statement('CALL registrar_mesa(?, ?, ?, ?, ?, ?, ?, ?)', [$sucursal->id, $validated['numeromesa'], $validated['capacidad'],
                $request->boolean('estado', true), auth()->user()->empleado->id, '210', request()->userAgent(), request()->ip(),]);
        } catch (QueryException $e) {
            return back()->withInput()->with('error', $this->mensajeErrorProcedimiento($e));
        }

        return back()->with('exito', "Mesa {$validated['numeromesa']} registrada.");
    }

    public function mesaUpdate(Request $request, Sucursal $sucursal, Mesa $mesa): RedirectResponse
    {
        abort_unless($mesa->idsucursal === $sucursal->id, 403, 'La mesa no pertenece a esta sucursal.');

        $this->autorizarSucursal($sucursal);

        $validated = $request->validate([
            'numeromesa' => ['required', 'integer', 'min:1'],
            'capacidad' => ['required', 'integer', 'min:1'],
            'estado' => ['nullable', 'boolean'],
        ]);

        try {
            DB::statement('CALL actualizar_mesa(?, ?, ?, ?, ?, ?, ?, ?, ?)', [$mesa->id, $mesa->idsucursal, $validated['numeromesa'],
                $validated['capacidad'], $request->boolean('estado'), auth()->user()->empleado->id, '211', request()->userAgent(), request()->ip(),]);
        } catch (QueryException $e) {
            return back()->with('error', $this->mensajeErrorProcedimiento($e));
        }

        return back()->with('exito', "Mesa {$validated['numeromesa']} actualizada.");
    }

    public function mesaBaja(Sucursal $sucursal, Mesa $mesa): RedirectResponse
    {
        abort_unless($mesa->idsucursal === $sucursal->id, 403, 'La mesa no pertenece a esta sucursal.');
        $this->autorizarSucursal($sucursal);
        DB::statement('CALL dar_baja_mesa(?, ?, ?, ?, ?)', [$mesa->id, auth()->user()->empleado->id, '215', request()->userAgent(), request()->ip(), ]);
        return back()->with('exito', "Mesa {$mesa->numeromesa} dada de baja.");
    }

    /**
     * Reasigna la cadena de mando cuando el gerente de una sucursal cambia:
     * los cajeros/meseros del antiguo gerente pasan a depender del nuevo,
     * y el antiguo gerente pasa a depender del nuevo gerente.
     */
    private function reasignarSubordinados(?int $jefeAnterior, ?int $jefeNuevo, ?int $sucursalId): void
    {
        DB::statement('CALL reasignar_subordinados(?, ?, ?)', [$jefeAnterior, $jefeNuevo, $sucursalId,]);
    }

    private function esGerente(): bool
    {
        return auth()->user()->empleado->rol?->claverol === 'GERENTE';
    }

    private function codigosPermisoActuales(): Collection
    {
        $empleado = auth()->user()->empleado;

        return $empleado->rol?->permisos
            ? $empleado->rol->permisos->where('estado', true)->pluck('codigo')
            : collect();
    }

    private function esAdmin(): bool
    {
        return auth()->user()->empleado->rol?->claverol === 'ADMINISTRADOR';
    }

    /**
     * Gerentes activos aún no asignados como gerente de otra sucursal activa.
     */
    private function gerentesDisponibles(): Collection
    {
        $asignados = Sucursal::where('estado', true)
            ->whereNotNull('idempleadogerente')
            ->pluck('idempleadogerente');

        return Empleado::with('rol')
            ->where('estado', true)
            ->whereHas('rol', fn ($q) => $q->where('claverol', 'GERENTE'))
            ->whereNotIn('id', $asignados)
            ->orderBy('nombre')
            ->get();
    }

    private function asegurarGerente(int $idEmpleado): void
    {
        $gerente = Empleado::with('rol')
            ->where('id', $idEmpleado)
            ->where('estado', true)
            ->whereHas('rol', fn ($q) => $q->where('claverol', 'GERENTE'))
            ->first();

        abort_unless($gerente, 422, 'Solo puedes asignar un gerente activo del sistema.');
    }

    private function autorizarSucursal(Sucursal $sucursal): void
    {
        if ($this->esGerente() && $sucursal->idempleadogerente !== auth()->user()->empleado->id) {
            abort(403, 'Solo puedes gestionar la sucursal que te fue asignada.');
        }
    }

    /**
     * Extrae el mensaje legible de un RAISE EXCEPTION lanzado por un procedimiento
     * o función almacenada de PostgreSQL, ignorando el prefijo SQLSTATE de la excepción.
     */
    private function mensajeErrorProcedimiento(QueryException $e): string
    {
        if (preg_match('/ERROR:\s+(.+)/', $e->getMessage(), $m)) {
            return trim($m[1]);
        }

        return 'No se pudo completar la operación solicitada.';
    }
}
