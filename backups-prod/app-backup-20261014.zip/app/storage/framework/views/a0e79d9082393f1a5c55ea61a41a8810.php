<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Cierre de caja · <?php echo e($sucursal->nombre); ?></title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 8.5px;
            color: #1f2430;
            line-height: 1.4;
        }

        .hoja {
            width: 100%;
            border: 1px solid #d9dde3;
            border-radius: 8px;
            overflow: hidden;
        }

        .topbar {
            background: #1f2430;
            color: #fff;
            padding: 16px 18px;
        }

        .topbar .marca {
            font-size: 12px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #e8c15c;
            font-weight: bold;
        }

        .topbar h1 {
            font-size: 19px;
            margin-top: 2px;
            text-align: center;
        }

        .topbar .subtitulo {
            text-align: center;
            font-size: 10px;
            color: #cfd4dc;
            margin-top: 2px;
        }

        .separador {
            height: 4px;
            background: #e8c15c;
        }

        .bloque {
            padding: 14px 16px;
        }

        .bloque-titulo {
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            color: #1f2430;
            border-bottom: 2px solid #e8c15c;
            padding-bottom: 4px;
            margin: 18px 0 8px;
        }

        .bloque-titulo.primero {
            margin-top: 0;
        }

        .ficha tr td {
            padding: 7px 10px;
            border: 1px solid #e3e6ea;
        }

        .ficha .rotulo {
            background: #f4f5f7;
            font-weight: bold;
            color: #5b6472;
            width: 40%;
        }

        table.datos {
            width: 100%;
            border-collapse: collapse;
        }

        table.datos th {
            background: #1f2430;
            color: #fff;
            text-align: left;
            padding: 6px 8px;
            font-size: 8.5px;
        }

        table.datos th.monto,
        table.datos td.monto {
            text-align: right;
        }

        table.datos td {
            padding: 5px 8px;
            border-bottom: 1px solid #eceef1;
        }

        table.datos tr:nth-child(even) td {
            background: #fafbfc;
        }

        table.datos tfoot td {
            font-weight: bold;
            background: #f4f5f7;
            border-top: 2px solid #e8c15c;
        }

        .total {
            font-size: 11px;
            font-weight: bold;
        }

        .titre {
            margin-top: 10px;
            font-weight: bold;
            color: #1f2430;
        }

        .texto {
            color: #5b6472;
        }

        .footer {
            margin-top: 16px;
            text-align: center;
            color: #9aa1ab;
            font-size: 8px;
            border-top: 1px solid #e3e6ea;
            padding-top: 8px;
        }

        .badge-dif {
            font-weight: bold;
            font-size: 13px;
        }

        .pedido-bloque {
            margin-bottom: 10px;
            page-break-inside: avoid;
        }

        .pedido-titulo {
            font-size: 9px;
            font-weight: bold;
            color: #1f2430;
            background: #f4f5f7;
            padding: 5px 8px;
            border: 1px solid #e3e6ea;
            border-bottom: 0;
        }

        table.datos-mini th {
            background: #5b6472;
            font-size: 8px;
            padding: 4px 6px;
        }

        table.datos-mini td {
            font-size: 8px;
            padding: 4px 6px;
        }
    </style>
</head>

<body>
    <div class="hoja">
        <div class="topbar">
            <div class="marca"><?php echo e($configuracionSitio->get('SITIO_NOMBRE')); ?></div>
            <h1>CIERRE DE CAJA</h1>
            <div class="subtitulo"><?php echo e($sucursal->nombre); ?> · <?php echo e($cierre->aperturaCaja?->caja?->nombre); ?></div>
        </div>
        <div class="separador"></div>

        <?php $apertura = $cierre->aperturaCaja; ?>

        <div class="bloque">
            <div class="bloque-titulo primero">Resumen de la jornada</div>
            <table class="datos ficha">
                <tr>
                    <td class="rotulo">Cierre</td>
                    <td>Cerrado el <?php echo e($cierre->fechacierre?->format('d/m/Y H:i')); ?>

                        por <?php echo e($cierre->empleado?->nombre); ?> <?php echo e($cierre->empleado?->apellido); ?></td>
                </tr>
                <tr>
                    <td class="rotulo">Apertura</td>
                    <td>Abierta el <?php echo e($apertura ? \Illuminate\Support\Carbon::parse($apertura->fechaapertura)->format('d/m/Y H:i') : '—'); ?>

                        por <?php echo e($apertura?->empleado?->nombre); ?> <?php echo e($apertura?->empleado?->apellido ?? ''); ?></td>
                </tr>
                <tr>
                    <td class="rotulo">Generado</td>
                    <td><?php echo e(now()->format('d/m/Y H:i')); ?> por <?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellido); ?></td>
                </tr>
            </table>

            <div class="bloque-titulo">Detalle de dinero</div>
            <table class="datos">
                <tbody>
                    <tr>
                        <td>Fondo inicial de la apertura</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->fondoinicial, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Ventas en efectivo</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->totalventasefectivo, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Ventas por QR / transferencia</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->totalventasqr, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Ventas con tarjeta</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->totalventastarjeta, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Ingresos de caja</td>
                        <td class="monto">+Bs. <?php echo e(number_format($cierre->totalingresos, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Egresos de caja</td>
                        <td class="monto">-Bs. <?php echo e(number_format($cierre->totalegresos, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Efectivo esperado</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->efectivoesperado, 2)); ?></td>
                    </tr>
                    <tr>
                        <td>Efectivo contado</td>
                        <td class="monto">Bs. <?php echo e(number_format($cierre->efectivocontado, 2)); ?></td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td>Diferencia</td>
                        <td class="monto">
                            <span class="badge-dif">
                                Bs. <?php echo e($cierre->diferencia >= 0 ? '+' : ''); ?><?php echo e(number_format($cierre->diferencia, 2)); ?>

                            </span>
                        </td>
                    </tr>
                </tfoot>
            </table>

            <?php if($cierre->observacion): ?>
                <div class="titre">Observación</div>
                <p class="texto"><?php echo e($cierre->observacion); ?></p>
            <?php endif; ?>

            <div class="bloque-titulo">Ventas y pedidos de la jornada (<?php echo e($pagos->count()); ?>)</div>
            <?php if($pagos->isEmpty()): ?>
                <p class="texto">No hubo ventas aprobadas durante esta jornada.</p>
            <?php else: ?>
                <table class="datos">
                    <thead>
                        <tr>
                            <th>Pedido</th>
                            <th>Fecha y hora</th>
                            <th>Tipo · Mesa</th>
                            <th>Contenido</th>
                            <th>Atendido por</th>
                            <th>Método de pago</th>
                            <th class="monto">Monto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $pedido = $pago->venta?->pedido;
                                $tieneProductos = $pedido?->detalles?->contains(fn ($d) => $d->idproductosucursal !== null) ?? false;
                                $tienePromos = $pedido?->detalles?->contains(fn ($d) => $d->idpromocion !== null) ?? false;
                            ?>
                            <tr>
                                <td><?php echo e($pedido?->nropedido ?? '—'); ?></td>
                                <td><?php echo e($pago->fechapago?->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($pedido?->mesa?->nombre ?? $pedido?->tipopedido); ?></td>
                                <td>
                                    <?php if($tieneProductos && $tienePromos): ?>
                                        Productos + Promoción
                                    <?php elseif($tienePromos): ?>
                                        Promoción
                                    <?php else: ?>
                                        Productos
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($pago->venta?->empleado?->nombre); ?> <?php echo e($pago->venta?->empleado?->apellido); ?></td>
                                <td><?php echo e($pago->metodoPago?->nombre); ?></td>
                                <td class="monto">Bs. <?php echo e(number_format($pago->montopago ?? 0, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="6" class="monto">Total cobrado</td>
                            <td class="monto">Bs. <?php echo e(number_format($pagos->sum(fn ($pago) => $pago->montopago ?? 0), 2)); ?></td>
                        </tr>
                    </tfoot>
                </table>
            <?php endif; ?>

            <?php if($pagos->isNotEmpty()): ?>
                <div class="bloque-titulo">Detalle por pedido</div>
                <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $pedido = $pago->venta?->pedido; ?>
                    <?php if($pedido && $pedido->detalles->isNotEmpty()): ?>
                        <div class="pedido-bloque">
                            <div class="pedido-titulo">
                                Pedido #<?php echo e($pedido->nropedido); ?>

                                · <?php echo e($pedido->mesa?->nombre ?? $pedido->tipopedido); ?>

                                · Bs. <?php echo e(number_format($pago->montopago ?? 0, 2)); ?>

                            </div>
                            <table class="datos datos-mini">
                                <thead>
                                    <tr>
                                        <th>Ítem</th>
                                        <th class="text-center">Cant.</th>
                                        <th class="monto">P. unitario</th>
                                        <th class="monto">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pedido->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($detalle->idpromocion): ?>
                                                    🏷️ <?php echo e($detalle->promocion?->nombre ?? 'Promoción'); ?>

                                                <?php else: ?>
                                                    <?php echo e($detalle->sucursalProducto?->producto?->nombre ?? 'Producto'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center"><?php echo e($detalle->cantidad); ?></td>
                                            <td class="monto">Bs. <?php echo e(number_format($detalle->preciounitario, 2)); ?></td>
                                            <td class="monto">Bs. <?php echo e(number_format($detalle->total, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="bloque-titulo">Movimientos de caja (<?php echo e($movimientos->count()); ?>)</div>
            <?php if($movimientos->isEmpty()): ?>
                <p class="texto">No hubo ingresos ni egresos registrados durante esta jornada.</p>
            <?php else: ?>
                <table class="datos">
                    <thead>
                        <tr>
                            <th>Fecha y hora</th>
                            <th>Tipo</th>
                            <th>Motivo</th>
                            <th>Registrado por</th>
                            <th class="monto">Monto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($mov->fechamovimiento?->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($mov->tipomovimiento === 'INGRESO' ? 'Ingreso' : 'Egreso'); ?></td>
                                <td><?php echo e($mov->motivo); ?></td>
                                <td><?php echo e($mov->empleado?->nombre); ?> <?php echo e($mov->empleado?->apellido); ?></td>
                                <td class="monto"><?php echo e($mov->tipomovimiento === 'INGRESO' ? '+' : '-'); ?>Bs. <?php echo e(number_format($mov->monto, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <div class="footer">
                <?php echo e($configuracionSitio->get('SITIO_NOMBRE')); ?> · Documento generado por el sistema ·
                <?php echo e(now()->format('d/m/Y H:i')); ?>

            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /var/www/html/resources/views/admin/caja/pdf/cierre.blade.php ENDPATH**/ ?>