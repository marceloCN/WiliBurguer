@extends('layouts.app')

@section('title', 'Administración de usuarios · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Administración de usuarios</h1>
                <p class="text-muted mb-0">Gestiona empleados y sus cuentas de acceso.</p>
            </div>
            <button class="btn btn-brand" data-bs-toggle="modal" data-bs-target="#crearUsuarioModal">
                + Nuevo usuario
            </button>
        </div>

        @if (session('exito'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('exito') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        @if ($sucursalGerente)
            <div class="alert alert-info alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
                <span>🗺️</span>
                <span>
                    Estás gestionando la sucursal <strong>{{ $sucursalGerente->nombre }}</strong>.
                    Solo puedes crear y administrar usuarios <strong>cajero o mesero</strong> de esta sucursal.
                </span>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        @if ($errors->any())
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Revisa los datos:</strong>
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        @endif

        <div class="card tarjeta-producto mb-3">
            <div class="card-body">
                <form method="GET" action="{{ route('dashboard.usuarios.index') }}" class="row g-2 align-items-end">
                    <div class="col-12 col-md-5">
                        <label for="busqueda" class="form-label small fw-bold">Buscar</label>
                        <div class="input-group">
                            <input type="text" name="busqueda" id="busqueda" class="form-control"
                                   placeholder="Nombre, apellido, usuario o correo…"
                                   value="{{ $busqueda }}">
                            <button type="submit" class="btn btn-brand">Buscar</button>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <label for="idrol" class="form-label small fw-bold">Rol</label>
                        <select name="idrol" id="idrol" class="form-select">
                            <option value="">Todos</option>
                            @foreach ($roles as $rol)
                                <option value="{{ $rol->id }}" @selected($idrol == $rol->id)>{{ $rol->nombrerol }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-6 col-md-2">
                        <label for="estado" class="form-label small fw-bold">Estado</label>
                        <select name="estado" id="estado" class="form-select">
                            <option value="">Todos</option>
                            <option value="1" @selected($estado === '1')>Activos</option>
                            <option value="0" @selected($estado === '0')>Inactivos</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-2 d-flex gap-2">
                        @if ($busqueda || $idrol || $estado !== null && $estado !== '')
                            <a href="{{ route('dashboard.usuarios.index') }}" class="btn btn-outline-secondary">Limpiar</a>
                        @endif
                    </div>
                </form>
            </div>
        </div>

        <div class="card tarjeta-producto">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Empleado</th>
                            <th>Usuario / correo</th>
                            <th>Rol</th>
                            <th>Sucursal</th>
                            <th>Estado</th>
                            <th>Último acceso</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($empleados as $empleado)
                            <tr>
                                <td>
                                    <div class="fw-semibold">{{ $empleado->nombre }} {{ $empleado->apellido }}</div>
                                    <div class="text-muted small">{{ $empleado->telefono }}</div>
                                </td>
                                <td>
                                    <div>{{ $empleado->cuentaUsuario?->usuario }}</div>
                                    <div class="text-muted small">{{ $empleado->cuentaUsuario?->correo }}</div>
                                </td>
                                <td><span class="badge text-bg-dark">{{ $empleado->rol?->nombrerol }}</span></td>
                                <td class="small">{{ $empleado->sucursal?->nombre ?? '—' }}</td>
                                <td>
                                    @if (!$empleado->cuentaUsuario)
                                        <span class="badge text-bg-secondary">Sin cuenta</span>
                                    @elseif ($empleado->estado && !$empleado->cuentaUsuario->bloqueado)
                                        <span class="badge text-bg-success">Activo</span>
                                    @elseif (!$empleado->estado)
                                        <span class="badge text-bg-danger">Inactivo</span>
                                    @else
                                        <span class="badge text-bg-warning">Bloqueado</span>
                                    @endif
                                </td>
                                <td class="small">
                                    {{ $empleado->cuentaUsuario?->ultimoacceso?->format('d/m/Y H:i') ?? '—' }}
                                </td>
                                <td class="text-end">
                                    {{-- si el empleado cuenta con cuenta de usuario --}}
                                    @if ($empleado->cuentaUsuario)
                                        {{-- si no es el gerente o administrador --}}
                                        @if ($empleado->id !== auth()->user()->empleado->id)
                                            <form method="POST" action="{{ route('dashboard.usuarios.estado', $empleado->cuentaUsuario) }}" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm {{ $empleado->estado ? 'btn-outline-danger' : 'btn-outline-success' }}">
                                                    {{ $empleado->estado ? 'Desactivar' : 'Activar' }}
                                                </button>
                                            </form>
                                            <button class="btn btn-sm btn-outline-brand" data-bs-toggle="modal" data-bs-target="#editarUsuarioModal"
                                                    data-usuario="{{ $empleado->cuentaUsuario->usuario }}" data-correo="{{ $empleado->cuentaUsuario->correo }}"
                                                    data-nombre="{{ $empleado->nombre }}" data-apellido="{{ $empleado->apellido }}"
                                                    data-telefono="{{ $empleado->telefono }}" data-rol-actual="{{ $empleado->rol?->id }}"
                                                    data-url-rol="{{ route('dashboard.usuarios.rol', $empleado->cuentaUsuario) }}"
                                                    data-url-password="{{ route('dashboard.usuarios.password', $empleado->cuentaUsuario) }}"
                                                    data-url-actualizar="{{ route('dashboard.usuarios.actualizar', $empleado->cuentaUsuario) }}">
                                                Editar
                                            </button>
                                        @else
                                            <span class="badge text-bg-light border">Tú</span>
                                        @endif
                                    @else
                                        <span class="text-muted small">—</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">No hay empleados registrados.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($empleados->hasPages())
                <div class="card-footer bg-light-subtle border-top py-3">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-muted">
                        <span>
                            Mostrando {{ $empleados->firstItem() }}–{{ $empleados->lastItem() }}
                            de {{ $empleados->total() }} usuarios
                        </span>
                        <nav aria-label="Paginación de usuarios">
                            {{ $empleados->onEachSide(1)->links() }}
                        </nav>
                    </div>
                </div>
            @endif
        </div>
    </div>

    {{-- Modal editar usuario (datos / rol / seguridad) --}}
    <div class="modal fade" id="editarUsuarioModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small mb-3">
                        Empleado: <strong id="editarUsuarioNombre"></strong><br>
                        Usuario: <strong id="editarUsuarioUsuario"></strong>
                    </p>
                    <ul class="nav nav-tabs mb-3" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="tabDatosTab" data-bs-toggle="tab"
                                    data-bs-target="#tabDatos" type="button" role="tab" aria-controls="tabDatos"
                                    aria-selected="true">Datos</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="tabRolTab" data-bs-toggle="tab"
                                    data-bs-target="#tabRol" type="button" role="tab" aria-controls="tabRol"
                                    aria-selected="false">Rol</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="tabSeguridadTab" data-bs-toggle="tab"
                                    data-bs-target="#tabSeguridad" type="button" role="tab" aria-controls="tabSeguridad"
                                    aria-selected="false">Seguridad</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="editarUsuarioTabs">

                        <div class="tab-pane fade show active" id="tabDatos" role="tabpanel" aria-labelledby="tabDatosTab">
                            <form method="POST" id="actualizarDatosForm">
                                @csrf
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Nombre *</label>
                                        <input type="text" name="nombre" id="editarNombre" class="form-control" required maxlength="100">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Apellido *</label>
                                        <input type="text" name="apellido" id="editarApellido" class="form-control" required maxlength="100">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Teléfono</label>
                                        <input type="text" name="telefono" id="editarTelefono" class="form-control" maxlength="15">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Usuario *</label>
                                        <input type="text" name="usuario" id="editarUsuarioCampo" class="form-control" required maxlength="255">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label">Correo *</label>
                                        <input type="email" name="correo" id="editarCorreo" class="form-control" required maxlength="255">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-brand mt-3">Guardar datos</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="tabRol" role="tabpanel" aria-labelledby="tabRolTab">
                            <form method="POST" id="cambiarRolForm">
                                @csrf
                                <label class="form-label">Nuevo rol *</label>
                                <select name="idrol" id="cambiarRolSelect" class="form-select" required>
                                    @foreach ($roles as $rol)
                                        <option value="{{ $rol->id }}">{{ $rol->nombrerol }}</option>
                                    @endforeach
                                </select>
                                <button type="submit" class="btn btn-brand mt-3">Guardar rol</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="tabSeguridad" role="tabpanel" aria-labelledby="tabSeguridadTab">
                            <form method="POST" id="resetPassForm">
                                @csrf
                                <label class="form-label">Nueva contraseña *</label>
                                <input type="password" name="password" class="form-control" required minlength="6">
                                <button type="submit" class="btn btn-brand mt-3">Guardar contraseña</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Modal crear usuario --}}
    <div class="modal fade" id="crearUsuarioModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <form method="POST" action="{{ route('dashboard.usuarios.store') }}">
                    @csrf
                    <div class="modal-header bg-light">
                        <h5 class="modal-title fw-bold">Nuevo usuario</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nombre *</label>
                                <input type="text" name="nombre" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Apellido *</label>
                                <input type="text" name="apellido" class="form-control" required maxlength="100">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Teléfono</label>
                                <input type="text" name="telefono" class="form-control" maxlength="15">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Rol *</label>
                                <select name="idrol" class="form-select" required>
                                    @foreach ($roles as $rol)
                                        <option value="{{ $rol->id }}">{{ $rol->nombrerol }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Usuario *</label>
                                <input type="text" name="usuario" class="form-control" required maxlength="255">
                                <div class="form-text">Sugerido automáticamente según nombre y apellido.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Correo *</label>
                                <input type="email" name="correo" class="form-control" required maxlength="255">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contraseña *</label>
                                <input type="password" name="password" class="form-control" required minlength="6">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-brand">Crear usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @endsection

@push('scripts')
    <script>
        const editarUsuarioModal = document.getElementById('editarUsuarioModal');
        editarUsuarioModal.addEventListener('show.bs.modal', function (event) {
            const boton = event.relatedTarget;

            document.getElementById('editarUsuarioNombre').textContent =
                `${boton.dataset.nombre} ${boton.dataset.apellido}`;
            document.getElementById('editarUsuarioUsuario').textContent = boton.dataset.usuario;

            document.getElementById('editarNombre').value = boton.dataset.nombre;
            document.getElementById('editarApellido').value = boton.dataset.apellido;
            document.getElementById('editarTelefono').value = boton.dataset.telefono || '';
            document.getElementById('editarUsuarioCampo').value = boton.dataset.usuario;
            document.getElementById('editarCorreo').value = boton.dataset.correo || '';

            document.getElementById('cambiarRolSelect').value = boton.dataset.rolActual;
            document.getElementById('cambiarRolForm').setAttribute('action', boton.dataset.urlRol);
            document.getElementById('resetPassForm').setAttribute('action', boton.dataset.urlPassword);
            document.getElementById('actualizarDatosForm').setAttribute('action', boton.dataset.urlActualizar);
        });

        const nombresUsuarios = new Set(@json($usuariosExistentes));

        function slugificarUsuario(texto) {
            return texto.toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-z0-9]+/g, '.')
                .replace(/^\.+|\.+$/g, '')
                .replace(/\.{2,}/g, '.');
        }

        function sugerirUsuario(nombre, apellido) {
            const base = slugificarUsuario(`${nombre || ''} ${apellido || ''}`);
            if (!base) return '';
            if (!nombresUsuarios.has(base)) return base;

            let sufijo = 1;
            while (nombresUsuarios.has(base + sufijo)) sufijo++;
            return base + sufijo;
        }

        const crearModal = document.getElementById('crearUsuarioModal');
        const crearNombre = crearModal.querySelector('input[name="nombre"]');
        const crearApellido = crearModal.querySelector('input[name="apellido"]');
        const crearUsuario = crearModal.querySelector('input[name="usuario"]');
        let usuarioGenerado = false;

        function regenerarUsuario() {
            if (usuarioGenerado || !crearUsuario.value) {
                crearUsuario.value = sugerirUsuario(crearNombre.value, crearApellido.value);
                usuarioGenerado = true;
            }
        }

        crearNombre.addEventListener('input', regenerarUsuario);
        crearApellido.addEventListener('input', regenerarUsuario);
        crearUsuario.addEventListener('input', function () {
            usuarioGenerado = false;
        });
        crearModal.addEventListener('hidden.bs.modal', function () {
            usuarioGenerado = false;
            crearUsuario.value = '';
        });
    </script>
@endpush