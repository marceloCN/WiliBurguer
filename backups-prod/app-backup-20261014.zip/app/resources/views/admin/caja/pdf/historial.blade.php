<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Historial de cierres · {{ $sucursalActual->nombre }}</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 7.5px;
            color: #1f2430;
            line-height: 1.4;
        }

        .hoja {
            width: 100%;
            border: 1px solid #d9dde3;
            border-radius: 8px;
            overflow: hidden;
        }

        .topbar {
            background: #1f2430;
            color: #fff;
            padding: 14px 18px;
        }

        .topbar .marca {
            font-size: 11px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: #e8c15c;
            font-weight: bold;
        }

        .topbar h1 {
            font-size: 17px;
            margin-top: 2px;
            text-align: center;
        }

        .topbar .subtitulo {
            text-align: center;
            font-size: 10px;
            color: #cfd4dc;
            margin-top: 2px;
        }

        .separador {
            height: 4px;
            background: #e8c15c;
        }

        .bloque {
            padding: 14px 16px;
        }

        .bloque-titulo {
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
            color: #1f2430;
            border-bottom: 2px solid #e8c15c;
            padding-bottom: 4px;
            margin-bottom: 8px;
        }

        table.resumen {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 14px;
        }

        table.resumen td {
            border: 1px solid #e3e6ea;
            padding: 6px 10px;
        }

        table.resumen .rotulo {
            background: #f4f5f7;
            font-weight: bold;
            color: #5b6472;
        }

        table.resumen .valor {
            font-weight: bold;
            font-size: 10px;
            text-align: center;
        }

        table.datos {
            width: 100%;
            border-collapse: collapse;
        }

        table.datos th {
            background: #1f2430;
            color: #fff;
            text-align: left;
            padding: 5px 6px;
            font-size: 7.5px;
            white-space: nowrap;
        }

        table.datos th.monto,
        table.datos td.monto {
            text-align: right;
        }

        table.datos td {
            padding: 4px 6px;
            border-bottom: 1px solid #eceef1;
            white-space: nowrap;
        }

        table.datos tr:nth-child(even) td {
            background: #fafbfc;
        }

        table.datos tfoot td {
            font-weight: bold;
            background: #f4f5f7;
            border-top: 2px solid #e8c15c;
        }

        .footer {
            margin-top: 14px;
            text-align: center;
            color: #9aa1ab;
            font-size: 7.5px;
            border-top: 1px solid #e3e6ea;
            padding-top: 8px;
        }
    </style>
</head>

<body>
    <div class="hoja">
        <div class="topbar">
            <div class="marca">{{ $configuracionSitio->get('SITIO_NOMBRE') }}</div>
            <h1>HISTORIAL DE CIERRES</h1>
            <div class="subtitulo">
                {{ $sucursalActual->nombre }} ·
                Del {{ $desde ?? 'inicio' }} al {{ $hasta ?? 'hoy' }} ·
                Generado {{ now()->format('d/m/Y H:i') }}
            </div>
        </div>
        <div class="separador"></div>

        <div class="bloque">
            @if ($cierres->isEmpty())
                <p>Sin cierres en el rango seleccionado.</p>
            @else
                <table class="datos">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Cierre (fecha)</th>
                            <th>Caja</th>
                            <th>Abierta por</th>
                            <th>Cerrada por</th>
                            <th class="monto">Fondo</th>
                            <th class="monto">Efectivo</th>
                            <th class="monto">QR</th>
                            <th class="monto">Tarjeta</th>
                            <th class="monto">Ventas</th>
                            <th class="monto">Ingresos</th>
                            <th class="monto">Egresos</th>
                            <th class="monto">Esperado</th>
                            <th class="monto">Contado</th>
                            <th class="monto">Diferencia</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($cierres as $index => $c)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $c->fechacierre?->format('d/m/Y H:i') }}</td>
                                <td>{{ $c->aperturaCaja?->caja?->nombre }}</td>
                                <td>{{ $c->aperturaCaja?->empleado?->nombre }}</td>
                                <td>{{ $c->empleado?->nombre }}</td>
                                <td class="monto">{{ number_format($c->fondoinicial, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalventasefectivo, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalventasqr, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalventastarjeta, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalventas, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalingresos, 2) }}</td>
                                <td class="monto">{{ number_format($c->totalegresos, 2) }}</td>
                                <td class="monto">{{ number_format($c->efectivoesperado, 2) }}</td>
                                <td class="monto">{{ number_format($c->efectivocontado, 2) }}</td>
                                <td class="monto">{{ $c->diferencia >= 0 ? '+' : '' }}{{ number_format($c->diferencia, 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5">Total ({{ $cierres->count() }} cierres)</td>
                            <td class="monto">{{ number_format($cierres->sum('fondoinicial'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalventasefectivo'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalventasqr'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalventastarjeta'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalventas'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalingresos'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('totalegresos'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('efectivoesperado'), 2) }}</td>
                            <td class="monto">{{ number_format($cierres->sum('efectivocontado'), 2) }}</td>
                            <td class="monto">{{ $cierres->sum('diferencia') >= 0 ? '+' : '' }}{{ number_format($cierres->sum('diferencia'), 2) }}</td>
                        </tr>
                    </tfoot>
                </table>
            @endif

            <div class="footer">
                {{ $configuracionSitio->get('SITIO_NOMBRE') }} · Generado por {{ $empleado->nombre }} {{ $empleado->apellido }}
                · {{ now()->format('d/m/Y H:i') }}
            </div>
        </div>
    </div>
</body>

</html>