<?php $__env->startSection('title', 'Historial de cierres · '.$configuracionSitio->get('SITIO_NOMBRE')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">📑 Historial de cierres</h1>
                <p class="text-muted mb-0"><?php echo e($sucursalActual->nombre); ?></p>
            </div>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('dashboard.caja.index', ['idsucursal' => $sucursalActual->id])); ?>"
                   class="btn btn-outline-secondary">← Caja y jornadas</a>
                <?php if($puedeHistorialCierres): ?>
                    <a href="<?php echo e(route('dashboard.caja.historial.pdf', [
                            'idsucursal' => $sucursalActual->id,
                            'desde' => $desde,
                            'hasta' => $hasta,
                        ])); ?>" class="btn btn-dark">
                        📄 PDF del rango
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php echo $__env->make('partials.mensajes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="card tarjeta-producto mb-4">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('dashboard.caja.historial')); ?>" class="row g-3 align-items-end">
                    <input type="hidden" name="idsucursal" value="<?php echo e($sucursalActual->id); ?>">
                    <div class="col-12 col-md-4">
                        <label class="form-label">Desde</label>
                        <input type="date" name="desde" value="<?php echo e($desde); ?>" class="form-control">
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label">Hasta</label>
                        <input type="date" name="hasta" value="<?php echo e($hasta); ?>" class="form-control">
                    </div>
                    <div class="col-12 col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-brand flex-fill">Filtrar</button>
                        <a href="<?php echo e(route('dashboard.caja.historial', ['idsucursal' => $sucursalActual->id])); ?>"
                           class="btn btn-outline-secondary">Limpiar</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card tarjeta-producto">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span class="fw-bold">Cierres</span>
                <span class="badge text-bg-dark"><?php echo e($cierres->total()); ?> cierre(s)</span>
            </div>
            <div class="card-body">
                <?php if($cierres->isEmpty()): ?>
                    <p class="text-muted text-center py-4 mb-0">Sin cierres en el rango seleccionado.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Cierre</th>
                                    <th>Caja</th>
                                    <th class="text-end">Efectivo</th>
                                    <th class="text-end">QR</th>
                                    <th class="text-end">Tarjeta</th>
                                    <th class="text-end">Total ventas</th>
                                    <th class="text-end">Esperado</th>
                                    <th class="text-end">Contado</th>
                                    <th class="text-end">Diferencia</th>
                                    <th class="text-end">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="small text-muted">
                                            <?php echo e($c->fechacierre?->format('d/m/Y H:i')); ?>

                                            <div class="text-nowrap">por <?php echo e($c->empleado?->nombre ?? '—'); ?></div>
                                        </td>
                                        <td><?php echo e($c->aperturaCaja?->caja?->nombre); ?></td>
                                        <td class="text-end">Bs. <?php echo e(number_format($c->totalventasefectivo, 2)); ?></td>
                                        <td class="text-end">Bs. <?php echo e(number_format($c->totalventasqr, 2)); ?></td>
                                        <td class="text-end">Bs. <?php echo e(number_format($c->totalventastarjeta, 2)); ?></td>
                                        <td class="text-end fw-semibold">Bs. <?php echo e(number_format($c->totalventas, 2)); ?></td>
                                        <td class="text-end">Bs. <?php echo e(number_format($c->efectivoesperado, 2)); ?></td>
                                        <td class="text-end">Bs. <?php echo e(number_format($c->efectivocontado, 2)); ?></td>
                                        <td class="text-end fw-semibold <?php echo e((float) $c->diferencia == 0 ? 'text-success' : ((float) $c->diferencia > 0 ? 'text-warning' : 'text-danger')); ?>">
                                            <?php echo e($c->diferencia >= 0 ? '+' : ''); ?><?php echo e(number_format($c->diferencia, 2)); ?>

                                        </td>
                                        <td class="text-end">
                                            <div class="d-flex gap-1 justify-content-end flex-wrap">
                                                <?php if($puedeDetalleCierre): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                                            data-bs-toggle="modal" data-bs-target="#detalleCierreModal"
                                                            data-cierre-url="<?php echo e(route('dashboard.caja.cierre.detalle', $c)); ?>">
                                                        Ver
                                                    </button>
                                                    <a href="<?php echo e(route('dashboard.caja.cierre.pdf', $c)); ?>"
                                                       class="btn btn-sm btn-outline-danger">
                                                        📄 PDF
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($cierres->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php if($puedeDetalleCierre): ?>
    <div class="modal fade" id="detalleCierreModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Detalle del cierre</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body" id="detalleCierreCuerpo">
                    <div class="text-center text-muted py-4">Cargando…</div>
                </div>
                <div class="modal-footer bg-light d-flex justify-content-between">
                    <a href="#" id="detalleCierrePdf" class="btn btn-sm btn-outline-danger">📄 PDF</a>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php if($puedeDetalleCierre): ?>
    <script>
        const modalDetalleCierre = document.getElementById('detalleCierreModal');
        if (modalDetalleCierre) {
            modalDetalleCierre.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                const cuerpo = document.getElementById('detalleCierreCuerpo');
                if (!boton || !boton.dataset.cierreUrl) return;

                const urlPdf = boton.closest('tr')
                    ? boton.closest('tr').querySelector('a[href*="/pdf"]')?.href
                    : null;

                cuerpo.innerHTML = '<div class="text-center text-muted py-4">Cargando…</div>';
                document.getElementById('detalleCierrePdf').href = urlPdf || '#';

                fetch(boton.dataset.cierreUrl)
                    .then(function (respuesta) {
                        if (!respuesta.ok) throw new Error('Error de red');
                        return respuesta.text();
                    })
                    .then(function (html) {
                        cuerpo.innerHTML = html;
                    })
                    .catch(function () {
                        cuerpo.innerHTML = '<div class="text-center text-danger py-4">No se pudo cargar el detalle.</div>';
                    });
            });
        }
    </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/caja/historial.blade.php ENDPATH**/ ?>