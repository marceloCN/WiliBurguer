<?php $__env->startSection('title', $configuracion->get('SITIO_NOMBRE', 'Burger Willy and Grill') . ' - ' . $configuracion->get('SITIO_ESLOGAN', 'Sabores que se quedan')); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if($configuracion->get('SITIO_HABILITAR_CARRUSEL', '1') && $sliders->isNotEmpty()): ?>
        <div id="sliderInicio" class="carousel slide carousel-fade hero-carousel" data-bs-ride="carousel" data-bs-interval="5500">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#sliderInicio" data-bs-slide-to="<?php echo e($i); ?>"
                            class="<?php echo e($loop->first ? 'active' : ''); ?>" aria-current="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                            aria-label="Diapositiva <?php echo e($i + 1); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                        <?php if(data_get($slider, 'imagen')): ?>
                            <img src="<?php echo e($slider['imagen']); ?>" class="d-block w-100 carousel-img" alt="<?php echo e(data_get($slider, 'titulo')); ?>" onerror="reemplazarImagenRota(this)">
                        <?php else: ?>
                            <div class="carousel-img d-flex align-items-center justify-content-center hero">
                                <div class="display-1">🍔</div>
                            </div>
                        <?php endif; ?>
                        <div class="carousel-caption carousel-caption-modern d-none d-md-block text-start">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-7">
                                        <?php if(data_get($slider, 'titulo')): ?>
                                            <span class="badcillo text-uppercase mb-2">Bienvenido a <?php echo e($configuracion->get('SITIO_NOMBRE', 'Burguer Willy')); ?></span>
                                            <h1 class="display-4 fw-bolder mb-3 text-shadow"><?php echo e($slider['titulo']); ?></h1>
                                        <?php endif; ?>
                                        <?php if(data_get($slider, 'subtitulo')): ?>
                                            <p class="lead mb-4 text-shadow-soft"><?php echo e($slider['subtitulo']); ?></p>
                                        <?php endif; ?>
                                        <?php if(data_get($slider, 'boton_texto')): ?>
                                            <a href="<?php echo e(data_get($slider, 'boton_url', '#menu')); ?>" class="btn btn-brand btn-lg px-4 shadow"><?php echo e($slider['boton_texto']); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#sliderInicio" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Anterior</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#sliderInicio" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Siguiente</span>
            </button>
        </div>
    <?php else: ?>
        <header class="hero py-5">
            <div class="container py-4 text-center">
                <h1 class="display-4 fw-bolder mb-3"><?php echo e($configuracion->get('SITIO_NOMBRE', 'Burger Willy and Grill')); ?></h1>
                <p class="lead mb-4"><?php echo e($configuracion->get('SITIO_ESLOGAN', 'Sabores que se quedan')); ?></p>
                <a href="#menu" class="btn btn-brand btn-lg px-4">Ver menú</a>
            </div>
        </header>
    <?php endif; ?>

    
    <?php if($configuracion->get('SITIO_HABILITAR_MENU', '1')): ?>
        <section id="categorias" class="py-5">
            <div class="container">
                <div class="text-center mb-5">
                    <span class="badcillo text-uppercase">Nuestro menú</span>
                    <h2 class="display-6 fw-bolder seccion-titulo">Explora por categoría</h2>
                    <p class="text-muted">Tocá una categoría para ver los productos de cada sucursal.</p>
                </div>

                <?php if($categorias->isEmpty()): ?>
                    <div class="alert alert-warning text-center">No hay categorías disponibles por el momento.</div>
                <?php else: ?>
                    <div class="d-flex flex-wrap justify-content-center gap-2 mb-5" id="filtroCategorias">
                        <button type="button" class="btn btn-brand categoria-pill active" data-categoria="*">
                            <strong>Todos</strong>
                        </button>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="btn btn-outline-brand categoria-pill"
                                    data-categoria="<?php echo e($categoria->nombre); ?>">
                                <span class="categoria-emoji">🍽️</span>
                                <strong><?php echo e($categoria->nombre); ?></strong>
                                <span class="badge text-bg-brand ms-1"><?php echo e($categoria->productos_count); ?></span>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    
    <?php if($configuracion->get('SITIO_HABILITAR_MENU', '1')): ?>
        <section id="menu" class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-5">
                    <span class="badcillo text-uppercase">Productos y precios</span>
                    <h2 class="display-6 fw-bolder seccion-titulo">Menú por sucursal
                        <span id="categoriaActual" class="badge text-bg-brand fs-6 align-middle ms-2">Todos</span>
                    </h2>
                    <p class="text-muted">Elige tu sucursal y revisa los productos disponibles con sus precios.</p>
                </div>

                <?php if($sucursales->isEmpty()): ?>
                    <div class="alert alert-warning text-center">No hay sucursales disponibles por el momento.</div>
                <?php else: ?>
                    <ul class="nav nav-pills justify-content-center mb-4 flex-wrap gap-2" id="sucursalTab" role="tablist">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link sucursal-tab <?php echo e($loop->first ? 'active' : ''); ?>"
                                        id="sucursal-<?php echo e($i); ?>-tab"
                                        data-bs-toggle="pill"
                                        data-bs-target="#sucursal-<?php echo e($i); ?>"
                                        type="button" role="tab"
                                        aria-controls="sucursal-<?php echo e($i); ?>"
                                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                                    📍 <?php echo e($sucursal->nombre); ?>

                                </button>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="tab-content" id="sucursalTabContent">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="sucursal-<?php echo e($i); ?>" role="tabpanel" aria-labelledby="sucursal-<?php echo e($i); ?>-tab">
                                <?php
                                    $porCategoria = $sucursal->productosSucursal
                                        ->filter(fn ($sp) => $sp->disponibilidad && isset($sp->producto))
                                        ->groupBy(fn ($sp) => $sp->producto->categoria?->nombre ?? 'Otros');
                                ?>

                                <?php if($porCategoria->isEmpty()): ?>
                                    <div class="alert alert-light text-center">La sucursal <b><?php echo e($sucursal->nombre); ?></b> no tiene productos disponibles.</div>
                                <?php endif; ?>

                                <div class="alert alert-light text-center d-none" data-sin-resultados>No hay productos de la categoría seleccionada en esta sucursal.</div>

                                <?php $__currentLoopData = $porCategoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-4 bloque-categoria" data-categoria="<?php echo e($categoria); ?>">
                                        <div class="d-flex align-items-center gap-2 mb-3">
                                            <span class="badge text-bg-brand px-3 py-2"><?php echo e($categoria); ?></span>
                                            <div class="flex-grow-1"><hr class="border-brand subtle my-0"></div>
                                        </div>
                                        <div class="row g-4">
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12 col-sm-6 col-lg-4 col-xl-3" data-categoria-item="<?php echo e($categoria); ?>">
                                                    <div class="card tarjeta-producto h-100">
                                                        <?php if($sp->producto->photo): ?>
                                                            <img src="<?php echo e(asset('storage/'.$sp->producto->photo)); ?>" class="card-img-top object-fit-cover" alt="<?php echo e($sp->producto->nombre); ?>">
                                                        <?php else: ?>
                                                            <div class="card-img-top bg-secondary bg-opacity-10 d-flex align-items-center justify-content-center display-4">🍽️</div>
                                                        <?php endif; ?>
                                                        <div class="card-body d-flex flex-column">
                                                            <h6 class="card-title fw-bold"><?php echo e($sp->producto->nombre); ?></h6>
                                                            <p class="card-text text-muted small flex-grow-1"><?php echo e($sp->producto->descripcion); ?></p>
                                                            <div class="d-flex justify-content-between align-items-center mt-2">
                                                                <span class="precio h5 mb-0">S/ <?php echo e(number_format($sp->precioproducto, 2)); ?></span>
                                                                <span class="badge <?php echo e($sp->disponibilidad ? 'text-bg-success' : 'text-bg-secondary'); ?>">
                                                                    <?php echo e($sp->disponibilidad ? 'Disponible' : 'Agotado'); ?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    
    <?php if($configuracion->get('SITIO_HABILITAR_PROMOCIONES', '1')): ?>
        <section id="promociones" class="py-5">
            <div class="container">
                <div class="text-center mb-5">
                    <span class="badcillo text-uppercase">Ofertas vigentes</span>
                    <h2 class="display-6 fw-bolder seccion-titulo">Promociones por sucursal</h2>
                    <p class="text-muted">Descuentos que puedes aprovechar hoy en cada local.</p>
                </div>

                <?php if($promocionesPorSucursal->isEmpty()): ?>
                    <div class="alert alert-light text-center">No hay promociones activas por el momento.</div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php $__currentLoopData = $promocionesPorSucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idSucursal => $promos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $sucursalPromo = $promos->first()?->sucursalesProducto
                                    ->first(fn ($sp) => $sp->sucursal?->id == $idSucursal)?->sucursal;
                            ?>
                            <div class="col-12 col-xl-6">
                                <div class="card tarjeta-producto h-100 p-2">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center justify-content-between mb-3">
                                            <h5 class="card-title fw-bold mb-0">📍 <?php echo e($sucursalPromo?->nombre ?? 'Sucursal'); ?></h5>
                                            <span class="badge text-bg-danger">Ofertas activas</span>
                                        </div>
                                        <div class="row g-3">
                                            <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-12">
                                                    <div class="promo-item rounded-4 p-3 h-100">
                                                        <?php if($promo->photo): ?>
                                                            <img src="<?php echo e(asset('storage/'.$promo->photo)); ?>"
                                                                 class="w-100 mb-3"
                                                                 style="max-height: 220px; object-fit: cover; border-radius: 1rem;"
                                                                 alt="Promoción <?php echo e($promo->nombre); ?>">
                                                        <?php endif; ?>
                                                        <div class="d-flex justify-content-between align-items-start gap-2">
                                                            <div>
                                                                <h6 class="fw-bold mb-1">
                                                                    <?php echo e($promo->nombre); ?>

                                                                    <?php if($promo->tipodescuento === 'PORCENTAJE'): ?>
                                                                        <span class="badge text-bg-danger ms-1">-<?php echo e(number_format($promo->valordescuento, 0)); ?>%</span>
                                                                    <?php else: ?>
                                                                        <span class="badge text-bg-danger ms-1">-S/ <?php echo e(number_format($promo->valordescuento, 2)); ?></span>
                                                                    <?php endif; ?>
                                                                </h6>
                                                                <p class="small text-muted mb-2">
                                                                    Desde <strong><?php echo e($promo->fechainicio->format('d/m/Y')); ?></strong>
                                                                    hasta <strong><?php echo e($promo->fechafin->format('d/m/Y')); ?></strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <?php if($promo->sucursalesProducto->isNotEmpty()): ?>
                                                            <ul class="list-unstyled small mb-0 row row-cols-md-2 gx-3">
                                                                <?php $__currentLoopData = $promo->sucursalesProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($sp->sucursal?->id == $idSucursal): ?>
                                                                        <li class="col d-flex justify-content-between border-bottom py-1">
                                                                            <span>🍔 <?php echo e($sp->producto?->nombre); ?></span>
                                                                            <span class="text-muted">S/ <?php echo e(number_format($sp->precioproducto, 2)); ?></span>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    
    <?php if($configuracion->get('SITIO_HABILITAR_SUCURSALES', '1')): ?>
        <section id="sucursales" class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-5">
                    <span class="badcillo text-uppercase">Visítanos</span>
                    <h2 class="display-6 fw-bolder seccion-titulo">Sucursales y horarios de atención</h2>
                    <p class="text-muted">Encuentra tu sucursal más cercana y visita nuestros horarios.</p>
                </div>

                <?php if($sucursales->isEmpty()): ?>
                    <div class="alert alert-warning text-center">No hay sucursales disponibles por el momento.</div>
                <?php else: ?>
                    <div class="row g-4 <?php echo e($sucursales->count() === 1 ? 'justify-content-center' : ''); ?>">
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 <?php echo e($sucursales->count() === 1 ? 'col-lg-8 col-xl-7' : 'col-lg-6'); ?>">
                                <div class="card tarjeta-producto h-100">
                                    <div id="mini-mapa-<?php echo e($sucursal->id); ?>" class="sucursal-mapa <?php echo e($sucursales->count() === 1 ? 'sucursal-mapa-unica' : ''); ?>"
                                         data-lat="<?php echo e(number_format((float) $sucursal->latitud, 6, '.', '')); ?>"
                                         data-lng="<?php echo e(number_format((float) $sucursal->longitud, 6, '.', '')); ?>">
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title fw-bold"><?php echo e($sucursal->nombre); ?></h5>
                                        <p class="card-text small text-muted mb-1">📍 <?php echo e($sucursal->direccion); ?></p>
                                        <p class="card-text small text-muted mb-3">📞 <?php echo e($sucursal->telefono); ?></p>

                                        <h6 class="text-uppercase text-muted small fw-bold mb-2">Horario de atención</h6>
                                        <?php
                                            $horarios = $sucursal->horarios
                                                ->filter(fn ($h) => $h->activo)
                                                ->sortBy(fn ($h) => $h->diaAtencion?->numerodia);
                                        ?>
                                        <?php if($horarios->isEmpty()): ?>
                                            <p class="small text-muted mb-0">Horario por definir.</p>
                                        <?php else: ?>
                                            <div class="row row-cols-2 gx-3 gy-1 small">
                                                <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col d-flex justify-content-between border-bottom py-1">
                                                        <span class="horario-dia"><?php echo e($h->diaAtencion?->nombredia ?? 'Sin asignar'); ?></span>
                                                        <span class="text-muted"><?php echo e(substr($h->horaapertura, 0, 5)); ?> – <?php echo e(substr($h->horacierre, 0, 5)); ?></span>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">

    <style>
        .badcillo {
            display: inline-block;
            color: var(--brand);
            font-weight: 700;
            letter-spacing: 2px;
            font-size: .85rem;
        }
        .hero-carousel .carousel-img {
            height: 78vh;
            object-fit: cover;
            filter: brightness(.55);
            min-height: 420px;
        }
        .carousel-caption-modern {
            right: auto;
            left: 0;
            top: 0;
            bottom: 0;
            display: flex !important;
            flex-direction: column;
            justify-content: center;
            width: 100%;
            padding: 0;
            text-align: left;
        }
        .text-shadow {
            text-shadow: 0 2px 12px rgba(0, 0, 0, .65);
        }
        .text-shadow-soft {
            text-shadow: 0 1px 6px rgba(0, 0, 0, .5);
        }
        .categoria-pill {
            border-radius: 2rem;
            display: inline-flex;
            align-items: center;
            gap: .4rem;
            transition: transform .15s ease, box-shadow .15s ease;
        }
        .categoria-pill:hover {
            transform: translateY(-3px);
            box-shadow: 0 .5rem 1.5rem color-mix(in srgb, var(--brand) 20%, transparent);
        }
        .categoria-emoji {
            font-size: 1.25rem;
        }
        .sucursal-tab {
            border-radius: 2rem;
        }
        .sucursal-tab.active {
            background-color: var(--brand) !important;
        }
        .border-brand {
            border-color: color-mix(in srgb, var(--brand) 25%, transparent) !important;
        }
        .promo-item {
            background: linear-gradient(135deg, #fff7ec 0%, #fdf1e0 100%);
            border: 1px solid rgba(212, 163, 115, .35);
        }
        .sucursal-mapa {
            height: 180px;
            border-radius: 1rem 1rem 0 0;
            background: #eee;
        }
        .sucursal-mapa-unica {
            height: 260px;
        }
        .categoria-pill.active {
            pointer-events: auto;
        }
        @media (max-width: 767px) {
            .hero-carousel .carousel-img {
                height: 62vh;
                min-height: 340px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        function reemplazarImagenRota(img) {
            if (!img || img.dataset.reemplazado) {
                return;
            }
            img.dataset.reemplazado = '1';
            const contenedor = img.parentElement;
            if (!contenedor) {
                return;
            }
            const sustituto = document.createElement('div');
            sustituto.className = 'carousel-img d-flex align-items-center justify-content-center hero';
            sustituto.innerHTML = '<div class="display-1">🍔</div>';
            contenedor.replaceChild(sustituto, img);
        }

        document.addEventListener('DOMContentLoaded', function () {
            const botones = document.querySelectorAll('#filtroCategorias .categoria-pill');
            const etiquetaActual = document.getElementById('categoriaActual');

            function aplicarFiltro(categoria) {
                document.querySelectorAll('.bloque-categoria').forEach(function (bloque) {
                    bloque.style.display = bloque.dataset.categoria === categoria || categoria === '*' ? '' : 'none';
                });

                document.querySelectorAll('.tab-pane').forEach(function (pane) {
                    const bloquesVisibles = pane.querySelectorAll('.bloque-categoria:not([style*="display: none"])');
                    const vacio = pane.querySelector('[data-sin-resultados]');
                    if (vacio) vacio.classList.toggle('d-none', bloquesVisibles.length > 0);
                });

                if (etiquetaActual) etiquetaActual.textContent = categoria === '*' ? 'Todos' : categoria;

                const menu = document.getElementById('menu');
                if (menu) menu.scrollIntoView({ behavior: 'smooth' });
            }

            botones.forEach(function (btn) {
                btn.addEventListener('click', function () {
                    botones.forEach(function (b) {
                        b.classList.remove('active');
                        b.classList.remove('btn-brand');
                        b.classList.add('btn-outline-brand');
                    });
                    btn.classList.add('active');
                    btn.classList.remove('btn-outline-brand');
                    btn.classList.add('btn-brand');
                    aplicarFiltro(btn.dataset.categoria);
                });
            });

            document.querySelectorAll('[data-bs-toggle="pill"]').forEach(function (tab) {
                tab.addEventListener('shown.bs.tab', function () {
                    const activo = document.querySelector('#filtroCategorias .categoria-pill.active');
                    aplicarFiltro(activo ? activo.dataset.categoria : '*');
                });
            });

            document.querySelectorAll('[id^="mini-mapa-"]').forEach(function (contenedor) {
                const id = contenedor.id.replace('mini-mapa-', '');
                const lat = parseFloat(contenedor.dataset.lat);
                const lng = parseFloat(contenedor.dataset.lng);
                const mapa = L.map(contenedor.id, { scrollWheelZoom: false }).setView([lat, lng], 15);
                L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap'
                }).addTo(mapa);
                L.marker([lat, lng]).addTo(mapa);
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/inicio.blade.php ENDPATH**/ ?>