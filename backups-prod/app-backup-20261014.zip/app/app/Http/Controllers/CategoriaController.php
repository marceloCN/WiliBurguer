<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CategoriaController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
        ]);

        $nombre = mb_trim($validated['nombre']);

        $existente = $this->categoriaPorNombre($nombre);

        if ($existente) {
            if ($existente->estado) {
                return back()->withInput()->with('error', 'Ya existe una categoría activa con ese nombre.');
            }

            $existente->update(['estado' => true]);
            $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'categoria', $existente->id, '300');

            return redirect()->route('dashboard.menu.index', ['idcategoria' => $existente->id])
                ->with('exito', "Categoría {$existente->nombre} reactivada.");
        }

        $categoria = Categoria::create([
            'nombre' => $nombre,
            'estado' => true,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'categoria', $categoria->id, '300');

        return redirect()->route('dashboard.menu.index')
            ->with('exito', "Categoría {$categoria->nombre} creada.");
    }

    public function update(Request $request, Categoria $categoria): RedirectResponse
    {
        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:255'],
        ]);

        $nombre = mb_trim($validated['nombre']);

        $existente = $this->categoriaPorNombre($nombre, $categoria->id);

        if ($existente && $existente->estado) {
            return back()->withInput()->with('error', 'Ya existe una categoría activa con ese nombre.');
        }

        $categoria->update(['nombre' => $nombre]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'categoria', $categoria->id, '301');

        return back()->with('exito', "Categoría {$categoria->nombre} actualizada.");
    }

    public function baja(Categoria $categoria): RedirectResponse
    {
        $categoria->update(['estado' => false]);

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'categoria', $categoria->id, '305');

        return back()->with('exito', "Categoría {$categoria->nombre} dada de baja.");
    }

    public function reactivar(Categoria $categoria): RedirectResponse
    {
        if ($categoria->estado) {
            return back()->with('info', "La categoría {$categoria->nombre} ya está activa.");
        }

        $categoria->update(['estado' => true]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'categoria', $categoria->id, '300');

        return redirect()->route('dashboard.menu.index', ['idcategoria' => $categoria->id])
            ->with('exito', "Categoría {$categoria->nombre} reactivada.");
    }

    private function categoriaPorNombre(string $nombre, ?int $ignorarId = null): ?Categoria
    {
        return Categoria::whereRaw('LOWER(nombre) = ?', [mb_strtolower($nombre)])
            ->when($ignorarId, fn ($query) => $query->where('id', '!=', $ignorarId))
            ->first();
    }
}
