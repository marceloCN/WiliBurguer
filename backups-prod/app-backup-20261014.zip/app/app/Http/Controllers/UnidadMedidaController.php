<?php

namespace App\Http\Controllers;

use App\Models\UnidadMedida;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UnidadMedidaController extends Controller
{
    public const TIPOS = ['UNIDAD', 'PESO', 'VOLUMEN'];

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:50'],
            'abreviatura' => ['required', 'string', 'max:10'],
            'tipo' => ['required', Rule::in(self::TIPOS)],
        ]);

        if ($this->existeAbreviatura($validated['abreviatura'])) {
            return back()->withInput()->with('error', 'Ya existe una unidad de medida con esa abreviatura.');
        }

        $unidad = UnidadMedida::create([
            'nombre' => mb_trim($validated['nombre']),
            'abreviatura' => mb_strtoupper($validated['abreviatura']),
            'tipo' => $validated['tipo'],
            'estado' => true,
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'unidadmedida', $unidad->id, '330');

        return redirect()->route('dashboard.insumos.index')
            ->with('exito', "Unidad de medida {$unidad->nombre} creada.");
    }

    public function update(Request $request, UnidadMedida $unidad): RedirectResponse
    {
        $validated = $request->validate([
            'nombre' => ['required', 'string', 'max:50'],
            'abreviatura' => ['required', 'string', 'max:10'],
            'tipo' => ['required', Rule::in(self::TIPOS)],
        ]);

        if ($this->existeAbreviatura($validated['abreviatura'], $unidad->id)) {
            return back()->withInput()->with('error', 'Ya existe una unidad de medida con esa abreviatura.');
        }

        $unidad->update([
            'nombre' => mb_trim($validated['nombre']),
            'abreviatura' => mb_strtoupper($validated['abreviatura']),
            'tipo' => $validated['tipo'],
        ]);

        $this->registrarAccion(auth()->user()->empleado->id, 'UPDATE', 'unidadmedida', $unidad->id, '331');

        return back()->with('exito', "Unidad de medida {$unidad->nombre} actualizada.");
    }

    public function baja(UnidadMedida $unidad): RedirectResponse
    {
        if ($this->unidadEnUso($unidad->id)) {
            return back()->with('error', "No puedes dar de baja la unidad {$unidad->nombre}: está usada por insumos.");
        }

        $unidad->update(['estado' => false]);

        $this->registrarAccion(auth()->user()->empleado->id, 'DELETE', 'unidadmedida', $unidad->id, '335');

        return back()->with('exito', "Unidad de medida {$unidad->nombre} dada de baja.");
    }

    public function reactivar(UnidadMedida $unidad): RedirectResponse
    {
        if ($unidad->estado) {
            return back()->with('info', "La unidad de medida {$unidad->nombre} ya está activa.");
        }

        $unidad->update(['estado' => true]);

        $this->registrarAccion(auth()->user()->empleado->id, 'CREATE', 'unidadmedida', $unidad->id, '330');

        return back()->with('exito', "Unidad de medida {$unidad->nombre} reactivada.");
    }

    private function existeAbreviatura(string $abreviatura, ?int $ignorarId = null): bool
    {
        return UnidadMedida::whereRaw('LOWER(abreviatura) = ?', [mb_strtolower($abreviatura)])
            ->when($ignorarId, fn ($query) => $query->where('id', '!=', $ignorarId))
            ->exists();
    }

    private function unidadEnUso(int $idUnidad): bool
    {
        return \App\Models\Insumo::where('idunidadmedida', $idUnidad)->exists();
    }
}