@extends('layouts.app')

@section('title', 'Caja y jornadas · '.$configuracionSitio->get('SITIO_NOMBRE'))

@section('content')
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h1 class="h3 fw-bold mb-0">Caja y jornadas 🔐</h1>
                <p class="text-muted mb-0">Abre la caja, registra movimientos y cierra la jornada.</p>
            </div>
        </div>

        @include('partials.mensajes')

        <p class="small text-muted mb-3">
            Cada <strong>apertura</strong> abre una jornada: no puede haber dos jornadas abiertas en la misma caja.
            Al abrirla se genera automáticamente un <strong>cierre provisional</strong>. Durante la jornada se registran
            los <strong>movimientos</strong> (ingresos y egresos) y, al final, se registra el <strong>cierre</strong>
            indicando el efectivo contado; el sistema calcula el efectivo esperado y la diferencia con los pagos y
            movimientos de la jornada.
        </p>

        <div class="row g-4">
            {{-- ================= Columna izquierda: SUCURSAL ================= --}}
            <div class="col-12 col-lg-4">
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Sucursal</span>
                        <span class="badge text-bg-dark">{{ $sucursales->count() }}</span>
                    </div>
                    <div class="list-group">
                        @foreach ($sucursales as $sucursal)
                            <a href="{{ route('dashboard.caja.index', ['idsucursal' => $sucursal->id]) }}"
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                      {{ $sucursalActual->id === $sucursal->id ? 'active' : '' }}">
                                <span class="fw-semibold">{{ $sucursal->nombre }}</span>
                                @if ($apertura && $sucursalActual->id === $sucursal->id)
                                    <span class="badge rounded-pill text-bg-success">Abierta</span>
                                @elseif (!$sucursal->estado)
                                    <span class="badge rounded-pill text-bg-secondary">Inactiva</span>
                                @endif
                            </a>
                        @endforeach
                    </div>
                </div>

                <div class="card tarjeta-producto">
                    <div class="card-header bg-light">
                        <span class="fw-bold">Cajas de {{ $sucursalActual->nombre }}</span>
                    </div>
                    <div class="list-group">
                        @forelse ($cajas as $caja)
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span class="fw-semibold">{{ $caja->nombre }}</span>
                                <span class="badge rounded-pill {{ $caja->activo ? 'text-bg-success' : 'text-bg-secondary' }}">
                                    {{ $caja->activo ? 'Activa' : 'Inactiva' }}
                                </span>
                            </div>
                        @empty
                            <div class="list-group-item text-center text-muted py-4">
                                No hay cajas registradas en esta sucursal.
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>

            {{-- ================= Columna derecha: JORNADA ================= --}}
            <div class="col-12 col-lg-8">
                <div class="d-flex align-items-center gap-2 mb-3 flex-wrap">
                    <span class="badge text-bg-brand">{{ $sucursalActual->nombre }}</span>
                    @if ($apertura)
                        <span class="badge text-bg-success">Jornada abierta</span>
                    @else
                        <span class="badge text-bg-secondary">Sin jornada abierta</span>
                    @endif
                </div>

                {{-- ---------- Apertura ---------- --}}
                <div class="card tarjeta-producto mb-4">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <span class="fw-bold">🔓 Apertura de caja</span>
                        @if ($apertura)
                            <span class="badge text-bg-success">ABIERTA</span>
                        @endif
                    </div>
                    <div class="card-body">
                        @if (! $apertura)
                            @if ($cajas->where('activo', true)->isEmpty())
                                <div class="alert alert-warning mb-0">
                                    No hay cajas <strong>activas</strong> en {{ $sucursalActual->nombre }}. Un
                                    administrador debe crearlas o reactivarlas desde «Sucursales».
                                </div>
                            @elseif ($puedeAbrir)
                                <form method="POST" action="{{ route('dashboard.caja.apertura.store') }}" class="row g-3 align-items-end">
                                    @csrf
                                    <input type="hidden" name="idsucursal" value="{{ $sucursalActual->id }}">
                                    <div class="col-12 col-md-5">
                                        <label class="form-label">Caja *</label>
                                        <select name="idcaja" class="form-select" required>
                                            @foreach ($cajas->where('activo', true) as $caja)
                                                <option value="{{ $caja->id }}">{{ $caja->nombre }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <label class="form-label">Fondo inicial (Bs.) *</label>
                                        <input type="number" name="montoinicial" class="form-control"
                                               min="0" step="0.01" max="99999999.99" required placeholder="0.00">
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <button type="submit" class="btn btn-brand w-100">Abrir caja</button>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-text">Al abrir la jornada se genera automáticamente su cierre provisional.</div>
                                    </div>
                                </form>
                            @else
                                <div class="alert alert-info mb-0">
                                    No hay una jornada abierta. Un cajero o gerente debe abrir la caja para operar.
                                </div>
                            @endif
                        @else
                            <div class="row g-3 mb-3">
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Caja</div>
                                    <div class="fw-semibold">{{ $apertura->caja?->nombre }}</div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Fondo inicial</div>
                                    <div class="fw-semibold">Bs. {{ number_format($apertura->montoinicial, 2) }}</div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Abierta el</div>
                                    <div class="fw-semibold">{{ $apertura->fechaapertura?->format('d/m/Y H:i') }}</div>
                                </div>
                                <div class="col-6 col-md-3">
                                    <div class="text-muted small">Aperturada por</div>
                                    <div class="fw-semibold">{{ $apertura->empleado?->nombre }} {{ $apertura->empleado?->apellido }}</div>
                                </div>
                            </div>

                            @php $cierre = $apertura->cierreCaja; @endphp
                            @if ($cierre)
                                <div class="alert alert-light border small mb-3">
                                    Cierre provisional generado · Efectivo esperado actual:
                                    <strong>Bs. {{ number_format($cierre->efectivoesperado, 2) }}</strong>
                                </div>
                            @endif

                            <div class="d-flex gap-2 flex-wrap">
                                @if ($puedeEditarApertura)
                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                            data-bs-toggle="modal" data-bs-target="#editarAperturaModal"
                                            data-id="{{ $apertura->id }}"
                                            data-caja="{{ $apertura->caja?->nombre }}"
                                            data-monto="{{ $apertura->montoinicial }}">
                                        Editar fondo inicial
                                    </button>
                                @endif
                                @if ($puedeBajaApertura)
                                    <form method="POST" action="{{ route('dashboard.caja.apertura.baja', $apertura) }}"
                                          onsubmit="return confirm('¿Anular la jornada abierta? Solo es posible si no tiene pagos aprobados.')">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Dar de baja apertura</button>
                                    </form>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>

                @if ($apertura)
                    {{-- ---------- Movimientos ---------- --}}
                    <div class="card tarjeta-producto mb-4">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <span class="fw-bold">💸 Movimientos de caja</span>
                            <span class="badge text-bg-dark">{{ $movimientos->count() }}</span>
                        </div>
                        <div class="card-body">
                            @if ($puedeRegistrarMovimiento)
                                <form method="POST" action="{{ route('dashboard.caja.movimiento.store', $apertura) }}"
                                      class="row g-2 align-items-end mb-3">
                                    @csrf
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small">Tipo *</label>
                                        <select name="tipomovimiento" class="form-select form-select-sm" required>
                                            <option value="INGRESO">Ingreso</option>
                                            <option value="EGRESO">Egreso</option>
                                        </select>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <label class="form-label small">Concepto *</label>
                                        <input type="text" name="concepto" class="form-control form-control-sm" maxlength="150" required
                                               placeholder="Ej.: compra de hielo">
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <label class="form-label small">Monto (Bs.) *</label>
                                        <input type="number" name="monto" class="form-control form-control-sm"
                                               min="0.01" step="0.01" max="99999999.99" required placeholder="0.00">
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <label class="form-label small">Observación</label>
                                        <input type="text" name="observacion" class="form-control form-control-sm" maxlength="250">
                                    </div>
                                    <div class="col-6 col-md-2">
                                        <button type="submit" class="btn btn-sm btn-brand w-100">Registrar</button>
                                    </div>
                                </form>
                            @endif

                            @if ($movimientos->isEmpty())
                                <p class="text-muted text-center py-3 mb-0">Aún no hay movimientos en esta jornada.</p>
                            @else
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Fecha</th>
                                                <th>Tipo</th>
                                                <th>Concepto</th>
                                                <th class="text-end">Monto</th>
                                                <th>Registró</th>
                                                <th class="text-end">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($movimientos as $movimiento)
                                                <tr>
                                                    <td class="small text-muted">{{ $movimiento->fechamovimiento?->format('d/m/Y H:i') }}</td>
                                                    <td>
                                                        <span class="badge {{ $movimiento->tipomovimiento === 'INGRESO' ? 'text-bg-success' : 'text-bg-danger' }}">
                                                            {{ $movimiento->tipomovimiento }}
                                                        </span>
                                                    </td>
                                                    <td>
                                                        {{ $movimiento->concepto }}
                                                        @if ($movimiento->observacion)
                                                            <div class="small text-muted">{{ $movimiento->observacion }}</div>
                                                        @endif
                                                    </td>
                                                    <td class="text-end fw-semibold {{ $movimiento->tipomovimiento === 'INGRESO' ? 'text-success' : 'text-danger' }}">
                                                        {{ $movimiento->tipomovimiento === 'INGRESO' ? '+' : '-' }} Bs. {{ number_format($movimiento->monto, 2) }}
                                                    </td>
                                                    <td class="small text-muted">{{ $movimiento->empleado?->nombre }} {{ $movimiento->empleado?->apellido }}</td>
                                                    <td class="text-end">
                                                        <div class="d-flex gap-1 justify-content-end">
                                                            @if ($puedeEditarMovimiento)
                                                                <button type="button" class="btn btn-sm btn-outline-primary"
                                                                        data-bs-toggle="modal" data-bs-target="#editarMovimientoModal"
                                                                        data-id="{{ $movimiento->id }}"
                                                                        data-tipo="{{ $movimiento->tipomovimiento }}"
                                                                        data-concepto="{{ $movimiento->concepto }}"
                                                                        data-monto="{{ $movimiento->monto }}"
                                                                        data-observacion="{{ $movimiento->observacion }}">
                                                                    Editar
                                                                </button>
                                                            @endif
                                                            @if ($puedeBajaMovimiento)
                                                                <form method="POST" action="{{ route('dashboard.caja.movimiento.baja', $movimiento) }}"
                                                                      onsubmit="return confirm('¿Eliminar este movimiento?')">
                                                                    @csrf
                                                                    <button type="submit" class="btn btn-sm btn-outline-danger">Baja</button>
                                                                </form>
                                                            @endif
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @endif
                        </div>
                    </div>

                    {{-- ---------- Cierre ---------- --}}
                    @if ($puedeCerrar && $apertura)
                        @php $cierreActual = $apertura->cierreCaja; @endphp
                        <div class="card tarjeta-producto mb-4">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <span class="fw-bold">🔒 Cierre de caja</span>
                                @if ($cierreActual)
                                    <span class="badge {{ (float) $cierreActual->diferencia == 0 ? 'text-bg-success' : ((float) $cierreActual->diferencia > 0 ? 'text-bg-warning' : 'text-bg-secondary') }}">
                                        Esperado Bs. {{ number_format($cierreActual->efectivoesperado, 2) }}
                                    </span>
                                @endif
                            </div>
                            <div class="card-body">
                                @if ($cierreActual)
                                    <div class="row g-2 small mb-3">
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Total ventas</div>
                                            <div class="fw-semibold">Bs. {{ number_format($cierreActual->totalventas, 2) }}</div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Ingresos</div>
                                            <div class="fw-semibold text-success">+ Bs. {{ number_format($cierreActual->totalingresos, 2) }}</div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Egresos</div>
                                            <div class="fw-semibold text-danger">- Bs. {{ number_format($cierreActual->totalegresos, 2) }}</div>
                                        </div>
                                        <div class="col-6 col-md-3">
                                            <div class="text-muted">Efectivo esperado</div>
                                            <div class="fw-semibold">Bs. {{ number_format($cierreActual->efectivoesperado, 2) }}</div>
                                        </div>
                                    </div>
                                @endif
                                <button type="button" class="btn btn-dark w-100" data-bs-toggle="modal" data-bs-target="#modalCerrarCaja">
                                    ⚠️ Cerrar caja
                                </button>
                            </div>
                        </div>

                        {{-- Modal de cierre --}}
                        <div class="modal fade" id="modalCerrarCaja" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <form method="POST" action="{{ route('dashboard.caja.cerrar', $apertura) }}" id="formCerrarCaja" class="modal-content border-0 shadow">
                                    @csrf
                                    <div class="modal-header bg-dark text-white">
                                        <h5 class="modal-title fw-bold">🔒 Cierre de caja</h5>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                                    </div>
                                    <div class="modal-body">
                                        @if ($cierreActual)
                                            <div class="alert alert-light border mb-3">
                                                <div class="row g-2 small text-center">
                                                    <div class="col-6">
                                                        <div class="text-muted">Ventas</div>
                                                        <div class="fw-semibold">Bs. {{ number_format($cierreActual->totalventas, 2) }}</div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Ingresos</div>
                                                        <div class="fw-semibold text-success">+ Bs. {{ number_format($cierreActual->totalingresos, 2) }}</div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Egresos</div>
                                                        <div class="fw-semibold text-danger">- Bs. {{ number_format($cierreActual->totalegresos, 2) }}</div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="text-muted">Esperado</div>
                                                        <div class="fw-semibold">Bs. {{ number_format($cierreActual->efectivoesperado, 2) }}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif

                                        <div class="mb-3">
                                            <label class="form-label fw-semibold">Efectivo contado (Bs.) *</label>
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-text">Bs.</span>
                                                <input type="number" name="efectivocontado" id="cerrarEfectivoContado" class="form-control"
                                                       min="0" step="0.01" max="99999999.99" required placeholder="0.00"
                                                       value="{{ $cierreActual?->efectivoesperado ?? '' }}"
                                                       data-esperado="{{ $cierreActual?->efectivoesperado ?? 0 }}">
                                            </div>
                                            <div class="form-text">Ingresa el dinero real que hay en caja.</div>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Observación</label>
                                            <input type="text" name="observacion" class="form-control" maxlength="250" placeholder="Opcional">
                                        </div>

                                        @if ($cierreActual)
                                            <div class="card border-0 bg-light">
                                                <div class="card-body py-2">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <span class="fw-semibold">Diferencia</span>
                                                        <span id="cerrarDiferencia" class="fs-5 fw-bold">Bs. 0.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="modal-footer bg-light">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-dark" id="btnConfirmarCierre">
                                            Confirmar cierre
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    @endif
                @endif

                {{-- ---------- Acceso al historial de cierres ---------- --}}
                @if ($puedeHistorialCierres)
                    <div class="card tarjeta-producto">
                        <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div>
                                <span class="fw-bold d-block">📑 Historial de cierres</span>
                                <small class="text-muted">Consulta y exporta a PDF los cierres por día o rango de fechas.</small>
                            </div>
                            <a href="{{ route('dashboard.caja.historial', ['idsucursal' => $sucursalActual->id]) }}"
                               class="btn btn-dark">
                                Ver historial
                            </a>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- ================= Modal editar fondo inicial (permiso 411) ================= --}}
    @if ($apertura && $puedeEditarApertura)
    <div class="modal fade" id="editarAperturaModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-editar-apertura" class="modal-content border-0 shadow">
                @csrf
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar fondo inicial</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label">Caja</label>
                    <input type="text" id="editarAperturaCaja" class="form-control" readonly disabled>
                    <div class="mt-3">
                        <label class="form-label">Fondo inicial (Bs.) *</label>
                        <input type="number" name="montoinicial" id="editarAperturaMonto" class="form-control"
                               min="0" step="0.01" max="99999999.99" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    @endif

    {{-- ================= Modal editar movimiento (permiso 421) ================= --}}
    @if ($apertura && $puedeEditarMovimiento)
    <div class="modal fade" id="editarMovimientoModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <form method="POST" id="form-editar-movimiento" class="modal-content border-0 shadow">
                @csrf
                <div class="modal-header bg-light">
                    <h5 class="modal-title fw-bold">Editar movimiento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Tipo *</label>
                            <select name="tipomovimiento" id="editarMovTipo" class="form-select" required>
                                <option value="INGRESO">Ingreso</option>
                                <option value="EGRESO">Egreso</option>
                            </select>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Monto (Bs.) *</label>
                            <input type="number" name="monto" id="editarMovMonto" class="form-control"
                                   min="0.01" step="0.01" max="99999999.99" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Concepto *</label>
                            <input type="text" name="concepto" id="editarMovConcepto" class="form-control" maxlength="150" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observación</label>
                            <input type="text" name="observacion" id="editarMovObservacion" class="form-control" maxlength="250">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-brand">Guardar cambios</button>
                </div>
            </form>
        </div>
    </div>
    @endif

@endsection

@push('scripts')
    <script>
        @if ($apertura && $puedeEditarApertura)
        const modalEditarApertura = document.getElementById('editarAperturaModal');
        if (modalEditarApertura) {
            modalEditarApertura.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('editarAperturaCaja').value = boton.dataset.caja;
                document.getElementById('editarAperturaMonto').value = boton.dataset.monto;
                document.getElementById('form-editar-apertura').setAttribute(
                    'action',
                    '{{ route('dashboard.caja.apertura.update', ['apertura' => '__ID__']) }}'.replace('__ID__', boton.dataset.id)
                );
            });
        }
        @endif

        @if ($apertura && $puedeEditarMovimiento)
        const modalEditarMovimiento = document.getElementById('editarMovimientoModal');
        if (modalEditarMovimiento) {
            modalEditarMovimiento.addEventListener('show.bs.modal', function (evento) {
                const boton = evento.relatedTarget;
                if (!boton) return;
                document.getElementById('editarMovTipo').value = boton.dataset.tipo;
                document.getElementById('editarMovConcepto').value = boton.dataset.concepto;
                document.getElementById('editarMovMonto').value = boton.dataset.monto;
                document.getElementById('editarMovObservacion').value = boton.dataset.observacion || '';
                document.getElementById('form-editar-movimiento').setAttribute(
                    'action',
                    '{{ route('dashboard.caja.movimiento.update', ['movimiento' => '__ID__']) }}'.replace('__ID__', boton.dataset.id)
                );
            });
        }
        @endif

        @if (($cierreActual ?? null) && $puedeCerrar)
        function actualizarDiferenciaCierre() {
            const input = document.getElementById('cerrarEfectivoContado');
            const span = document.getElementById('cerrarDiferencia');
            if (!input || !span) return;

            const esperado = parseFloat(input.dataset.esperado) || 0;
            const contado = parseFloat(input.value) || 0;
            const diferencia = Math.round((contado - esperado) * 100) / 100;
            const simbolo = diferencia >= 0 ? '+' : '';

            span.textContent = 'Bs. ' + simbolo + diferencia.toFixed(2);
            span.className = 'fs-5 fw-bold ' + (diferencia === 0 ? 'text-success' : (diferencia > 0 ? 'text-warning' : 'text-danger'));
        }

        const cerrarEfectivoContado = document.getElementById('cerrarEfectivoContado');
        if (cerrarEfectivoContado) {
            cerrarEfectivoContado.addEventListener('input', actualizarDiferenciaCierre);
            actualizarDiferenciaCierre();

            const modalCerrarCaja = document.getElementById('modalCerrarCaja');
            if (modalCerrarCaja) {
                modalCerrarCaja.addEventListener('shown.bs.modal', actualizarDiferenciaCierre);
            }
        }
        @endif

    </script>
@endpush