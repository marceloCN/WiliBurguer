-- Procedimiento almacenado: registrar_acceso
-- Replica el comportamiento de \App\Http\Controllers\LoginController::registrarAcceso
-- (inserción en bitacoraacceso con usuario y resultado), y lo usan store() y destroy()
-- a través del método registrarAcceso() del controlador.
--
-- Nota: SOLO PostgreSQL (CREATE PROCEDURE, PostgreSQL >= 11). No debe usarse
-- como migración porque las pruebas corren sobre SQLite (:memory:).

CREATE OR REPLACE PROCEDURE registrar_acceso(
    p_id_empleado INTEGER,
    p_tipo_acceso VARCHAR(20),
    p_equipo VARCHAR(100),
    p_ip VARCHAR(45),
    p_resultado VARCHAR(20),
    p_detalle VARCHAR(255)
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO bitacoraacceso (idempleado, tipoacceso, equipo, ip, resultado, detalle)
    VALUES (
        p_id_empleado,
        p_tipo_acceso,
        p_equipo,
        p_ip,
        p_resultado,
        LEFT(p_detalle, 255)
    );
END;
$$;